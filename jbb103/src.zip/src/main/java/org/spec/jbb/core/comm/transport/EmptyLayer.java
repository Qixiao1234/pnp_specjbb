/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport;

public class EmptyLayer implements Layer<Data, Data> {
    @Override
    public Data convertDown(Data topInstance) {
        return topInstance;
    }

    @Override
    public Data convertUp(Data bottomInstance) {
        return bottomInstance;
    }
}
