/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.response;

import org.spec.jbb.core.tx.response.PartialOkResponse;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class NoDataForDataMiningResponse extends PartialOkResponse {

    private static final long serialVersionUID = 4093497746403407858L;

    @Override
    public String toString() {
        return "Not enough data for datamining";
    }

}
