/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

import org.spec.jbb.util.InstanceFactory;

import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentCreateHashMap<K, V> extends ConcurrentHashMap<K, V> implements CreateMap<K, V>{

    private static final long serialVersionUID = -4996404600961895798L;
    private final InstanceFactory<V> factory;

    public ConcurrentCreateHashMap(InstanceFactory<V> factory) {
        this.factory = factory;
    }

    @Override
    public V getOrCreate(Object key) {
        V v = super.get(key);
        if (v == null) {
            V instance = factory.getInstance();
            V prevValue = super.putIfAbsent((K)key, instance);
            v = (prevValue != null) ? prevValue : instance;
        }
        return v;
    }
}
