/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.response;

import org.spec.jbb.core.comm.AbstractResponse;
import org.spec.jbb.core.comm.Response;

import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement
public class CompositeResponse extends AbstractResponse {

    private static final long serialVersionUID = 6624511433084902174L;
    @XmlElementWrapper
    private final List<Response> responses;

    private CompositeResponse() {
        // JAXB
        this(null);
    }

    public CompositeResponse(List<Response> responses) {
        this.responses = responses;
    }

    public List<Response> getResponses() {
        return responses;
    }

    @Override
    public String toString() {
        return "CompositeResponse{" +
                "responses=" + responses +
                '}';
    }

}
