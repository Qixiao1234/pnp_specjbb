/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.purchase;

public class PurchaseItem {
    private final long barcode;
    private final int quantity;

    public PurchaseItem(long barcode, int quantity) {
        this.barcode = barcode;
        this.quantity = quantity;
    }

    public long getBarcode() {
        return barcode;
    }

    public int getQuantity() {
        return quantity;
    }
}
