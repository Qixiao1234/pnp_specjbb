/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.onlinepurchase;

import org.spec.jbb.core.collections.CollectionUtils;
import org.spec.jbb.core.collections.Mix;
import org.spec.jbb.sm.SM;
import org.spec.jbb.util.JbbProperties;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class RandomOnlinePurchaseAgent extends AbstractOnlinePurchaseAgent {

    private final Mix<OnlineType> onlineType;
    private final int probInStorePickup;

    public RandomOnlinePurchaseAgent() {
        probInStorePickup = JbbProperties.getInstance().getOnlinePurchaseInStorePickup();

        onlineType = CollectionUtils.getFixedMix(
                    new OnlineType[]{
                            OnlineType.DIFFERENT_HQ,
                            OnlineType.SAME_HQ,
                            OnlineType.SAME_SM,
                    },
                    new int[]{
                            JbbProperties.getInstance().getOnlinePurchaseOtherHQ(),
                            JbbProperties.getInstance().getOnlinePurchaseSameHQ(),
                            JbbProperties.getInstance().getOnlinePurchaseSameSM(),
                    }
            );
    }

    @Override
    public String getSM(SM sm) {
        List<String> sms = null;
        switch (onlineType.next()) {
        case SAME_SM:
            return sm.getName();
        case SAME_HQ:
            sms = sm.getSmsInSameHQ();
            break;
        case DIFFERENT_HQ:
            sms = sm.getSmsInOtherHQ();
            break;
        }
        String randomSM = CollectionUtils.getRandomElement(sms);
        return (randomSM == null) ? sm.getName() : randomSM;
    }

    @Override
    public boolean isInstorePickup() {
        return ThreadLocalRandom.current().nextInt(0, 100) <= probInStorePickup;
    }
}
