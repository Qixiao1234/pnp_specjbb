/*
 * Copyright (c) 2012-2014 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

import org.spec.jbb.core.ExecutionHandler;
import org.spec.jbb.core.comm.Incoming;
import org.spec.jbb.core.comm.Outgoing;
import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.counters.Counter;
import org.spec.jbb.core.counters.CounterFactory;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.probe.ProbeFactory;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.core.tx.response.ErrorResponse;
import org.spec.jbb.core.tx.response.FailedTransactionResponse;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.core.tx.response.PartialOkResponse;
import org.spec.jbb.core.tx.response.NullResponse;
import org.spec.jbb.hq.tx.response.BusinessReportResponse;
import org.spec.jbb.sm.tx.request.AbstractBusinessTxInjectorRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class AbstractPool implements Pool {

    private final String poolName;
    private final Counter processedTasks;
    private final Counter passedTxInjectorTasks;
    private final Counter partialTxInjectorTasks;
    private final Counter failedTxInjectorTasks;
    protected volatile Probe probe;
    private Logger logger;

    public AbstractPool(String name) {
        poolName = name;
        logger = Logger.getLogger("org.spec.jbb." + name);
        processedTasks = CounterFactory.getCounter();
        passedTxInjectorTasks = CounterFactory.getCounter();
        partialTxInjectorTasks = CounterFactory.getCounter();
        failedTxInjectorTasks = CounterFactory.getCounter();
        probe = ProbeFactory.getDefaultProbe();
    }

    @Override
    public PoolPerfomanceData getProcessedCount() {
        return new PoolPerfomanceData(passedTxInjectorTasks.get(), partialTxInjectorTasks.get(), 
                failedTxInjectorTasks.get(), processedTasks.get());
    }

    protected List<Response> process(int tier, ExecutionHandler handler, List<? extends Incoming> batch, int from, int to) {
        List<Response> responses = new ArrayList<>();

        for (int c = from; c < to; c++) {
            responses.add((Response) processOne(tier, handler, batch.get(c)));
        }

        return responses;
    }

    protected Outgoing processOne(int tier, ExecutionHandler handler, Incoming incoming) {
        Outgoing response;

        probe.countType("requests.type", incoming);

        try {
            response = handler.execute(tier, incoming);
            if (response == null) {
                response = new NullResponse();
            }
        } catch (TransactionException e) {
            response = new FailedTransactionResponse("Transaction had failed (non-fatal)", e);
        } catch (Throwable e) {
            response = new ErrorResponse("Failed to execute", e);
            logger.log(Level.SEVERE, "Unhandled exception during execution", e);
        }
        return response;
    }

    @Override
    public void sample() {
        probe.sample("poolName", poolName);
        probe.sample("processedCount", getProcessedCount());
    }

    @Override
    public void instrument(Probe probe) {
        this.probe = probe;
    }

    /**
     * Callback when a batch starts executing
     */
    protected void onBatchStart(List<? extends Incoming> batch) {
        probe.inc("batches.started");
    }

    /**
     * Callback upon completion of a batch
     */
    protected void onBatchCompletion(List<? extends Incoming> batch, List<Response> responses) {
        probe.inc("batches.finished");

        int i = 0;
        int passed = 0;
        int partial = 0;
        int failed = 0;
        for (Incoming incoming : batch) {
            if (incoming instanceof AbstractBusinessTxInjectorRequest) {
                Response response = responses.get(i);
                if ((response instanceof OkResponse) || (response instanceof BusinessReportResponse)) {
                    passed++;
                } else if (response instanceof PartialOkResponse) {
                    partial++;
                } else {
                    failed++;
                }
            }
            i++;
        }
        passedTxInjectorTasks.inc(passed);
        partialTxInjectorTasks.inc(partial);
        failedTxInjectorTasks.inc(failed);

        processedTasks.inc(batch.size());
    }

    @Override
    public List<Response> processLocally(int tier, ExecutionHandler handler, List<? extends Incoming> requests) {
        onBatchStart(requests);
        List<Response> responses = process(tier, handler, requests, 0, requests.size());
        onBatchCompletion(requests, responses);
        return responses;
    }
}
