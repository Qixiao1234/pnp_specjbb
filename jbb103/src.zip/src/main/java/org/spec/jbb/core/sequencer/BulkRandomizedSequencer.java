/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.sequencer;

public class BulkRandomizedSequencer extends BulkGrowingSequencer {

    private static final int STRIDE_SIZE = 2011; // I like this prime number (Aleksey)
    private static final long serialVersionUID = -62594201735465300L;

    public BulkRandomizedSequencer(int regionSize) {
        super(regionSize);
    }

    @Override
    public Long next() {
        /**
         * Performs stride adjustment.
         * We want to shuffle incoming numbers to same range, without collisions.
         */
        Long v = super.next();

        long elementsInStride = ((Long.MAX_VALUE - 1) / STRIDE_SIZE);
        long stride = v / elementsInStride;
        long positionInStride = v % elementsInStride;

        return stride + positionInStride*STRIDE_SIZE;
    }

}
