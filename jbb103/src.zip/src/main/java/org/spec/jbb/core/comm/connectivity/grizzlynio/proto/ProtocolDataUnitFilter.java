/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity.grizzlynio.proto;

import org.glassfish.grizzly.Buffer;
import org.glassfish.grizzly.filterchain.AbstractCodecFilter;


public final class ProtocolDataUnitFilter extends AbstractCodecFilter<Buffer, ProtocolDataUnit> {

    public ProtocolDataUnitFilter() {
        super(new ProtocolDataUnitDecoder(), new ProtocolDataUnitEncoder());
    }

}
