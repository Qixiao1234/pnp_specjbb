/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.tx.request.MoveInInventoryMessage;

public class MoveInInventoryTransaction extends AbstractInventoryTransaction {

    public MoveInInventoryTransaction(SM sm, MoveInInventoryMessage message, TransactionContext ctx) {
        super(sm, message.getBarcode(), message.getQuantity(), ctx);
    }

    @Override
    public Response execute() {
        moveIn(getBarcode(), getQuantity());
        return new OkResponse();
    }

    @Override
    public String toString() {
        return super.toString() + ", MOVE IN";
    }

}
