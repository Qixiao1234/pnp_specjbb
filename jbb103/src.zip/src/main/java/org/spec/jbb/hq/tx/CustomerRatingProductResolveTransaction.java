/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.request.CustomerRatingProductResolveRequest;
import org.spec.jbb.hq.tx.response.CustomerRatingProductResolveResponse;

public class CustomerRatingProductResolveTransaction extends AbstractTransaction {

    private HQ hq;
    private int rating;

    public CustomerRatingProductResolveTransaction(HQ hq,
            CustomerRatingProductResolveRequest incoming, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        this.rating = incoming.getRating();
    }

    @Override
    public Response execute() throws TransactionException {
        Long barcode = hq.getCustomerReviewRandomBarcode(rating);
        return new CustomerRatingProductResolveResponse(barcode);
    }

    @Override
    public String toString() {
        return "CustomerRatingProductResolveTx: rating={" + rating + "}";
    }

}
