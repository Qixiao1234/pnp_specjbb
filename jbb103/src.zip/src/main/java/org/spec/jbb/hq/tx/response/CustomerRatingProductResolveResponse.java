/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.response;

import org.spec.jbb.core.comm.AbstractResponse;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class CustomerRatingProductResolveResponse extends AbstractResponse {

    private static final long serialVersionUID = -7796514522247156394L;
    @XmlElement
    private final Long barcode;

    @SuppressWarnings("unused")
    private CustomerRatingProductResolveResponse() {
        // JAXB
        this(null);
    }

    public CustomerRatingProductResolveResponse(Long barcode) {
        this.barcode = barcode;
    }

    public Long getBarcode() {
        return barcode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        CustomerRatingProductResolveResponse that = (CustomerRatingProductResolveResponse) o;

        if (barcode != null ? !barcode.equals(that.barcode) : that.barcode != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), barcode);
    }
    
    @Override
    public String toString() {
        return "Rating Product resolved: barcode={" + barcode + "}";
    }

}
