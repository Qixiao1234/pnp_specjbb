/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.collections.BinaryFunction;
import org.spec.jbb.core.collections.CollectionUtils;
import org.spec.jbb.core.collections.HashMultiSet;
import org.spec.jbb.core.collections.MultiSet;
import org.spec.jbb.core.collections.UpdateHashMap;
import org.spec.jbb.core.collections.UpdateMap;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.db.DataMiningCursor;
import org.spec.jbb.hq.entity.Receipt;
import org.spec.jbb.hq.entity.ReceiptLine;
import org.spec.jbb.hq.entity.SMBusinessReport;
import org.spec.jbb.sm.coupon.GenericCoupon;
import org.spec.jbb.sp.Invoice;
import org.spec.jbb.util.InstanceFactory;
import org.spec.jbb.util.JbbProperties;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;


public class SupermarketAudit {

    private long totalReceipts;
    private BigDecimal cashFlowIn;
    private long totalQuantityOfItemsPurchasedByLine;
    private long totalSpecificCoupons;
    private long totalUniqueItemsPurchasedPerReceipt;
    private long totalGenericCouponsRedeemed;
    private BigDecimal customerSavingsFromGenericCoupons;

    private HQ hq;
    private String smName;

    private MultiSet<Long> productQuantities;
    private UpdateMap<Long, BigDecimal> customerSpendingMap;
    private MultiSet<Long> productReplenishes;


    private static final BinaryFunction<BigDecimal> BD_SUM_FUNCTION = new BinaryFunction<BigDecimal>() {
        @Override
        public BigDecimal apply(BigDecimal v1, BigDecimal v2) {
            return v1.add(v2);
        }
    };

    public SupermarketAudit(HQ hq, String smName) {
        this.smName = smName;
        this.hq = hq;

        cashFlowIn = BigDecimal.ZERO;
        customerSavingsFromGenericCoupons = BigDecimal.ZERO;

        productQuantities = new HashMultiSet<> ();

        customerSpendingMap = new UpdateHashMap<>(new InstanceFactory<BigDecimal>() {
            private static final long serialVersionUID = 6946188371826393278L;

            public BigDecimal getInstance() {
                return BigDecimal.ZERO;
            }
        });

        productReplenishes = new HashMultiSet<>();

    }

    public SMBusinessReport generate() {

        return collect() ? analyze() : null;
    }

    private boolean collect() {

        DataMiningCursor<Receipt> receiptData = hq.getDataMiningManager().receiptsCursor(smName);

        /**
         * It is fine to proceed without invoice data because that simply means the SM never had to replenish
         * its inventory in this period.
         */
        if (!receiptData.hasNext()) {
            return false;
        }

        while (receiptData.hasNext()) {
            Receipt receipt = receiptData.next();
            summarizeReceipt(receipt);
        }

        DataMiningCursor<Invoice> invoiceData =
            hq.getDataMiningManager().invoicesCursor(smName);

        while (invoiceData.hasNext()) {
            Invoice invoice = invoiceData.next();
            summarizeInvoice(invoice);
        }

        return true;
    }

    private SMBusinessReport analyze() {

        /**
         * Reduction to compute average amount spent per customer
         */
        Collection<BigDecimal> customerSpendingAmounts = customerSpendingMap.values();
        long totalUniqueCustomers = customerSpendingAmounts.size();

        BigDecimal totalSpent = BigDecimal.ZERO;
        for (BigDecimal amount : customerSpendingAmounts) {
            totalSpent = totalSpent.add(amount);
        }

        BigDecimal averageSpendingPerCustomer =
            totalSpent.divide(BigDecimal.valueOf(totalUniqueCustomers), 2, BigDecimal.ROUND_HALF_EVEN);

        /**
         * Average store visits per customer.
         */
        double averageVisitsPerCustomer = (double)totalReceipts / (double)totalUniqueCustomers;

        /**
         * Bottom 'n' least popular products sold.
         */
        List<Long> worstSellingProducts = new ArrayList<>(
                CollectionUtils.head(CollectionUtils.elementsAsList(productQuantities),
                        JbbProperties.getInstance().getDataMiningLeastPopularProductsCount()));
        /**
         * Top 'n' products replenished in this SM
         */

        List<Long> topReplenishedProducts = new ArrayList<>(
                CollectionUtils.tail(CollectionUtils.elementsAsList(productReplenishes),
                        JbbProperties.getInstance().getDataMiningTopReplenishedProductsCount()));

        long totalUniqueProductsPurchased = productQuantities.elementSet().size();
        long averageUniquePurchasesPerVisit = totalUniqueItemsPurchasedPerReceipt / totalReceipts;
        long averagePurchasesPerVisit = totalQuantityOfItemsPurchasedByLine / totalReceipts;
        long totalProductsReplenished = productReplenishes.elementSet().size();
                
        return new SMBusinessReport(totalReceipts,
            totalQuantityOfItemsPurchasedByLine,
            totalUniqueItemsPurchasedPerReceipt,
            totalGenericCouponsRedeemed,
            totalSpecificCoupons,
            totalUniqueCustomers,
            totalUniqueProductsPurchased,
            averageUniquePurchasesPerVisit,
            averagePurchasesPerVisit,
            totalProductsReplenished,
            averageVisitsPerCustomer,
            averageSpendingPerCustomer,
            customerSavingsFromGenericCoupons,
            cashFlowIn,
            smName,
            topReplenishedProducts,
            worstSellingProducts);
    }


    private void summarizeReceipt(Receipt receipt) {

        totalReceipts++;

        cashFlowIn = cashFlowIn.add(receipt.getTotal());

        long customerId = receipt.getCustomerId();

        for (ReceiptLine rl : receipt.getReceiptLines()) {
            totalQuantityOfItemsPurchasedByLine += rl.getQuantity();
            if (rl.getSpecificCoupon() != null) {
                totalSpecificCoupons++;
            }

            productQuantities.add(rl.getBarcode(), rl.getQuantity());
        }

        customerSpendingMap.update(customerId, receipt.getTotal(), BD_SUM_FUNCTION);
        totalUniqueItemsPurchasedPerReceipt += receipt.getAllBarcodes().size();

        GenericCoupon coupon = receipt.getGenericCoupon();
        if (coupon != null) {
            totalGenericCouponsRedeemed++;
            BigDecimal nonDiscountedPrice = receipt.getTotal().divide(coupon.getMultiplier(), 2, BigDecimal.ROUND_HALF_EVEN);
            customerSavingsFromGenericCoupons = customerSavingsFromGenericCoupons.add(nonDiscountedPrice.subtract(receipt.getTotal()));
        }

    }

    private void summarizeInvoice(Invoice invoice) {

        Collection<Long> products = invoice.getBarcodes();
        for (Long barcode : products) {
            int quantity = invoice.getQuantity(barcode);
            productReplenishes.add(barcode, quantity);
        }
    }

}
