/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.advertisement;

import org.spec.jbb.util.JbbProperties;

/**
 * The factory to create Advertisement agent Currently only one Advertisement
 * agent is supported
 */
public class AdvertisementAgentFactory {

    /**
     * Only static usage is allowed
     */
    private AdvertisementAgentFactory() {

    }

    public static AdvertisementAgent createAdvertisementAgent() {
        AdvertisementAgentType type = JbbProperties.getInstance().getAdvertisementAgentType();
        
        switch (type) {
        case BASIC:
            return new BasicAdvertisementAgent();
        case HQBASED:
            return new HQAdvertisementAgent();
        default:
            throw new UnsupportedOperationException("Failed to construct " + type + " advertisement agent");
        }
    }

}
