/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.request;

import org.spec.jbb.core.comm.AbstractMessage;
import org.spec.jbb.core.comm.transport.TransportType;
import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.InstallmentPurchaseVoidTransaction;
import org.spec.jbb.sm.InstallmentPurchase;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD) 
public class InstallmentPurchaseVoidMessage extends AbstractMessage {

    private static final long serialVersionUID = -4330638625105115644L;
    @XmlElement
    private final InstallmentPurchase installmentPurchase;
    
    @SuppressWarnings("unused")
    private InstallmentPurchaseVoidMessage(){
        // JAXB
        this(null);
    }
    
    public InstallmentPurchaseVoidMessage(
            InstallmentPurchase installmentPurchase) {
        this.installmentPurchase = installmentPurchase;
    }
    public InstallmentPurchase getInstallmentPurchase() {
        return installmentPurchase;
    }
    
     @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }

            InstallmentPurchaseVoidMessage installmentPurchaseVoidMessage = (InstallmentPurchaseVoidMessage) o;

            if (installmentPurchase != null ? !installmentPurchase.equals(installmentPurchaseVoidMessage.installmentPurchase) : installmentPurchaseVoidMessage.installmentPurchase != null) {
                return false;
            }
            return true;
        }

        @Override
        public int hashCode() {
            return Objects.hash(installmentPurchase);
        }

    @Override
    public Transaction getTransaction(HQ hq, TransactionContext ctx) {
        return new InstallmentPurchaseVoidTransaction(hq, this, ctx);
    }

    @Override
    public String toString() {
        return "Installment purchase = " + installmentPurchase;
    }

    @Override
    public TransportType getTransportHint() {
        return TransportType.SERIALIZED_ENCRYPTED;
    }

}
