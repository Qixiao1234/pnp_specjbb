/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.scheduler;

import org.spec.jbb.util.random.SpecRandom;

public interface Scheduler {

    /**
     * Register scheduled task with given delay and delay type
     * @param task task to schedule
     * @param delayRandom delay generator
     * @param delayType type
     */
    void register(ScheduledTask task, SpecRandom delayRandom, DelayType delayType);

    /**
     * Remove the task
     * @param task task to remove
     */
    void remove(ScheduledTask task);

    /**
     * Shutdown scheduler terminating all running tasks
     */
    void shutdown();

    /**
     * Enable specific task.
     * This call has no effect if task was not registered first.
     *
     * @param task task to enable
     */
    void enable(ScheduledTask task);

    /**
     * Disable specific task.
     * This call has no effect if task was not registered first, or already disabled
     *
     * @param task task to disable
     */
    void disable(ScheduledTask task);

    /**
     * Forcefully flush all the queues.
     */
    void zap();

}
