/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.request;

import org.spec.jbb.core.comm.AbstractRequest;
import org.spec.jbb.core.comm.transport.TransportType;
import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.entity.CustomerProfile;
import org.spec.jbb.hq.tx.UpdateCustomerProfileTransaction;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
public class UpdateCustomerProfileRequest extends AbstractRequest {

    private static final long serialVersionUID = -581877231916284705L;
    @XmlElement
    private final long customerId;

    @XmlElement
    private final CustomerProfile profile;
    
    private UpdateCustomerProfileRequest() {
        // JAXB
        this(0, null);
    }

    public UpdateCustomerProfileRequest(long customerId, CustomerProfile profile) {
        this.customerId = customerId;
        this.profile = profile;
    }

    public long getCustomerId() {
        return customerId;
    }

    public CustomerProfile getCustomerProfile() {
        return profile;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        UpdateCustomerProfileRequest that = (UpdateCustomerProfileRequest) o;

        if (customerId != that.customerId) {
            return false;
        }

        if (profile != null ? !profile.equals(that.profile) : that.profile != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(customerId, profile);
    }

    @Override
    public String toString() {
        return "Update profile for customer #" + customerId;
    }

    @Override
    public Transaction getTransaction(HQ hq, TransactionContext ctx) {
        return new UpdateCustomerProfileTransaction(hq, this, ctx);
    }

    @Override
    public TransportType getTransportHint() {
        return TransportType.SERIALIZED_ENCRYPTED;
    }

}
