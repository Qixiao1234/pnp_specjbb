/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.discount;

import java.io.Serializable;

/**
 * Abstract implementation of Discount keeping barcode of the product this Discount is for
 *
 */
public class AbstractDiscount implements Discount, Serializable {

    private static final long serialVersionUID = -5336544039750324326L;
    /**
     * barcode of the product this Discount is for
     */
    private final long barcode;
    
    public AbstractDiscount(long barcode) {
        this.barcode = barcode;
    }
    
    @Override
    public long getBarcode() {
        return barcode;
    }

}
