/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport.encapsulation;

import org.spec.jbb.core.collections.HashMultiMap;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;

public class JAXBAdapters {

    /**
     * JAXB adapter for HashMap instances
     * Values of the map should be understandable for JAXB 
     */
    public static class HashMapAdapter extends XmlAdapter<MapElement[], Map<Object, Object>> {
        public MapElement[] marshal(Map<Object, Object> arg0) throws Exception {
            MapElement[] mapElements = new MapElement[arg0.size()];
            int i = 0;
            for (Map.Entry<Object, Object> entry : arg0.entrySet()) {
                mapElements[i++] = new MapElement<>(entry.getKey(), entry.getValue());
            }
            return mapElements;
        }

        public Map<Object, Object> unmarshal(MapElement[] arg0) throws Exception {
            Map<Object, Object> r = new HashMap<>();
            for (MapElement mapelement : arg0) {
                r.put(mapelement.key, mapelement.value);
            }
            return r;
        }

    }
    public static class MapElement<K, V> {
        @XmlElement
        public final K key;

        @XmlElement
        public final V value;

        private MapElement() {
            // JAXB
            this(null, null);
        }

        public MapElement(K key, V value) {
            this.key = key;
            this.value = value;
        }
    }

    /**
     * JAXB adapter for HashMap instances
     * Values of the queue should be understandable for JAXB 
     */
    public static class PriorityQueueAdapter extends XmlAdapter<Object[], Queue<Object>> {
        public Object[] marshal(Queue<Object> q) throws Exception {
            return q.toArray(new Object[q.size()]);
        }

        public Queue<Object> unmarshal(Object[] obj) throws Exception {
            return new PriorityQueue<>(Arrays.asList(obj));
        }
    }

    /**
     * JAXB adapter for HashMap instances with values of the type PriorityQueue
     * Values of the PriorityQueue should be understandable for JAXB 
     */
    public static class HashMap2PriorityQueueAdapter extends XmlAdapter<MapCollectionElement[], Map<Long, PriorityQueue<Object>>> {
        @Override
        public MapCollectionElement<Long, Object>[] marshal(Map<Long, PriorityQueue<Object>> arg) throws Exception {
            MapCollectionElement<Long, Object>[] result = new MapCollectionElement[arg.size()];
            int i = 0;
            for (Map.Entry<Long, PriorityQueue<Object>> entry : arg.entrySet()) {
                result[i++] = new MapCollectionElement<>(entry.getKey(), new ArrayList<>(entry.getValue()));
            }
            return result;
        }

        @Override
        public Map<Long, PriorityQueue<Object>> unmarshal(MapCollectionElement[] arg) throws Exception {
            Map<Long, PriorityQueue<Object>> r = new HashMap<>();
            for (MapCollectionElement<Long, Object> elem : arg) {
                r.put(elem.key, new PriorityQueue<>(elem.value));
            }
            return r;
        }
    }
    
    /**
     * JAXB adapter for ConcurrentHashMap instances with values of the type PriorityQueue
     * Values of the PriorityQueue should be understandable for JAXB 
     */
    public static class ConcurrentHashMap2PriorityQueueAdapter extends XmlAdapter<MapCollectionElement[], Map<Long, PriorityQueue<Object>>> {
        @Override
        public MapCollectionElement<Long, Object>[] marshal(Map<Long, PriorityQueue<Object>> arg) throws Exception {
            MapCollectionElement<Long, Object>[] result = new MapCollectionElement[arg.size()];
            int i = 0;
            for (Map.Entry<Long, PriorityQueue<Object>> entry : arg.entrySet()) {
                result[i++] = new MapCollectionElement<>(entry.getKey(), entry.getValue());
            }
            return result;
        }

        @Override
        public Map<Long, PriorityQueue<Object>> unmarshal(MapCollectionElement[] arg) throws Exception {
            Map<Long, PriorityQueue<Object>> r = new ConcurrentHashMap<>();
            for (MapCollectionElement<Long, Object> elem : arg) {
                r.put(elem.key, new PriorityQueue<>(elem.value));
            }
            return r;
        }
    }

    public static class MultiHashMapAdapter extends XmlAdapter<MapCollectionElement[], HashMultiMap<Object, Object>> {

        @Override
        public MapCollectionElement[] marshal(HashMultiMap<Object, Object> arg) throws Exception {
            MapCollectionElement<Object, Object>[] result = new MapCollectionElement[arg.keySet().size()];
            int i = 0;
            for (Map.Entry<Object, Collection<Object>> entry : arg.asMap().entrySet()) {
                result[i++] = new MapCollectionElement<>(entry.getKey(), entry.getValue());
            }
            return result;
        }

        @Override
        public HashMultiMap<Object, Object> unmarshal(MapCollectionElement[] arg) throws Exception {
            HashMultiMap<Object, Object> result = new HashMultiMap<>();
            for (MapCollectionElement elem : arg) {
                result.putAll(elem.key, elem.value);
            }
            return result;
        }

    }

    public static class MapCollectionElement<K, V> {
        @XmlElement
        public final K key;
    
        @XmlElementWrapper
        public final Collection<V> value;

        private MapCollectionElement() {
            // JAXB
            this(null, null);
        }

        public MapCollectionElement(K key, Collection<V> value) {
            this.key = key;
            this.value = value;
        }
    }
    
}
