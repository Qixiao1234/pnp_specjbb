/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter.data;

import org.spec.jbb.core.spi.SpiFactory;
import org.spec.jbb.util.JbbProperties;

public class DataWriterFactory extends SpiFactory<DataWriterProvider> {
    public DataWriterFactory() {
        super(DataWriterProvider.class);
    }
    
    public DataWriter newDataWriter(String fileName, int compressionLevel) {
        return newDataWriter(JbbProperties.getInstance().getDataWriterProvider(), fileName, compressionLevel);
    }
    
    public DataWriter newDataWriter(String providerName, String fileName, int compressionLevel) {
        DataWriterProvider provider = get(providerName);
        return provider.newProvider(fileName, compressionLevel);
    }
}
