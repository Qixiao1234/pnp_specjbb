/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.spec.jbb.core.ComplianceTest;
import org.spec.jbb.core.collections.Pair;
import org.spec.jbb.core.comm.connectivity.ConnectivityFactory;
import org.spec.jbb.infra.Screen;
import org.spec.jbb.infra.snapshot.SnapshotManagerFactory;
import org.spec.jbb.util.ReflectionUtils;
import org.spec.jbb.util.StreamUtil;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Collection;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import org.spec.jbb.reporter.data.DataWriterFactory;

public class Environment {

    private static final String SIGNATURES_FILE = "kit-signatures";

    public static void prepare() {
        enumerateProviders();
    }

    public static void enumerateProviders() {
        ConnectivityFactory fa = new ConnectivityFactory();
        Collection<Pair<String,String>> pairs = fa.listProvidersWithDesc();
        fa.shutdown();

        Screen.println("Enumerating plugins...");
        Screen.println("   Connectivity:");
        for (Pair<String, String> pair : pairs) {
            Screen.println(String.format("    %20s: %s", pair.left, pair.right));
        }
        Screen.println("   Snapshot:");
        for (Pair<String, String> pair : new SnapshotManagerFactory().listProvidersWithDesc()) {
            Screen.println(String.format("    %20s: %s", pair.left, pair.right));
        }
        Screen.println("   Data Writers:");
        for (Pair<String, String> pair : new DataWriterFactory().listProvidersWithDesc()) {
            Screen.println(String.format("    %20s: %s", pair.left, pair.right));
        }
        Screen.println();
    }

    public static void runTests(boolean reallyDo) {
        if (reallyDo) {
            Screen.println("Running tests...");

            try {
                Collection<Class> classes = ReflectionUtils.findAllAnnotatedWith(ComplianceTest.class);
                for (Class klass : classes) {
                    Result result = JUnitCore.runClasses(klass);
                    Screen.println(String.format("  %3d tests, %3d failures, %5d msec:  %s",
                                result.getRunCount(), result.getFailureCount(), result.getRunTime(), klass.getName()));
                    if (!result.wasSuccessful()) {
                        Screen.println(klass.getName() + " had failed, terminating");
                        System.exit(1);
                    }
                }
            } catch (IOException e) {
                throw new IllegalStateException(e.getMessage(), e);
            }

            Screen.println("Tests are OK, proceeding.");
        } else {
            Screen.println("Tests are skipped.");
        }
        Screen.println();
    }
    
    private static boolean getActualSignatures(final SortedMap<String, byte[]> actual) {
        try {
            ReflectionUtils.enumerate(new ReflectionUtils.ResultCallback() {
                @Override
                public void accept(String name, byte[] contents) {
                    try {
                        MessageDigest md = MessageDigest.getInstance("SHA-1");
                        actual.put(name, md.digest(contents));
                    } catch (NoSuchAlgorithmException e) {
                        throw new IllegalStateException(e.getMessage(), e);
                    }

                }
            });
            return true;
        } catch (Throwable e) {
            Screen.println("  Exception while reading the bundle: " + e.getMessage());
            return false;
        }
    }

    public static void performKitValidation(boolean reallyDo, boolean failOnError) {

        if (!reallyDo) {
            Screen.println("Kit validation is skipped.");
            return;
        }

        Screen.println("Validating kit integrity...");

        final SortedMap<String, byte[]> actual = new TreeMap<>();
        boolean failed = !getActualSignatures(actual);

        /**
         * Load golden signatures
         */
        SortedMap<String, byte[]> golden = new TreeMap<>();

        InputStream stream = null;
        ObjectInputStream ois = null;
        try {
            stream = Thread.currentThread().getContextClassLoader().getResourceAsStream(SIGNATURES_FILE);
            if (stream != null) {
                ois = new ObjectInputStream(stream);
                Object o = ois.readObject();
                if (o instanceof SortedMap) {
                    golden = (SortedMap<String, byte[]>) o;
                }
            }
        } catch (ClassNotFoundException | IOException e) {
            Screen.println("  Exception while reading the bundle: " + e.getMessage());
            failed = true;
        } finally {
            StreamUtil.safeClose(ois);
            StreamUtil.safeClose(stream);
        }

        /**
         * Check golden against actual
         */
        SortedSet<String> names = new TreeSet<>();
        names.addAll(golden.keySet());
        names.addAll(actual.keySet());

        for (String name : names) {
            if (name.equals(SIGNATURES_FILE)) {
                continue;
            }

            byte[] gSig = golden.get(name);
            byte[] aSig = actual.get(name);

            if (gSig == null && aSig != null) {
                Screen.println("  Found file \"" + name + "\", but it is NOT expected");
                failed = true;
            } else

            if (gSig != null && aSig == null) {
                Screen.println("  Can't find file \"" + name + "\", but it is expected");
                failed = true;
            } else

            if (!Arrays.equals(aSig, gSig)) {
                Screen.println("  Signature mismatch for \"" + name + "\"");
                failed = true;
            }
        }

        if (failed) {
            Screen.println("Kit validation had failed, use -ikv to ignore.");
            if (failOnError) {
                System.exit(1);
            }
        } else {
            Screen.println("Kit validation had passed.");
        }
        Screen.println();
    }

    public static void main(String[] args) {
        final SortedMap<String, byte[]> actual = new TreeMap<>();
        if (getActualSignatures(actual)) {
            /**
             * Save golden signatures
             */
            try (
                    FileOutputStream fos = new FileOutputStream(SIGNATURES_FILE);
                    ObjectOutputStream oos = new ObjectOutputStream(fos)) {
                oos.writeObject(actual);
            } catch (IOException e) {
                Screen.println("  Exception while writing the bundle: " + e.getMessage());
            }
        }
    }
}
