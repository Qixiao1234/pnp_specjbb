/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.advertisement.AdvertisementAgent;
import org.spec.jbb.sm.advertisement.IssuedAdvertisement;
import org.spec.jbb.sm.tx.request.AdvertisementIssueRequest;
import org.spec.jbb.sm.tx.response.AdvertisementIssueResponse;

public class AdvertisementIssueTransaction extends AbstractSMTransaction {

    private final AdvertisementAgent agent;

    public AdvertisementIssueTransaction(SM sm, AdvertisementIssueRequest req, TransactionContext ctx) {
        super(sm, ctx);
        this.agent = storage.getAdvertisementAgent();
    }

    @Override
    public Response execute() {
        if(agent.reserveSlot(ctx)) {
            IssuedAdvertisement adv = IssuedAdvertisement.EMPTY;
            try {
                adv = agent.createAdvertisementBatch(ctx, sm);
                advertisements.addAdvertisements(adv);
                return new AdvertisementIssueResponse(true);
            } finally {
                agent.addIssuedAdvertisement(ctx, adv);
            }
        }
        return new AdvertisementIssueResponse(false);
    }

    @Override
    public String toString() {
        return "AdvertisementIssueTx";
    }
}
