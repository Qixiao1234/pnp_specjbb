/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport;

public enum TransportType {

    NULL(
            EncapsulationType.NULL,
            CompressionType.NONE,
            EncryptionType.NONE
    ),

    PLAIN(
            EncapsulationType.NONE,
            CompressionType.NONE,
            EncryptionType.NONE
    ),

    SERIALIZED(
            EncapsulationType.SERIALIZED,
            CompressionType.NONE,
            EncryptionType.NONE
    ),

    SERIALIZED_COMPRESSED(
            EncapsulationType.SERIALIZED,
            CompressionType.GZIP,
            EncryptionType.NONE
    ),

    SERIALIZED_ENCRYPTED(
            EncapsulationType.SERIALIZED,
            CompressionType.NONE,
            EncryptionType.AES
    ),

    SERIALIZED_COMPRESSED_ENCRYPTED(
            EncapsulationType.SERIALIZED,
            CompressionType.GZIP,
            EncryptionType.AES
    ),

    XML(
            EncapsulationType.XML_JAXB,
            CompressionType.NONE,
            EncryptionType.NONE
    ),

    XML_COMPRESSED(
            EncapsulationType.XML_JAXB,
            CompressionType.GZIP,
            EncryptionType.NONE
    ),

    XML_ENCRYPTED(
            EncapsulationType.XML_JAXB,
            CompressionType.NONE,
            EncryptionType.AES
    ),

    XML_COMPRESSED_ENCRYPTED(
            EncapsulationType.XML_JAXB,
            CompressionType.GZIP,
            EncryptionType.AES
    );

    private EncapsulationType encType;
    private CompressionType compType;
    private EncryptionType cryptType;

    TransportType(EncapsulationType encType, CompressionType compType, EncryptionType cryptType) {
        this.encType = encType;
        this.compType = compType;
        this.cryptType = cryptType;
    }

    public EncapsulationType getEncapsulationType() {
        return encType;
    }

    public EncryptionType getCryptoType() {
        return cryptType;
    }

    public CompressionType getCompressionType() {
        return compType;
    }

    public boolean isByte() {
        return encType != EncapsulationType.NONE && encType != EncapsulationType.NULL;
    }

    public enum EncapsulationType {
        NULL,
        NONE,
        SERIALIZED,
        XML_JAXB,
    }

    public enum CompressionType {
        NONE,
        GZIP,
    }

    public enum EncryptionType {
        NONE,
        AES,
        RSA,
        DES,
    }


}
