/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.response;

import org.spec.jbb.core.comm.AbstractResponse;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public final class DiscountIssueResponse extends AbstractResponse {

    private static final long serialVersionUID = -270230845693132208L;
    @XmlElement
    private final boolean result;

    private DiscountIssueResponse() {
        // JAXB
        this(false);
    }

    public DiscountIssueResponse(boolean result) {
        this.result = result;
    }

    public boolean getResult() {
        return result;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        DiscountIssueResponse that = (DiscountIssueResponse) o;

        if (result != that.result) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), result);
    }

    @Override
    public String toString() {
        return "DiscountIssueResponse{" + result + "}";
    }
    
}
