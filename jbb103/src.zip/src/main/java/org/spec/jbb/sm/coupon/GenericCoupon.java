/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.coupon;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class GenericCoupon extends AbstractCoupon {

    private static final long serialVersionUID = -2145384569916942142L;

    private GenericCoupon() {
        super();
        // JAXB constructor
    }
    
    public GenericCoupon(Date expirationDate, int percent) {
        super(expirationDate, percent);
    }

    @Override
    public String toString() {
        return "{" + super.toString() + "}";
    }

}
