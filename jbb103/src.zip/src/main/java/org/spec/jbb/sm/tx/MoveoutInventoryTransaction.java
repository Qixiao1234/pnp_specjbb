/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.tx.request.MoveoutInventoryRequest;
import org.spec.jbb.sm.tx.response.MoveoutInventoryResponse;

public final class MoveoutInventoryTransaction extends AbstractInventoryTransaction {

    public MoveoutInventoryTransaction(SM sm, MoveoutInventoryRequest request, TransactionContext ctx) {
        super(sm, request.getBarcode(), request.getQuantity(), ctx);
    }

    @Override
    public Response execute() throws TransactionException {
        int quantity = moveOut(getBarcode(), getQuantity());
        return new MoveoutInventoryResponse(getBarcode(), quantity);
    }

    @Override
    public String toString() {
        return super.toString() + ", MOVE OUT";
    }
}
