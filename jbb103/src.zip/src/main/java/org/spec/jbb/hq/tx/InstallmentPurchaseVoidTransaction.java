/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.request.InstallmentPurchaseVoidMessage;
import org.spec.jbb.hq.tx.request.InstallmentPurchaseVoidRequest;
import org.spec.jbb.sm.InstallmentPurchase;
import org.spec.jbb.util.JbbProperties;

import java.math.BigDecimal;

public class InstallmentPurchaseVoidTransaction extends AbstractTransaction {

    private final HQ hq;
    private final InstallmentPurchase installmentPurchase;

    public InstallmentPurchaseVoidTransaction(HQ hq, InstallmentPurchaseVoidRequest request, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        this.installmentPurchase = null;
    }

    public InstallmentPurchaseVoidTransaction(HQ hq,
            InstallmentPurchaseVoidMessage incoming, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        this.installmentPurchase = incoming.getInstallmentPurchase();
    }

    @Override
    public Response execute() throws TransactionException {
        if(installmentPurchase != null){
            hq.addCustomerReturnRightOffAmount(processVoid(installmentPurchase));
            return new OkResponse();
        }

        int numOfTransactionsToProcess = JbbProperties.getInstance().getNumberOfInstallmentVoidsToProcess();
        BigDecimal voidAmount = BigDecimal.ZERO;
        for (int index = 0; index < numOfTransactionsToProcess; index++){
            InstallmentPurchase tempInstallmentPurchase = hq.getNextInstallmentPurchase();
            if (tempInstallmentPurchase == null){
                break;
            }
            voidAmount = voidAmount.add(processVoid(tempInstallmentPurchase));
        }

       	hq.addCustomerReturnRightOffAmount(voidAmount);

       	return new OkResponse();
    }

    private BigDecimal processVoid(InstallmentPurchase pInstallmetPurchase) {
        //refund money back to customer
        BigDecimal voidAmount = pInstallmetPurchase.getVoidAmount();
        hq.refundCustomer(pInstallmetPurchase.getCustomerId(),  voidAmount);
        return voidAmount;
    }

    @Override
    public String toString() {
        return "InstallmentPurchaseVoidTransaction: purchase={" + installmentPurchase + "}";
    }

}
