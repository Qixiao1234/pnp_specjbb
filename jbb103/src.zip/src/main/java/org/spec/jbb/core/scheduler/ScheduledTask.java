/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.scheduler;

/**
 * Scheduled task
 */
public interface ScheduledTask {
    
    Runnable getRunTask();

    /**
     * Called when scheduler decides to disable task
     */
    void cleanup();

}
