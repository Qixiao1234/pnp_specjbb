/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.probe;

public enum ProfileMode {

    /**
     * Intrusive profiling:
     *  - gather all data, even if that can degrade performance
     */
    INTRUSIVE,

    /**
     * Non-intrusive profiling:
     *  - gather data which is not associated with performance penalty
     */
    NON_INTRUSIVE,

    /**
     * Disable any sort of profiling
     */
    DISABLED

}
