/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm;

import org.spec.jbb.core.EntityType;
import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.Topology;
import org.spec.jbb.core.cache.BoundedWriteBackCache;
import org.spec.jbb.core.cache.Connector;
import org.spec.jbb.core.cache.SoftReferenceCache;
import org.spec.jbb.core.collections.CollectionUtils;
import org.spec.jbb.core.collections.Mix;
import org.spec.jbb.core.comm.Incoming;
import org.spec.jbb.core.comm.Outgoing;
import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.executor.AbstractBatchExecutor;
import org.spec.jbb.core.onlinepurchase.OnlinePurchaseAgent;
import org.spec.jbb.core.onlinepurchase.OnlinePurchaseAgentFactory;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.probe.ProbeFactory;
import org.spec.jbb.core.purchase.PurchaseAgent;
import org.spec.jbb.core.purchase.PurchaseAgentFactory;
import org.spec.jbb.core.threadpools.Tiers;
import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.core.tx.TransactionExecutor;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.entity.CustomerProfile;
import org.spec.jbb.hq.entity.Product;
import org.spec.jbb.hq.tx.request.GetCustomerProfileRequest;
import org.spec.jbb.hq.tx.request.ProductResolveRequest;
import org.spec.jbb.hq.tx.request.ResolveCustomerRequest;
import org.spec.jbb.hq.tx.request.UpdateCustomerProfileRequest;
import org.spec.jbb.hq.tx.response.CustomerProfileResponse;
import org.spec.jbb.hq.tx.response.CustomerResolveResponse;
import org.spec.jbb.hq.tx.response.ProductResolveResponse;
import org.spec.jbb.sm.advertisement.AdvertisementAgentFactory;
import org.spec.jbb.sm.advertisement.Advertisements;
import org.spec.jbb.sm.coupon.CouponFactory;
import org.spec.jbb.sm.discount.DiscountAgentFactory;
import org.spec.jbb.sm.storage.SupermarketStorage;
import org.spec.jbb.sm.storage.SupermarketStorageImpl;
import org.spec.jbb.sm.tx.CustomerProfileException;
import org.spec.jbb.util.JbbProperties;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class SM extends AbstractBatchExecutor {

    /**
     * Supermarket storage
     */
    private final SupermarketStorage storage;

    /**
     * HQ to which this SM is bound
     */
    private final String owningHQ;

    /**
     * Customer selector
     */
    private final CustomerSelection customerSelector;

    /**
     * Purchase agent is handles in each SM
     * Its behavior can very from one SM to another due to hotness updates.
     */
    private final PurchaseAgent purchaseAgent;

    /**
     * Online purchase agent determines which SM to use for remote purchase requests
     */
    private final OnlinePurchaseAgent onlinePurchaseAgent;

    /**
     * Suppliers to replenish products from
     */
    private final Mix<Mix<String>> suppliersForReplenish;

    /**
     * new coupon generator
     */
    private final CouponFactory couponFactory;

    /*
      Topology cache
     */
    private final List<String> smsInSameHQ;
    private final List<String> smsInOtherHQ;

    /*
      JbbProperties cache
     */
    private final boolean isReplenishPercentEnabled;
    private final int specificCouponThresholdPercent;
    private final int specificCouponCountPercent;
    private final BigDecimal genericCouponThreshold;
    private final BigDecimal installmentPaymentPercent;
    private final BigDecimal installmentFee;
    private final int maxCustomerScoreBuckets;
    private final int numEditPositions;
    private final int discountHotnessShift;
    private final float orderQuantityThreshold;
    private final float passedScanPercent;

    /*
       Probes.
     */
    private volatile Probe couponProbe;
    private volatile Probe replenishProbe;

    /**
     * Creates blank Supermarket with pre-seeded values.
     * @param name supermarket name
     * @param owningHQ HQ to which this SM is bound
     */
    protected SM(String name, String owningHQ) {
        this(new Tiers(), name, owningHQ, null);
    }

    /**
     * Creates Supermarket with existing storage
     * @param tiers thread pools
     * @param name supermarket name
     * @param owningHQ HQ to which this SM is bound
     * @param storage supermarket storage
     */
    public SM(Tiers tiers, String name, final String owningHQ, SupermarketStorage storage) {
        super(EntityType.SM, name, tiers);
        this.owningHQ = owningHQ;

        customerSelector = new CustomerSelection(this);
        purchaseAgent = PurchaseAgentFactory.makePurchaseAgent();
        discountHotnessShift = JbbProperties.getInstance().getHotnessDiscount();

        Topology topology = new Topology();
        smsInSameHQ = new ArrayList<>(topology.getSMsInSameHQ(name, owningHQ));
        smsInOtherHQ = new ArrayList<>(topology.getSMsInOtherHQ(owningHQ));
        onlinePurchaseAgent = OnlinePurchaseAgentFactory.getOnlinePurchaseAgent();

        orderQuantityThreshold = JbbProperties.getInstance().getOrederQuantityThreshold() * 0.01f;
        passedScanPercent = JbbProperties.getInstance().getPassedScanPercent() * 0.01f;
        
        isReplenishPercentEnabled = JbbProperties.getInstance().isReplenishPercentEnabled();
        
        suppliersForReplenish = CollectionUtils.<Mix<String>>getFixedMix(
                new Mix[]{
                    CollectionUtils.getMix(topology.getSPforHQ(owningHQ)),
                    CollectionUtils.getMix(topology.getSPNamesRemoteForHQ(owningHQ))
                },
                new int[]{
                    JbbProperties.getInstance().getReplenishLocalPercent(),
                    (topology.getSPNamesRemoteForHQ(owningHQ).isEmpty() ? 0 :
                    100 - JbbProperties.getInstance().getReplenishLocalPercent())
                });

        specificCouponThresholdPercent = JbbProperties.getInstance().getSpecificCouponIssueThresholdPercent();
        specificCouponCountPercent = JbbProperties.getInstance().getSpecificCouponIssueCountPercent();
        genericCouponThreshold = BigDecimal.valueOf(JbbProperties.getInstance().getGenericCouponIssueThreshold());
        installmentPaymentPercent = BigDecimal.valueOf(JbbProperties.getInstance().getInstallmentPaymentPercent(), 2);
        installmentFee = BigDecimal.valueOf(JbbProperties.getInstance().getInstallmentFeeInCents(), 2);
        maxCustomerScoreBuckets = JbbProperties.getInstance().getMaxCustomerScoreBuckets();
        numEditPositions = JbbProperties.getInstance().getEditItemCount();
        
        couponProbe = ProbeFactory.getDefaultProbe();
        couponFactory = new CouponFactory();
        
        replenishProbe = ProbeFactory.getDefaultProbe();

        /**
         * Rebind storage.
         */
        if (storage == null) {
            storage = new SupermarketStorageImpl(
                SupermarketUtil.createInventory(),
                new SoftReferenceCache<TransactionContext, Long, Product>(),
                new SoftReferenceCache<TransactionContext, Long, String>(),
                new BoundedWriteBackCache<TransactionContext, Long, CustomerProfile>(customerSelector.getSize() *
                    JbbProperties.getInstance().getCustomerCacheSize() / 100),
                DiscountAgentFactory.createDiscountAgent(),
                AdvertisementAgentFactory.createAdvertisementAgent(),
                new Advertisements()
            );
        }

        /**
         * Rebind cache connector.
         */
        storage.getCustomerProfileCache().setConnector(new Connector<TransactionContext, Long, CustomerProfile>() {
            @Override
            public CustomerProfile read(TransactionContext ctx, Long key) {
                Response response = ctx.sendRequest(resolveCustomer(ctx, key), new GetCustomerProfileRequest(key));

                if (response instanceof CustomerProfileResponse) {
                    return ((CustomerProfileResponse) response).getCustomerProfile();
                }

                throw new CustomerProfileException("Unable to read customer profile");
            }

            @Override
            public void write(TransactionContext ctx, Long key, CustomerProfile value) {
                Response response = ctx.sendRequest(resolveCustomer(ctx, key),
                        new UpdateCustomerProfileRequest(key, value));

                if (!(response instanceof OkResponse)) {
                    throw new CustomerProfileException("Unable to write customer profile");
                }
            }

            @Override
            public int getPriority(TransactionContext ctx, Long key) {
                return customerSelector.getCustomerHotness(key);
            }
        });

        storage.getProductCache().setConnector(new Connector<TransactionContext, Long, Product>(){

            @Override
            public Product read(TransactionContext ctx, Long key) {
                Response response = ctx.sendRequest(owningHQ, new ProductResolveRequest(key));
                if (response instanceof ProductResolveResponse) {
                    ProductResolveResponse resp = (ProductResolveResponse) response;
                    return resp.getProduct();
                } else {
                    throw new ProductResolveFailedException("Can't resolve product, got " + response);
                }
            }

            @Override
            public void write(TransactionContext ctx, Long key, Product value) {
                throw new UnsupportedOperationException();
            }

            @Override
            public int getPriority(TransactionContext ctx, Long key) {
                throw new UnsupportedOperationException();
            }
        });

        storage.getCustomerCache().setConnector(new Connector<TransactionContext, Long, String>(){

            @Override
            public String read(TransactionContext ctx, Long key) {
                Response response = ctx.sendRequest(owningHQ, new ResolveCustomerRequest(key));
                if (response instanceof CustomerResolveResponse) {
                    return ((CustomerResolveResponse) response).getOwningHQ();
                } else {
                    throw new IllegalStateException("Can't resolve customer, got " + response);
                }
            }

            @Override
            public void write(TransactionContext ctx, Long key, String value) {
                throw new UnsupportedOperationException();
            }

            @Override
            public int getPriority(TransactionContext ctx, Long key) {
                throw new UnsupportedOperationException();
            }
        });

        this.storage = storage;
    }

    @Override
    public void sample() {
        super.sample();
        probe.sample("customers.queue", customerSelector.getSize());
        storage.sample();
        customerSelector.sample();
        if (purchaseAgent instanceof Measurable) {
            ((Measurable) purchaseAgent).sample();
        }
    }

    @Override
    public void instrument(Probe probe) {
        super.instrument(probe);
        storage.instrument(probe);

        customerSelector.instrument(probe.getChild("customerSelector"));
        storage.getInventory().instrument(probe.getChild("inventory"));
        if (purchaseAgent instanceof Measurable) {
            ((Measurable) purchaseAgent).instrument(probe.getChild("purchaseagent"));
        }
        couponProbe = probe.getChild("coupon");
        replenishProbe = probe.getChild("replenish");
    }

    @Override
    public Outgoing execute(int tier, Incoming incoming) throws TransactionException {
        TransactionExecutor executor = getTransactionExecutor();
        Transaction transaction = incoming.getTransaction(this, new TransactionContext(getLink(), tier));
        return executor.execute(transaction);
    }

    /*
       ------------ SHORTCUT METHODS ----------------
     */

    public long getNextReceiptNumber() {
        return storage.getReceiptSequencer().next();
    }

    public String resolveCustomer(TransactionContext ctx, long customerId) {
        return storage.getCustomerCache().get(ctx, customerId);
    }

    public List<String> getSmsInSameHQ() {
        return smsInSameHQ;
    }

    public List<String> getSmsInOtherHQ() {
        return smsInOtherHQ;
    }

    public PurchaseAgent getPurchaseAgent() {
        return purchaseAgent;
    }

    public OnlinePurchaseAgent getOnlinePurchaseAgent() {
        return onlinePurchaseAgent;
    }

    public CustomerSelection getCustomerSelector() {
        return customerSelector;
    }

    public CouponFactory getCouponFactory() {
        return couponFactory;
    }

    public SupermarketStorage getStorage() {
        return storage;
    }

    public Probe getReplenishProbe() {
        return replenishProbe;
    }

    public Probe getCouponProbe() {
        return couponProbe;
    }

    public String getOwningHQname() {
        return owningHQ;
    }

    public Mix<Mix<String>> getSuppliersForReplenish() {
        return suppliersForReplenish;
    }

    /*
       ------------ CACHED JBB PROPERTIES ----------------
     */

    public boolean isReplenishPercentEnabled() {
        return isReplenishPercentEnabled;
    }

    public float getOrderQuantityThreshold() {
        return orderQuantityThreshold;
    }

    public int getSpecificCouponThresholdPercent() {
        return specificCouponThresholdPercent;
    }

    public int getSpecificCouponCountPercent() {
        return specificCouponCountPercent;
    }

    public BigDecimal getGenericCouponThreshold() {
        return genericCouponThreshold;
    }

    public BigDecimal getInstallmentPaymentPercent() {
        return installmentPaymentPercent;
    }

    public BigDecimal getInstallmentFee() {
        return installmentFee;
    }

    public int getMaxCustomerScoreBuckets() {
        return maxCustomerScoreBuckets;
    }

    public int getNumEditPositions() {
        return numEditPositions;
    }


    public int getDiscountHotnessShift() {
        return discountHotnessShift;
    }

    public float getPassedScanPercent() {
        return passedScanPercent;
    }

}
