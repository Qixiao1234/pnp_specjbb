/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq;

import org.spec.jbb.core.Conventions;
import org.spec.jbb.core.EntityType;
import org.spec.jbb.core.Topology;
import org.spec.jbb.core.collections.CollectionUtils;
import org.spec.jbb.core.collections.ConcurrentCreateHashMap;
import org.spec.jbb.core.collections.CreateMap;
import org.spec.jbb.core.collections.Mix;
import org.spec.jbb.core.collections.MultiMap;
import org.spec.jbb.core.collections.sampling.SamplingBuffer;
import org.spec.jbb.core.collections.sampling.SamplingBufferFactory;
import org.spec.jbb.core.comm.Incoming;
import org.spec.jbb.core.comm.Outgoing;
import org.spec.jbb.core.counters.Counter;
import org.spec.jbb.core.counters.CounterFactory;
import org.spec.jbb.core.executor.AbstractBatchExecutor;
import org.spec.jbb.core.generator.CustomerGenerator;
import org.spec.jbb.core.generator.ProductGenerator;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.probe.ProbeFactory;
import org.spec.jbb.core.threadpools.Tiers;
import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.core.tx.TransactionExecutor;
import org.spec.jbb.hq.db.DataMiningManager;
import org.spec.jbb.hq.db.Storage;
import org.spec.jbb.hq.entity.Category;
import org.spec.jbb.hq.entity.Customer;
import org.spec.jbb.hq.entity.CustomerProfile;
import org.spec.jbb.hq.entity.HQBusinessReport;
import org.spec.jbb.hq.entity.Product;
import org.spec.jbb.hq.entity.Receipt;
import org.spec.jbb.hq.entity.ReceiptLine;
import org.spec.jbb.hq.entity.SMBusinessReport;
import org.spec.jbb.hq.tx.request.AdjustHeadQuarterInventoryMessage;
import org.spec.jbb.sm.InstallmentPurchase;
import org.spec.jbb.sm.advertisement.IssuedAdvertisement;
import org.spec.jbb.sm.entity.InStorePickupOrder;
import org.spec.jbb.sm.entity.Order;
import org.spec.jbb.sm.entity.ShippingOrder;
import org.spec.jbb.sp.Invoice;
import org.spec.jbb.util.InstanceFactory;
import org.spec.jbb.util.JbbProperties;
import org.spec.jbb.util.ThreadLocalSink;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Headquarters class.
 */
public class HQ extends AbstractBatchExecutor {

    /**
     * Storage
     */
    private final Storage storage;

    /**
     * Routing information cache
     */
    private final String orderFulfillmentName;

    private ThreadLocalSink<BigDecimal> customerReturnRightOffAmount = new ThreadLocalSink<>(BigDecimal.ZERO);

    private CreateMap<String, SamplingBuffer<IssuedAdvertisement>> suggestedAdvertisement;

    private volatile Probe dataMiningTxProbe;

    private final BigDecimal initialCreditCardLimit;

    /**
     * Mix of supermarkets for selection of random receipts.
     */   
    private final Mix<String> smNamesMix;

    /**
     * HQ statistics
     */
    private Counter numberOfReceipts;
    private Counter numberOfBarcodesInAllReceitps;

    public enum SMInventoryDirection {
        OUT,
        IN
    }

    public HQ(Tiers tiers, String name, String ofName) throws Exception {
        this(tiers, name, ofName, null);
    }

    public HQ(Tiers tiers, String name, String ofName, Storage storage) throws Exception {
        super(EntityType.HQ, name, tiers);

        this.orderFulfillmentName = ofName;

        if (storage == null) {
            this.storage = new Storage();
            populateDatabase();
        } else {
            this.storage = storage;
        }

        final int maxDataMiningResults = JbbProperties.getInstance().getMaxDataMiningResults();

        suggestedAdvertisement = new ConcurrentCreateHashMap<>(
                new InstanceFactory<SamplingBuffer<IssuedAdvertisement>>() {
                    private static final long serialVersionUID = 964936219733329963L;

                    @Override
                    public SamplingBuffer<IssuedAdvertisement> getInstance() {
                        return SamplingBufferFactory.getInstance(maxDataMiningResults);
                    }
                });

        dataMiningTxProbe = ProbeFactory.getDefaultProbe();

        initialCreditCardLimit = JbbProperties.getInstance().getInitialCreditCardLimit();
        
        smNamesMix = CollectionUtils.getMix(new Topology().getSMforHQ(name));

        numberOfReceipts = CounterFactory.getCounter();
        numberOfBarcodesInAllReceitps = CounterFactory.getCounter();
    }

    public Storage getStorage() {
        return storage;
    }

    @Override
    public Outgoing execute(int tier, Incoming incoming) throws TransactionException {
        TransactionExecutor executor = getTransactionExecutor();
        Transaction tx = incoming.getTransaction(this, new TransactionContext(getLink(), tier));
        return executor.execute(tx);
    }

    /**
     * Populate the database with products, customers, supermarkets, etc.
     *
     * @throws Exception
     */
    private void populateDatabase() {

        ProductGenerator productGenerator = new ProductGenerator();
        List<Product> products = productGenerator.generate();
        for (Product product : products) {
            storage.store(product);
        }

        CustomerGenerator customerGenerator = new CustomerGenerator();
        for (Customer customer : customerGenerator.generate()) {
            storage.storeCustomerOwner(customer.getId(), customer.getOwningHQ());
            if (customer.getOwningHQ().equalsIgnoreCase(getName())) {
                storage.store(customer);
            }
        }

        /*
         * Find all the SMs for this HQ and populate their initial inventory.
         */
        Collection<String> smNames = new Topology().getSMforGroup(Conventions.getGroupID(getName()));

        for (String sm : smNames) {
            for (Product product : products) {
                storage.adjustSupermarketInventory(sm, product.getBarcode(), product.getProductQuantity());
            }
        }

    }

    @Override
    public void instrument(Probe probe) {
        super.instrument(probe);
        dataMiningTxProbe = probe.getChild("DataMiningTx");
        storage.instrument(probe.getChild("storage"));
    }

    @Override
    public void sample() {
        super.sample();
        storage.sample();
        if (probe.shouldGoInsane()) {
            probe.sample("customers.credit", getTotalCustomerCredit());
        }
        probe.sample("processedReceipts", getStatistics());
    }

    /**
     * Add a receipt to the HQ database
     * @param receipt receipt to add
     */
    public void addReceipt(Receipt receipt) {
        storage.addReceipt(receipt);
        numberOfReceipts.inc(1);
        numberOfBarcodesInAllReceitps.inc(receipt.getAllBarcodes().size());
    }

    public HQStatistics getStatistics() {
        return new HQStatistics(numberOfReceipts.get(), numberOfBarcodesInAllReceitps.get());
    }

    public void addSupplierInvoice(Invoice invoice) {
        Queue<Invoice> invoices = storage.getInvoices();
        if (!invoices.offer(invoice)) {
            throw new IllegalStateException("Unable to add invoice");
        }
    }

    public Receipt selectRandomReceipt() {
        return storage.selectRandomReceipt(smNamesMix.next());
    }

    public Queue<Invoice> getInvoices() {
        return storage.getInvoices();
    }

    public Product findProduct(long barcode) {
        return storage.findProduct(barcode);
    }

    public DataMiningManager getDataMiningManager() {
        return storage.getDataMiningManager();
    }

    /**
     * Produce an HQ report from whatever SM reports have been accumulated so far.
     * There should always be at least one SM report from which to produce an HQ
     * report.
     */
    public HQBusinessReport generateHQReport(SMBusinessReport smReport) {

        storage.putSMReport(smReport);

        List<SMBusinessReport> smReports = new ArrayList<>(storage.getSMReports().values());
        HQBusinessReport report = new HQBusinessReport(getName(), smReports);
        report.finalizeReport();
        return report;
    }


    /**
     * Adjusts the quantity of items in a supermarket's inventory from
     * a supermarket receipt.
     *
     * @param receipt receipt to send
     * @param movement : IN or OUT
     * @param propagate true if need to notify other HQs
     */
    public void adjustSupermarketInventory(TransactionContext ctx, Receipt receipt, SMInventoryDirection movement, boolean propagate) {
        int direction = (movement == SMInventoryDirection.OUT) ? -1 : 1;

        List<String> hqToNotify = new ArrayList<>();
        MultiMap<String, ReceiptLine> map = receipt.getReceiptLinesBySM();
        for (Map.Entry<String, Collection<ReceiptLine>> entry : map.asMap().entrySet()) {
            String hqName = topology.getHQNameForSM(entry.getKey());
            if (hqName.equals(getName())){
                for (ReceiptLine line : entry.getValue()) {
                    storage.adjustSupermarketInventory(entry.getKey(), line.getBarcode(), line.getQuantity()*direction);
                }
            } else {
                if (propagate) {
                    hqToNotify.add(hqName);
                }
            }
        }

        for (String hqName : hqToNotify) {
            ctx.sendMessage(hqName, new AdjustHeadQuarterInventoryMessage(receipt, movement));
        }
    }

    /**
     * Adjusts the quantity of items in a supermarket's inventory from
     * a supplier invoice.  Assumes inventory is always moved into a
     * supermarket.
     *
     * @param invoice
     */
    public void adjustSupermarketInventory(Invoice invoice) {
        for (long barcode : invoice.getBarcodes()) {
            storage.adjustSupermarketInventory(invoice.getDestinationSupermarket(), barcode, invoice.getQuantity(barcode));
        }
    }
    
    public void refundCustomer(long customerId, BigDecimal amount) {
        storage.updateCustomerBalance(customerId, amount);
        probe.add("money.out", amount.longValue());
    }

    /*
     * Check whether there is sufficient credit on the customer's credit card for the
     * payment to proceed.  If there isn't enough credit then replenish the customer's
     * credit.  This is necessary because a customer cannot exist in the benchmark in
     * a perpetually delinquent state.  This effectively means that a customer will
     * always have enough credit for the requested purchase amount.
     */
    public boolean reserveCredit(long customerId, BigDecimal amount) {
        if (storage.getCustomerBalance(customerId).compareTo(BigDecimal.ZERO) == -1) {
            storage.updateCustomerBalance(customerId, initialCreditCardLimit);
            probe.inc("customer.replenished");
        }
        return true;
    }

    public boolean drawCredit(long customerId, BigDecimal amount) {
        storage.updateCustomerBalance(customerId, amount.negate());
        probe.add("money.in", amount.longValue());
        return true;
    }

    public BigDecimal getTotalCustomerCredit() {
        return storage.getTotalCustomerCredit();
    }

    public String getOwner(long customerId) {
        return storage.getCustomerOwner(customerId);
    }
    
    public void add(InstallmentPurchase installmentPurchase) {
        storage.putToQueue(installmentPurchase);
    }
            
    public InstallmentPurchase getNextInstallmentPurchase(){
        return storage.getNextInstallmentPurchase();
    }

    public long getInstallmentPurchaseQueueSize(){
        return storage.getInstallmentQueueSize();
    }
       
    public CustomerProfile getCustomerProfile(long id) {
        return storage.getCustomerProfile(id);
    }

    public void updateCustomerProfile(long id, CustomerProfile profile) {
        storage.updateCustomerProfile(id, profile);
    }

    public void addOrder(Order order) {
        storage.putToQueue(order);
    }

    public InStorePickupOrder getNextInStorePickup() {
        return storage.getNextInStorePickup();
    }

    public ShippingOrder getNextShippingOrder() {
        return storage.getNextShippingOrder();
    }

    public void setCustomerReviewScore(long barcode, int score) {
        storage.setCustomerReviewScore(barcode, score);
    }

    public int getCustomerReviewScore(long barcode) {
        return storage.getCustomerReviewScore(barcode);
    }

    public Long getCustomerReviewRandomBarcode(int reviewScore) {
        return storage.getCustomerReviewRandomBarcode(reviewScore);
    }

    public String getCustomerZipCode(long customerId) {
        Customer customer = storage.findCustomer(customerId);
        if (customer != null && customer.getAddress() != null) {
            return customer.getAddress().getZip();
        }
        return null;
    }

    public String getOrderFulfillmentName() {
        return orderFulfillmentName;
    }

    public long getOnlinePurchaseShippingQueueSize() {
        return storage.getOnlinePurchaseShippingQueueSize();
     }
 
    public long getOnlinePurchaseInstorePickupQueueSize() {
        return storage.getOnlinePurchaseInstorePickupQueueSize();
    }

    public void addCustomerReturnRightOffAmount(BigDecimal amount) {
        BigDecimal currentAmount = customerReturnRightOffAmount.get();
        BigDecimal newAmount = currentAmount.add(amount);
        customerReturnRightOffAmount.put(newAmount);
    }

    public Map<Long, AtomicLong> getSupermarketInventoryMirror(String smName) {
        return storage.getSupermarketInventory(smName);
    }

    public void suggestAdvertisement(String smName, IssuedAdvertisement adv) {
        SamplingBuffer<IssuedAdvertisement> buffer = suggestedAdvertisement.getOrCreate(smName);
        buffer.put(adv);
    }
    
    public IssuedAdvertisement getSuggestedAdvertisement(String smName) {
        return suggestedAdvertisement.getOrCreate(smName).get();
    }
    
    public Set<Long> getBarcodesForCategory(Category c) {
        return storage.getBarcodesForCategory(c);
    }
    
    public Probe getDataMiningTxProbe() {
        return dataMiningTxProbe;
    }
}
