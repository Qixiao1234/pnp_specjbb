/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.tx;

import org.spec.jbb.core.comm.Message;
import org.spec.jbb.core.comm.Request;
import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.comm.Uplink;

import java.util.List;

public class TransactionContext {

    private final Uplink link;
    private final int tier;

    public TransactionContext(Uplink link, int tier) {
        this.link = link;
        this.tier = tier;
    }

    public void sendMessage(String target, Message message) {
        link.sendMessage(target, tier, message);
    }

    public Response sendRequest(String target, Request request) {
        return link.sendRequest(target, tier, request);
    }

    public void sendMessage(String target, List<Message> messages) {
        link.sendMessage(target, tier, messages);
    }
}
