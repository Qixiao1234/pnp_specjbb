/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.cache;

import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.locks.LockManager;
import org.spec.jbb.core.locks.LockManagerFactory;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.probe.ProbeFactory;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;

/**
 * Bounded implementation of WriteBackCache.
 *
 * Implementation note:
 *   Methods adherent to the same key: get(), update(), and release(key) are NOT thread safe.
 *   One key life-cycle consist of sequential calls of these methods. This simplifies implementation a lot.
 *
 *   When called for different keys, these methods are completely safe.
 *   Purging is done internally in thread-safe manner as well.
 */
public class BoundedWriteBackCache<C, K, V> implements WriteBackCache<C, K, V>, Measurable, Serializable {

    private static final long serialVersionUID = 637833215520694403L;

    /**
     * Cache storage
     */
    private final ConcurrentMap<K, CacheEntry<K, V>> cache = new ConcurrentHashMap<>();

    /**
     * Locks for each key
     */
    private transient volatile LockManager<K> locks;

    /**
     * Statistic stuff
     */
    private transient volatile Probe probe;

    /**
     * Actual size
     */
    private final AtomicInteger size = new AtomicInteger(0);

    /**
     * Size bound
     */
    private final int bound;

    /**
     * Which elements to purge?
     */
    private final Queue<CacheEntry<K, V>> removePriorityQueue;

    private transient volatile Connector<C, K, V> connector;

    public BoundedWriteBackCache(int bound) {
        if (bound < 0) {
            throw new IllegalArgumentException("Size should be non-negative: " + bound);
        }
        this.bound = bound;
        this.removePriorityQueue = new PriorityBlockingQueue<>(Math.max(1, bound), CacheEntry.PRIORITY_COMPARATOR);

        init();
    }

    private void init() {
        locks = LockManagerFactory.getLockManager();
        probe = ProbeFactory.getDefaultProbe();
    }

    public void setConnector(Connector<C, K, V> connector) {
        if (connector == null) {
            throw new IllegalArgumentException("connector is null");
        }
        this.connector = connector;
    }

    private V get0(K key) {
        CacheEntry<K, V> entry = cache.get(key);
        if (entry != null) {
            V value = entry.get();
            if (value != null) {
                return value;
            }
        }
        return null;
    }
    
    @Override
    public V get(C ctx, K key) {
        /**
         * Fast-path: try to get element and return.
         */
        V value = get0(key);
        if (value != null) {
            probe.inc("hit");
            return value;
        }

        /**
         * SLOW-PATH:
         *   - ask backing storage for value
         *   - store it in cache
         *
         * If there's a race for space and we can't add up just read value, then answer it without caching.
         * If backing storage returns null, then we don't invalidate cache.
         */
        Lock lock = locks.getLock(key);
        lock.lock();
        try {
            value = get0(key);
            if (value != null) {
                probe.inc("hit_waited");
                return value;
            }

            probe.inc("miss");
            value = connector.read(ctx, key);
            if (value != null) {
                if (size.incrementAndGet() <= bound || purgeSingle(ctx)) {
                    CacheEntry<K, V> old = cache.put(key, new CacheEntry<>(key, value, connector.getPriority(ctx, key)));
                    assert (old == null);
                } else {
                    size.decrementAndGet();
                }
            }
            return value;
        } finally {
            lock.unlock();
        }
    }

    /**
     * Flush and remove all non-active elements.
     */
    void flush(C ctx) {
        /**
         * Try to flush atomically.
         * If entry can not be purged, then place it on the queue back.
         */
        List<CacheEntry<K, V>> falseRemovedEntries = new ArrayList<>();
        try {
            CacheEntry<K, V> entry;
            while ((entry = removePriorityQueue.poll()) != null) {
                if (!tryPurge(ctx, entry)) {
                    falseRemovedEntries.add(entry);
                }
            }
        } finally {
            removePriorityQueue.addAll(falseRemovedEntries);
        }
    }

    /**
     * Purges (and writes back) one non-active entry from the cache
     */
    private boolean purgeSingle(C ctx) {

        /**
         * Try to purge atomically.
         * If entry can not be purged, then place it on the queue back.
         */
        List<CacheEntry<K, V>> falseRemovedEntries = new ArrayList<>();
        try {
            CacheEntry<K, V> entry;
            while ((entry = removePriorityQueue.poll()) != null) {
                if (tryPurge(ctx, entry)) {
                    return true; // success
                } else {
                    falseRemovedEntries.add(entry);
                }
            }
        } finally {
            removePriorityQueue.addAll(falseRemovedEntries);
        }
        return false;
    }

    /**
     * Try to purge entry from cache.
     * @param entry entry to purge
     * @return true, if succeeded
     */
    private boolean tryPurge(C ctx, CacheEntry<K, V> entry) {
        if (entry.isDead()) {
            K key = entry.getKey();
            Lock lock = locks.getLock(key);
            lock.lock();
            try {
                /**
                 * Remove can only happen under the lock.
                 * tryToRemove() will deliver change to REMOVED state for get() fastpath, which is not guarded by lock.
                 */
                if (entry.tryToRemove()) {
                    boolean removed = cache.remove(key, entry);
                    assert removed;
                    connector.write(ctx, key, entry.getValue());
                    size.decrementAndGet();
                    return true;
                }
            } finally {
                lock.unlock();
            }
        }
        return false;
    }

    private boolean update0(K key, V value) {
        CacheEntry<K, V> entry = cache.get(key);
        if (entry != null && entry.set(value)) {
            return true;
        }
        return false;
    }
    
    /**
     * Updates the value in cache.
     * It will not update backing storage unless the entry is evicted.
     *
     * @param key key to update
     * @param value value to update
     */
    @Override
    public void update(C ctx, K key, V value) {
        if (value == null) {
            throw new NullPointerException();
        }

        /**
         * Fast-path, try to write in cache entry.
         */
        if(update0(key, value)) {
            return;
        }

        /**
         * Slow-path, no cache entry, write back directly to backing storage
         */
        Lock lock = locks.getLock(key);
        lock.lock();
        try {
            if (!update0(key, value)) {
                connector.write(ctx, key, value);
            }
        } finally {
            lock.unlock();
        }
    }

    /**
     * Releases entry from cache, marking it for write-back.
     *
     * @param key key to release
     */
    @Override
    public void release(C ctx, K key) {
        CacheEntry<K, V> entry = cache.get(key);
        if (entry != null) {
            if (entry.toDead() && !entry.isQueued()) {
                entry.setQueued();
                boolean success = removePriorityQueue.offer(entry);
                if (!success) {
                    throw new IllegalStateException("Removal queue rejected offer");
                }
            }
        }
    }

    public int getSize() {
        return size.get();
    }

    @Override
    public void instrument(Probe probe) {
        this.probe = probe;
        locks.instrument(probe.getChild("lockmanager"));
    }

    @Override
    public void sample() {
        probe.sample("size", getSize());
        probe.sample("purgeQueue.size", removePriorityQueue.size());
        locks.sample();
    }

    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
        ois.defaultReadObject();
        init();

        /*
           Bring cache in consistent state.
         */
        removePriorityQueue.clear();
        for(CacheEntry<K, V> entry : cache.values()) {
            release(null, entry.getKey());
        }
    }

    /**
     * Cache Entry
     * @param <K>
     * @param <V>
     */
    public static class CacheEntry<K, V> implements Serializable {
        // value is in cache and active
        private static final int CL_ACTIVE = 0;

        // value is in cache, but not active; may be removed
        private static final int CL_DEAD = 1;

        // value is NOT in cache, but cache entry is still in cache map
        // due to not completed removing process.
        private static final int CL_REMOVED = 2;
        
        private static final long serialVersionUID = -7439306864727274869L;

        private static final Comparator<CacheEntry> PRIORITY_COMPARATOR = new PriorityComparator();

        private final AtomicInteger state = new AtomicInteger(CL_ACTIVE);
        private final K key;
        private volatile V value;
        private final int priority;
        private volatile boolean queued = false;

        CacheEntry(K key, V value, int priority) {
            this.key = key;
            this.value = value;
            this.priority = priority;
        }

        K getKey() {
            return key;
        }

        V getValue() {
            return value;
        }

        /**
         * Atomic operation
         * returns value if state is active
         * returns value and set state to active if state is dead
         * returns null if state is removed.
         *
         * @return value
         */
        V get() {
            return toActive() ? value : null;
        }

        boolean isDead() {
            return state.get() == CL_DEAD;
        }


        /**
         * Atomically transfer dead state into active state.
         * returns true if state became (or already) active.
         *
         * @return true, if succeeded
         */
        private boolean toActive() {
            while(true) {
                int currentState = state.get();
                switch (currentState) {
                    case CL_ACTIVE:
                        return true;
                    case CL_DEAD:
                        if (state.compareAndSet(CL_DEAD, CL_ACTIVE)) {
                            return true;
                        }
                        break;
                    case CL_REMOVED:
                        return false;
                    default:
                        throw new IllegalStateException("Unknown state: " + currentState);
                }
            }
        }

        /**
         * Atomically transfer active state to dead state.
         * returns false if already dead.
         *
         * @return true, if succeeded
         */
        boolean toDead() {
            while(true) {
                int currentState = state.get();
                switch (currentState) {
                    case CL_ACTIVE:
                        if (state.compareAndSet(CL_ACTIVE, CL_DEAD)) {
                            return true;
                        }
                        break;
                    case CL_DEAD:
                        return false;
                    case CL_REMOVED:
                        return false;
                    default:
                        throw new IllegalStateException("Unknown state: " + currentState);
                }
            }
        }

        boolean tryToRemove() {
            return state.compareAndSet(CL_DEAD, CL_REMOVED);
        }

        boolean set(V value) {
            if (toActive()) {
                this.value = value;
                return true;
            }
            return false;
        }

        int getPriority() {
            return priority;
        }

        void setQueued() {
            this.queued = true;
        }

        boolean isQueued() {
            return queued;
        }

        private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
            ois.defaultReadObject();
            this.state.set(CL_ACTIVE);
        }

        public static final class PriorityComparator implements Comparator<CacheEntry>, Serializable {
            private static final long serialVersionUID = 7851017900885362576L;

            @Override
            public int compare(CacheEntry o1, CacheEntry o2) {
                return Integer.compare(o1.getPriority(), o2.getPriority());
            }

        }
    }
}
