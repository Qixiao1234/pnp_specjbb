/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.request.ProcessHQInvoicesRequest;
import org.spec.jbb.sm.tx.request.PaymentRequest;
import org.spec.jbb.sp.Invoice;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

public class ProcessHQInvoicesTransaction extends AbstractTransaction {

    private final HQ hq;

    public ProcessHQInvoicesTransaction(HQ hq, ProcessHQInvoicesRequest request, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
    }

    @Override
    public Response execute() {

        /**
         * Just drain.
         */

        Queue<Invoice> invoices = hq.getInvoices();
        List<Invoice> rejectedInvoices = new ArrayList<>();

        Invoice invoice;
        while((invoice = invoices.poll()) != null) {
            Response response = ctx.sendRequest(invoice.getSupplier(), new PaymentRequest(invoice.getKey()));
            if (!(response instanceof OkResponse)) {
                rejectedInvoices.add(invoice);
            }

            hq.getDataMiningManager().addInvoice(invoice);
        }
        invoices.addAll(rejectedInvoices);
        
        return new OkResponse();
    }

    @Override
    public String toString() {
        return "ProcessHQInvoicesTransactionTx";
    }

}
