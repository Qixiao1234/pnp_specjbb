/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

import org.spec.jbb.core.ExecutionHandler;
import org.spec.jbb.core.comm.Incoming;
import org.spec.jbb.core.comm.Outgoing;
import org.spec.jbb.core.tx.response.NullResponse;

public class DummyExecutionHandler implements ExecutionHandler {

    @Override
    public Outgoing execute(int tier, Incoming incoming) {
        return new NullResponse();
    }
}
