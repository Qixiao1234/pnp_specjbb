/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.policy;

import org.spec.jbb.core.comm.transport.TransportType;

public interface TransportSelectionPolicy {

    TransportType get(String fromName, String toName, boolean spanningMultipleICs);

}
