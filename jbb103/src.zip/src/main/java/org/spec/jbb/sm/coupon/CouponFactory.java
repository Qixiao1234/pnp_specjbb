/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.coupon;

import org.spec.jbb.util.JbbProperties;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * The factory class for creation of new instances of Coupon.
 *
 */
public class CouponFactory {

    private long expirationDurationMin;
    private long expirationDurationMax;
    private int genericPercentMin;
    private int genericPercentMax;
    private int specificPercentMin;
    private int specificPercentMax;

    public CouponFactory() {
        expirationDurationMax = JbbProperties.getInstance().getMaxCouponExpiration();
        expirationDurationMin = JbbProperties.getInstance().getMinCouponExpiration();
        genericPercentMax = JbbProperties.getInstance().getMaxGenericCouponPercent();
        genericPercentMin = JbbProperties.getInstance().getMinGenericCouponPercent();
        specificPercentMax = JbbProperties.getInstance().getMaxSpecificCouponPercent();
        specificPercentMin = JbbProperties.getInstance().getMinSpecificCouponPercent();
    }

    private long getExpirationDuration() {
        return ThreadLocalRandom.current().nextLong(expirationDurationMin, expirationDurationMax + 1);
    }

    private int getGenericPercent() {
        return ThreadLocalRandom.current().nextInt(genericPercentMin, genericPercentMax + 1);
    }

    private int getSpecificPercent() {
        return ThreadLocalRandom.current().nextInt(specificPercentMin, specificPercentMax + 1);
    }

    /**
     * Create new generic coupon.
     * Its percentage attributes is a random value in the range of [genericPercentMin, genericPercentMax].
     * Its expiration attribute is a random value in range of [expirationDurationMin, expirationDurationMax].  
     * 
     * @return new generic coupon
     */
    public GenericCoupon createGenericCoupon() {
        return new GenericCoupon(new Date(new Date().getTime() + getExpirationDuration()), getGenericPercent());
    }

    /**
     * Create a list of specific coupons.
     * Percentage attributes of each coupon is a random value in the range of [specificPercentMin, specificPercentMax].
     * Expiration attribute of all coupons is a random value in range of [expirationDurationMin, expirationDurationMax].  
     * 
     * @param barcode
     * @param count
     * @return
     */
    public List<SpecificCoupon> createSpecificCoupons(long barcode, int count) {
        Date date = new Date(new Date().getTime() + getExpirationDuration());
        List<SpecificCoupon> list = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            list.add(new SpecificCoupon(barcode, date, getSpecificPercent()));
        }
        return list;
    }
}
