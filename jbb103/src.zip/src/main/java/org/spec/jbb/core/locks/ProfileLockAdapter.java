/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.locks;

import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.probe.ProbeFactory;
import org.spec.jbb.core.time.StopWatch;
import org.spec.jbb.core.time.TimeFactory;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Profiling adapter for reentrant lock.
 */
class ProfileLockAdapter implements Lock, Measurable {

    private volatile Probe probe;
    private final Lock backingLock;
    private final String prefix;

    public ProfileLockAdapter(String prefix, Lock backingLock) {
        this.prefix = prefix;
        this.probe = ProbeFactory.getDefaultProbe();
        this.backingLock = backingLock;
    }

    public String getPrefix() {
        return prefix;
    }

    @Override
    public void lock() {
        probe.inc("attempts");

        StopWatch acquireWatch = TimeFactory.getStopwatch();
        acquireWatch.start();
        backingLock.lock();
        acquireWatch.stop();
        probe.add("timeWaiting", acquireWatch.getElapsedNsecs());

        probe.inc("success");
    }

    @Override
    public void lockInterruptibly() throws InterruptedException {
        StopWatch acquireWatch = TimeFactory.getStopwatch();
        acquireWatch.start();
        backingLock.lockInterruptibly();
        acquireWatch.stop();
        probe.add("timeWaiting", acquireWatch.getElapsedNsecs());
    }

    @Override
    public boolean tryLock() {
        probe.inc("attempts");
        boolean result = backingLock.tryLock();
        probe.inc(result ? "success" : "failed");
        return result;
    }

    @Override
    public void unlock() {
        backingLock.unlock();
    }

    @Override
    public Condition newCondition() {
        return backingLock.newCondition();
    }

    @Override
    public boolean tryLock(long timeout, TimeUnit unit) throws InterruptedException {
        probe.inc("attempts");
        boolean result = backingLock.tryLock(timeout, unit);
        probe.inc(result ? "success" : "failed");
        return result;
    }

    @Override
    public void instrument(Probe probe) {
        this.probe = probe;
    }

    @Override
    public void sample() {
        if (backingLock instanceof ReentrantLock) {
            probe.sample("waiters", ((ReentrantLock) backingLock).getQueueLength());
        }
    }
}
