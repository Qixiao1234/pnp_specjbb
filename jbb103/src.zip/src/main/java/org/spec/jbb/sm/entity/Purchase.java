/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.entity;

import org.spec.jbb.core.collections.HashMultiSet;
import org.spec.jbb.core.collections.MultiSet;

import java.util.Collection;

/**
 * This class represents a pending or completed purchase.
 */
public class Purchase {

    private final long customerId;
    private final MultiSet<Long> shoppingCart;

    public Purchase(long customerId) {
        this.customerId = customerId;
        this.shoppingCart = new HashMultiSet<>();
    }

    public Collection<Long> getBarcodes() {
        return shoppingCart.elementSet();
    }

    public void add(long barcode, int quantity) {
        shoppingCart.add(barcode, quantity);
    }

    public int getQuantity(long barcode) {
        return shoppingCart.count(barcode);
    }

    public long getCustomerId() {
        return customerId;
    }
}
