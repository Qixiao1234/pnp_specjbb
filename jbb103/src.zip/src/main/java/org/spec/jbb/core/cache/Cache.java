/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.cache;

import org.spec.jbb.core.Measurable;

/**
 * Generic interface for cache.
 * Most of the usages populate cache on failure; connector provides cache with new values.
 *
 * @param <C> context to run in
 * @param <K> key type
 * @param <V> value type
 */
public interface Cache<C, K, V> extends Measurable {

    /**
     * Set connector to cooperate with decorated entity.
     * @param connector connector
     */
    void setConnector(Connector<C, K, V> connector);

    /**
     * Get value from cache.
     * If there's no value in the cache, connector will be asked to provide value.
     *
     * @param ctx context to run in
     * @param key key to read
     * @return value associated with key; null, iff connector returned null.
     */
    V get(C ctx, K key);

    /**
     * Flush the cache, removing all entries.
     */
    void flush(C ctx);

}
