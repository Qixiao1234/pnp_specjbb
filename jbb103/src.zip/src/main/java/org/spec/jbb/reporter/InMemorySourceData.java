/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

import org.spec.jbb.core.collections.HashMultiMap;
import org.spec.jbb.core.collections.MultiMap;
import org.spec.jbb.core.comm.LocationInfo;
import org.spec.jbb.infra.IterationStatus;
import org.spec.jbb.infra.TimeData;
import org.spec.jbb.infra.validation.ValidationReport;
import org.spec.jbb.util.JbbProperties;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

public class InMemorySourceData implements SourceData {

    private final List<StatsFrame> frames;
    private final List<Map<String, JbbProperties>> properties;
    private final List<LogRecordFrame.LogDataChunk> logRecords;
    private final List<ValidationReport> validationReports;
    private final SortedMap<Long, IterationStatus> statuses;
    private final Map<String, String> marks;
    private final MultiMap<String, LocationInfo> agentInfo;
    private final List<TimeData> timeData;
    private final String source;
    private volatile boolean isDataValid;

    public InMemorySourceData(String source) {
        this.source = source;
        this.frames = new ArrayList<>();
        this.properties = new ArrayList<>();
        this.logRecords = new ArrayList<>();
        this.validationReports = new ArrayList<>();
        this.statuses = new TreeMap<>();
        this.marks = new HashMap<>();
        this.agentInfo = new HashMultiMap<>();
        this.timeData = new ArrayList<>();
    }

    @Override
    public void ensureRead() {
        RunDataReader reader = new RunDataReader(source);
        Frame data;
        while((data = reader.getNextPoint()) != null) {
            if (data instanceof StatsFrame) {
                if (!((StatsFrame) data).getProfileData().isEmpty()) {
                    ((StatsFrame) data).getProfileData().internAll();
                    frames.add((StatsFrame) data);
                }
            }
            if (data instanceof PropertiesFrame) {
                properties.add(((PropertiesFrame) data).getPropsMap());
            }
            if (data instanceof LogRecordFrame) {
                logRecords.add(((LogRecordFrame)data).getData());
            }
            if (data instanceof RunStatusFrame) {
                statuses.put(((RunStatusFrame) data).getTime(), ((RunStatusFrame) data).getStatus());
            }
            if (data instanceof MarkFrame) {
                marks.put(((MarkFrame) data).getKey(), ((MarkFrame) data).getValue());
            }
            if (data instanceof AgentInfoFrame) {
                agentInfo.putAll(((AgentInfoFrame) data).getAgent(), ((AgentInfoFrame) data).getLocations());
            }
            if (data instanceof ValidationFrame) {
                validationReports.add(((ValidationFrame)data).getReport());
            }
            if (data instanceof TimeDataFrame) {
                timeData.add(((TimeDataFrame) data).getTimeData());
            }
        }
        isDataValid = reader.isDataValid();
        reader.close();
    }

    @Override
    public void runPass(Collection<? extends Visitor> visitors) {
        List<Visitor> acceptedVisitors = new ArrayList<>();
        for (Visitor visitor : visitors) {
            if (visitor.shouldRun()) {
                acceptedVisitors.add(visitor);
            }
        }

        if (acceptedVisitors.size() > 0) {
            for(StatsFrame frame : frames) {
                for(Visitor visitor : acceptedVisitors) {
                    visitor.visit(frame);
                }
            }
        }
    }

    @Override
    public final void runPass(Collection<? extends Visitor>... visitors) {
        List<Visitor> composite = new ArrayList<>();
        for (Collection<? extends Visitor> coll : visitors) {
            composite.addAll(coll);
        }
        runPass(composite);
    }

    @Override
    public void runPass(Visitor... visitors) {
        runPass(Arrays.asList(visitors));
    }

    @Override
    public void shutdown() {
        // do nothing
    }

    @Override
    public Iterable<LogRecordFrame.LogDataChunk> getLogRecords() {
        return Collections.unmodifiableCollection(logRecords);
    }

    @Override
    public Iterable<Map<String, JbbProperties>> getProperties() {
        return Collections.unmodifiableCollection(properties);
    }

    @Override
    public Iterable<IterationStatus> getStatuses() {
        return statuses.values();
    }

    @Override
    public Map<String, String> getMarks() {
        return marks;
    }

    @Override
    public Iterable<TimeData> getTimeData() {
        return Collections.unmodifiableCollection(timeData);
    }

    @Override
    public boolean isDataValid() {
        return isDataValid;
    }

    @Override
    public MultiMap<String, LocationInfo> getAgentInfos() {
        return agentInfo;
    }

    public List<ValidationReport> getValidationReports() {
        return validationReports;
    }
}
