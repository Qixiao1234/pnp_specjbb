/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.response;

import org.spec.jbb.core.comm.AbstractResponse;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class AdvertisementIssueResponse extends AbstractResponse {

    private static final long serialVersionUID = 8407589144080324917L;
    @XmlElement
    private final boolean result;

    private AdvertisementIssueResponse() {
        // JAXB
        this(false);
    }

    public AdvertisementIssueResponse(boolean result) {
        this.result = result;
    }

    public boolean getResult() {
        return result;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        AdvertisementIssueResponse that = (AdvertisementIssueResponse) o;

        if (result != that.result) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), result);
    }

    @Override
    public String toString() {
        return "AdvertisementIssueResponse{" + result + "}";
    }
}
