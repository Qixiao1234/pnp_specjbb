/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.generator;

import org.spec.jbb.core.Topology;
import org.spec.jbb.core.collections.CollectionUtils;
import org.spec.jbb.core.collections.HashMultiSet;
import org.spec.jbb.core.collections.Mix;
import org.spec.jbb.core.collections.MultiSet;
import org.spec.jbb.hq.entity.Category;
import org.spec.jbb.hq.entity.Product;
import org.spec.jbb.util.JbbProperties;
import org.spec.jbb.util.RandomData;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class ProductGenerator {

    public List<Product> generate() {
        return generate(JbbProperties.getInstance().getProductCount(), JbbProperties.getInstance().getRandomSeed());
    }

    public List<Long> generateBarcodes() {
        return generateBarcodes(JbbProperties.getInstance().getProductCount(), JbbProperties.getInstance().getRandomSeed());
    }

    public List<Category> generateCategories() {
        return generateCategories(JbbProperties.getInstance().getNumberOfCategories(), JbbProperties.getInstance().getRandomSeed());
    }
    
    public MultiSet<Long> generateHotness() {
        return generateHotness(generateBarcodes());
    }


    List<Product> generate(int count, long seed) {
        int prop_MinProductPriceInCents = JbbProperties.getInstance().getMinProductPriceInCents();
        int prop_MaxProductPriceInCents = JbbProperties.getInstance().getMaxProductPriceInCents();
        int prop_MinProductNameChars = JbbProperties.getInstance().getMinProductNameChars();
        int prop_MaxProductNameChars = JbbProperties.getInstance().getMaxProductNameChars();
        
        int prop_MinProductQuantity = JbbProperties.getInstance().getMinProductQuantity();
        int prop_MaxProductQuantity = JbbProperties.getInstance().getMaxProductQuantity();
        int prop_MinQuantityReplenish = JbbProperties.getInstance().getMinQuantityReplenish();
        int prop_MaxQuantityReplenish = JbbProperties.getInstance().getMaxQuantityReplenish();
        int prop_hotnessMultiplerQuantityReplenish = JbbProperties.getInstance().getHotnessMultiplierQuantityReplenish();
        
        /*
          get a random barcode not already in the uniqueBarcodes,
          i.e. cannot use duplicate bar codes
          NOTE: uniqueBarcodes will contain the set of Product bar codes
                which are also in the inventory
           */

        RandomData randomData = new RandomData(seed);
        List<Product> result = new ArrayList<>();

        List<Long> barcodes = generateBarcodes(count, seed);

        Topology topology = new Topology();

        Mix<String> SPs = CollectionUtils.getMix(new Random(seed), topology.getSPnames());
        
        int categoriesPerProduct = JbbProperties.getInstance().getCategoriesPerProduct();
        Integer[] cppValues = new Integer[categoriesPerProduct];
        int[] cppWeights = new int[categoriesPerProduct];
        for(int i = 0; i < categoriesPerProduct; i++) {
            cppValues[i] = i+1;
            cppWeights[i] = categoriesPerProduct - i;
        }
        Mix<Integer> cpp = CollectionUtils.getFixedMix(new Random(seed), cppValues, cppWeights);
        Mix<Category> categoryMix = CollectionUtils.getMix(new Random(seed), generateCategories());
        MultiSet<Long> hotness = generateHotness(barcodes);
        Mix<Integer> quantityReplenish = CollectionUtils.getRangeMix(new Random(seed), 
                prop_MinQuantityReplenish, prop_MaxQuantityReplenish + 1);
        
        for(Long barcode : barcodes) {
            Set<Category> categories = new HashSet<>();
            int numberOfCategories = cpp.next();
            for(int i = 0; i < numberOfCategories; i++) {
                Category c = categoryMix.next();
                if (!categories.add(c)) {
                    i--;
                }
            }

            Product p = new Product(
                    barcode,
                    randomData.createProductName(prop_MinProductNameChars, prop_MaxProductNameChars),
                    randomData.createRandomPrice(prop_MinProductPriceInCents, prop_MaxProductPriceInCents),
                    randomData.randomInt(prop_MinProductQuantity, prop_MaxProductQuantity),
                    quantityReplenish.next() + hotness.count(barcode) * prop_hotnessMultiplerQuantityReplenish,
                    SPs.next(),
                    categories
                    );

            result.add(p);
        }

        return result;
    }


    List<Long> generateBarcodes(int count, long seed) {
        List<Long> result = new ArrayList<>();
        RandomData randomData = new RandomData(seed);
        Set<Long> uniqueBarcodes = new HashSet<>();
        for (int c = 0; c < count; c++) {
            Long next;
            do {
                next = randomData.createBarcode();
            } while (!uniqueBarcodes.add(next));

            result.add(next);
        }

        return result;
    }

    List<Category> generateCategories(int count, long seed) {
        RandomData randomData = new RandomData(seed);

        Set<Integer> unique = new HashSet<>();

        List<Category> result = new ArrayList<>(count);
        for(int i = 0; i < count; i++) {

            Integer next;
            do {
                next = randomData.randomInt(0, Integer.MAX_VALUE);
            } while(!unique.add(next));

            result.add(new Category(next));
        }
        
        return result;
    }
    
    public MultiSet<Long> generateHotness(List<Long> barcodes) {
        int hotnessInitMax = JbbProperties.getInstance().getHotnessInitMax();
        
        Integer[] hotness = new Integer[hotnessInitMax + 1];
        int[] hotnessWeights = new int[hotnessInitMax + 1];
        for (int i = 0; i < hotnessInitMax + 1; i++) {
            hotness[i] = i + 1;
            hotnessWeights[i] = hotnessInitMax + 1 - i;
        }
        Mix<Integer> hotnesses = CollectionUtils.getFixedMix(
                new Random(JbbProperties.getInstance().getRandomSeed()),
                hotness, hotnessWeights);
        MultiSet<Long> result = new HashMultiSet<> ();
        for (Long b : barcodes) {
            result.add(b, hotnesses.next());
        }
        
        return result;
    }

}