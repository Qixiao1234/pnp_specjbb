/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.request;

public abstract class AbstractPurchaseRequest extends AbstractBusinessTxInjectorRequest {

    private static final long serialVersionUID = -996275273139952691L;

    protected AbstractPurchaseRequest() {
        super();
    }

    public AbstractPurchaseRequest(boolean isSaturate) {
        super(isSaturate);
    }

}
