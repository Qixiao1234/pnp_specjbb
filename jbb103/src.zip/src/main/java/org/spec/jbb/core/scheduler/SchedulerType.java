/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.scheduler;

public enum SchedulerType {

    SELF_RESUBMIT,

    SELF_RESUBMIT_QUEUED,

    LOOP_TIMER_QUEUED,

    PLL,

    SINGLE_LOOP_TIMER,

}
