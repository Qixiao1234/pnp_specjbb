/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.sequencer;

public class RangeSequencer implements Sequencer<Long> {

    private final long stop;
    private long counter;

    public RangeSequencer(long start, long stop) {
        this.counter = start;
        this.stop = stop;
    }

    @Override
    public Long next() {
        if (counter < stop) {
            return counter++;
        } else {
            return null;
        }
    }

}
