/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

import org.spec.jbb.core.collections.CreateHashMap;
import org.spec.jbb.core.collections.CreateMap;
import org.spec.jbb.core.collections.Pair;
import org.spec.jbb.infra.txinjector.BusinessRequestName;
import org.spec.jbb.util.InstanceFactory;
import org.spec.jbb.infra.IterationLabel;
import org.spec.jbb.infra.RTDistributionCollection;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public class ResponseTimeCurve implements Serializable { 
    private static final long serialVersionUID = -2414002364235518831L;
        
    private final CreateMap<BusinessRequestName, CreateMap<Long, PercentileValues>> indiPercent;
    private final CreateMap<Long, PercentileValues> totalPercent;

    private final CreateMap<BusinessRequestName, Map<Long, double[]>> indiSamples;
    private final Map<Long, double[]> totalSamples;

    private final CreateMap<BusinessRequestName, Map<Long, Pair<Double, Double>>> indiProbesRatio;
    private final Map<Long, Pair<Double, Double>> totalProbesRatio;
    
    private final Map<Long, Double> irByProbes;

    private final SortedSet<Long> irs;
    private final Map<Long, Boolean> statuses;

    private final int subSampleLimit;
    
    private Long preErrorIR;
    private String errorReason;

    private final Map<Long, Double> successes;
    private final CreateMap<Long, Map<BusinessRequestName, Double>> successesPerRequest;
    
    private final IterationLabel iterationLabel;

    public ResponseTimeCurve(int subSampleLimit, IterationLabel iterationLabel) {
        this.subSampleLimit = subSampleLimit;
        this.iterationLabel = iterationLabel;
        indiPercent = new CreateHashMap<>(
                new InstanceFactory<CreateMap<Long, PercentileValues>>() {

                    private static final long serialVersionUID = -598379158054906404L;

                    @Override
                    public CreateMap<Long, PercentileValues> getInstance() {
                        return new CreateHashMap<>(
                                new InstanceFactory<PercentileValues>() {

                                    private static final long serialVersionUID = -9213323075640147303L;

                                    @Override
                                    public PercentileValues getInstance() {
                                        return new PercentileValues();
                                    }
                                }
                        );
                    }
                }
        );

        indiSamples = new CreateHashMap<BusinessRequestName, Map<Long, double[]>>(
                new InstanceFactory<Map<Long, double[]>>() {

                    private static final long serialVersionUID = 7161463942172793819L;

                    @Override
                    public Map<Long, double[]> getInstance() {
                        return new HashMap<>();
                    }
                }
        );

        totalPercent = new CreateHashMap<Long, PercentileValues>(
                new InstanceFactory<PercentileValues>() {

                    private static final long serialVersionUID = -9213323075640147303L;

                    @Override
                    public PercentileValues getInstance() {
                        return new PercentileValues();
                    }
                }
        );
        
        indiProbesRatio = new CreateHashMap<BusinessRequestName, Map<Long, Pair<Double, Double>>>(
                new InstanceFactory<Map<Long, Pair<Double, Double>>>() {

                    private static final long serialVersionUID = 7161463942172793819L;

                    @Override
                    public Map<Long, Pair<Double, Double>> getInstance() {
                        return new HashMap<>();
                    }
                });
        
        irByProbes = new HashMap<>();

        totalSamples = new HashMap<>();
        totalProbesRatio = new HashMap<>();
        statuses = new HashMap<>();

        irs = new TreeSet<>();

        preErrorIR = null;

        errorReason = null;

        successes = new HashMap<>();

        successesPerRequest = new CreateHashMap<Long, Map<BusinessRequestName, Double>>(
                new InstanceFactory<Map<BusinessRequestName, Double>>() {

                    private static final long serialVersionUID = 7161463942172793819L;

                    @Override
                    public Map<BusinessRequestName, Double> getInstance() {
                        return new HashMap<>();
                    }
                });
    }

    public void putSuccesses(long ir, double count) {
        successes.put(ir, count);
    }

    public void putSuccesses(long ir, BusinessRequestName requestName, double count) {
        successesPerRequest.getOrCreate(ir).put(requestName, count);
    }

    public void putPercentile(long ir, BusinessRequestName requestName, int level, double percentile, double error) {
        irs.add(ir);
        indiPercent.getOrCreate(requestName).getOrCreate(ir).put(level, new Pair<>(percentile, error));
    }
    
    public void putPercentile(long ir, int level, double percentile, double error) {
        irs.add(ir);
        totalPercent.getOrCreate(ir).put(level, new Pair<>(percentile, error));
    }

    public void putSamples(long ir, BusinessRequestName requestName, RTDistributionCollection samples) {
        irs.add(ir);
        if (samples.getN() > subSampleLimit) {
            indiSamples.getOrCreate(requestName).put(ir, samples.subsampleUnique(subSampleLimit));
        } else {
            indiSamples.getOrCreate(requestName).put(ir, samples.getValues());
        }
    }

    public void addStatus(long ir, boolean status) {
        statuses.put(ir, status);
    }

    public void setErrorMark(long ir) {
        if(preErrorIR == null) {
            preErrorIR = ir;
        }
    }

    public void setErrorReason(String errorReason) {
        this.errorReason = errorReason;
    }

    public void putSamples(long ir, RTDistributionCollection samples) {
        irs.add(ir);
        if (samples.getN() > subSampleLimit) {
            totalSamples.put(ir, samples.subsampleUnique(subSampleLimit));
        } else {
            totalSamples.put(ir, samples.getValues());
        }
    }
    
    public void putProbesRatio(long ir, BusinessRequestName requestName, Pair<Double, Double> ratio) {
        indiProbesRatio.getOrCreate(requestName).put(ir, ratio);
    }

    public void putProbesRatio(long ir, Pair<Double, Double> ratio) {
        totalProbesRatio.put(ir, ratio);
    }
    
    public void purIrByProbes(long ir, Double probeIR) {
        irByProbes.put(ir, probeIR);
    }
    
    public Double getSuccesses(long ir, BusinessRequestName requestName) {
        return convert(successesPerRequest.getOrCreate(ir).get(requestName));
    }
    
    public Double getSuccesses(Long ir) {
        return convert(successes.get(ir));
    }

    public Double getIrByProbes(long ir) {
         return convert(irByProbes.get(ir));
    }
    
    public Pair<Double, Double> getProbesRatio(long ir) {
        Pair<Double, Double> res = totalProbesRatio.get(ir);
        return res == null ? new Pair<>(0D, 0D) : res;
    }

    public Pair<Double, Double> getProbesRatio(BusinessRequestName requestName, long ir) {
        Pair<Double, Double> res = indiProbesRatio.getOrCreate(requestName).get(ir);
        return res == null ? new Pair<>(0D, 0D) : res;
    }

    public Set<BusinessRequestName> getRequestNames() {
        return indiPercent.keySet();
    }

    public double[] getSamples(long ir, BusinessRequestName name) {
        return indiSamples.getOrCreate(name).get(ir);
    }

    public double[] getSamples(long ir) {
        return totalSamples.get(ir);
    }

    public Collection<Long> getIRs() {
        return irs;
    }

    public PercentileValues getLevels(long ir) {
        return totalPercent.getOrCreate(ir);
    }

    public CreateMap<Long, PercentileValues> getLevelsMap() {
        return totalPercent;
    }

    public PercentileValues getLevels(long ir, BusinessRequestName name) {
        return indiPercent.getOrCreate(name).getOrCreate(ir);
    }

    public CreateMap<Long, PercentileValues> getLevelsMap(BusinessRequestName name) {
        return indiPercent.getOrCreate(name);
    }

    public boolean isOk(Long ir) {
        Boolean status = statuses.get(ir);
        return (status == null) ? false : status;
    }

    public Long getErrorMark() {
        return preErrorIR;
    }
    
    public String getErrorReason() {
        return errorReason;
    }

    public IterationLabel getIterationLabel() {
        return iterationLabel;
    }
    
    public String getIrName() {
        return iterationLabel == iterationLabel.RT_CURVE ? "jOPS" : "Iteration";
    }
    
    public static class PercentileValues extends CreateHashMap<Integer, Pair<Double, Double>> {

        private static final long serialVersionUID = 4341068758115537786L;

        public PercentileValues() {
            super(new InstanceFactory<Pair<Double, Double>>() {

                private static final long serialVersionUID = 3762808569046254516L;

                @Override
                public Pair<Double, Double> getInstance() {
                    return new Pair<>(Double.NaN, Double.NaN);
                }
            });
        }

        @Override
        public Pair<Double, Double> get(Object key) {
            return super.getOrCreate(key);
        }
    };

    private static Double convert(Double value) {
        return value == null ? 0D : value;
    }
}
