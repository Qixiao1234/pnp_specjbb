/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.locks;

import org.spec.jbb.core.Measurable;

import java.util.concurrent.locks.Lock;

public interface LockManager<K> extends Measurable {
    /**
     * Get lock associated with key.
     * It's always guaranteed two concurrent calls for the same key will yield the same lock.
     *
     * @param key key to look up key for
     * @return lock
     */
    Lock getLock(K key);

}
