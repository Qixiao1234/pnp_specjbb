/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

import org.spec.jbb.core.sequencer.Sequencer;
import org.spec.jbb.core.sequencer.SequencerFactory;

import java.util.concurrent.ThreadFactory;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SpecThreadFactory {

    private SpecThreadFactory() {
        // prevent instantiation
    }

    public static ThreadFactory newFactory(final String name, final int priority, final boolean isDaemon) {
        return new ThreadFactory() {

            private Logger logger = Logger.getLogger("org.spec.jbb.thread");
            private Sequencer<Long> id = SequencerFactory.getNonSkippingSequencer();

            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r);
                t.setName(name + "." + id.next());
                t.setPriority(priority);
                t.setDaemon(isDaemon);
                t.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
                    @Override
                    public void uncaughtException(Thread t, Throwable e) {
                        logger.log(Level.SEVERE, "Uncaught exception", e);
                    }
                });
                return t;
            }
        };
    }

    public static ThreadFactory newFactory(String name) {
        return newFactory(name, false);
    }

    public static ThreadFactory newFactory(String name, boolean isDaemon) {
        return newFactory(name, Thread.NORM_PRIORITY, isDaemon);
    }


}
