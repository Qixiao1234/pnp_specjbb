/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

import org.spec.jbb.core.Conventions;
import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.util.JbbProperties;

import java.util.ArrayList;
import java.util.List;

public class Tiers implements Measurable {

    private List<Pool> tiers;
    private int maxTiers;

    public Tiers() {
        this("NoName");
    }

    public Tiers(String name) {
        tiers = new ArrayList<>();
        maxTiers = JbbProperties.getInstance().getMaxTiers();
        for (int c = 0; c < Conventions.TIER_BACKEND_FIRST; c++) {
            tiers.add(null);
        }

        for (int c = Conventions.TIER_BACKEND_FIRST; c <= maxTiers; c++) {
            Pool pool = ThreadPoolFactory.newPool(Conventions.getPoolName(name, Conventions.getTierName(c)));
            tiers.add(pool);
        }
    }

    public void start() {
        for (int c = Conventions.TIER_BACKEND_FIRST; c <= maxTiers; c++) {
            tiers.get(c).start();
        }
    }

    public Pool get(int tier) {
        if (tier > maxTiers) {
            throw new IllegalStateException("Not enough tiers, requested " + tier + ", max = " + maxTiers);
        }
        if (tier < Conventions.TIER_BACKEND_FIRST) {
            throw new IllegalStateException("Can not execute at this tier = " + tier);
        }
        return tiers.get(tier);
    }

    public int getMax() {
        return maxTiers;
    }

    public void shutdown() {
        for (int c = Conventions.TIER_BACKEND_FIRST; c <= maxTiers; c++) {
            tiers.get(c).shutdown();
        }
    }

    @Override
    public void instrument(Probe probe) {
        for (int c = Conventions.TIER_BACKEND_FIRST; c <= maxTiers; c++) {
            Pool pool = tiers.get(c);
            pool.instrument(probe.getChild(Conventions.getTierName(c)));
        }
    }

    @Override
    public void sample() {
        for (int c = Conventions.TIER_BACKEND_FIRST; c <= maxTiers; c++) {
            tiers.get(c).sample();
        }
    }
}
