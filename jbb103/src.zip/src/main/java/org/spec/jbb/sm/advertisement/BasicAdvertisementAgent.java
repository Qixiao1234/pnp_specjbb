/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.advertisement;

import org.spec.jbb.core.collections.CollectionUtils;
import org.spec.jbb.core.generator.ProductGenerator;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.entity.Category;
import org.spec.jbb.sm.SM;
import org.spec.jbb.util.JbbProperties;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * This is simple implementation of AdvertisementAgent based on random
 * generator.
 */
public class BasicAdvertisementAgent extends AbstractAdvertisementAgent implements Serializable {

    private static final long serialVersionUID = -7547721980460540701L;
    /**
     * Minimum number of products to provide advertisement to at once
     */
    private final int minQty;
    /**
     * Maximum number of products to provide advertisement to at once
     */
    private final int maxQty;
    /**
     * List of all available barcodes
     */
    private List<Long> barcodes;
    /**
     * List of all available categories
     */
    private List<Category> categories;

    public BasicAdvertisementAgent() {
        super();
        minQty = JbbProperties.getInstance().getMinAdvertisementBasicQty();
        maxQty = JbbProperties.getInstance().getMaxAdvertisementBasicQty();
        barcodes = new ArrayList<>(new ProductGenerator().generateBarcodes());
        categories = new ProductGenerator().generateCategories();
    }

    @Override
    public IssuedAdvertisement createAdvertisementBatch(TransactionContext ctx, SM sm) {
        int qty = ThreadLocalRandom.current().nextInt(minQty, maxQty);
        List<Long> list = new ArrayList<>(qty);
        for (int i = 0; i < qty; i++) {
            list.add(CollectionUtils.getRandomElement(barcodes));
        }
        Category c = CollectionUtils.getRandomElement(categories);
        return new IssuedAdvertisement(c, list);
    }

}
