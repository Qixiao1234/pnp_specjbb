/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity;

public class HttpConstants {

    public static final String CONTEXT_DATA = "/Handler";
    public static final String CONTEXT_RESOLVEIP = "/ResolveIP";

    public static final String HEADER_FROM = "X-SPEC-From";
    public static final String HEADER_TO = "X-SPEC-To";
    public static final String HEADER_TRANSPORTTYPE = "X-SPEC-TransportType";
    public static final String HEADER_SHOULDBEANSWERED = "X-SPEC-ShouldBeAnswered";
    public static final String HEADER_TIER = "X-SPEC-Tier";
}
