/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx;

import org.spec.jbb.core.collections.CollectionUtils;
import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.entity.CustomerProfile;
import org.spec.jbb.hq.entity.Product;
import org.spec.jbb.hq.entity.Receipt;
import org.spec.jbb.hq.tx.request.CheckAndReserveCreditRequest;
import org.spec.jbb.hq.tx.request.DrawCreditRequest;
import org.spec.jbb.hq.tx.request.PurchaseReceiptMessage;
import org.spec.jbb.sm.ReceiptBuilder;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.ShoppingCartItem;
import org.spec.jbb.sm.coupon.GenericCoupon;
import org.spec.jbb.sm.coupon.SpecificCoupon;
import org.spec.jbb.sm.discount.BOGODiscount;
import org.spec.jbb.sm.discount.Discount;
import org.spec.jbb.sm.discount.PercentageDiscount;
import org.spec.jbb.sm.tx.request.InStorePurchaseRequest;
import org.spec.jbb.sm.tx.request.InstallmentPurchaseRequest;

import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class InStorePurchaseTransaction extends AbstractPurchaseTransaction {

    public InStorePurchaseTransaction(SM sm, InStorePurchaseRequest req, TransactionContext ctx) {
        super(sm, req, ctx);
    }

    public InStorePurchaseTransaction(SM sm, InstallmentPurchaseRequest req, TransactionContext ctx) {
        super(sm, req, ctx);
    }

    @Override
    protected boolean doPurchase(Product product, int quantity) throws TransactionException {
        
        long barcode = product.getBarcode();
        int reservedQuantity = reserveProduct(barcode, quantity);

        if (reservedQuantity == quantity) {

            /**
             * Enough goods to serve:
             *  - reserve specific amount of goods
             *  - calculate price of the item taking into account
             *    - available discount
             *    - available coupons
             *  - add to shopping cart several entries separately for
             *    - each BOGO discount
             *    - each coupon
             *    - remained part
             *  - issue advertisement
             */

            BigDecimal price = product.getPrice();

            Discount discount = inventory.getDiscount(barcode);
            if (discount != null) {
                if (discount instanceof BOGODiscount) {
                    int qtyInShoppingCart = shoppingCart.getQuantity(barcode);
                    int totalQtyForFree = (qtyInShoppingCart + reservedQuantity) / 2;
                    int qtyForFreeInShoppingCart = qtyInShoppingCart / 2;
                    int qtyForFree = Math.min(totalQtyForFree - qtyForFreeInShoppingCart, reservedQuantity);

                    reservedQuantity -= qtyForFree;
                    if (qtyForFree > 0) {
                        shoppingCart.add(barcode, qtyForFree, BigDecimal.ZERO, sm.getName());
                    }
                } else if (discount instanceof PercentageDiscount) {
                    shoppingCart.add(barcode, reservedQuantity,
                            price.multiply(((PercentageDiscount) discount).getMultiplier()).setScale(2, BigDecimal.ROUND_HALF_EVEN), sm.getName());
                    reservedQuantity = 0;
                }
            }

            CustomerProfile profile = shoppingCart.getProfile();

            SpecificCoupon specificCoupon;
            while (reservedQuantity > 0 && (specificCoupon = profile.pollSpecificCoupon(barcode)) != null) {
                shoppingCart.add(barcode, 1, price.multiply(specificCoupon.getMultiplier()).setScale(2, BigDecimal.ROUND_HALF_EVEN),
                        sm.getName(), specificCoupon);
                reservedQuantity--;
            }

            if (reservedQuantity > 0) {
                shoppingCart.add(barcode, reservedQuantity, price, sm.getName());
            }

            List<Long> advertisedBarcodes = advertisements.getAdvertisements(product);
            if (!advertisedBarcodes.isEmpty()) {
                long advertisedBarcode = CollectionUtils.getRandomElement(advertisedBarcodes);
                profile.addAdvertisement(advertisedBarcode);
            }
            return true;
        } else {
            if(reservedQuantity > 0) {
                unreserveProduct(barcode, reservedQuantity);
            }
            return false;
        }
    }

    protected void doCheckout() throws TransactionException {

        /*
         * Remove expired coupons and apply generic coupon
         */
        CustomerProfile profile = shoppingCart.getProfile();

        GenericCoupon genericCoupon = profile.pollGenericCoupon();
        shoppingCart.setGenericCoupon(genericCoupon);

        /**
         * Generate receipt
         */
        Receipt receipt = ReceiptBuilder.build(sm.getNextReceiptNumber(), shoppingCart, sm.getName(), genericCoupon);

        BigDecimal totalPrice = receipt.getTotal();

        /**
         * Check credit
         */

        final String targetHQ = sm.resolveCustomer(ctx, customerId);

        Response creditResponse = ctx.sendRequest(targetHQ, new CheckAndReserveCreditRequest(customerId, totalPrice));
        if (creditResponse instanceof OkResponse) {

            /**
             * Credit accepted.
             *  - Move out product from Inventory
             *  - Issue new specific and generic coupons
             */
            for (ShoppingCartItem item : shoppingCart) {
                moveOut(item.getBarcode(), item.getQuantity());
                if (ThreadLocalRandom.current().nextInt(100) < sm.getSpecificCouponThresholdPercent()) {
                    int cnt = Math.max(1, item.getQuantity() * sm.getSpecificCouponCountPercent() / 100);
                    profile.addSpecificCoupons(item.getBarcode(), sm.getCouponFactory().createSpecificCoupons(item.getBarcode(),
                            cnt));
                }
            }

            if (totalPrice.compareTo(sm.getGenericCouponThreshold()) > 0) {
                profile.addGenericCoupon(sm.getCouponFactory().createGenericCoupon());
            }

            /**
             * Draw amount from customer's credit
             */
            ctx.sendRequest(targetHQ, new DrawCreditRequest(customerId, totalPrice));

            /**
             * Push receipt
             */
            ctx.sendMessage(owningHQ, new PurchaseReceiptMessage(receipt));

        } else {
            throw new NotEnoughCreditException("Not enough credit, got " + creditResponse);
        }

    }
    
    @Override
    public String toString() {
        return super.toString() + ", instore";
    }

}
