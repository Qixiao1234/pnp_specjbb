/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.purchase;

import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.collections.CollectionUtils;
import org.spec.jbb.core.collections.ConcurrentHashMultiSet;
import org.spec.jbb.core.collections.Mix;
import org.spec.jbb.core.collections.MultiSet;
import org.spec.jbb.core.generator.ProductGenerator;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.hq.entity.CustomerProfile;
import org.spec.jbb.util.InstanceFactory;
import org.spec.jbb.util.JbbProperties;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.logging.Logger;

/**
 * PurchaseAgent implementation taking into account customer profile. Each
 * barcode can have two hotness levels: initial and updated hotness levels. It
 * is possible to change hotness level and return it back, after that hotness
 * level can be changed to another one and them return back again and so on.
 * <p/>
 * CustomerProfile can also change the hotness level of the product. If there
 * are specific coupons or advertisements in customer profile then they are
 * change the hotness of the corresponding products.
 */
public class CustomerSpecificPurchaseAgent extends AbstractPurchaseAgent implements Measurable {

    private final MultiSet<Long> initialBarcodeHotness;
    private final Mix<Long> initialBarcodeHotnessMix;

    private final MultiSet<Long> updatedBarcodeHotness;
    private Mix<Long> updatedBarcodeHotnessMix;

    /**
     * Maximum available hotness up. It is a  maximum of
     * discount/advertisement/coupon appendant.
     */
    private final int hotnessShiftMax;

    /**
     * Coupon appendant to hotness level
     */
    private final int hotnessCoupon;

    /**
     * Advertisement appendant to hotness level
     */
    private final int hotnessAdvertisement;

    /**
     * Logger for logging debugging messages
     */
    private final Logger logger;

    public CustomerSpecificPurchaseAgent() {
        super();
        logger = Logger.getLogger("org.spec.jbb.core.purchase.CustomerSpecificPurchaseAgent");
        int hotnessDiscount = JbbProperties.getInstance().getHotnessDiscount();
        hotnessAdvertisement = JbbProperties.getInstance().getHotnessAdvertisement();
        hotnessCoupon = JbbProperties.getInstance().getHotnessCoupon();
        hotnessShiftMax = Math.max(hotnessCoupon, Math.max(hotnessAdvertisement, hotnessDiscount));
        
        initialBarcodeHotness = CollectionUtils.unmodifiableMultiSet(new ProductGenerator().generateHotness());
        initialBarcodeHotnessMix = CollectionUtils.getMix(initialBarcodeHotness);
        
        updatedBarcodeHotness = new ConcurrentHashMultiSet<>();
        updatedBarcodeHotnessMix = null;
    }

    @Override
    public Collection<PurchaseItem> getNextProducts(final CustomerProfile cp) {
        final int purchaseSize = getPurchaseSize();
        List<PurchaseItem> result = new ArrayList<>(purchaseSize);
        
        Mix<Long> updatedBarcodeHotnessMix = this.updatedBarcodeHotnessMix;
        if(updatedBarcodeHotnessMix == null) {
            updatedBarcodeHotnessMix = CollectionUtils.getMix(updatedBarcodeHotness);
            this.updatedBarcodeHotnessMix = updatedBarcodeHotnessMix;
        }
        final Mix<Long> specificCouponMix = cp != null ? CollectionUtils.getLazyMix(new InstanceFactory<Mix<Long>>() {

            private static final long serialVersionUID = 3998915612168321748L;

            @Override
            public Mix<Long> getInstance() {
                return CollectionUtils.getMix(cp.getBarcodesForSpecificCoupons(), hotnessCoupon);
            }
        }, cp.getBarcodesForSpecificCouponsSize() * this.hotnessCoupon) : CollectionUtils.<Long>emptyMix();

        final Mix<Long> advertisementMix = cp != null ? CollectionUtils.getLazyMix(new InstanceFactory<Mix<Long>>() {

            private static final long serialVersionUID = 8090796141221748421L;

            @Override
            public Mix<Long> getInstance() {
                return CollectionUtils.getMix(cp.getAdvertisementBarcodes(), hotnessAdvertisement);
            }
        }, cp.getAdvertisementSize() * this.hotnessAdvertisement) : CollectionUtils.<Long>emptyMix();

        for (int i = 0; i < purchaseSize; i++) {
            long barcode = CollectionUtils.selectRandom(
                    initialBarcodeHotnessMix, initialBarcodeHotnessMix.getMixWeight(),
                    updatedBarcodeHotnessMix, updatedBarcodeHotnessMix.getMixWeight(),
                    specificCouponMix, specificCouponMix.getMixWeight(),
                    advertisementMix, advertisementMix.getMixWeight()).next();
            
            result.add(new PurchaseItem(barcode, getQuantityNumber()));
        }

        return result;
    }

    @Override
    public void updateHotness(List<Long> barcodes, int shift) {
        // we need to move element from one column of card table to another
        // and then update hotnessLevelMix
        // NO need a write lock for an update because of
        // updatedBarcodeHotness is ConcurrentMultiMap
        if (shift > hotnessShiftMax) {
            logger.severe("new hotness shift is out of range: " + shift + " while max is " + hotnessShiftMax);
            return;
        }
        boolean isUpdated = false;
        for (long barcode : barcodes) {
            if (shift > 0) { // up hotness
                if (!updatedBarcodeHotness.setCount(barcode, 0, shift)) {
                    // It is not a bug, several items are in the same discount batch
                    logger.fine("Incorrect request to up hotness: barcode=" + barcode + ",  " +
                            "current=" + (initialBarcodeHotness.count(barcode) + updatedBarcodeHotness.count(barcode)) +
                            ", init=" + initialBarcodeHotness.count(barcode)
                            + ", shift=" + shift);
                } else {
                    isUpdated = true;
                }
            } else if (shift < 0) { // down hotness
                if (!updatedBarcodeHotness.setCount(barcode, -shift, 0)) {
                    // It is not a bug, several items are in the same discount batch
                    logger.fine("Incorrect request to down hotness: barcode=" + barcode + ",  " +
                            "current=" + (initialBarcodeHotness.count(barcode) + updatedBarcodeHotness.count(barcode)) +
                            ", init=" + initialBarcodeHotness.count(barcode)
                            + ", shift=" + shift);
                } else {
                    isUpdated = true;
                }
            }
        }
        if(isUpdated) {
            updatedBarcodeHotnessMix = null;
        }
    }

    @Override
    public String toString() {
        return "InitialHotness: \n" + initialBarcodeHotness + "UpdatedHotness: " + updatedBarcodeHotness;
    }

    @Override
    public void instrument(Probe probe) {
    }

    @Override
    public void sample() {
    }

}
