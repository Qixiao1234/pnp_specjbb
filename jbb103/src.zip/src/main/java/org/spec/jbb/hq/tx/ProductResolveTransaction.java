/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.entity.Product;
import org.spec.jbb.hq.tx.request.ProductResolveRequest;
import org.spec.jbb.hq.tx.response.ProductResolveResponse;

public class ProductResolveTransaction extends AbstractTransaction {

    private final HQ hq;
    private final long barcode;

    public ProductResolveTransaction(HQ hq, ProductResolveRequest req, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        this.barcode = req.getBarcode();
    }

    @Override
    public Response execute() {
        Product product = hq.findProduct(barcode);
        return new ProductResolveResponse(product);
    }

    @Override
    public String toString() {
        return "ProductResolveTx: barcode={" + barcode + "}";
    }

}
