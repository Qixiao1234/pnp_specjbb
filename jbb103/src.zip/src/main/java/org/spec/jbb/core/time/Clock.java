/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.time;

public interface Clock {

    /**
     * Answers local time with millisecond precision.
     *
     * @return time in milliseconds
     */
    long getTimeMsec();

}
