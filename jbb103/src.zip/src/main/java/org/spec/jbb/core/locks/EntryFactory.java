/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.locks;

import java.lang.ref.ReferenceQueue;

public final class EntryFactory<K, V> {

    private final LockRefType type;

    public EntryFactory(LockRefType type) {
        this.type = type;
    }

    public Entry<K, V> newEntry(K key, V value, ReferenceQueue<V> queue) {
        switch (type) {
            case STRONG:
                return new StrongEntry<>(key, value);
            case WEAK:
                return new WeakEntry<>(key, value, queue);
            case SOFT:
                return new SoftEntry<>(key, value, queue);
            default:
                throw new IllegalStateException("Unknown reference type: " + type);
        }
    }

}
