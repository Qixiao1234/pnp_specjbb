/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.policy;

import org.spec.jbb.core.comm.transport.TransportType;
import org.spec.jbb.infra.heartbeat.HeartbeatWatchdog;

import java.util.HashSet;
import java.util.Set;

public class MaxXmlPolicy implements TransportSelectionPolicy {

    private final static Set<String> EXCEPTIONS = new HashSet<String>() {{
        add("Controller"); // controller
        add(HeartbeatWatchdog.LEADER_NAME);     // heartbeat leader
    }

        private static final long serialVersionUID = 2425693049933053754L;
    };

    @Override
    public TransportType get(String fromName, String toName, boolean spanningMultipleICs) {
        if (EXCEPTIONS.contains(fromName) || EXCEPTIONS.contains(toName)) {
            /**
             * Waaay too boring to set all the JAXB annotations for infra requests.
             */
            return TransportType.SERIALIZED_COMPRESSED;
        }
        return TransportType.XML;
    }
}
