/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm;

import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.collections.CollectionUtils;
import org.spec.jbb.core.collections.Mix;
import org.spec.jbb.core.generator.CustomerGenerator;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.probe.ProbeFactory;
import org.spec.jbb.util.JbbProperties;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * This class is responsible for handling customers available for SM.
 * 
 * Temporary this class also supports access to HQ for customer profile. Later
 * this functionality will be moved to customer cache.
 */
public class CustomerSelection implements Measurable {

    /**
     * Mix of local and remote customers to determine local or remote customer
     * should be picked up next
     */
    private final Mix<CustomerType> lrMix;

    /**
     * Local customer hotness
     */
    private final CustomerHotness localCustomers;

    /**
     * Remote customer hotness
     */
    private final CustomerHotness remoteCustomers;

    /**
     * Set of active customers
     */
    private final Set<Long> activeCustomers;

    /**
     * Specifies the position of customer in data structure for remove and
     * release operations
     */
    private final Map<Long, CustomerPosition> positionMap;

    private volatile Probe probe;

    public CustomerSelection(SM sm) {
        this.positionMap = new ConcurrentHashMap<>();

        CustomerGenerator cg = new CustomerGenerator();

        Collection<Long> localIDs = cg.getLocalCustomerIDsForSM(sm.getName());
        localCustomers = generateHotness(CustomerType.LOCAL, localIDs);

        Collection<Long> remoteIDs = cg.getRemoteCustomerIDsForSM(sm.getName());
        remoteCustomers = generateHotness(CustomerType.REMOTE, remoteIDs);

        this.lrMix = CollectionUtils.getFixedMix(
                new CustomerType[] {
                        CustomerType.LOCAL,
                        CustomerType.REMOTE
                },
                new int[] {
                        localIDs.size(),
                        remoteIDs.size()
                }
        );

        activeCustomers = Collections.newSetFromMap(new ConcurrentHashMap<Long, Boolean>());

        probe = ProbeFactory.getDefaultProbe();
    }

    private CustomerHotness generateHotness(CustomerType type, Collection<Long> ids) {

        final int HOTNESS_UPPER_BOUND = JbbProperties.getInstance().getCustomerHotnessUpperBound();

        Mix<Integer> hotnessGeneratorMix = CollectionUtils.getRangeMix(new Random(JbbProperties.getInstance().getRandomSeed()), 0, HOTNESS_UPPER_BOUND);

        Collection<CustomerPosition> positions = new ArrayList<>(ids.size());
        for (long id : ids) {
            CustomerPosition position = new CustomerPosition(id, type, hotnessGeneratorMix.next());
            positions.add(position);
            positionMap.put(id, position);
        }
        return new CustomerHotness(HOTNESS_UPPER_BOUND, positions);
    }

    /**
     * Gets the customer hotness for specified id.
     * 
     * @param id of the customer
     * @return hotness of the customer
     */
    public int getCustomerHotness(long id) {
        CustomerPosition cp = positionMap.get(id);
        return cp.hotness;
    }
    
    public boolean isCustomerActive(long id) {
        return activeCustomers.contains(id);
    }

    private CustomerHotness getCustomerHotness(CustomerType type) {
        return type == CustomerType.LOCAL ? localCustomers : remoteCustomers;
    }

    /**
     * Returns the idle customer id and lock it. This id will not be returned by
     * this method until releaseCustomer(id) method is invoked with this id as a
     * parameter.
     * 
     * @return customer ID
     */
    public long getAndLockNextCustomerID() {

        /**
         * Try to pick up the customer:
         *  - if target customer type have no customers, then fallback to other type
         *  - in (unlikely) case other type is empty as well, terminate
         *
         * This method is running in deterministic time, and also detects benchmark misconfiguration.
         */
        Long id;

        CustomerType type = lrMix.next();
        id = getCustomerHotness(type).getCustomerID();
        if (id == null) {
            id = getCustomerHotness(other(type)).getCustomerID();
            if (id == null) {
                throw new IllegalStateException("Unable to pick up customer (not enough customers?)");
            }
        }

        activeCustomers.add(id);
        return id;
    }

    /**
     * Release the customer id. After invocation of this method
     * getAndLockNextCustomer method can return this customer id.
     * 
     * Before making this customer ID available for picking up this method
     * checks whether this customer should be deleted. If it should be deleted
     * then customer is deleted.
     * 
     * @param id
     *            customer id
     */
    public void releaseCustomerID(long id) {
        CustomerPosition p = positionMap.get(id);
        activeCustomers.remove(id);
        getCustomerHotness(p.type).releaseCustomerID(p);
    }

    /**
     * Return approximation of idle customers. If the customer is on his way
     * from active list to passive one or vice versa then customer is not
     * accounted.
     * 
     * @return the number of idle customers
     */
    public int getSize() {
        return localCustomers.getSize() + remoteCustomers.getSize() - activeCustomers.size();
    }

    @Override
    public void instrument(Probe probe) {
        this.probe = probe;
    }

    @Override
    public void sample() {
        probe.sample("customers.local", localCustomers.getSize());
        probe.sample("customers.remote", remoteCustomers.getSize());
        probe.sample("customers.active", activeCustomers.size());
    }

    public static CustomerType other(CustomerType type) {
        return type == CustomerType.LOCAL ? CustomerType.REMOTE : CustomerType.LOCAL;
    }

    /**
     * This class represent the type of the customer relating to SM
     */
    public static enum CustomerType {
        LOCAL, REMOTE
    }

    /**
     * The class describes the location of the customer to simplify release or
     * remove operations.
     * 
     */
    private static class CustomerPosition {
        public final long id;
        public final CustomerType type;
        public final int hotness;

        public CustomerPosition(long id, CustomerType type, int hotness) {
            this.id = id;
            this.type = type;
            this.hotness = hotness;
        }

        @Override
        public String toString() {
            return "{id=" + id + ",type=" + type + ",hotness=" + hotness + "}";
        }

    }

    private static class CustomerHotness {
        /**
         * ListMix for picking up the customer ID according to its weight
         */
        private final Mix<Integer> hotnessLevelMix;
        /**
         * Table keeping the customer IDs
         */
        private final List<Queue<Long>> hotnessTable;

        /**
         * Total number of active and passive customer
         */
        private final int size;
        private final int hotnessUpperBound;

        public CustomerHotness(int hotnessUpperBound, Collection<CustomerPosition> positions) {
            this.hotnessUpperBound = hotnessUpperBound;
            hotnessTable = new ArrayList<>();
            for (int i = 0; i < hotnessUpperBound; i++) {
                hotnessTable.add(new ConcurrentLinkedQueue<Long>());
            }

            int[] hotness = new int[hotnessTable.size()];
            for (CustomerPosition p : positions) {
                hotnessTable.get(p.hotness).add(p.id);
                hotness[p.hotness]++;
            }

            Integer[] levels = new Integer[hotnessTable.size()];
            for (int i = 0; i < hotness.length; i++) {
                levels[i] = i;
                hotness[i] *= (i+1);
            }

            hotnessLevelMix = CollectionUtils.getFixedMix(levels, hotness);

            this.size = positions.size();
        }

        public int getSize() {
            return size;
        }

        /**
         * Pick up the customer ID basing on weights. First pick up the hotness
         * level then poll first customer with this hotness level. If there is
         * no available customers with picked up hotness level then pick up
         * next hotness level. If all customers are removed then return null.
         * 
         * @return null if all customers are removed or id of customer
         */
        public Long getCustomerID() {
            // pick up hotness level. If there's no hotness levels available, just return
            Integer hotnessLevel = hotnessLevelMix.next();
            if (hotnessLevel == null) {
                return null;
            }

            // go for upper-levels first
            for (int i = hotnessLevel; i < hotnessUpperBound; i++) {
                Long id = hotnessTable.get(i).poll();
                if (id != null) {
                    return id;
                }
            }

            // go down (also, second chance to pick from this level again)
            for (int i = hotnessLevel; i >= 0; i--) {
                Long id = hotnessTable.get(i).poll();
                if (id != null) {
                    return id;
                }
            }
            return null;
        }

        /**
         * Put customer ID back to queue making his idle and available for
         * picking up
         * 
         * @param p
         *            location of the customer ID
         */
        public void releaseCustomerID(CustomerPosition p) {
            hotnessTable.get(p.hotness).add(p.id);
        }

        @Override
        public String toString() {
            return hotnessTable.toString();
        }
    }
}
