/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.onlinepurchase;

import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.collections.ConcurrentCreateHashMap;
import org.spec.jbb.core.collections.ConcurrentHashMultiSet;
import org.spec.jbb.core.collections.Window;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.probe.ProbeFactory;
import org.spec.jbb.util.InstanceFactory;
import org.spec.jbb.util.JbbProperties;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;

public class ProductReviewScoreBuckets implements Measurable, Serializable {

    private static final long serialVersionUID = 1549080115003381585L;
    private final ConcurrentHashMultiSet<Long> barcodeToScores;
    private final ConcurrentCreateHashMap<Integer, Window<Long>> scoreToBarcodes;
    private final int maxCustomerScoreBuckets;
    private final int maxBarcodesPerScore;

    private transient volatile Probe probe;

    public ProductReviewScoreBuckets() {
        super();

        maxCustomerScoreBuckets = JbbProperties.getInstance().getMaxCustomerScoreBuckets() - 1;
        maxBarcodesPerScore = JbbProperties.getInstance().getMaxBarcodesPerScore();

        barcodeToScores = new ConcurrentHashMultiSet<>();
        scoreToBarcodes = new ConcurrentCreateHashMap<>(new InstanceFactory<Window<Long>>() {
            private static final long serialVersionUID = 7629230269452142033L;

            @Override
            public Window<Long> getInstance() {
                return new Window<>(maxBarcodesPerScore);
            }
        });

        probe = ProbeFactory.getDefaultProbe();
    }

    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
        ois.defaultReadObject();
        probe = ProbeFactory.getDefaultProbe();
    }

    public void setScore(long barcode, int score) {
        barcodeToScores.setCount(barcode, score);

        // NOTE: Window is not synchronized, but we tolerate concurrent updates
        //       without synchronization for scalability reasons.
        scoreToBarcodes.getOrCreate(score).add(barcode);
    }

    public Long getRandomBarcode(int reviewScore) {
        if (reviewScore > maxCustomerScoreBuckets || reviewScore < 0) {
            return null;
        }

        return scoreToBarcodes.getOrCreate(reviewScore).getRandomValue();
    }

    public int getScore(long barcode) {
        return barcodeToScores.count(barcode);
    }

    @Override
    public void instrument(Probe probe) {
        this.probe = probe;
    }

    @Override
    public void sample() {
        probe.sample("barcodesToScore.size", barcodeToScores.elementSet().size());
        probe.sample("scoreToBarcodes.size", scoreToBarcodes.size()*maxBarcodesPerScore);
    }
}
