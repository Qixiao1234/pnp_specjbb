/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.db;

import java.io.Serializable;
import org.spec.jbb.core.collections.ConcurrentCreateHashMap;
import org.spec.jbb.core.collections.CreateMap;
import org.spec.jbb.core.collections.sampling.SamplingBuffer;
import org.spec.jbb.core.collections.sampling.SamplingBufferFactory;
import org.spec.jbb.util.InstanceFactory;

public class DataMiningStorage<E> implements Serializable {

    private static final long serialVersionUID = 8002255752576307546L;

    private final CreateMap<String, SamplingBuffer<E>> buffers;
    private final int lodeSize;

    public DataMiningStorage(final int lodeSize) {
        buffers = new ConcurrentCreateHashMap<>(
                new InstanceFactory<SamplingBuffer<E>>() {
                    private static final long serialVersionUID = -6501033623147076942L;

                    @Override
                    public SamplingBuffer<E> getInstance() {
                        return SamplingBufferFactory.getInstance(lodeSize);
                    }
                } );

        this.lodeSize = lodeSize;
    }

    /*
     * Add the element for data mining.
     */
    public void add(E element, String filter) {
        buffers.getOrCreate(filter).put(element);
    }

    /*
     * Retrieve a cursor over a sample of collected data.
     */
    public DataMiningCursor<E> cursor(String filter) {
        return new DataMiningCursor<>(buffers.getOrCreate(filter).snapshot(), lodeSize);
    }

}
