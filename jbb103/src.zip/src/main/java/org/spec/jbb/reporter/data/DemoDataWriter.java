/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter.data;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.spec.jbb.core.Conventions;
import org.spec.jbb.core.comm.AbstractConnectionClient;
import org.spec.jbb.core.comm.ConnectionClient;
import org.spec.jbb.core.comm.Request;
import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.reporter.Frame;

public class DemoDataWriter extends AbstractConnectionClient implements DataWriter {

    private volatile String listener;
    
    public DemoDataWriter() {
        super("DemoDataWriter");
    }

    @Override
    public void open(ConnectionClient client) throws IOException {
        client.getLink().register(this);
        while(listener == null) {
            Logger.getLogger(DemoDataWriter.class.getName()).log(Level.INFO, "Wait for client...");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(DemoDataWriter.class.getName()).log(Level.SEVERE, null, ex);
                break;
            }
        }
        Logger.getLogger(DemoDataWriter.class.getName()).log(Level.INFO, "Listener is " + listener);
    }

    @Override
    public void write(Frame frame) throws IOException {
        if(listener != null) {
            getLink().sendRequest(listener, Conventions.TIER_INFRA, new DemoRequest(frame));
        }
    }

    @Override
    public void flush() throws IOException {
    }

    @Override
    public void close() {
    }

    @Override
    public List<Response> handle(String from, List<Request> requests, int currentTier, int targetTier) {
        for (Request r : requests) {
            Logger.getLogger(DemoDataWriter.class.getName()).log(Level.INFO, "Got request " + r + " from " + from);
            if (listener == null) {
                if (r instanceof DemoAttachRequest) {
                    listener = from;
                    break;
                }
            }
        }
        return Collections.nCopies(requests.size(), (Response)new OkResponse());
    }
    
}
