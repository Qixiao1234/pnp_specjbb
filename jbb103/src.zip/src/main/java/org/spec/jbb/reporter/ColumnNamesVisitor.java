/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

import org.spec.jbb.infra.ProfileData;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class ColumnNamesVisitor implements Visitor {

    private Set<String> names = new HashSet<>();

    @Override
    public void visit(StatsFrame point) {
        ProfileData profileData = point.getProfileData();
        names.addAll(profileData.getKeys());
    }

    @Override
    public boolean shouldRun() {
        return true;
    }

    public Collection<String> getNames() {
        return names;
    }
}
