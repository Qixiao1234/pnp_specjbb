/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.discount.Discount;
import org.spec.jbb.sm.discount.DiscountAgent;
import org.spec.jbb.sm.tx.request.DiscountIssueRequest;
import org.spec.jbb.sm.tx.response.DiscountIssueResponse;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DiscountIssueTransaction extends AbstractSMTransaction {

    private final DiscountAgent agent;
    
    public DiscountIssueTransaction(SM sm, DiscountIssueRequest req, TransactionContext ctx) {
        super(sm, ctx);
        this.agent = storage.getDiscountAgent();
    }

    @Override
    public Response execute() {
        if (agent.reserveSlot()) {
            List<Discount> batch = null;
            try {
                batch = agent.createDiscountBatch();
                List<Long> barcodes = new ArrayList<>(batch.size());
                for (Discount d : batch) {
                    // Add discount to Inventory
                    inventory.setDiscount(d);
                    barcodes.add(d.getBarcode());
                }
                // modify hotness
                purchaseAgent.updateHotness(barcodes, sm.getDiscountHotnessShift());
                return new DiscountIssueResponse(true);
            } finally {
                agent.addDiscountBatch(batch == null ? Collections.<Discount>emptyList() : batch);
            }
        }
        return new DiscountIssueResponse(false);
    }

    @Override
    public String toString() {
        return "DiscountIssueTx";
    }

}
