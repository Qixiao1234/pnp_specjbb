/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.request;

import org.spec.jbb.core.comm.AbstractRequest;
import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.GetSuggestedAdvertisementTransaction;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
public class GetSuggestedAdvertisementRequest extends AbstractRequest {

    private static final long serialVersionUID = 7115731575386979940L;
    @XmlElement
    private final String smName;
    
    private GetSuggestedAdvertisementRequest() {
        // JAXB
        this(null);
    }

    public GetSuggestedAdvertisementRequest(String smName) {
        this.smName = smName;
    }
    
    public String getSmName() {
        return smName;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        GetSuggestedAdvertisementRequest that = (GetSuggestedAdvertisementRequest) o;

        if (smName != null ? !smName.equals(that.smName) : that.smName != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), smName);
    }

    @Override
    public String toString() {
        return "Request suggested advertisement for SM " + smName;
    }

    @Override
    public Transaction getTransaction(HQ hq, TransactionContext ctx) {
        return new GetSuggestedAdvertisementTransaction(hq, this, ctx);
    }
}
