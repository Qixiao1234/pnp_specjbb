/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections.queues;

import org.spec.jbb.util.JbbProperties;

import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.LinkedBlockingQueue;

public class QueueFactory {

    private QueueFactory() {
        // prevent instantiation
    }

    public static <E> Queue<E> getBoundedQueue(int capacity) {
        return getBoundedQueue(JbbProperties.getInstance().getBoundedBlockingQueueType(), capacity);
    }

    public static <E> Queue<E> getBoundedQueue(QueueType type, int capacity) {
        int stripes = JbbProperties.getInstance().getQueueStripeCount();
        switch (type) {
            case ABQ:
                return new ArrayBlockingQueue<>(capacity);
            case ABQ_STRIPED:
                return new StripedArrayBlockingQueue<>(capacity, stripes);
            case LBQ:
                return new LinkedBlockingQueue<>(capacity);
            case LBQ_STRIPED:
                return new StripedLinkedBlockingQueue<>(capacity, stripes);
            default:
                throw new IllegalArgumentException("Bounded queue implementation is N/A: " + type);
        }
    }

    public static <E> Queue<E> getUnboundedQueue() {
        return getUnboundedQueue(JbbProperties.getInstance().getUnboundedBlockingQueueType());
    }

    public static <E> Queue<E> getUnboundedQueue(QueueType type) {
        int stripes = JbbProperties.getInstance().getQueueStripeCount();
        switch (type) {
            case CLQ:
                return new ConcurrentLinkedQueue<>();
            case CLQ_STRIPED:
                return new StripedConcurrentLinkedQueue<>(Integer.MAX_VALUE, stripes);
            case LBQ:
                return new LinkedBlockingQueue<>();
            case LBQ_STRIPED:
                return new StripedLinkedBlockingQueue<>(Integer.MAX_VALUE, stripes);
            default:
                throw new IllegalArgumentException("Unbounded queue implementation is N/A: " + type);
        }
    }

    public static <E extends Delayed> Queue<E> getDelayQueue() {
        return getDelayQueue(JbbProperties.getInstance().getDelayQueueType());
    }

    public static <E extends Delayed> Queue<E> getDelayQueue(QueueType type) {
        int stripes = JbbProperties.getInstance().getQueueStripeCount();
        switch (type) {
            case DELAYQ:
                return new DelayQueue<>();
            case DELAYQ_STRIPED:
                return new StripedDelayQueue<>(stripes);
            default:
                throw new IllegalArgumentException("Delay queue implementation is N/A: " + type);
        }
    }
}
