/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport.encapsulation;

import org.spec.jbb.core.comm.transport.Data;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class JavaSerializationEncapsulationLayer<T> implements EncapsulationLayer<T> {

    @Override
    public Data convertDown(T topInstance) {
        ByteArrayOutputStream os = new ByteArrayOutputStream();

        try (
            ObjectOutputStream oos = new ObjectOutputStream(os)
        ) {
            oos.writeObject(topInstance);
        } catch (IOException e) {
            throw new IllegalStateException("Serialization transport encountered exception", e);
        }

        return Data.wrap(os);
    }

    @Override
    public T convertUp(Data bottomInstance) {
        try (
            ObjectInputStream ois = new ObjectInputStream(bottomInstance.getStream())
        ) {
            return (T) ois.readObject();
        } catch (ClassCastException | ClassNotFoundException | IOException e) {
            throw new IllegalStateException("Serialization transport encountered exception", e);
        }
    }
}
