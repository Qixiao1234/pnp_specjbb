/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.objectpool;

import org.spec.jbb.util.InstanceFactory;

import java.util.Deque;
import java.util.concurrent.ConcurrentLinkedDeque;


public class SimplePool<V> {

    private final Deque<V> queue;
    private final InstanceFactory<V> factory;

    public SimplePool(InstanceFactory<V> factory) {
        this.factory = factory;
        queue = new ConcurrentLinkedDeque<>();
    }

    public V acquire() {
        V value = queue.poll();
        return value == null ? factory.getInstance() : value;
    }

    public void release(V object) {
        queue.push(object);
    }

}
