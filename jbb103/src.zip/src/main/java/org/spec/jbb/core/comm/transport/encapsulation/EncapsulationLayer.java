/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport.encapsulation;

import org.spec.jbb.core.comm.transport.Data;
import org.spec.jbb.core.comm.transport.Layer;

public interface EncapsulationLayer<TT> extends Layer<TT, Data> {
}
