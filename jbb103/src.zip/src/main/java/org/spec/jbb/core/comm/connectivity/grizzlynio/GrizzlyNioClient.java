/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity.grizzlynio;

import org.glassfish.grizzly.Connection;
import org.glassfish.grizzly.GrizzlyFuture;
import org.glassfish.grizzly.filterchain.BaseFilter;
import org.glassfish.grizzly.filterchain.FilterChainContext;
import org.glassfish.grizzly.filterchain.NextAction;
import org.spec.jbb.core.comm.Packet;
import org.spec.jbb.core.comm.connectivity.Client;
import org.spec.jbb.core.comm.connectivity.grizzlynio.proto.ProtocolDataUnit;
import org.spec.jbb.core.objectpool.ObjectPool;
import org.spec.jbb.core.objectpool.PoolException;
import org.spec.jbb.core.threadpools.SettableFuture;
import org.spec.jbb.util.JbbProperties;

import java.io.IOException;
import java.net.InetAddress;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class GrizzlyNioClient implements Client {

    private final ObjectPool<Destination, PoolableConnection> pool;
    private final String hostName;
    private final int port;

    public GrizzlyNioClient(ObjectPool<Destination, PoolableConnection> pool, String hostName, int port) {
        this.pool = pool;
        this.hostName = hostName;
        this.port = port;
    }

    private ProtocolDataUnit send(ProtocolDataUnit unit) throws IOException, InterruptedException {
        Destination dest = new Destination(hostName, port);

        // acquire connection
        PoolableConnection pc;
        try {
            pc = pool.acquire(dest);
        } catch (PoolException e) {
            throw new IOException("NIO Client threw unexpected exception", e);
        }
        
        final Future<ProtocolDataUnit> adaptedFuture = pc.prepare();
        final Connection connection = pc.getConn();

        // write
        try {
            GrizzlyFuture writeFuture = connection.write(unit);
            writeFuture.get(JbbProperties.getInstance().getWriteTimeout(), TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            pool.destroy(dest, pc);
            Thread.currentThread().interrupt();
            throw e;
        } catch (ExecutionException | TimeoutException e) {
            pool.destroy(dest, pc);
            throw new IOException("Unable to write: ", e);
        }

        // read
        ProtocolDataUnit rcvMessage;
        try {
            rcvMessage = adaptedFuture.get(JbbProperties.getInstance().getReadTimeout(), TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            pool.destroy(dest, pc);
            Thread.currentThread().interrupt();
            throw e;
        } catch (ExecutionException | TimeoutException e) {
            pool.destroy(dest, pc);
            throw new IOException("Unable to read: ", e);
        }

        if (rcvMessage == null) {
            pool.destroy(dest, pc);
            throw new IOException("NIO Client had not received the acknowledgement");
        }

        pool.release(dest, pc);

        return rcvMessage;
    }

    @Override
    public Packet send(Packet packet) throws IOException, InterruptedException {
        ProtocolDataUnit unit = new ProtocolDataUnit(packet);
        ProtocolDataUnit response = send(unit);

        if (packet.shouldBeAnswered()) {
            return response.toPacket();
        } else {
            return Packet.NO_DATA;
        }
    }

    @Override
    public String resolveMyIp() throws IOException, InterruptedException {
        ProtocolDataUnit response = send(new ProtocolDataUnit(ProtocolDataUnit.Type.IP_REQUEST, null, null));
        if (response.getType() == ProtocolDataUnit.Type.IP_DATA) {
            InetAddress address = InetAddress.getByAddress(response.getBody());
            return address.getHostAddress();
        }
        throw new IOException("IP resolution failed");
    }

    public static final class CustomClientFilter extends BaseFilter
            implements FutureHolder {
        private volatile SettableFuture<ProtocolDataUnit> resultFuture;

        @Override
        public void resetFuture(SettableFuture<ProtocolDataUnit> resultFuture) {
            this.resultFuture = resultFuture;
        }
        
        @Override
        public NextAction handleRead(FilterChainContext ctx) throws IOException {
            final ProtocolDataUnit message = ctx.getMessage();
            resultFuture.set(message);
            return ctx.getStopAction();
        }

        @Override
        public void exceptionOccurred(FilterChainContext ctx, Throwable error) {
            super.exceptionOccurred(ctx, error);
            resultFuture.setException(error);
        }
    }

}
