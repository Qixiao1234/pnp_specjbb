/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.executor;

public abstract class AbstractBatchRouter implements BatchRouter {

    private final String name;
    private final String[] targetNames;

    public AbstractBatchRouter(String name, String... targetNames) {
        this.name = name;
        this.targetNames = targetNames;
    }

    protected String[] getTargets() {
        return targetNames;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void shutdown() {
        // do nothing
    }

}
