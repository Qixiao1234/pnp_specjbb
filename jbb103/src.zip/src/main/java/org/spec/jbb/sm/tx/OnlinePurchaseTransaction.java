/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx;

import org.spec.jbb.core.Topology;
import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.onlinepurchase.OnlinePurchaseAgent;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.entity.Product;
import org.spec.jbb.hq.entity.Receipt;
import org.spec.jbb.hq.tx.request.CheckAndReserveCreditRequest;
import org.spec.jbb.hq.tx.request.CustomerRatingProductResolveRequest;
import org.spec.jbb.hq.tx.request.DrawCreditRequest;
import org.spec.jbb.hq.tx.request.FindCustomerZipRequest;
import org.spec.jbb.hq.tx.request.GetProductReviewScoreRequest;
import org.spec.jbb.hq.tx.request.PurchaseReceiptMessage;
import org.spec.jbb.hq.tx.request.StoreOrderMessage;
import org.spec.jbb.hq.tx.response.CustomerRatingProductResolveResponse;
import org.spec.jbb.hq.tx.response.FindCustomerZipResponse;
import org.spec.jbb.hq.tx.response.ProductReviewScoreResponse;
import org.spec.jbb.sm.ReceiptBuilder;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.ShoppingCartItem;
import org.spec.jbb.sm.entity.InStorePickupOrder;
import org.spec.jbb.sm.entity.Order;
import org.spec.jbb.sm.entity.ShippingOrder;
import org.spec.jbb.sm.tx.request.MoveoutInventoryRequest;
import org.spec.jbb.sm.tx.request.OnlinePurchaseRequest;
import org.spec.jbb.sm.tx.request.ReserveInventoryRequest;
import org.spec.jbb.sm.tx.request.UnreserveInventoryRequest;
import org.spec.jbb.sm.tx.response.MoveoutInventoryResponse;
import org.spec.jbb.sm.tx.response.ReserveInventoryResponse;
import org.spec.jbb.util.JbbProperties;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

public final class OnlinePurchaseTransaction extends AbstractPurchaseTransaction {

    private final Topology topology;
    private final String targetSM;
    private final boolean instorePickup;

    public OnlinePurchaseTransaction(SM sm, OnlinePurchaseRequest req, TransactionContext ctx) {
        super(sm, req, ctx);
        this.topology = sm.getTopology();
        OnlinePurchaseAgent purchaseAgent = sm.getOnlinePurchaseAgent();
        targetSM = purchaseAgent.getSM(sm);
        instorePickup = purchaseAgent.isInstorePickup();
    }

    @Override
    protected boolean doPurchase(Product product, int quantity) throws TransactionException {
        long barcode = product.getBarcode();
        BigDecimal price = product.getPrice();

        int reservedQty = reserveInventory(targetSM, barcode, quantity);
        int totalReservedQty = addToShoppingcart(targetSM, reservedQty, barcode, price, 0);

        if (quantity > totalReservedQty) {
            for (String otherSMName : getOtherSMList()) {
                reservedQty = reserveInventoryRequest(otherSMName, barcode, quantity - totalReservedQty);
                totalReservedQty = addToShoppingcart(otherSMName, reservedQty, barcode, price, totalReservedQty);
                if (quantity <= totalReservedQty) {
                    break;
                }
            }
        }

        return quantity == totalReservedQty;
    }

    @Override
    protected void doCheckout() throws TransactionException {
        replace();

        /**
         * Generate receipt
         */
        Receipt receipt = ReceiptBuilder.build(sm.getNextReceiptNumber(), shoppingCart, sm.getName(), null);

        BigDecimal totalPrice = receipt.getTotal();

        final String targetHQ = sm.resolveCustomer(ctx, customerId);

        Response creditResponse = ctx.sendRequest(targetHQ, new CheckAndReserveCreditRequest(customerId, totalPrice));
        if (creditResponse instanceof OkResponse) {

            Map<String, Order> orders = new HashMap<>();
            for (ShoppingCartItem item : shoppingCart) {
                String smName = item.getSmName();
                long barcode = item.getBarcode();
                int quantity = item.getQuantity();

                moveOutInventory(smName, barcode, quantity);

                Order order = orders.get(smName);
                if (order == null) {
                    if (instorePickup) {
                        order = new InStorePickupOrder(customerId);
                    } else {
                        String zipcode = findCustomerZipcode(targetHQ);
                        order = new ShippingOrder(customerId, zipcode);
                    }
                    orders.put(smName, order);
                }
                order.addItem(barcode, quantity);
            }

            ctx.sendRequest(targetHQ, new DrawCreditRequest(customerId, totalPrice));
            ctx.sendMessage(owningHQ, new PurchaseReceiptMessage(receipt));

            for (Entry<String, Order> entry : orders.entrySet()) {
                String superMarket = entry.getKey();
                Order order = entry.getValue();
                ctx.sendMessage(topology.getHQNameForSM(superMarket), new StoreOrderMessage(order));
            }
        } else {
            throw new NotEnoughCreditException("Not enough credit, got " + creditResponse);
        }
    }

    private void replace() throws TransactionException {
        int numOfItemsToReplace = sm.getNumEditPositions();

        int shoppingcartSize = shoppingCart.size();
        if (shoppingcartSize > numOfItemsToReplace) {
            int randomIndex = ThreadLocalRandom.current().nextInt(shoppingcartSize - numOfItemsToReplace);
            
            List<ShoppingCartItem> replaceItems = new ArrayList<>(shoppingCart.getItemSublist(randomIndex, randomIndex + numOfItemsToReplace));
            for (ShoppingCartItem item : replaceItems) {
                Long barcode = item.getBarcode();
                int qty = item.getQuantity();
                String smName = item.getSmName();

                Long replaceBarcode = getReplacementBarcode(barcode);
                if (replaceBarcode != null) {
                    int reservedQty = reserveInventory(smName, replaceBarcode, qty);

                    if (reservedQty > 0) {
                        unreserveInventory(smName, barcode, qty);
                        Product replaceProduct = resolveProduct(replaceBarcode);
                        shoppingCart.removeItem(item);
                        shoppingCart.add(replaceBarcode, reservedQty, replaceProduct.getPrice(), smName);
                    }
                }
            }
        }
    }

    private Long getReplacementBarcode(Long barcode) throws TransactionException {
        Response response = ctx.sendRequest(owningHQ, new GetProductReviewScoreRequest(barcode));
        if (response instanceof ProductReviewScoreResponse) {
            int currentProductScore = ((ProductReviewScoreResponse) response).getRating();

            // the product is highly rated so do nothing
            int maxCustomerScoreBuckets = sm.getMaxCustomerScoreBuckets();
            if (currentProductScore > maxCustomerScoreBuckets / 2) {
                return null;
            }

            int rating = ThreadLocalRandom.current().nextInt(currentProductScore,
                    maxCustomerScoreBuckets);

            Response response1 = ctx.sendRequest(owningHQ, new CustomerRatingProductResolveRequest(rating));
            if (response1 instanceof CustomerRatingProductResolveResponse) {
                return ((CustomerRatingProductResolveResponse) response1).getBarcode();
            }
        }
        throw new TransactionException("Product Review Barcode failed");
   }

    private void unreserveInventory(String smName, long barcode, int qty) throws TransactionException {
        if (smName.equals(sm.getName())) {
            unreserveProduct(barcode, qty);
        } else {
            Response response = ctx.sendRequest(smName, new UnreserveInventoryRequest(barcode, qty));
            if (!(response instanceof OkResponse)) {
                throw new TransactionException("Unreserving inventory failed");
            }
         }
     }

    private int reserveInventory(String smName, long barcode, int qty) throws TransactionException {
        if (smName.equals(sm.getName())) {
            return reserveProduct(barcode, qty);
        } else {
            return reserveInventoryRequest(smName, barcode, qty);
        }
    }
    
    private int reserveInventoryRequest(String smName, long barcode, int qty) throws TransactionException {
        Response response = ctx.sendRequest(smName, new ReserveInventoryRequest(barcode, qty));
        if (response instanceof ReserveInventoryResponse) {
            return ((ReserveInventoryResponse) response).getQuantity();
        } else {
            throw new TransactionException("Reserving inventory failed");
        }
    }

    private String findCustomerZipcode(String targetHQ) throws TransactionException {
        Response re = ctx.sendRequest(targetHQ, new FindCustomerZipRequest(customerId));
        if (re instanceof FindCustomerZipResponse) {
            return ((FindCustomerZipResponse) re).getZipcode();
        } else {
            throw new TransactionException("Finding customer barcode failedd");
        }
    }

    private List<String> getOtherSMList() {
        Set<String> smSet = new HashSet<>();
        if(JbbProperties.getInstance().getOnlinePurchaseOnlyLocal()) {
            smSet.addAll(topology.getSMforHQ(owningHQ));
        } else {
            smSet.addAll(topology.getSMnames());
        }
        smSet.remove(sm.getName());

        if (smSet.size() > 0) {
            List<String> smList = new ArrayList<>();
            smList.addAll(smSet);
            Collections.shuffle(smList, ThreadLocalRandom.current());
            return smList;
        } else {
            return Collections.emptyList();
        }
    }

    private int addToShoppingcart(String targetSM, int reservedQty, long barcode, BigDecimal price, int totalReservedQty) {
        if (reservedQty > 0) {
            shoppingCart.add(barcode, reservedQty, price, targetSM);
            return totalReservedQty + reservedQty;
        }
        return totalReservedQty;
    }

    private void moveOutInventory(String smName, long barcode, int quantity) throws TransactionException {
        if (sm.getName().equals(smName)) {
            moveOut(barcode, quantity);
        } else {
            Response response = ctx.sendRequest(smName, new MoveoutInventoryRequest(barcode, quantity));
            if (!(response instanceof MoveoutInventoryResponse)) {
                throw new TransactionException("Moving out of inventory failed");
            }
        }
    }

    @Override
    public String toString() {
        return super.toString() + ", online, inStorePickup={" + instorePickup + "}";
    }

}
