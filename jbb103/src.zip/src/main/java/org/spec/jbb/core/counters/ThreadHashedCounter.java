/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

/*
 * Written by Doug Lea with assistance from members of JCP JSR-166
 * Expert Group and released to the public domain, as explained at
 * http://creativecommons.org/publicdomain/zero/1.0/
 */

package org.spec.jbb.core.counters;

import org.spec.jbb.util.JbbProperties;

import java.io.Serializable;
import java.util.concurrent.atomic.AtomicLong;

/** 
 * A counter based on an array of counts. Each thread increments the
 * count at an index based on its hash code. Method get() collects all
 * counts non-atomically, so may return stale values. The array size
 * is configured to be the power of two nearest to the property
 * getThreadHashCounterCapBound().
 */
public class ThreadHashedCounter implements Counter, Serializable {

    public static final long serialVersionUID = 1L;

    static final int CAP = cap();
    static int cap() {
        int p = JbbProperties.getInstance().getThreadHashCounterCapBound();
        int c = 1;
        while (c < p) 
            c <<= 1;
        return c;
    }

    /**
     * The counters. Currently all initialized upon construction, but
     * accessors null check to simplify lazier initialization in the
     * future.
     */ 
    private final AtomicLong[] counters;

    public ThreadHashedCounter() {
        AtomicLong[] cs = new AtomicLong[CAP];
        for (int i = 0; i < CAP; ++i)
            cs[i] = new AtomicLong();
        counters = cs;
    }

    @Override
    public void inc(long d) {
        AtomicLong[] cs = counters;

        /**
        * Returns a hash index for the current thread.  Uses a one-step
        * FNV-1a hash code (http://www.isthe.com/chongo/tech/comp/fnv/)
        * based on the current thread's Thread.getId().
        */
        long id = Thread.currentThread().getId();
        int hash = (((int)(id ^ (id >>> 32))) ^ 0x811c9dc5) * 0x01000193;
        int i = hash & (cs.length - 1);
        AtomicLong a = cs[i];
        long v;
        do {
            v = a.get();
        } while (!a.compareAndSet(v, v + d));
    }

    @Override
    public long get() {
        AtomicLong[] cs = counters;
        long sum = 0L;
        for (AtomicLong a : cs) {
            if (a != null) {
                sum += a.get();
            }
        }
        return sum;
    }

    @Override
    public long getAndReset() {
        AtomicLong[] cs = counters;
        long sum = 0L;
        for (AtomicLong a : cs) {
            if (a != null) {
                long v;
                do {
                    v = a.get();
                } while (!a.compareAndSet(v, 0L));
                sum += v;
            }
        }
        return sum;
    }

    @Override
    public void reset() {
        AtomicLong[] cs = counters;
        for (AtomicLong a : cs) {
            if (a != null) {
                a.set(0L);
            }
        }
    }
    
    public String toString() {
        return "" + get();
    }
}