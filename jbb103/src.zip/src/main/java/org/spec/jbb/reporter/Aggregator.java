/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

import java.util.List;

public interface Aggregator {
    Double aggregate(List<Double> values);
}
