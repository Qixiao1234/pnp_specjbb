/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.locks;

import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.probe.Probe;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class ProfileRWLockAdapter implements ReadWriteLock, Measurable {

    private final String prefix;
    private final ReentrantReadWriteLock backingLock;

    private final ConcurrentMap<Lock, ProfileLockAdapter> adapters;

    private volatile Probe probe;

    public ProfileRWLockAdapter(String prefix, ReentrantReadWriteLock backingLock) {
        this.prefix = prefix;
        this.backingLock = backingLock;
        this.adapters = new ConcurrentHashMap<>();
    }

    public String getPrefix() {
        return prefix;
    }

    @Override
    public void instrument(Probe probe) {
        this.probe = probe;
        for (ProfileLockAdapter adapter : adapters.values()) {
            adapter.instrument(probe.getChild(adapter.getPrefix()));
        }
    }

    @Override
    public void sample() {
        probe.sample("waiters", backingLock.getQueueLength());
        for (ProfileLockAdapter adapter : adapters.values()) {
            adapter.sample();
        }
    }

    @Override
    public Lock readLock() {
        Lock lock = backingLock.readLock();

        ProfileLockAdapter adapter = adapters.get(lock);
        if (adapter == null) {
            ProfileLockAdapter newAdapter = new ProfileLockAdapter("read", lock);
            ProfileLockAdapter extAdapter = adapters.putIfAbsent(lock, newAdapter);
            adapter = (extAdapter == null) ? newAdapter : extAdapter;
            adapter.instrument(probe.getChild(adapter.getPrefix()));
        }

        return adapter;
    }

    @Override
    public Lock writeLock() {
        Lock lock = backingLock.writeLock();

        ProfileLockAdapter adapter = adapters.get(lock);
        if (adapter == null) {
            ProfileLockAdapter newAdapter = new ProfileLockAdapter("write", lock);
            ProfileLockAdapter extAdapter = adapters.putIfAbsent(lock, newAdapter);
            adapter = (extAdapter == null) ? newAdapter : extAdapter;
            adapter.instrument(probe.getChild(adapter.getPrefix()));
        }

        return adapter;
    }
}
