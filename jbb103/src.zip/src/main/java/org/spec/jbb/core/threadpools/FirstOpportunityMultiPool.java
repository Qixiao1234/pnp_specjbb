/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

import org.spec.jbb.core.ExecutionHandler;
import org.spec.jbb.core.comm.Incoming;
import org.spec.jbb.core.comm.Response;

import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;

/**
 * This implementation makes multiple threadpools and forwards requests in "first opportunity" fashion.
 * <p/>
 * E.g. it will try to submit the batch for execution to the first pool.
 * It will move to next pool only if previous is not accepting the batches anymore.
 * Note: this implementation can overbloat first threadpools while leaving latest threadpools starving.
 *
 * @see RoundRobinMultiPool
 */
public class FirstOpportunityMultiPool extends AbstractMultiPool {

    public FirstOpportunityMultiPool(String name) {
        super(name);
    }

    @Override
    public Future<List<Response>> enqueueBatch(int tier, ExecutionHandler handler, List<? extends Incoming> b) {
        RejectedExecutionException up = null;
        for (Pool p : getPools()) {
            try {
                Future<List<Response>> future = p.enqueueBatch(tier, handler, b);
                return future;
            } catch(RejectedExecutionException e) {
                up = e;
            }
        }
        throw up; //whoops
    }

    @Override
    public Future<List<Response>> forceBatch(int tier, ExecutionHandler handler, List<? extends Incoming> batch) throws InterruptedException {
        return getPools().get(0).forceBatch(tier, handler, batch);
    }

    @Override
    public List<Response> processLocally(int tier, ExecutionHandler handler, List<? extends Incoming> requests) {
        return getPools().get(0).processLocally(tier, handler, requests);
    }

    @Override
    public void assistExecute(Runnable runnable) {
        getPools().get(0).assistExecute(runnable);
    }
}