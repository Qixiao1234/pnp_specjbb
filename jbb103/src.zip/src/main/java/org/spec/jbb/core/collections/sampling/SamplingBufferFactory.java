/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections.sampling;

import org.spec.jbb.util.JbbProperties;

public class SamplingBufferFactory {

    private SamplingBufferFactory() {
        // prevent instantiation
    }

    public static <T> SamplingBuffer<T> getInstance(int capacity) {
        return getInstance(JbbProperties.getInstance().getSamplingBufferType(), capacity);
    }

    public static <T> SamplingBuffer<T> getInstance(SamplingBufferType type, int capacity) {
        switch (type) {
            case QUEUED:
                return new QueuedSamplingBuffer<>(capacity);
            case CIRCULAR_ARRAY:
                return new CircularArraySamplingBuffer<>(capacity);
            case RANDOM_ARRAY:
                return new RandomArraySamplingBuffer<>(capacity);
            default:
                throw new IllegalArgumentException("Unknown sampling buffer type: " + type);
        }
    }

}
