/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity.plain;

import org.spec.jbb.core.comm.Packet;
import org.spec.jbb.core.comm.connectivity.Client;
import org.spec.jbb.core.comm.connectivity.HttpConstants;
import org.spec.jbb.core.comm.transport.Data;
import org.spec.jbb.core.comm.transport.TransportType;
import org.spec.jbb.util.StreamUtil;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

/**
 * EXPERIMENTAL JDK-based HTTP client
 *
 * This implementation is provided to test internal connectivity API.
 * Performance and correctness of this implementation is not guaranteed.
 */
public class PlainHttpClient implements Client {
    private URL dataURL;
    private URL resolveURL;

    public PlainHttpClient(String host, int port) {
        try {
            dataURL = new URL("http://" + host + ":" + port + "/Handler");
            resolveURL = new URL("http://" + host + ":" + port + "/ResolveIP");
        } catch (MalformedURLException e) {
            throw new IllegalArgumentException("URL is not valid", e);
        }
    }

    @Override
    public Packet send(Packet packet) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) dataURL.openConnection();
        connection.setReadTimeout((int)TimeUnit.SECONDS.toMillis(30));
        connection.setConnectTimeout((int)TimeUnit.SECONDS.toMillis(30));
        connection.setDoInput(true);
        connection.setDoOutput(true);

        connection.addRequestProperty(HttpConstants.HEADER_FROM, packet.getFrom());
        connection.addRequestProperty(HttpConstants.HEADER_TO, packet.getTo());
        connection.addRequestProperty(HttpConstants.HEADER_TRANSPORTTYPE, packet.getTransportType().toString());
        connection.addRequestProperty(HttpConstants.HEADER_SHOULDBEANSWERED, Boolean.toString(packet.shouldBeAnswered()));
        connection.addRequestProperty(HttpConstants.HEADER_TIER, Integer.toString(packet.getCurrentTier()));

        OutputStream outputStream = connection.getOutputStream();
        outputStream.write(packet.getData().getArray());
        outputStream.flush();
        outputStream.close();

        InputStream inputStream = connection.getInputStream();
        Data data = Data.wrap(StreamUtil.readFully(inputStream));
        inputStream.close();

        String from = connection.getHeaderField(HttpConstants.HEADER_FROM);
        String to = connection.getHeaderField(HttpConstants.HEADER_TO);
        TransportType type = TransportType.valueOf(connection.getHeaderField(HttpConstants.HEADER_TRANSPORTTYPE));
        boolean shouldBeAnswered = Boolean.valueOf(connection.getHeaderField(HttpConstants.HEADER_SHOULDBEANSWERED));
        int tier = Integer.valueOf(connection.getHeaderField(HttpConstants.HEADER_TIER));

        return new Packet(from, to, type, data, shouldBeAnswered, tier);
    }

    @Override
    public String resolveMyIp() throws IOException {
        HttpURLConnection connection = (HttpURLConnection) resolveURL.openConnection();
        connection.setDoOutput(true);
        InputStream inputStream = connection.getInputStream();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        StreamUtil.copy(inputStream, baos);
        return InetAddress.getByAddress(baos.toByteArray()).getHostAddress();
    }

}
