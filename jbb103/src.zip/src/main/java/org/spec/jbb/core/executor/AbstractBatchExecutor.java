/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.executor;

import org.spec.jbb.core.EntityType;
import org.spec.jbb.core.Topology;
import org.spec.jbb.core.comm.Message;
import org.spec.jbb.core.comm.Request;
import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.comm.Uplink;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.probe.ProbeFactory;
import org.spec.jbb.core.threadpools.Pool;
import org.spec.jbb.core.threadpools.Tiers;
import org.spec.jbb.core.tx.SimpleTransactionExecutor;
import org.spec.jbb.core.tx.TransactionExecutor;
import org.spec.jbb.core.tx.response.ErrorResponse;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.core.tx.response.RejectedResponse;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;

public abstract class AbstractBatchExecutor implements BatchExecutor {

    private final String name;
    private final EntityType type;

    private TransactionExecutor txExecutor;
    private Uplink link;

    private final Tiers tiers;
    protected volatile Probe probe;
    protected Topology topology;

    public AbstractBatchExecutor(EntityType type, String name) {
        this(type, name, new Tiers());
    }

    public AbstractBatchExecutor(EntityType type, String name, Tiers tiers) {
        this.type = type;
        this.name = name;

        this.txExecutor = new SimpleTransactionExecutor(name);
        this.probe = ProbeFactory.getDefaultProbe();
        this.topology = new Topology();

        this.tiers = tiers;
    }

    @Override
    public List<Response> handle(String from, List<Request> requests, int currentTier, int targetTier) {
        Pool pool = tiers.get(targetTier);

        /**
         * If possible, process locally.
         */
        if (targetTier == currentTier) {
            return pool.processLocally(targetTier, this, requests);
        }

        /**
         * If any request is durable, entire batch is durable.
         */
        boolean isDurable = false;
        for (Request request : requests) {
            if (request.isDurable()) {
                isDurable = true;
                break;
            }
        }

        /**
         * If any request requires response, entire batch requires response
         */
        boolean isRequiresResponse = false;
        for (Request request : requests) {
            if (request.isRequiresResponse()) {
                isRequiresResponse = true;
                break;
            }
        }

        /**
         * If batch is durable, make sure it gets accepted.
         */
        Future<List<Response>> future = null;

        boolean isAccepted = true;
        if (isDurable) {
                try {
                    future = pool.forceBatch(targetTier, this, requests);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return Collections.<Response>nCopies(requests.size(), new RejectedResponse());
                } catch (RejectedExecutionException e) {
                    isAccepted = false;
                }
        } else {
            try {
                future = pool.enqueueBatch(targetTier, this, requests);
            } catch (RejectedExecutionException e) {
                isAccepted = false;
            }
        }

        /**
         * If batch is accepted, wait for result.
         */
        if (isAccepted) {
            try {
                if (isRequiresResponse) {
                    if (future != null) {
                        return future.get();
                    } else {
                        return Collections.<Response>nCopies(requests.size(), new ErrorResponse("Null future"));
                    }
                } else {
                    return Collections.<Response>nCopies(requests.size(), new OkResponse());
                }
            } catch (CancellationException e) {
                return Collections.<Response>nCopies(requests.size(), new ErrorResponse("Cancelled", e));
            } catch (InterruptedException e) {
                return Collections.<Response>nCopies(requests.size(), new ErrorResponse("Interrupted", e));
            } catch (ExecutionException e) {
                return Collections.<Response>nCopies(requests.size(), new ErrorResponse("Execution exception", e));
            }
        } else {
            return Collections.<Response>nCopies(requests.size(), new RejectedResponse());
        }
    }

    @Override
    public void handleMessage(String sender, List<Message> messages, int currentTier, int targetTier) {

        Pool pool = tiers.get(targetTier);

        /**
         * If any message is durable, entire batch is durable.
         */
        boolean isDurable = false;
        for (Message message : messages) {
            if (message.isDurable()) {
                isDurable = true;
                break;
            }
        }

        /**
         * If batch is durable, make sure it gets accepted.
         */
        if (isDurable) {
            try {
                pool.forceBatch(targetTier, this, messages);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } catch (RejectedExecutionException e) {
                // do nothing: no way to communicate rejection for messages
            }
        } else {
            try {
                pool.enqueueBatch(targetTier, this, messages);
            } catch (RejectedExecutionException e) {
                // do nothing: no way to communicate rejection for messages
            }
        }
    }

    @Override
    public EntityType getType() {
        return type;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void shutdown() {
    }

    @Override
    public void instrument(Probe probe) {
        this.probe = probe;
        txExecutor.instrument(probe.getChild("transactions"));
    }

    @Override
    public void sample() {
        probe.sample("name", name);
        txExecutor.sample();
    }

    @Override
    public TransactionExecutor getTransactionExecutor() {
        return txExecutor;
    }

    @Override
    public void setUplink(Uplink link) {
        this.link = link;
    }

    public Uplink getLink() {
        return link;
    }

    public Topology getTopology() {
        return topology;
    }
}
