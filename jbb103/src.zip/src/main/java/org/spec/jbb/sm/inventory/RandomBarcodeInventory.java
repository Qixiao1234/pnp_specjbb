/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.inventory;

import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.sm.discount.Discount;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicReference;

/**
 * A class representing a Supermarket Inventory of Products using
 * a ConcurrentHashMap as the backing storage for the Products.
 * <p/>
 * Note: ConcurrentHashMap preserves atomicity when looking up and creating
 * QuantityInfo objects, then QuantityInfo preserves atomicity while
 * updating quantity counters.
 */
public class RandomBarcodeInventory implements Inventory, Serializable {

    private static final long serialVersionUID = -1983259857435987324L;

    private final ConcurrentMap<Long, AtomicQuantityInfo> inventory;

    public RandomBarcodeInventory(int size) {
        this.inventory = new ConcurrentHashMap<>(size);
    }

    @Override
    public int moveIn(long barcode, int quantity) {
        checkQuantity(quantity);
        AtomicQuantityInfo quantityInfo = lookupOrCreate(barcode);
        quantityInfo.in(quantity);
        return quantity;
    }

    private void checkQuantity(int quantity) {
        if (quantity < 0) {
            throw new IllegalArgumentException("quantity is negative");
        }
    }

    private AtomicQuantityInfo lookupOrCreate(long barcode) {
        return lookup(barcode, true);
    }

    private AtomicQuantityInfo lookupOrFail(long barcode) {
        AtomicQuantityInfo quantityInfo = lookup(barcode, false);
        if (quantityInfo == null) {
            throw new IllegalStateException("Product record is not existent");
        }
        return quantityInfo;
    }

    private AtomicQuantityInfo lookup(long barcode, boolean canCreate) {
        AtomicQuantityInfo quantityInfo = inventory.get(barcode);
        if (quantityInfo == null && canCreate) {
            quantityInfo = new AtomicQuantityInfo();
            AtomicQuantityInfo storedInfo = inventory.putIfAbsent(barcode, quantityInfo);
            if (storedInfo != null) {
                quantityInfo = storedInfo;
            }
        }
        return quantityInfo;
    }

    @Override
    public int reserve(long barcode, int quantity) {
        checkQuantity(quantity);
        AtomicQuantityInfo quantityInfo = lookupOrFail(barcode);
        return quantityInfo.reserve(quantity);
    }

    @Override
    public int unreserve(long barcode, int quantity) {
        checkQuantity(quantity);
        AtomicQuantityInfo quantityInfo = lookupOrFail(barcode);
        return quantityInfo.unreserve(quantity);
    }

    @Override
    public int moveOut(long barcode, int quantity) {
        checkQuantity(quantity);
        AtomicQuantityInfo quantityInfo = lookupOrFail(barcode);
        return quantityInfo.out(quantity);
    }

    @Override
    public int getQuantity(long barcode) {
        AtomicQuantityInfo quantityInfo = lookup(barcode, false);
        return quantityInfo == null ? 0 : quantityInfo.getTotal();
    }

    @Override
    public List<Long> toList() {
        List<Long> result = new ArrayList<>();
        result.addAll(inventory.keySet());
        return result;
    }

    @Override
    public int size() {
        return inventory.size();
    }

    @Override
    public void clearDiscount(Discount discount) {
        AtomicQuantityInfo quantityInfo = lookupOrFail(discount.getBarcode());
        quantityInfo.clearDiscount(discount);
    }

    @Override
    public void setDiscount(Discount discount) {
        AtomicQuantityInfo quantityInfo = lookupOrFail(discount.getBarcode());
        quantityInfo.setDiscount(discount);
    }

    @Override
    public Discount getDiscount(long barcode) {
        AtomicQuantityInfo quantityInfo = lookup(barcode, false);
        return quantityInfo == null ? null : quantityInfo.getDiscount();
    }

    @Override
    public void instrument(Probe probe) {
        // do nothing
    }

    @Override
    public void sample() {
        // do nothing
    }

    @Override
    public int updateReplenishInFlightQuantity(long barcode, int quantity) {
        AtomicQuantityInfo quantityInfo = lookupOrFail(barcode);
        return quantityInfo.updateReplenishInFlightQuantity(quantity);
    }

    @Override
    public int getReplenishInFlightQuantity(long barcode) {
        AtomicQuantityInfo quantityInfo = lookupOrFail(barcode);
        return quantityInfo.getReplenishInFlightQuantity();
    }

    /**
     * Atomically-updated quantity info for particular product.
     */
    private static class AtomicQuantityInfo extends AtomicReference<QuantityInfo> {

        private static final long serialVersionUID = -8738764328743263723L;

        public AtomicQuantityInfo() {
            super(new QuantityInfo());
        }

        public void in(int quantity) {
            QuantityInfo prevInfo, newInfo;
            do {
                prevInfo = get();
                newInfo = new QuantityInfo(prevInfo);
                newInfo.in(quantity);
            } while (!compareAndSet(prevInfo, newInfo));
        }

        public int reserve(int quantity) {
            QuantityInfo prevInfo, newInfo;
            int result;
            do {
                prevInfo = get();
                newInfo = new QuantityInfo(prevInfo);
                result = newInfo.reserve(quantity);
            } while (!compareAndSet(prevInfo, newInfo));
            return result;
        }

        public int unreserve(int quantity) {
            QuantityInfo prevInfo, newInfo;
            int result;
            do {
                prevInfo = get();
                newInfo = new QuantityInfo(prevInfo);
                result = newInfo.unreserve(quantity);
            } while (!compareAndSet(prevInfo, newInfo));
            return result;
        }

        public int out(int quantity) {
            QuantityInfo prevInfo, newInfo;
            int result;
            do {
                prevInfo = get();
                newInfo = new QuantityInfo(prevInfo);
                result = newInfo.out(quantity);
            } while (!compareAndSet(prevInfo, newInfo));
            return result;
        }

        public int getTotal() {
            QuantityInfo quantityInfo = get();
            return quantityInfo.available + quantityInfo.reserved;
        }

        public void setDiscount(Discount discount) {
            QuantityInfo prevInfo, newInfo;
            do {
                prevInfo = get();
                newInfo = new QuantityInfo(prevInfo);
                newInfo.setDiscount(discount);
            } while (!compareAndSet(prevInfo, newInfo));
        }

        public void clearDiscount(Discount discount) {
            QuantityInfo prevInfo, newInfo;
            do {
                prevInfo = get();
                newInfo = new QuantityInfo(prevInfo);
                newInfo.clearDiscount(discount);
            } while (!compareAndSet(prevInfo, newInfo));
        }

        public Discount getDiscount() {
            return get().getDiscount();
        }

        private int updateReplenishInFlightQuantity(int quantity) {
            QuantityInfo prevInfo, newInfo;
            do {
                prevInfo = get();
                newInfo = new QuantityInfo(prevInfo);
                newInfo.updateReplenishInFlightQuantity(quantity);
            } while (!compareAndSet(prevInfo, newInfo));
            return prevInfo.getReplenishInFlightQuantity();
        }

        private int getReplenishInFlightQuantity() {
            return get().getReplenishInFlightQuantity();
        }

    }

    private static class QuantityInfo implements Serializable {

        private static final long serialVersionUID = -463638783111987626L;

        private int available;
        private int reserved;
        private int replenishQuantityInFlight;
        private Discount discount;

        private QuantityInfo(int available, int reserved, Discount discount, int replenishQuantityInFlight) {
            this.available = available;
            this.reserved = reserved;
            this.discount = discount;
            this.replenishQuantityInFlight = replenishQuantityInFlight;
        }

        public QuantityInfo() {
            this(0, 0, null, 0);
        }

        public QuantityInfo(QuantityInfo copy) {
            this(copy.available, copy.reserved, copy.discount, copy.replenishQuantityInFlight);
        }

        public void in(int quantity) {
            available += quantity;
        }

        public int reserve(int quantity) {
            int toReserve = Math.min(available, quantity);
            available -= toReserve;
            reserved += toReserve;
            return toReserve;
        }

        public int unreserve(int quantity) {
            int toUnreserve = Math.min(reserved, quantity);
            reserved -= toUnreserve;
            available += toUnreserve;
            return toUnreserve;
        }

        public int out(int quantity) {
            int toOut = Math.min(reserved, quantity);
            reserved -= toOut;
            return toOut;
        }

        public void setDiscount(Discount discount) {
            this.discount = discount;
        }

        public void clearDiscount(Discount discount) {
            if (discount.equals(this.discount)) {
                this.discount = null;
            }
        }

        public Discount getDiscount() {
            return this.discount;
        }

        private void updateReplenishInFlightQuantity(int quantity) {
            replenishQuantityInFlight += quantity;
        }

        private int getReplenishInFlightQuantity() {
            return replenishQuantityInFlight;
        }

    }

}
