/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Message;
import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.request.InstallmentPurchasePaymentRequest;
import org.spec.jbb.hq.tx.request.InstallmentPurchaseVoidMessage;
import org.spec.jbb.sm.InstallmentPurchase;
import org.spec.jbb.util.JbbProperties;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class InstallmentPurchasePaymentTransaction extends AbstractTransaction {

    private final HQ hq;

    public InstallmentPurchasePaymentTransaction(HQ hq, InstallmentPurchasePaymentRequest request, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
    }

    @Override
    public Response execute() throws TransactionException {
        List<Message> voidMessages = new ArrayList<>();
        boolean finalPayment;
        int processCount = (int) (hq.getInstallmentPurchaseQueueSize() / 1);
        BigDecimal paymentPercent = BigDecimal.valueOf(JbbProperties.getInstance().getInstallmentPaymentPercent());
        for (int index = 0 ; index < processCount; index ++){
            finalPayment = false;
            InstallmentPurchase installmentPurchase =  hq.getNextInstallmentPurchase();
            if (installmentPurchase == null){
                break;
            }
            BigDecimal totalPurchaseAmount = installmentPurchase.getTotalAmount();
            BigDecimal currentPayment = totalPurchaseAmount.multiply(paymentPercent).setScale(2, BigDecimal.ROUND_HALF_EVEN);

            if (currentPayment.compareTo(installmentPurchase.getBalance()) >= 0){
                currentPayment = installmentPurchase.getBalance();
                finalPayment = true;
            }
            boolean success =  hq.reserveCredit(installmentPurchase.getCustomerId(), currentPayment);
            if (success){
                hq.drawCredit(installmentPurchase.getCustomerId(), currentPayment);
                installmentPurchase.addPayment(currentPayment);
                if (!finalPayment){
                    addToQueue(installmentPurchase);
                }
            } else {
                voidMessages.add(new InstallmentPurchaseVoidMessage(installmentPurchase));
            }            
        }

        if (voidMessages.size() > 0){
            ctx.sendMessage(hq.getName(), voidMessages);
        }
        return new OkResponse();
    }

    private void addToQueue(InstallmentPurchase installmentPurchase) {
        installmentPurchase.resetDelay();
        hq.add(installmentPurchase);
    }

    @Override
    public String toString() {
        return "InstallmentPurchasePaymentTx";
    }

}
