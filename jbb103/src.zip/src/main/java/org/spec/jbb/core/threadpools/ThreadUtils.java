/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

public class ThreadUtils {

    private static Logger logger = Logger.getLogger("org.spec.jbb");

    /**
     * Timeout for one single wait
     */
    private static final int WAIT_MSEC = 1000;

    private ThreadUtils() {
        // prevent instantiation
    }

    /**
     * Forces thread to terminate.
     * This method returns only if requested thread is dead.
     * If thread is failing to stop, regardless of multiple interrupt()s, this method will never return.
     *
     * @param thread thread to shut down
     */
    public static void terminateThread(Thread thread) {
        thread.interrupt();
        try {
            thread.join(WAIT_MSEC);
        } catch (InterruptedException e) {
            // swallow, should wait for threads to terminate
        }

        while (thread.isAlive()) {
            logger.warning("Failed to stop thread " + thread + ", trying again");
            thread.interrupt();
            try {
                thread.join(WAIT_MSEC);
            } catch (InterruptedException e) {
                // swallow, should wait for threads to terminate
            }
        }
    }

    /**
     * Forces ExecutorService to terminate.
     * This method returns only if requested executor had shut down.
     * If executor is failing to shut down regardless of multiple shutdownNow()s, this method will never return.
     *
     * @param executor service to shutdown
     */
    public static void terminatePool(ExecutorService executor) {
        terminatePool(executor, false);
    }
    
    public static void terminatePool(ExecutorService executor, boolean orderly) {
        if (executor == null) {
            return;
        }

        while(true) {
            if(orderly) {
                executor.shutdown();
            } else {
                executor.shutdownNow();
            }
            try {
                if (executor.awaitTermination(WAIT_MSEC, TimeUnit.MILLISECONDS)) return;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
            logger.warning("Failed to stop executor service " + executor + ", trying again");
        }
    }

    public static <T> void checkForException(List<Future<T>> futures) throws ExecutionException {
        for (Future<?> future : futures) {
            try {
                future.get();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }
}
