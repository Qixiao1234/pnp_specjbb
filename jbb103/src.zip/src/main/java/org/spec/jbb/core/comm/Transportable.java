/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm;

import org.spec.jbb.core.comm.transport.TransportType;

import java.io.Serializable;

public interface Transportable extends Serializable {

    /**
     * Answers which transport is preferred with this transportable.
     * @return transport type
     */
    TransportType getTransportHint();

}
