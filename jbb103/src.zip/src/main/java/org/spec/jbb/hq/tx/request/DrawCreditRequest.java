/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.request;

import org.spec.jbb.core.comm.AbstractRequest;
import org.spec.jbb.core.comm.transport.TransportType;
import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.DrawCreditTransaction;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.math.BigDecimal;
import java.util.Objects;

@XmlRootElement
public class DrawCreditRequest extends AbstractRequest {

    private static final long serialVersionUID = 565565715286914754L;
    @XmlElement
    private final long customerId;

    @XmlElement
    private final BigDecimal totalPrice;

    private DrawCreditRequest() {
        // JAXB
        this(0, BigDecimal.ZERO);
    }

    public DrawCreditRequest(long customerId, BigDecimal totalPrice) {
        super();
        this.customerId = customerId;
        this.totalPrice = totalPrice;
    }

    public long getCustomerId() {
        return customerId;
    }

    public BigDecimal getTotalPrice() {
        return totalPrice;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DrawCreditRequest that = (DrawCreditRequest) o;

        if (customerId != that.customerId) {
            return false;
        }
        if (totalPrice != null ? !totalPrice.equals(that.totalPrice) : that.totalPrice != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(customerId, totalPrice);
    }

    @Override
    public String toString() {
        return "Draw credit for customer #" + customerId + ", $" + totalPrice;
    }

    @Override
    public Transaction getTransaction(HQ hq, TransactionContext ctx) {
        return new DrawCreditTransaction(hq, this, ctx);
    }

    @Override
    public TransportType getTransportHint() {
        return TransportType.SERIALIZED_ENCRYPTED;
    }

}
