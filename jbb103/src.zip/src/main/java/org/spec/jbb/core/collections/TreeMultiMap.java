/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.NavigableMap;
import java.util.TreeMap;

public class TreeMultiMap<K,V> extends AbstractMultiMap<K,V> implements NavigableMultiMap<K,V> {

    private static final long serialVersionUID = 5066842125833765252L;

    public TreeMultiMap(){
        super(new TreeMap<K, Collection<V>>());
    }

    public TreeMultiMap(Comparator<? super K> comparator){
        super(new TreeMap<K, Collection<V>>(comparator));
    }

    @Override
    public NavigableMap<K, Collection<V>> asNavigableMap() {
        return (NavigableMap<K, Collection<V>>)backingMap;
    }

    @Override
    public Comparator<? super K> comparator() {
        return ((NavigableMap<K, Collection<V>>)backingMap).comparator();
    }

    @Override
    public K firstKey() {
        return ((NavigableMap<K, Collection<V>>)backingMap).firstKey();
    }

    @Override
    public K lastKey() {
        return ((NavigableMap<K, Collection<V>>)backingMap).lastKey();
    }

    @Override
    Collection<V> getOrCreate(K key) {
        Collection<V> coll = backingMap.get(key);
        if (coll == null) {
            coll = new ArrayList<>();
            backingMap.put(key, coll);
        }
        return coll;
    }

}
