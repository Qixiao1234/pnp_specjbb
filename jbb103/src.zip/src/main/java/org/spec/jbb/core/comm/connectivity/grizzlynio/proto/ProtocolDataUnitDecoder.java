/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity.grizzlynio.proto;

import org.glassfish.grizzly.AbstractTransformer;
import org.glassfish.grizzly.Buffer;
import org.glassfish.grizzly.Grizzly;
import org.glassfish.grizzly.TransformationException;
import org.glassfish.grizzly.TransformationResult;
import org.glassfish.grizzly.attributes.Attribute;
import org.glassfish.grizzly.attributes.AttributeStorage;

public class ProtocolDataUnitDecoder extends AbstractTransformer<Buffer, ProtocolDataUnit> {

    private static final Attribute<Integer> stateAttribute =
            Grizzly.DEFAULT_ATTRIBUTE_BUILDER.createAttribute("ParseState");
    private static final Attribute<ProtocolDataUnit> preparsedMessageAttr =
            Grizzly.DEFAULT_ATTRIBUTE_BUILDER.createAttribute("PreparsedMessage");

    @Override
    protected TransformationResult<Buffer, ProtocolDataUnit> transformImpl(
            AttributeStorage storage,
            Buffer input) throws TransformationException {

        // check if we are in the middle of message parsing
        ProtocolDataUnit message = preparsedMessageAttr.get(storage);
        // get the current parsing state
        Integer parseState = stateAttribute.get(storage);

        if (message == null) {
            // if we just started to parse the message - create destination object
            message = new ProtocolDataUnit();
            parseState = 0;
        }

        boolean isParsing = true;
        while (isParsing) {
            switch (parseState) {
                case 0: // magic
                {
                    if (input.remaining() >= ProtocolDataUnit.MAGIC.length) {
                        byte[] magic = new byte[ProtocolDataUnit.MAGIC.length];
                        input.get(magic);
                        message.compareMagic(magic);
                        parseState++;
                    } else {
                        isParsing = false;
                        break;
                    }
                }

                case 1: // type
                    if (input.remaining() >= 4) {
                        message.setType(ProtocolDataUnit.Type.values()[input.getInt()]);
                        parseState++;
                    } else {
                        isParsing = false;
                        break;
                    }

                case 2: // header length
                {
                    if (input.remaining() >= 4) {
                        message.setHeaderLength(input.getInt());
                        parseState++;
                    } else {
                        isParsing = false;
                        break;
                    }
                }

                case 3: // header
                {
                    int length = message.getHeaderLength();
                    if (input.remaining() >= length) {
                        final byte[] header = new byte[length];
                        input.get(header);
                        message.setHeader(header);
                        parseState++;
                    } else {
                        isParsing = false;
                        break;
                    }
                }

                case 4: // body length
                {
                    if (input.remaining() >= 4) {
                        message.setBodyLength(input.getInt());
                        parseState++;
                    } else {
                        isParsing = false;
                        break;
                    }
                }

                case 5: // body
                {
                    int length = message.getBodyLength();
                    if (input.remaining() >= length) {
                        final byte[] body = new byte[length];
                        input.get(body);
                        message.setBody(body);
                        parseState++;
                    }

                    isParsing = false;
                    break;
                }

            }
        }

        if (parseState < 6) {  // Not enough data to parse whole message
            // Save the parsing state
            preparsedMessageAttr.set(storage, message);
            stateAttribute.set(storage, parseState);

            // Stop the filterchain execution until more data available
            return TransformationResult.createIncompletedResult(input);
        } else {
            // Remove intermediate parsing state
            preparsedMessageAttr.remove(storage);
            stateAttribute.remove(storage);

            return TransformationResult.createCompletedResult(message, input);
        }
    }

    @Override
    public String getName() {
        return "ProtocolDataUnitDecoder";
    }

    @Override
    public boolean hasInputRemaining(AttributeStorage storage, Buffer input) {
        return input != null && input.hasRemaining();
    }
}
