/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.time;

public interface StopWatch {

    /**
     * Resets stopwatch.
     */
    void reset();

    /**
     * Starts stopwatch.
     * Use this to start or resume stopwatch.
     */
    void start();

    /**
     * Stops stopwatch
     * Use this to stop or pause stopwatch.
     */
    void stop();

    /**
     * Answers total nanoseconds elapsed since last reset.
     *
     * @return nanoseconds since last reset
     */
    long getElapsedNsecs();

    /**
     * Answers total milliseconds elapsed since last reset.
     *
     * @return milliseconds since last reset
     */
    long getElapsedMsecs();
}
