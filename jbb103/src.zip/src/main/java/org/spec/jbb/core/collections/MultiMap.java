/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

public interface MultiMap<K, V> {

    /**
     * Answers mapped view of this multimap.
     * @return backing map representation
     */
    Map<K, Collection<V>> asMap();

    /**
     * Clears multimap.
     */
    void clear();

    /**
     * Returns a view of all values associated with a key.
     * If no mappings in the MultiMap have the provided key, an empty collection is returned.
     * @param key - key to search
     * @return the collection of values that the key maps to
     */
    Collection<V> get(K key);

    /**
     * Checks in multimap is empty.
     * @return true, if multimap is empty
     */
    boolean isEmpty();

    /**
     * Answers the set of keys
     * @return key set
     */
    public Set<K> keySet();

    /**
     * Stores a key-value pair in the multimap.
     * @param key - key to store in the multimap
     * @param value - value to store in the multimap
     */
    public void put(K key, V value);

    /**
     * Stores a collection of values with the same key.
     * @param key - key to store in the multimap
     * @param values - values to store in the multimap
     */
    public void putAll(K key, Iterable<V> values);

    /**
     * Stores all key-value pairs from given map
     * @param map map to read values from
     */
    public void putAll(MultiMap<K, V> map);

    /**
     * Removes the first occurrence of the specified value from
     * the values associated with a key.
     * @param key key to look for
     * @param value value to look for
     * @return true, if multimap had changed
     */
    public boolean remove(Object key, Object value);

    /**
     * The same as for(V v:values) { this.remove(key,v); }
     * @param key to look for
     * @param values values to look for
     * @return true, if multimap had changed
     */
    public boolean remove(K key, Collection<V> values);

    /**
     * Removes all values associated with a given key.
     * @param key
     * @return the list of removed values, or an empty list
     */
    public Collection<V> removeAll(K key);

    /**
     * Answers the size of multimap, counting repetitions.
     * @return number of key-value pairs.
     */
    public int size();

    /**
     * Answers all values in multimap
     * @return collection with multimap values
     */
    public Iterable<V> values();

}
