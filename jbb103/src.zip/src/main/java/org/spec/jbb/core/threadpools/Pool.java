/*
 * Copyright (c) 2012-2014 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

import org.spec.jbb.core.ExecutionHandler;
import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.comm.Incoming;
import org.spec.jbb.core.comm.Response;

import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;

/**
 * Pool interface.
 * <p/>
 * General responsibilites of a pool are:
 * - accepting Batches for processing
 * - dividing them into SubBatches
 * - executing SubBatches
 * - dispatching execution of SubBatches
 * - generating lifecycle events on Batches and SubBatches
 */
public interface Pool extends Measurable {

    /**
     * Enqueue batch for execution.
     * <p/>
     * The semantics of this method adheres to {@link java.util.concurrent.BlockingQueue}'s offer() method.
     * Callers should check for return value.
     *
     * @param incomings batch to enqueue
     * @return true if successful, false if not
     */
    Future<List<Response>> enqueueBatch(int tier, ExecutionHandler handler, List<? extends Incoming> incomings) throws RejectedExecutionException;

    /**
     * Enqueue batch for execution, possibly waiting while queue is empty
     * <p/>
     * The semantics of this method adheres to {@link java.util.concurrent.BlockingQueue}'s put() method.
     *
     * @param incomings batch to enqueue
     * @throws InterruptedException if interrupted while waiting
     */
    Future<List<Response>> forceBatch(int tier, ExecutionHandler handler, List<? extends Incoming> incomings) throws InterruptedException;

    /**
     * Starts the pool: starts threads, etc.
     *
     * @throws IllegalStateException if already started.
     */
    void start();

    /**
     * Shutdown the pool.
     */
    void shutdown();

    /**
     * Sets the execution handler to define the operations on subbatches to perform in this pool.
     * If unset, the pool will use internal dummy execution handler, which does nothing about subbatches.
     *
     * @param handler handler to use
     * @see org.spec.jbb.core.ExecutionHandler
     */
//    void setExecutionHandler(ExecutionHandler handler);

    PoolPerfomanceData getProcessedCount();

    List<Response> processLocally(int tier, ExecutionHandler handler, List<? extends Incoming> requests);

    /**
     * Borrow one worker to execute particular task.
     * @param runnable task to execute.
     */
    void assistExecute(Runnable runnable);
}
