/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.response;

import org.spec.jbb.core.comm.AbstractResponse;
import org.spec.jbb.core.comm.transport.TransportType;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class FindCustomerZipResponse extends AbstractResponse {

    private static final long serialVersionUID = 8554806813253452924L;
    @XmlElement
    private final String zipcode;

    @SuppressWarnings("unused")
    private FindCustomerZipResponse() {
        // JAXB
        this(null);
    }

    public FindCustomerZipResponse(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getZipcode() {
        return zipcode;
    }

    @Override
    public String toString() {
        return "FindCustomerZip: zipCode={" + zipcode + "}";
    }

    @Override
    public TransportType getTransportHint() {
        return TransportType.SERIALIZED_ENCRYPTED;
    }

}
