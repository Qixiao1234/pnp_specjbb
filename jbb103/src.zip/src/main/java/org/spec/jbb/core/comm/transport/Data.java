/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.Serializable;

/**
 * Holder for abstract data.
 */
public abstract class Data implements Serializable {

    private static final long serialVersionUID = 4904954888439929584L;

    /**
     * Answer empty Data instance
     * @return empty Data.
     */
    public static Data empty() {
        return new BinaryData(new byte[0]);
    }

    /**
     * Wrap array to new instance.
     * @param data array to wrap
     * @return new Data
     */
    public static Data wrap(byte[] data) {
        return new BinaryData(data);
    }

    /**
     * Convert BAOS to Data.
     * @param bos baos to wrap.
     * @return new Data
     */
    public static Data wrap(ByteArrayOutputStream bos) {
        return new BinaryData(bos.toByteArray());
    }

    /**
     * Convert reference to Data
     * @param ref reference to convert
     * @return new Data
     */
    public static Data wrapReference(Object ref) {
        return new ReferenceData(ref);
    }

    Data() {
    }

    /**
     * Get backing array
     * @return backing array
     */
    public abstract byte[] getArray();

    /**
     * Get input stream corresponding to this Data
     * @return stream instance
     */
    public abstract InputStream getStream();

    /**
     * Get reference
     * @return reference
     */
    public abstract Object getReference();
}
