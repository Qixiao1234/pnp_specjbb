/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.entity;

import org.spec.jbb.core.comm.transport.encapsulation.JAXBAdapters;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Order implements Delayed, Serializable {

    private static final long serialVersionUID = -5724233764160268207L;
    @XmlElement
    private final long customerId;

    @XmlJavaTypeAdapter(JAXBAdapters.HashMapAdapter.class)
    private final HashMap<Long, Integer> items;

    @XmlElement
    private final long endOfDelay;

    @SuppressWarnings("unused")
    private Order() {
        this.customerId = 0;
        endOfDelay = 0;
        items = null;
    }

    public Order(long customerId) {
        this.customerId = customerId;
        endOfDelay = System.currentTimeMillis() + 1000;
        items = new HashMap<>();
    }

    public long getCustomerId() {
        return customerId;
    }

    public Set<Long> getBarcodes() {
        return items.keySet();
    }

    public void addItem(long barCode, int qty) {
        items.put(barCode, qty);
    }

    @Override
    public int compareTo(Delayed o) {
        long cEndofDelay = ((Order) o).getEndOfDelay();
        return Long.compare(endOfDelay, cEndofDelay);
    }

    @Override
    public long getDelay(TimeUnit unit) {
        long currMills = System.currentTimeMillis();
        return unit.convert(endOfDelay - currMills, TimeUnit.MILLISECONDS);
    }

    long getEndOfDelay() {
        return endOfDelay;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Order order = (Order) o;

        if (customerId != order.customerId) {
            return false;
        }

        if (endOfDelay != order.endOfDelay) {
            return false;
        }

        if (items != null ? !items.equals(order.items) : order.items != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(customerId, endOfDelay, items);
    }
}
