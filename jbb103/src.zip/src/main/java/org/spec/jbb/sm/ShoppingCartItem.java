/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm;

import org.spec.jbb.sm.coupon.SpecificCoupon;

import java.math.BigDecimal;

public class ShoppingCartItem {
    private final long barcode;
    private final int quantity;
    private final BigDecimal price;
    private final SpecificCoupon specificCoupon;
    private final String smName;

    public ShoppingCartItem(long barcode, int quantity, BigDecimal price, SpecificCoupon specificCoupon, String smName) {
        this.barcode = barcode;
        this.quantity = quantity;
        this.price = price;
        this.smName = smName;
        this.specificCoupon = specificCoupon;
    }
    public ShoppingCartItem(long barcode, int quantity, BigDecimal price) {
        this(barcode, quantity, price, null, null);
    }

    public long getBarcode() {
        return barcode;
    }
    public int getQuantity() {
        return quantity;
    }
    public BigDecimal getPrice() {
        return price;
    }
    public String getSmName() {
        return smName;
    }
    
     public SpecificCoupon getSpecificCoupon() {
        return specificCoupon;
    }
    
}
