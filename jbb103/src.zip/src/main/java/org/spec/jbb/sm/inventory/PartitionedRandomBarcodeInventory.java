/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.inventory;

import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.sm.discount.Discount;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PartitionedRandomBarcodeInventory implements Inventory, Serializable {

    /*
     * Implementation notes:
     *
     * This implementation assumes Product has barcode as it's one and only primary key.
     */

    private static final long serialVersionUID = 5148732459872341242L;

    final private List<Inventory> partitions;
    final private int numberOfBuckets;

    public PartitionedRandomBarcodeInventory(int numberOfBuckets, int bucketSize) {
        this.numberOfBuckets = roundUpToPowerOfTwo(numberOfBuckets);
        this.partitions = new ArrayList<>(numberOfBuckets);
        for (int i = 0; i < this.numberOfBuckets; i++) {
            Inventory stride = new RandomBarcodeInventory(numberOfBuckets * bucketSize);
            partitions.add(stride);
        }
    }

    @Override
    public int moveIn(long barcode, int quantity) {
        int bucket = makeBucketIndex(barcode);
        return partitions.get(bucket).moveIn(barcode, quantity);
    }

    @Override
    public int reserve(long barcode, int quantity) {
        int bucket = makeBucketIndex(barcode);
        return partitions.get(bucket).reserve(barcode, quantity);
    }

    @Override
    public int unreserve(long barcode, int quantity) {
        int bucket = makeBucketIndex(barcode);
        return partitions.get(bucket).unreserve(barcode, quantity);
    }

    @Override
    public int moveOut(long barcode, int quantity) {
        int bucket = makeBucketIndex(barcode);
        return partitions.get(bucket).moveOut(barcode, quantity);
    }

    @Override
    public int getQuantity(long barcode) {
        int bucket = makeBucketIndex(barcode);
        return partitions.get(bucket).getQuantity(barcode);
    }

    @Override
    public void clearDiscount(Discount discount) {
        int bucket = makeBucketIndex(discount.getBarcode());
        partitions.get(bucket).clearDiscount(discount);
    }

    @Override
    public Discount getDiscount(long barcode) {
        int bucket = makeBucketIndex(barcode);
        return partitions.get(bucket).getDiscount(barcode);
    }

    @Override
    public void setDiscount(Discount discount) {
        int bucket = makeBucketIndex(discount.getBarcode());
        partitions.get(bucket).setDiscount(discount);
    }

    @Override
    public List<Long> toList() {
        List<Long> result = new ArrayList<>();
        for (Inventory stride : partitions) {
            result.addAll(stride.toList());
        }
        return result;
    }

    @Override
    public int size() {
        int size = 0;
        for (Inventory stride : partitions) {
            size += stride.size();
        }
        return size;
    }

    private int makeBucketIndex(long barcode) {
        int index = indexFor(barcode);
        if (index > this.numberOfBuckets) {
            throw new InventoryOutOfBoundsException(index, this.numberOfBuckets);
        }
        return index;
    }

    private int roundUpToPowerOfTwo(int numberOfBuckets) {
        // Find a power of 2 >= numberOfBuckets
        int newBucketSize = 1;
        while (newBucketSize < numberOfBuckets) {
            newBucketSize <<= 1;
        }
        return newBucketSize;
    }

    /**
     * Returns index for a bar code.
     */
    private int indexFor(long barCode) {
        int hash = (int) hash(barCode);
        return hash & (numberOfBuckets - 1);
    }

    private long hash(long h) {
        h ^= (h >>> 20) ^ (h >>> 12);
        return h ^ (h >>> 7) ^ (h >>> 4);
    }

    @Override
    public void instrument(Probe probe) {
        // do nothing
    }

    @Override
    public void sample() {
        // do nothing
    }

    @Override
    public int updateReplenishInFlightQuantity(long barcode, int quantity) {
        int bucket = makeBucketIndex(barcode);
        return partitions.get(bucket).updateReplenishInFlightQuantity(barcode, quantity);
    }

    @Override
    public int getReplenishInFlightQuantity(long barcode) {
        int bucket = makeBucketIndex(barcode);
        return partitions.get(bucket).getReplenishInFlightQuantity(barcode);
    }
}
