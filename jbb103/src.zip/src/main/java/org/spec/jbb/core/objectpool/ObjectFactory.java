/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.objectpool;

public interface ObjectFactory<K extends PoolKey, T extends Poolable> {

    T get(K key) throws PoolException, InterruptedException;

    void shutdown();

}
