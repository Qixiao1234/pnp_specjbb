/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

public class MarkFrame implements Frame {

    public static final long serialVersionUID = 1L;

    private final String key;
    private final String value;

    public MarkFrame(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    @Override
    public Frame cleanForSubmission(CleanForSubmissionContext ctx) {
        return this;
    }

    @Override
    public String toString() {
        return "Mark " + key + " = " + value;
    }
}
