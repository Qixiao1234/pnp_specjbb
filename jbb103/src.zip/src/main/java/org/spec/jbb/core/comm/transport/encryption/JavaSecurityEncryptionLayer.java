/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport.encryption;

import org.spec.jbb.core.comm.transport.Data;
import org.spec.jbb.core.comm.transport.EncryptionKeys;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.GeneralSecurityException;

public class JavaSecurityEncryptionLayer implements EncryptionLayer {

    private final SecretKeySpec skeySpec;
    private final String cipherName;
    private final String modeName;
    private final String paddingName;
    private final IvParameterSpec initVector;

    public JavaSecurityEncryptionLayer(String cipherName, String modeName, String paddingName) {
        this.cipherName = cipherName;
        this.modeName = modeName;
        this.paddingName = paddingName;
        this.skeySpec = EncryptionKeys.getFor(cipherName);
        this.initVector = new IvParameterSpec(
                new byte[]{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00});
    }

    @Override
    public Data convertDown(Data topInstance) {
        try {
            Cipher cipher = Cipher.getInstance(cipherName + "/" + modeName + "/" + paddingName);
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, initVector);
            byte[] data = cipher.doFinal(topInstance.getArray());
            return Data.wrap(data);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(cipherName + " transport marshaller throws unexpected exception: " + e);
        }
    }

    @Override
    public Data convertUp(Data bottomInstance) {
        try {
            Cipher cipher = Cipher.getInstance(cipherName + "/" + modeName + "/" + paddingName);
            cipher.init(Cipher.DECRYPT_MODE, skeySpec, initVector);
            byte[] data = cipher.doFinal(bottomInstance.getArray());
            return Data.wrap(data);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(cipherName + " transport unmarshaller throws unexpected exception: " + e);
        }
    }
}
