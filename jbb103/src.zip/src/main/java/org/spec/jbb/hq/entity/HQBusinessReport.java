/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.entity;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Objects;

@XmlRootElement
public class HQBusinessReport implements Serializable {

    private static final long serialVersionUID = -2018443344780509922L;
    @XmlElement
    private String hqName;

    @XmlElement
    private BigDecimal totalCashFlowIn;

    @XmlElementWrapper
    private Collection<SMBusinessReport> smReports;

    private HQBusinessReport() {
        super();
        // JAXB constructor
    }

    public BigDecimal getTotalCashFlowIn() {
        return totalCashFlowIn;
    }

    public Collection<SMBusinessReport> getSmReports() {
        return smReports;
    }

    public String getHQName() {
        return hqName;
    }

    public void setHQName(String hqName) {
        this.hqName = hqName;
    }

    public HQBusinessReport(String hqName, Collection<SMBusinessReport> smReports) {
        this.hqName = hqName;
        this.smReports = smReports;
        this.totalCashFlowIn = BigDecimal.ZERO;
    }

    public void finalizeReport() {

        for (SMBusinessReport smReport : smReports) {
            totalCashFlowIn = totalCashFlowIn.add(smReport.getCashFlowIn());
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        HQBusinessReport that = (HQBusinessReport) o;

        if (hqName != null ? !hqName.equals(that.hqName) : that.hqName != null) {
            return false;
        }

        if (totalCashFlowIn != null ? !totalCashFlowIn.equals(that.totalCashFlowIn) : that.totalCashFlowIn != null) {
            return false;
        }

        if (smReports != null ? !smReports.equals(that.smReports) : that.smReports != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                hqName,
                totalCashFlowIn,
                smReports
        );
    }


    @Override
    public String toString() {
        return "HQBusinessReport{" +
                "hqName='" + hqName + '\'' +
                ", totalCashFlowIn=" + totalCashFlowIn +
                ", smReports=" + smReports +
                '}';
    }

}
