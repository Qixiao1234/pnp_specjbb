/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx;

import org.spec.jbb.core.tx.TransactionException;

public class InventoryDepletedException extends TransactionException {
    private static final long serialVersionUID = -3726550949032228822L;

    public InventoryDepletedException(String message) {
        super(message);
    }
}
