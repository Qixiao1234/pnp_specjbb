/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.collections.CollectionUtils;
import org.spec.jbb.core.collections.HashMultiSet;
import org.spec.jbb.core.collections.MultiSet;
import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.db.DataMiningCursor;
import org.spec.jbb.hq.entity.Category;
import org.spec.jbb.hq.entity.Receipt;
import org.spec.jbb.hq.tx.request.AssociativityOfCategoryRequest;
import org.spec.jbb.hq.tx.response.NoDataForDataMiningResponse;
import org.spec.jbb.sm.advertisement.IssuedAdvertisement;
import org.spec.jbb.util.JbbProperties;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

public class AssociativityOfCategoryTransaction extends AbstractTransaction {

    private final HQ hq;
    private final String smName;
    private final Category category;
    private final DataMiningCursor<Receipt> data;
    private static final String dmName = "AssociativityOfCategory";
    private static final String dmStatEmptyAssocMap = dmName + ".assocMap.EMPTY";
    private static final String dmStatNonEmptyAssocMap = dmName + ".assocMap.NON_EMPTY";
    private final Set<Long> barcodesInCategory;

    public AssociativityOfCategoryTransaction(HQ hq, AssociativityOfCategoryRequest request, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;

        this.smName = request.getSmName();
        this.data = hq.getDataMiningManager().receiptsCursor(smName);

        Long barcode = hq.getDataMiningManager().pickRandomBarcodeFromReceipts(data);
        if (barcode != null) {
            List<Category> categories = new ArrayList<>(hq.findProduct(barcode).getCategories());
            this.category = CollectionUtils.getRandomElement(categories);
            this.barcodesInCategory = hq.getBarcodesForCategory(category);
        } else {
            this.category = null;
            this.barcodesInCategory = null;
        }
    }

    @Override
    public Response execute() {

        /*
         * Build associativity map
         */
        final MultiSet<Long> associativity = new HashMultiSet<>();
        while (data.hasNext()) {
            Receipt r = data.next();
            Collection<Long> barcodes = r.getAllBarcodesLocalToReceiptSM();
            for (Long b1 : barcodes) {
                if (barcodesInCategory.contains(b1)) {
                    associativity.addAll(barcodes);
                    break;
                }
            }
        }

        /*
         * Find most popular products for category
         */

        if (!associativity.isEmpty()) {
            hq.getDataMiningTxProbe().inc(dmStatNonEmptyAssocMap);
            List<Long> hottestBarcodes = new ArrayList<>(
                    CollectionUtils.tail(CollectionUtils.elementsAsList(associativity),
                            JbbProperties.getInstance().getDataMiningHottestCount(dmName)));
            /*
            * Suggest new advertisement
            */
            hq.suggestAdvertisement(smName, new IssuedAdvertisement(category, hottestBarcodes));
        } else {
            hq.getDataMiningTxProbe().inc(dmStatEmptyAssocMap);
        }

        if (data.hasEnoughElements()) {
        return new OkResponse();
        } else {
            return new NoDataForDataMiningResponse();
        }
    }

    @Override
    public String toString() {
        return "AssociativityOfCategoryTx: smName = {" + smName + "}, category = {" + category + "}, data = {" + data + "}";
    }

}
