/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * Message does not need to be answered.
 */
@XmlJavaTypeAdapter(AbstractMessage.JAXBAdapter.class)
public interface Message extends Incoming {

}