/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.counters;


public interface Counter {

    /**
     * Increment counter
     * @param increment increment
     */
    void inc(long increment);

    /**
     * Get counter value.
     * Implementation consideration:
     * Some implementations may return somewhat stale values if that helps performance.
     *
     * @return counter value
     */
    long get();

    /**
     * Reset counter
     */
    void reset();

    /**
     * Get and reset counter value.
     * Implementation consideration:
     * Some implementations may return somewhat stale values if that helps performance.
     *
     * @return counter value.
     */
    long getAndReset();

}
