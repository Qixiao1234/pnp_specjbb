/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.request;

import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.tx.ProductReturnTransaction;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement
@XmlType(name = "SM.HqProductReturnRequest")
public class ProductReturnRequest extends AbstractBusinessTxInjectorRequest {

    private static final long serialVersionUID = -8140936378091335454L;

    private ProductReturnRequest() {
        // JAXB
        this(false);
    }

    public ProductReturnRequest(boolean isSaturate) {
        super(isSaturate);
    }

    @Override
    public Transaction getTransaction(SM sm, TransactionContext ctx) {
        return new ProductReturnTransaction(sm, this, ctx);
    }

    @Override
    public String toString() {
        return "Initiate product return";
    }
}
