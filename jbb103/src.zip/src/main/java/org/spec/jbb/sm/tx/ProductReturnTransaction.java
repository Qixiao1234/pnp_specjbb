/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.HQ.SMInventoryDirection;
import org.spec.jbb.hq.entity.Receipt;
import org.spec.jbb.hq.entity.ReceiptLine;
import org.spec.jbb.hq.tx.request.AdjustSupermarketInventoryMessage;
import org.spec.jbb.hq.tx.request.CustomerRefundMessage;
import org.spec.jbb.hq.tx.request.RandomReceiptRequest;
import org.spec.jbb.hq.tx.response.RandomReceiptResponse;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.tx.request.MoveInInventoryMessage;
import org.spec.jbb.sm.tx.request.ProductReturnRequest;

import java.util.Collection;
import java.util.Map;

public class ProductReturnTransaction extends AbstractSMTransaction {
    
    public ProductReturnTransaction(SM sm, ProductReturnRequest req, TransactionContext ctx) {
        super(sm, ctx);
    }

    @Override
    public Response execute() {
        Response response = ctx.sendRequest(owningHQ, new RandomReceiptRequest());
        if(response instanceof RandomReceiptResponse) {
            RandomReceiptResponse resp = (RandomReceiptResponse)response;
            Receipt receipt = resp.getReceipt();
            if (receipt != null){
                for (Map.Entry<String, Collection<ReceiptLine>> entry : receipt.getReceiptLinesBySM().asMap().entrySet()) {
                    String smName = entry.getKey();
                    for (ReceiptLine line : entry.getValue()) {
                        long barcode = line.getBarcode();
                        int quantity = line.getQuantity();
                        if (smName.equals(sm.getName())){
                            moveIn(barcode, quantity);
                        } else {
                            ctx.sendMessage(smName, new MoveInInventoryMessage(barcode, quantity));
                        }
                    }
                }
                String custTargetHQ = sm.resolveCustomer(ctx, receipt.getCustomerId());
                ctx.sendMessage(custTargetHQ, new CustomerRefundMessage(receipt.getCustomerId(), receipt.getTotal()));
                ctx.sendMessage(owningHQ,     new AdjustSupermarketInventoryMessage(receipt, SMInventoryDirection.IN));
            }
        }
        return new OkResponse();
    }

    @Override
    public String toString() {
        return "ProductReturnTx: random receipt";
    }

}
