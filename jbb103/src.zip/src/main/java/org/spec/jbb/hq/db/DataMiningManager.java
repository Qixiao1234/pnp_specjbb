/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.db;

import org.spec.jbb.core.collections.CollectionUtils;
import org.spec.jbb.hq.entity.Receipt;
import org.spec.jbb.sp.Invoice;
import org.spec.jbb.util.JbbProperties;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

public class DataMiningManager implements Serializable {

    private static final long serialVersionUID = 7331687123281981970L;

    private final DataMiningStorage<Receipt> receiptStorage;
    private final DataMiningStorage<Invoice> invoiceStorage;

    public DataMiningManager() {
        final int numReceipts = JbbProperties.getInstance().getNumberOfReceiptsForDataMining();
        receiptStorage = new DataMiningStorage<>(numReceipts);

        final int numInvoices = JbbProperties.getInstance().getNumberOfInvoicesForDataMining();
        invoiceStorage = new DataMiningStorage<>(numInvoices);
    }

    public void addReceipt(Receipt receipt) {
        receiptStorage.add(receipt, receipt.getSupermarket());
    }

    public void addInvoice(Invoice invoice) {
        invoiceStorage.add(invoice, invoice.getDestinationSupermarket());
    }

    public DataMiningCursor<Receipt> receiptsCursor(String filterBySM) {
        return receiptStorage.cursor(filterBySM);
    }

    public DataMiningCursor<Invoice> invoicesCursor(String filterBySM) {
        return invoiceStorage.cursor(filterBySM);
    }

    public Long pickRandomBarcodeFromReceipts(DataMiningCursor<Receipt> cursor) {
        if (cursor.hasAnyElements()) {
            Receipt receipt = cursor.getRandom();
            Collection<Long> barcodes = receipt.getAllBarcodes();
            if (barcodes.size() > 0) {
                return CollectionUtils.getRandomElement(new ArrayList<>(barcodes));
            }
        }

        return null;
    }

    public Long pickRandomCustomerIdFromReceipts(DataMiningCursor<Receipt> cursor) {
        Receipt receipt = cursor.getRandom();
        return (receipt != null) ? receipt.getCustomerId() : null;
    }

    public Receipt selectRandomReceipt(String smName) {
        return receiptsCursor(smName).getRandom();
    }
}
