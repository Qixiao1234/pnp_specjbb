/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.util.AbstractSet;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class ConcurrentWeakHashMap<K, V> implements Map<K, V> {

    private final ConcurrentMap<WeakKey<K>, V> backingMap;
    private final ReferenceQueue<K> expungeEntries;

    public ConcurrentWeakHashMap() {
        this.backingMap = new ConcurrentHashMap<>();
        this.expungeEntries = new ReferenceQueue<K>();
    }

    @Override
    public int size() {
        expunge();
        return backingMap.size();
    }

    @Override
    public boolean isEmpty() {
        expunge();
        return backingMap.isEmpty();
    }

    @Override
    public boolean containsKey(Object key) {
        expunge();
        checkNull(key);
        return backingMap.containsKey(new WeakKey<>(key));
    }

    @Override
    public boolean containsValue(Object value) {
        expunge();
        return backingMap.containsValue(value);
    }

    @Override
    public V get(Object key) {
        expunge();
        checkNull(key);
        return backingMap.get(new WeakKey<>(key));
    }

    @Override
    public V put(K key, V value) {
        expunge();
        checkNull(key);
        return backingMap.put(new WeakKey<>(key, expungeEntries), value);
    }

    @Override
    public V remove(Object key) {
        expunge();
        checkNull(key);
        return backingMap.remove(new WeakKey<>(key));
    }

    @Override
    public void putAll(Map<? extends K, ? extends V> m) {
        expunge();
        for (Map.Entry<? extends K, ? extends V> entry : m.entrySet()) {
            checkNull(entry.getKey());
            backingMap.put(new WeakKey<>(entry.getKey(), expungeEntries), entry.getValue());
        }
    }

    private void checkNull(Object obj) {
        if (obj == null) {
            throw new NullPointerException();
        }
    }

    @Override
    public void clear() {
        expunge();
        backingMap.clear();
    }

    @Override
    public Set<K> keySet() {
        expunge();
        return new AbstractSet<K>() {

            @Override
            public Iterator<K> iterator() {
                final Iterator<WeakKey<K>> iterator = backingMap.keySet().iterator();
                return new Iterator<K>() {

                    @Override
                    public boolean hasNext() {
                        return iterator.hasNext();
                    }

                    @Override
                    public K next() {
                        return iterator.next().get();
                    }

                    @Override
                    public void remove() {
                        iterator.remove();
                    }
                };
            }

            @Override
            public int size() {
                return backingMap.keySet().size();
            }
        };
    }

    @Override
    public Collection<V> values() {
        expunge();
        return backingMap.values();
    }

    @Override
    public Set<Entry<K, V>> entrySet() {
        expunge();
        return new AbstractSet<Entry<K, V>>() {

            @Override
            public Iterator<Entry<K, V>> iterator() {
                final Iterator<Entry<WeakKey<K>, V>> iterator = backingMap.entrySet().iterator();
                return new Iterator<Entry<K, V>>() {

                    @Override
                    public boolean hasNext() {
                        return iterator.hasNext();
                    }

                    @Override
                    public Entry<K, V> next() {
                        final Entry<WeakKey<K>, V> entry = iterator.next();
                        return new Entry<K, V>() {

                            @Override
                            public K getKey() {
                                return entry.getKey().get();
                            }

                            @Override
                            public V getValue() {
                                return entry.getValue();
                            }

                            @Override
                            public V setValue(V value) {
                                return entry.setValue(value);
                            }
                        };
                    }

                    @Override
                    public void remove() {
                        iterator.remove();
                    }
                };
            }

            @Override
            public int size() {
                return backingMap.entrySet().size();
            }
        };
    }

    private void expunge() {
        Reference<? extends K> reference;
        while ((reference = expungeEntries.poll()) != null) {
            backingMap.remove(reference);
        }
    }

    private static class WeakKey<K> extends WeakReference<K> {

        public final int hashcode;
        
        public WeakKey(K key, ReferenceQueue<K> queue) {
            super(key, queue);
            hashcode = Objects.hashCode(key);
        }

        public WeakKey(K key) {
            super(key);
            hashcode = Objects.hashCode(key);
        }

        @Override
        public int hashCode() {
            return hashcode;
        }

        @Override
        public boolean equals(Object obj) {
            if ((obj != null) && (obj instanceof WeakKey)) {
                K that = ((WeakKey<K>) obj).get();
                K mine = get();
                return that == null || mine == null ? this == obj : mine.equals(that);
            }
            return false;
        }

        @Override
        public String toString() {
            return String.valueOf(get());
        }
        
    }
}
