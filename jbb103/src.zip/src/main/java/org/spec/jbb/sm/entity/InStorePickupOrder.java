/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.entity;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public final class InStorePickupOrder extends Order {

    private static final long serialVersionUID = 8548812188873777920L;

    @SuppressWarnings("unused")
    private InStorePickupOrder() {
        this(1);
    }

    public InStorePickupOrder(long customerId) {
        super(customerId);
    }

    @Override
    public String toString() {
        return "InStore pickup";
    }

}
