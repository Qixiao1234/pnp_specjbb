/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class SMBusinessReport implements Serializable {

    private static final long serialVersionUID = 1496494721709032063L;
    
    @XmlElement
    private final long totalReceipts;

    @XmlElement
    private final long totalQuantityOfItemsPurchasedByLine;

    @XmlElement
    private final long totalUniqueItemsPurchasedPerReceipt;

    @XmlElement
    private final long totalGenericCouponsRedeemed;

    @XmlElement
    private final long totalSpecificCoupons;

    @XmlElement
    private final long totalUniqueCustomers;

    @XmlElement
    private final long totalUniqueProductsPurchased;

    @XmlElement
    private final long averageUniquePurchasesPerVisit;

    @XmlElement
    private final long averagePurchasesPerVisit;

    @XmlElement
    private final long totalProductsReplenished;

    @XmlElement
    private final double averageVisitsPerCustomer;

    @XmlElement
    private final BigDecimal averageSpendingPerCustomer;

    @XmlElement
    private final BigDecimal customerSavingsFromGenericCoupons;

    @XmlElement
    private final BigDecimal cashFlowIn;

    @XmlElement
    private final String smName;

    @XmlElementWrapper
    private final List<Long> topReplenishedProducts;

    @XmlElementWrapper
    private final List<Long> worstSellingProducts;

    // JAXB constructor
    private SMBusinessReport() {
        this(0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0D,
            null,
            null,
            null,
            "name",
            null,
            null);
    }

    public SMBusinessReport(long totalReceipts,
            long totalQuantityOfItemsPurchasedByLine,
            long totalUniqueItemsPurchasedPerReceipt,
            long totalGenericCouponsRedeemed,
            long totalSpecificCoupons,
            long totalUniqueCustomers,
            long totalUniqueProductsPurchased,
            long averageUniquePurchasesPerVisit,
            long averagePurchasesPerVisit,
            long totalProductsReplenished,
            double averageVisitsPerCustomer,
            BigDecimal averageSpendingPerCustomer,
            BigDecimal customerSavingsFromGenericCoupons,
            BigDecimal cashFlowIn,
            String smName,
            List<Long> topReplenishedProducts,
            List<Long> worstSellingProducts) {

        this.totalReceipts = totalReceipts;
        this.totalQuantityOfItemsPurchasedByLine = totalQuantityOfItemsPurchasedByLine;
        this.totalUniqueItemsPurchasedPerReceipt = totalUniqueItemsPurchasedPerReceipt;
        this.totalGenericCouponsRedeemed = totalGenericCouponsRedeemed;
        this.totalSpecificCoupons = totalSpecificCoupons;
        this.totalUniqueCustomers = totalUniqueCustomers; 
        this.totalUniqueProductsPurchased = totalUniqueProductsPurchased;
        this.averageUniquePurchasesPerVisit = averageUniquePurchasesPerVisit;
        this.averagePurchasesPerVisit = averagePurchasesPerVisit;
        this.totalProductsReplenished = totalProductsReplenished;
        this.averageVisitsPerCustomer = averageVisitsPerCustomer;
        this.averageSpendingPerCustomer = averageSpendingPerCustomer;
        this.customerSavingsFromGenericCoupons = customerSavingsFromGenericCoupons;
        this.cashFlowIn = cashFlowIn;
        this.smName = smName;
        this.topReplenishedProducts = topReplenishedProducts;
        this.worstSellingProducts = worstSellingProducts;
    }

    public long getTotalReceipts() {
        return totalReceipts;
    }

    public long getTotalQuantityOfItemsPurchasedByLine() {
        return totalQuantityOfItemsPurchasedByLine;
    }

    public long getTotalUniqueItemsPurchasedPerReceipt() {
        return totalUniqueItemsPurchasedPerReceipt;
    }

    public long getTotalGenericCouponsRedeemed() {
        return totalGenericCouponsRedeemed;
    }

    public long getTotalSpecificCoupons() {
        return totalSpecificCoupons;
    }

    public long getTotalUniqueCustomers() {
        return totalUniqueCustomers;
    }

    public long getTotalUniqueProductsPurchased() {
        return totalUniqueProductsPurchased;
    }

    public long getAverageUniquePurchasesPerVisit() {
        return averageUniquePurchasesPerVisit;
    }

    public long getAveragePurchasesPerVisit() {
        return averagePurchasesPerVisit;
    }

    public long getTotalProductsReplenished() {
        return totalProductsReplenished;
    }

    public double getAverageVisitsPerCustomer() {
        return averageVisitsPerCustomer;
    }

    public BigDecimal getAverageSpendingPerCustomer() {
        return averageSpendingPerCustomer;
    }

    public BigDecimal getCustomerSavingsFromGenericCoupons() {
        return customerSavingsFromGenericCoupons;
    }

    public BigDecimal getCashFlowIn() {
        return cashFlowIn;
    }

    public String getSmName() {
        return smName;
    }

    public List<Long> getTopReplenishedProducts() {
        return topReplenishedProducts;
    }

    public List<Long> getWorstSellingProducts() {
        return worstSellingProducts;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        SMBusinessReport that = (SMBusinessReport) o;

        if (totalReceipts != that.totalReceipts) {
            return false;
        }

        if (totalQuantityOfItemsPurchasedByLine != that.totalQuantityOfItemsPurchasedByLine) {
            return false;
        }

        if (totalUniqueItemsPurchasedPerReceipt != that.totalUniqueItemsPurchasedPerReceipt) {
            return false;
        }

        if (totalGenericCouponsRedeemed != that.totalGenericCouponsRedeemed) {
            return false;
        }

        if (totalSpecificCoupons != that.totalSpecificCoupons) {
            return false;
        }

        if (totalUniqueCustomers != that.totalUniqueCustomers) {
            return false;
        }

        if (totalUniqueProductsPurchased != that.totalUniqueProductsPurchased) {
            return false;
        }

        if (averageUniquePurchasesPerVisit != that.averageUniquePurchasesPerVisit) {
            return false;
        }

        if (averagePurchasesPerVisit != that.averagePurchasesPerVisit) {
            return false;
        }

        if (totalProductsReplenished != that.totalProductsReplenished) {
            return false;
        }

        if (averageSpendingPerCustomer != null ?
                !averageSpendingPerCustomer.equals(that.averageSpendingPerCustomer) : that.averageSpendingPerCustomer!= null) {
            return false;
        }

        if (customerSavingsFromGenericCoupons != null ?
                !customerSavingsFromGenericCoupons.equals(that.customerSavingsFromGenericCoupons) : that.customerSavingsFromGenericCoupons != null) {
            return false;
        }

        if (cashFlowIn != null ? !cashFlowIn.equals(that.cashFlowIn) : that.cashFlowIn!= null) {
            return false;
        }

        if (smName != null ? !smName.equals(that.smName) : that.smName!= null) {
            return false;
        }

        if (topReplenishedProducts != null ? !topReplenishedProducts.equals(that.topReplenishedProducts) : that.topReplenishedProducts != null) {
            return false;
        }

        if (worstSellingProducts != null ? !worstSellingProducts.equals(that.worstSellingProducts) : that.worstSellingProducts != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                smName,
                totalReceipts,
                totalQuantityOfItemsPurchasedByLine,
                totalUniqueItemsPurchasedPerReceipt,
                totalGenericCouponsRedeemed,
                totalSpecificCoupons,
                totalUniqueCustomers,
                totalUniqueProductsPurchased,
                averageUniquePurchasesPerVisit,
                averagePurchasesPerVisit,
                totalProductsReplenished,
                averageSpendingPerCustomer,
                customerSavingsFromGenericCoupons,
                cashFlowIn,
                topReplenishedProducts,
                worstSellingProducts
        );
    }


    @Override
    public String toString() {
        return "SMBusinessReport{" +
                "averagePurchasesPerVisit=" + averagePurchasesPerVisit +
                ", totalReceipts=" + totalReceipts +
                ", totalQuantityOfItemsPurchasedByLine=" + totalQuantityOfItemsPurchasedByLine +
                ", totalUniqueItemsPurchasedPerReceipt=" + totalUniqueItemsPurchasedPerReceipt +
                ", totalGenericCouponsRedeemed=" + totalGenericCouponsRedeemed +
                ", totalSpecificCoupons=" + totalSpecificCoupons +
                ", totalUniqueCustomers=" + totalUniqueCustomers +
                ", totalUniqueProductsPurchased=" + totalUniqueProductsPurchased +
                ", averageUniquePurchasesPerVisit=" + averageUniquePurchasesPerVisit +
                ", totalProductsReplenished=" + totalProductsReplenished +
                ", averageVisitsPerCustomer=" + averageVisitsPerCustomer +
                ", averageSpendingPerCustomer=" + averageSpendingPerCustomer +
                ", customerSavingsFromGenericCoupons=" + customerSavingsFromGenericCoupons +
                ", cashFlowIn=" + cashFlowIn +
                ", smName='" + smName + '\'' +
                ", topReplenishedProducts=" + topReplenishedProducts +
                ", worstSellingProducts=" + worstSellingProducts +
                '}';
    }
}
