/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class ConcurrentMultiMap<K, V> implements MultiMap<K,V>, Serializable {

    private static final long serialVersionUID = -5926537087917727785L;
    private ConcurrentMap<K, Entry<V>> backingMap = new ConcurrentHashMap<>();

    @Override
    public void put(K key, V value) {
        getOrCreate(key).add(value);
    }

    @Override
    public void putAll(K key, Iterable<V> values) {
        getOrCreate(key).addAll(values);
    }

    @Override
    public void putAll(MultiMap<K, V> map) {
        for(K k : map.keySet()) {
            putAll(k, map.get(k));
        }
    }

    private Entry<V> getOrCreate(K key) {
        Entry<V> entry = backingMap.get(key);
        if (entry == null) {
            Entry<V> newEntry = new Entry<>();
            entry = backingMap.putIfAbsent(key, newEntry);
            if (entry == null) {
                entry = newEntry;
            }
        }
        return entry;
    }

    @Override
    public List<V> get(K key) {
        Entry<V> entry = backingMap.get(key);
        return (entry != null) ? entry.get() : Collections.<V>emptyList();
    }

    @Override
    public boolean isEmpty() {
        return backingMap.isEmpty();
    }

    @Override
    public boolean remove(Object key, Object value) {
        Entry<V> entry = backingMap.get(key);
        return (entry != null) && entry.remove(value);
    }

    @Override
    public boolean remove(K key, Collection<V> values) {
        Entry<V> entry = backingMap.get(key);
        return (entry != null) && entry.remove(values);
    }

    @Override
    public Set<K> keySet() {
        return backingMap.keySet();
    }

    @Override
    public int hashCode() {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean equals(Object obj) {
        throw new UnsupportedOperationException();
    }

    @Override
    public List<V> removeAll(K key) {
        Entry<V> entry = backingMap.remove(key);
        return (entry != null) ? entry.get() : Collections.<V>emptyList();
    }

    @Override
    public Map<K, Collection<V>> asMap() {
        throw new UnsupportedOperationException();
    }

    @Override
    public void clear() {
        backingMap.clear();
    }

    @Override
    public Iterable<V> values() {
        throw new UnsupportedOperationException();
    }

    @Override
    public int size() {
        int total = 0;
        for (Entry en : backingMap.values()) {
            total += en.size();
        }
        return total;
    }

    private static class Entry<V> implements Serializable {
        private static final long serialVersionUID = 414110330791636923L;
        private final List<V> list = new ArrayList<>();
        private final Lock readLock;
        private final Lock writeLock;

        public Entry() {
            ReadWriteLock rwl = new ReentrantReadWriteLock();
            readLock = rwl.readLock();
            writeLock = rwl.writeLock();
        }

        public void add(V value) {
            writeLock.lock();
            try {
                list.add(value);
            } finally {
                writeLock.unlock();
            }
        }

        public void addAll(Iterable<V> values) {
            writeLock.lock();
            try {
                for (V value : values) {
                    list.add(value);
                }
            } finally {
                writeLock.unlock();
            }
        }

        public List<V> get() {
            readLock.lock();
            try {
                return new ArrayList<>(list);
            } finally {
                readLock.unlock();
            }
        }

        public V getRandom() {
            readLock.lock();
            try {
                return CollectionUtils.getRandomElement(list);
            } finally {
                readLock.unlock();
            }
        }

        public int size() {
            readLock.lock();
            try {
                return list.size();
            } finally {
                readLock.unlock();
            }
        }

        public boolean remove(Object value) {
            writeLock.lock();
            try {
                return list.remove(value);
            } finally {
                writeLock.unlock();
            }
        }

        public boolean remove(Collection<V> values) {
            if (!values.isEmpty()) {
                writeLock.lock();
                try {
                    boolean wasRemoved = false;
                    for(V v : values) {
                        wasRemoved |= list.remove(v);
                    }
                    return wasRemoved;
                } finally {
                    writeLock.unlock();
                }
            }
            return false;
        }

    }


}
