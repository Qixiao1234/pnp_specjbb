/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.response;

import org.spec.jbb.core.comm.AbstractResponse;
import org.spec.jbb.core.comm.LocationInfo;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class LookupResponse extends AbstractResponse {

    private static final long serialVersionUID = 3779441153871955323L;
    @XmlElement
    private final String name;

    @XmlElement
    private final LocationInfo info;

    private LookupResponse() {
        // JAXB
        this(null, null);
    }

    public LookupResponse(String name, LocationInfo info) {
        this.name = name;
        this.info = info;
    }

    public String getLocation() {
        return info.getLocation();
    }

    public String getName() {
        return name;
    }

    public int getPort() {
        return info.getPort();
    }

    public LocationInfo getInfo() {
        return info;
    }

    @Override
    public String toString() {
        return name + " is @ " + info;
    }
    
}
