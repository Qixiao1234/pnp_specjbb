/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter.data;

import java.io.IOException;
import org.spec.jbb.core.comm.ConnectionClient;
import org.spec.jbb.reporter.Frame;

public class SilentDataWriter implements DataWriter {

    public SilentDataWriter() {
    }

    @Override
    public void open(ConnectionClient client) throws IOException {
    }

    @Override
    public void write(Frame frame) throws IOException {
    }

    @Override
    public void flush() throws IOException {
    }

    @Override
    public void close() {
    }
    
}
