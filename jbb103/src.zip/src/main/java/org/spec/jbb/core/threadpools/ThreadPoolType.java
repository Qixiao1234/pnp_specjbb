/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

/**
 * Thread pool type
 */
public enum ThreadPoolType {

    MULTI_JUC(MultiPoolType.ROUND_ROBIN, PoolType.JUC_QUEUE_BATCH_QUEUE_SUBBATCH),
    SINGLE_JUC_QUEUE(MultiPoolType.NONE, PoolType.JUC_QUEUE_BATCH_QUEUE_SUBBATCH),
    SINGLE_JUC_SYNC(MultiPoolType.NONE, PoolType.JUC_QUEUE_BATCH_SYNC_SUBBATCH),
    FORK_JOIN(MultiPoolType.NONE, PoolType.FORK_JOIN),
    STATIC_FORK_JOIN(MultiPoolType.NONE, PoolType.STATIC_FORK_JOIN),
    ;

    private PoolType poolType;
    private MultiPoolType multipoolType;

    ThreadPoolType(MultiPoolType multipoolType, PoolType poolType) {
        this.multipoolType = multipoolType;
        this.poolType = poolType;
    }

    public MultiPoolType getMultipoolType() {
        return multipoolType;
    }

    public PoolType getPoolType() {
        return poolType;
    }

    public enum MultiPoolType {
        NONE,
        ROUND_ROBIN,
        FIRST_OPPORTUNITY
    }

    public  enum PoolType {
        JUC_QUEUE_BATCH_QUEUE_SUBBATCH,
        JUC_QUEUE_BATCH_SYNC_SUBBATCH,
        FORK_JOIN,
        STATIC_FORK_JOIN,
    }

}
