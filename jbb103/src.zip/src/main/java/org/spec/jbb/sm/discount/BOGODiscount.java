/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.discount;

/**
 * BOGO (Buy One Get One free discount) representation
 */
public class BOGODiscount extends AbstractDiscount {

    private static final long serialVersionUID = 80780068259894860L;

    public BOGODiscount(long barcode) {
        super(barcode);
    }

}
