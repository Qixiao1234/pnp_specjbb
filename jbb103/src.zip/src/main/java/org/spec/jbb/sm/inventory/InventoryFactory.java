/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.inventory;

import org.spec.jbb.util.JbbProperties;

/**
 * A factory object that knows how to construct an Inventory.
 */
public class InventoryFactory {

    /**
     * Make an Inventory based on an inventory type property of a size
     * determined by a property having a number of inventory buckets
     * specified by a property.
     *
     * @return an Inventory implementation matching the Inventory properties
     */
    public static Inventory makeInventory() {
        return makeInventory(JbbProperties.getInstance().getSupermarketInventoryType());
    }

    public static Inventory makeInventory(InventoryType type) {
        int totalProducts = JbbProperties.getInstance().getNumberOfInventoryProducts();

        switch (type) {
            case RANDOM:
                return new RandomBarcodeInventory(totalProducts);
            case PARTITIONED_RANDOM:
                int numberOfBuckets = JbbProperties.getInstance().getNumberOfInventoryBuckets();
                int bucketSize = totalProducts / numberOfBuckets;
                return new PartitionedRandomBarcodeInventory(numberOfBuckets, bucketSize);
            case LOCKED_RANDOM:
                return new LockedRandomBarcodeInventory(totalProducts);
            default:
                throw new UnsupportedOperationException("Failed to construct " + type + " inventory");
        }

    }
}
