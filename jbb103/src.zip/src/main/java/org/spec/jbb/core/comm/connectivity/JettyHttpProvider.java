/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity;

import org.spec.jbb.core.comm.connectivity.jettyhttp.JettyHttpServer;
import org.spec.jbb.core.comm.connectivity.plain.PlainHttpClient;
import org.spec.jbb.core.probe.Probe;

public class JettyHttpProvider implements ConnectivityProvider {
    @Override
    public Server newServer(int port, ServerCallback callback) {
        return new JettyHttpServer(port, callback);
    }

    @Override
    public Client newClient(String hostname, int port) {
        return new PlainHttpClient(hostname, port);
    }

    @Override
    public String getName() {
        return "HTTP_Jetty";
    }

    @Override
    public String getDescription() {
        return "Jetty HTTP server, JDK HTTP client";
    }

    @Override
    public void shutdown() {
        // do nothing else
    }

    @Override
    public void instrument(Probe probe) {
        // do nothing
    }

    @Override
    public void sample() {
        // do nothing
    }
}
