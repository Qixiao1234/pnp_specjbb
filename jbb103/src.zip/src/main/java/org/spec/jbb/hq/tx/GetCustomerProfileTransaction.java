/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.entity.CustomerProfile;
import org.spec.jbb.hq.tx.request.GetCustomerProfileRequest;
import org.spec.jbb.hq.tx.response.CustomerProfileResponse;

public class GetCustomerProfileTransaction extends AbstractTransaction {

    private final HQ hq;
    private final long customerID;

    public GetCustomerProfileTransaction(HQ hq, GetCustomerProfileRequest request, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        this.customerID = request.getCustomerId();
    }

    @Override
    public Response execute() throws TransactionException {
        CustomerProfile profile = hq.getCustomerProfile(customerID);
        return new CustomerProfileResponse(profile);
    }

    @Override
    public String toString() {
        return "GetCustomerProfileTx: customerId={" + customerID + "}";
    }

}
