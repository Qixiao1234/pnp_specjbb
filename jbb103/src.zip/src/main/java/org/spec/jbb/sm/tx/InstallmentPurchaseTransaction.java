/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.entity.CustomerProfile;
import org.spec.jbb.hq.entity.Product;
import org.spec.jbb.hq.entity.Receipt;
import org.spec.jbb.hq.tx.request.CheckAndReserveCreditRequest;
import org.spec.jbb.hq.tx.request.DrawCreditRequest;
import org.spec.jbb.hq.tx.request.InstallmentPurchaseReceiptMessage;
import org.spec.jbb.hq.tx.request.PurchaseReceiptMessage;
import org.spec.jbb.sm.InstallmentPurchase;
import org.spec.jbb.sm.ReceiptBuilder;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.ShoppingCartItem;
import org.spec.jbb.sm.coupon.GenericCoupon;
import org.spec.jbb.sm.tx.request.InstallmentPurchaseRequest;

import java.math.BigDecimal;
import java.util.concurrent.ThreadLocalRandom;

public class InstallmentPurchaseTransaction extends InStorePurchaseTransaction {

    public InstallmentPurchaseTransaction(SM sm, InstallmentPurchaseRequest req, TransactionContext ctx) {
        super(sm, req, ctx);
    }

    @Override
    protected boolean doPurchase(Product product, int quantity) throws TransactionException {
        if(super.doPurchase(product, quantity)) {
            shoppingCart.add(sm.getInstallmentFee());
            return true;
        }
        return false;
    }

    @Override
    protected void doCheckout() throws TransactionException {

        CustomerProfile profile = shoppingCart.getProfile();

        GenericCoupon genericCoupon = profile.pollGenericCoupon();
        shoppingCart.setGenericCoupon(genericCoupon);

        Receipt receipt = ReceiptBuilder.build(sm.getNextReceiptNumber(), shoppingCart, sm.getName(), genericCoupon);

        BigDecimal totalPrice = receipt.getTotal();

        BigDecimal downPaymentAmount = totalPrice.multiply(sm.getInstallmentPaymentPercent()).setScale(2, BigDecimal.ROUND_HALF_EVEN);
        final String targetHQ = sm.resolveCustomer(ctx, customerId);

        Response creditResponse = ctx.sendRequest(targetHQ,
                new CheckAndReserveCreditRequest(customerId, downPaymentAmount));

        if (creditResponse instanceof OkResponse) {
            /**
             * Credit accepted. Move out product from Inventory
             */
            for (ShoppingCartItem item : shoppingCart) {
                moveOut(item.getBarcode(), item.getQuantity());
                // Everything is ok, now let's issue new coupons then
                // This logic for initial implementation, later the source for
                // issuing new coupons can come from some data mining operations
                if (ThreadLocalRandom.current().nextInt(100) < sm.getSpecificCouponThresholdPercent()) {
                    // ok, need to issue coupon
                    int cnt = Math.max(1, item.getQuantity() * sm.getSpecificCouponCountPercent() / 100);
                    profile.addSpecificCoupons(item.getBarcode(),
                            sm.getCouponFactory().createSpecificCoupons(item.getBarcode(), cnt));
                }
            }

            // Issue new generic coupon
            if (totalPrice.compareTo(sm.getGenericCouponThreshold()) > 0) {
                // issue generic coupon
                profile.addGenericCoupon(sm.getCouponFactory().createGenericCoupon());
            }

            /**
             * Draw amount from customer's credit
             */
            ctx.sendRequest(targetHQ, new DrawCreditRequest(customerId, totalPrice));

            /**
             * Push receipt
             */
            ctx.sendMessage(owningHQ, new PurchaseReceiptMessage(receipt));

            InstallmentPurchase purchase = new InstallmentPurchase(
                    shoppingCart.getInstallmentFee(), downPaymentAmount, totalPrice,
                    customerId);

            ctx.sendMessage(targetHQ,
                    new InstallmentPurchaseReceiptMessage(purchase));
        } else {
            throw new NotEnoughCreditException("Not enough credit, got " + creditResponse);
        }
    }

    @Override
    public String toString() {
        return super.toString() + ", installment";
    }

}
