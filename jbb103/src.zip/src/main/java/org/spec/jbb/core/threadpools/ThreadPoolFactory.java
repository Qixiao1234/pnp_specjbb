/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

import org.spec.jbb.core.Conventions;
import org.spec.jbb.util.JbbProperties;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.SynchronousQueue;

public class ThreadPoolFactory {

    private ThreadPoolFactory() {
        // prevent instantiation
    }

    public static Multipool newPool(String name) {
        return newPool(name, JbbProperties.getInstance().getThreadPoolTypeFor(Conventions.getPoolID(name)));
    }

    public static Multipool newPool(String name, ThreadPoolType type) {
        int poolSize = JbbProperties.getInstance().getWorkerPoolCountFor(Conventions.getPoolID(name));

        Multipool multipool = createMultipool(name, type.getMultipoolType());
        for (int c = 0; c < poolSize; c++) {
            multipool.addPool(createPool(name, type.getPoolType()));
        }

        return multipool;
    }

    private static Multipool createMultipool(String name, ThreadPoolType.MultiPoolType type) {
        switch (type) {
            case NONE:
                return new EmptyMultiPool();
            case ROUND_ROBIN:
                return new RoundRobinMultiPool(name);
            case FIRST_OPPORTUNITY:
                return new FirstOpportunityMultiPool(name);
            default:
                throw new IllegalArgumentException("Multipool not found: " + type);
        }
    }

    private static Pool createPool(String name, ThreadPoolType.PoolType type) {
        
        String poolID = Conventions.getPoolID(name);

        int batchQueueSize = JbbProperties.getInstance().getQueueSizeFor(poolID);
        int subBatchQueueSize = JbbProperties.getInstance().getSubQueueSizeFor(poolID);

        boolean isFair = JbbProperties.getInstance().isFair(poolID);

        switch (type) {
            case JUC_QUEUE_BATCH_QUEUE_SUBBATCH:
                return new JUCThreadPool(name, new ArrayBlockingQueue<Runnable>(batchQueueSize, isFair), new ArrayBlockingQueue<Runnable>(subBatchQueueSize, isFair));
            case JUC_QUEUE_BATCH_SYNC_SUBBATCH:
                return new JUCThreadPool(name, new ArrayBlockingQueue<Runnable>(batchQueueSize, isFair), new SynchronousQueue<Runnable>(isFair));
            case FORK_JOIN:
                return new ForkJoinThreadPool(name);
            case STATIC_FORK_JOIN:
                return new StaticForkJoinThreadPool(name);
            default:
                throw new IllegalArgumentException("Pool not found: " + type);
        }
    }

}
