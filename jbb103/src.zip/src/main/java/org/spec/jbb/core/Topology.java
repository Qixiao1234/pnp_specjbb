/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core;

import org.spec.jbb.core.collections.HashMultiMap;
import org.spec.jbb.core.collections.MultiMap;
import org.spec.jbb.infra.BackendDescription;
import org.spec.jbb.infra.BackendEntitiesDistribution;
import org.spec.jbb.infra.Group;
import org.spec.jbb.util.JbbProperties;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * This class generates appropriate topology for SPECjbb2015 instance.
 *
 * @author Aleksey Shipilev
 */
public class Topology {

    private final List<String> txiNames;

    private final List<String> hqNames;
    private final List<String> smNames;
    private final List<String> spNames;

    private final Map<String, String>      mapSMtoHQ;
    private final MultiMap<String, String> mapHQtoSM;
    private final MultiMap<String, String> mapHQtoSP;

    private final Map<String, String>      mapBackendToHQ;
    private final MultiMap<String, String> mapBackendToSM;
    private final MultiMap<String, String> mapBackendToSP;
    
    private final Collection<Group> groups;
    private final List<String>      groupIDs;

    private final MultiMap<String, String> groupBEnames;
    private final MultiMap<String, String> groupTXnames;

    private final Map<String, String>      groupToHQ;
    private final MultiMap<String, String> groupToSM;
    private final MultiMap<String, String> groupToSP;

    public Topology() {
        this(JbbProperties.getInstance());
    }

    public Topology(JbbProperties prop) {
        groups = prop.getGroupInfo();

        if (groups.isEmpty()) {
            // Should not happen in real run, only in test mode
            for (int gnum = 1; gnum <= prop.getNumberOfGroups(); gnum++) {
                //System.err.println("Warning: GroupInfo is empty in Topology");
                Group group = new Group("Group" + gnum, 1, 1);
                String JVMID = "CompositeJVM";
                group.getTxInjectorList().add(JVMID);
                BackendEntitiesDistribution distribution = prop.getBackendEntitiesDistribution();
                BackendDescription description = new BackendDescription(JVMID, distribution);
                group.getBackendList().add(description);
                groups.add(group);
            }
        }

        txiNames = new ArrayList<>();
        
        mapSMtoHQ = new HashMap<>();
        mapHQtoSM = new HashMultiMap<>();
        mapHQtoSP = new HashMultiMap<>();
        
        hqNames = new ArrayList<>();
        smNames = new ArrayList<>();
        spNames = new ArrayList<>();

        mapBackendToHQ = new HashMap<>();
        mapBackendToSM = new HashMultiMap<>();
        mapBackendToSP = new HashMultiMap<>();
        
        groupIDs = new ArrayList<>();
        groupBEnames = new HashMultiMap<>();
        groupTXnames = new HashMultiMap<>();
        groupToHQ = new HashMap<>();
        groupToSM = new HashMultiMap<>();
        groupToSP = new HashMultiMap<>();

        generate();
    }

    private void generate() {

        for (Group group : groups) {
            String groupID = group.getID();
            groupIDs.add(groupID);

            /*
               TxInjectors for group
             */
            for (String txInjector : group.getTxInjectorList()) {
                String txiName = Conventions.getTxInjectorName(groupID, txInjector);
                txiNames.add(txiName);
                groupTXnames.put(groupID, txiName);
            }

            /*
               Backends for group
             */
            String beJvmHoldingHq = null;
            for (BackendDescription backendDescription : group.getBackendList()) {
                String beJvmName = Conventions.getBackendName(groupID, backendDescription.getJVMID());
                groupBEnames.put(groupID, beJvmName);

                BackendEntitiesDistribution distribution = backendDescription.getBackendEntitiesDistribution();

                // supermarkets
                for (int sm = 0; sm < distribution.getSMCount(); sm++) {
                    String smName = Conventions.getSMName(beJvmName, sm);
                    mapBackendToSM.put(beJvmName, smName);
                    groupToSM.put(groupID, smName);
                    smNames.add(smName);
                }

                // suppliers
                for (int sp = 0; sp < distribution.getSPCount(); sp++) {
                    String spName = Conventions.getSPName(beJvmName, sp);
                    mapBackendToSP.put(beJvmName, spName);
                    groupToSP.put(groupID, spName);
                    spNames.add(spName);
                }

                // headquarters
                if (distribution.containsHQ()) {
                    beJvmHoldingHq = beJvmName;
                }
            }

            // If no HQ present in this group add it to any Backend JVM
            if (beJvmHoldingHq == null) {
                BackendDescription backend = group.getBackendList().get(0);
                beJvmHoldingHq = Conventions.getBackendName(groupID, backend.getJVMID());
            }

            String hqName = Conventions.getHQname(beJvmHoldingHq);
            mapBackendToHQ.put(beJvmHoldingHq, hqName);
            groupToHQ.put(groupID, hqName);
            hqNames.add(hqName);
        }

        /*
           Bind SM/HQ/SP within the same group.
         */
        for (String groupID : groupIDs) {
            String hqName = groupToHQ.get(groupID);
            for (String smName : groupToSM.get(groupID)) {
                mapSMtoHQ.put(smName, hqName);
                mapHQtoSM.put(hqName, smName);
            }
            for (String spName : groupToSP.get(groupID)) {
                mapHQtoSP.put(hqName, spName);
            }
        }
    }

    /**
     * Answers all HQ names in the system
     * @return hq names
     */
    public Collection<String> getHQnames() {
        return Collections.unmodifiableCollection(hqNames);
    }

    /**
     * Answers all SP names in the system
     * @return SP names
     */
    public Collection<String> getSPnames() {
        return Collections.unmodifiableCollection(spNames);
    }

    /**
     * Answers all SM names in the system
     * @return SM names
     */
    public Collection<String> getSMnames() {
        return Collections.unmodifiableCollection(smNames);
    }

    /**
     * Answers all TxInjector names in the system
     * @return TxInjector names
     */
    public Collection<String> getTXInames() {
        return Collections.unmodifiableCollection(txiNames);
    }

    /**
     * Answers HQ name for given SM.
     * @param smName SM to resolve HQ for
     * @return HQ name
     */
    public String getHQNameForSM(String smName) {
        return mapSMtoHQ.get(smName);
    }

    /**
     * Answers all SMs bound to specific HQ
     * @param hqName HQ to resolve SMs
     * @return list of SM bound to HQ
     */
    public Collection<String> getSMforHQ(String hqName) {
        return Collections.unmodifiableCollection(mapHQtoSM.get(hqName));
    }

    /**
     * Answers all SPs bound to specific HQ
     * @param hqName HQ to resolve SPs
     * @return list of SP bound to HQ
     */
    public Collection<String> getSPforHQ(String hqName) {
        return Collections.unmodifiableCollection(mapHQtoSP.get(hqName));
    }

    /**
     * Answer HQ name for given backend
     * @param backendName backend name
     * @return HQ residing in backend
     */
    public String getHQforBackend(String backendName) {
        return mapBackendToHQ.get(backendName);
    }

    /**
     * Answers all SMs for given backend
     * @param backendName backend name
     * @return list of SM residing in backend
     */
    public Collection<String> getSMforBackend(String backendName) {
        return Collections.unmodifiableCollection(mapBackendToSM.get(backendName));
    }

    /**
     * Answers all SPs for given backend
     * @param backendName backend name
     * @return list of SP residing in backend
     */
    public Collection<String> getSPforBackend(String backendName) {
        return Collections.unmodifiableCollection(mapBackendToSP.get(backendName));
    }

    /**
     * Answers all SMs for given group
     * @param groupID group id
     * @return list of SM working in given group
     */
    public Collection<String> getSMforGroup(String groupID) {
        return Collections.unmodifiableCollection(groupToSM.get(groupID));
    }

    /**
     * Answers all SPs for given group
     * @param groupID group id
     * @return list of SP working in given group
     */
    public Collection<String> getSPforGroup(String groupID) {
        return Collections.unmodifiableCollection(groupToSP.get(groupID));
    }

    /**
     * Answers HQ for given group
     * @param groupID group id
     * @return HQ working in given group
     */
    public String getHQforGroup(String groupID) {
        return groupToHQ.get(groupID);
    }

    /**
     * Answers SMs bound to the same HQ
     * @param smName SM which is bound to HQ
     * @param hqName HQ to look for
     * @return list of SMs bound to specific HQ, except given
     */
    public Collection<String> getSMsInSameHQ(String smName, String hqName) {
        Collection<String> result = new HashSet<>(getSMforHQ(hqName));
        result.remove(smName);
        return Collections.unmodifiableCollection(result);
    }

    /**
     * Answers SMs bound to all HQs, except given
     * @param skipHQname HQ to skip
     * @return list of SMs bound to all HQs except given
     */
    public Collection<String> getSMsInOtherHQ(String skipHQname) {
        Collection<String> namesToEnumerate = new ArrayList<>(hqNames);
        hqNames.remove(skipHQname);

        Set<String> smNames = new HashSet<>();
        for (String hqName : namesToEnumerate) {
            smNames.addAll(mapHQtoSM.get(hqName));
        }
        return Collections.unmodifiableCollection(smNames);
    }

    /**
     * Answers SPs which are remote to given HQ
     * @param hqName HQ name to skip
     * @return list of remote SPs for given HQ
     */
    public Collection<String> getSPNamesRemoteForHQ(String hqName) {
        Set<String> result = new HashSet<>(spNames);
        result.removeAll(mapHQtoSP.get(hqName));
        return Collections.unmodifiableCollection(result);
    }

    /**
     * Answers Backends which contains any HQ
     * @return list of Backends containing any HQ
     */
    public Collection<String> getBackendsHoldingHQ() {
        return mapBackendToHQ.keySet();
    }

    /**
     * Answers Backend which contains given SM
     * @param smName SM name to resolve Backend
     * @return Backend containing the specified SM
     */
    public String getBackendForSM(String smName) {
        for(String be : mapBackendToSM.keySet()) {
            if(mapBackendToSM.get(be).contains(smName)) {
                return be;
            }
        }
        return null;
    }

    public String toString() {
        StringBuilder result = new StringBuilder();
        for (String groupID : groupIDs) {
            result.append("Group " + groupID + ":\n");
            for(String txiName : groupTXnames.get(groupID)) {
                result.append("").append(txiName).append("\n");
            }
            for (String beJvmName : groupBEnames.get(groupID)) {
                result.append(beJvmName).append("\n");

                result.append(" Headquarter:").append("\n");
                String hq = mapBackendToHQ.get(beJvmName);
                if (hq != null) {
                    result.append("   ").append(hq).append("\n");
                }

                result.append(" Supermarkets:").append("\n");
                for (String sm : mapBackendToSM.get(beJvmName)) {
                    result.append("   ").append(sm).append(" (target ").append(getHQNameForSM(sm)).append(")").append("\n");
                }

                result.append(" Suppliers:").append("\n");
                for (String sp : mapBackendToSP.get(beJvmName)) {
                    result.append("   ").append(sp).append("\n");
                }
                result.append("\n");
            }
        }

        result.append("Purchases to be distributed among ").append(getSMnames()).append("\n");
        result.append("Customer drivers to be distributed among ").append(getTXInames()).append("\n");
        result.append("Customers to be distributed among ").append(getHQnames()).append("\n");
        result.append("Product replenishes to be distributed among ").append(getSPnames()).append("\n");
        return result.toString();
    }

}
