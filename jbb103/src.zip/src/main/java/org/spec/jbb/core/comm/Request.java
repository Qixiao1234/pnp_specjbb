/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * Request is something that needs to be answered with Response.
 */
@XmlJavaTypeAdapter(AbstractRequest.JAXBAdapter.class)
public interface Request extends Incoming {

    boolean isRequiresResponse();

}
