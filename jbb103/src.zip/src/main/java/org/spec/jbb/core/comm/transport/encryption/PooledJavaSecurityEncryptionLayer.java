/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport.encryption;

import org.spec.jbb.core.comm.transport.Data;
import org.spec.jbb.core.comm.transport.EncryptionKeys;
import org.spec.jbb.core.objectpool.SimplePool;
import org.spec.jbb.util.InstanceFactory;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;

public class PooledJavaSecurityEncryptionLayer implements EncryptionLayer {

    private final SecretKeySpec skeySpec;
    private final String cipherName;
    private final String modeName;
    private final String paddingName;
    private IvParameterSpec initVector;

    private final SimplePool<Cipher> pool;

    public PooledJavaSecurityEncryptionLayer(String cipherName, String modeName, String paddingName) {
        this.cipherName = cipherName;
        this.modeName = modeName;
        this.paddingName = paddingName;
        this.skeySpec = EncryptionKeys.getFor(cipherName);
        this.pool = new SimplePool<>(new InstanceFactory<Cipher>() {
            private static final long serialVersionUID = 8559418164403350518L;

            @Override
            public Cipher getInstance() {
                try {
                    return Cipher.getInstance(PooledJavaSecurityEncryptionLayer.this.cipherName + "/" + PooledJavaSecurityEncryptionLayer.this.modeName + "/" + PooledJavaSecurityEncryptionLayer.this.paddingName);
                } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
                    throw new IllegalStateException(e);
                }
            }
        });
        this.initVector = new IvParameterSpec(
                new byte[]{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00});
    }

    @Override
    public Data convertDown(Data topInstance) {
        Cipher cipher = null;
        try {
            cipher = pool.acquire();
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, initVector);
            byte[] data = cipher.doFinal(topInstance.getArray());
            return Data.wrap(data);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(cipherName + " transport marshaller throws unexpected exception: " + e);
        } finally {
            if (cipher != null) {
                pool.release(cipher);
            }
        }
    }

    @Override
    public Data convertUp(Data bottomInstance) {
        Cipher cipher = null;
        try {
            cipher = pool.acquire();
            cipher.init(Cipher.DECRYPT_MODE, skeySpec, initVector);
            byte[] data = cipher.doFinal(bottomInstance.getArray());
            return Data.wrap(data);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(cipherName + " transport unmarshaller throws unexpected exception: " + e);
        } finally {
            if (cipher != null) {
                pool.release(cipher);
            }
        }
    }
}
