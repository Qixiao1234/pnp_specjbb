/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.response;

import org.spec.jbb.core.comm.AbstractResponse;
import org.spec.jbb.core.comm.transport.TransportType;
import org.spec.jbb.hq.entity.HQBusinessReport;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
public class BusinessReportResponse extends AbstractResponse {

    private static final long serialVersionUID = -5115612446516201193L;
    @XmlElement
    private final HQBusinessReport report;

    private BusinessReportResponse() {
        // JAXB
        this(null);
    }

    public BusinessReportResponse(HQBusinessReport report) {
        this.report = report;
    }

    public HQBusinessReport getReport() {
        return report;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        BusinessReportResponse that = (BusinessReportResponse) o;

        if (report != null ? !report.equals(that.report) : that.report!= null) {
            return false;
        }

        return true;

    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), report);
    }

    @Override
    public String toString() {
        return "BusinessReport: report={" + report + "}";
    }

    @Override
    public TransportType getTransportHint() {
        return TransportType.XML_COMPRESSED_ENCRYPTED;
    }
}
