/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections.queues;

import java.util.Queue;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;

public class StripedDelayQueue<E extends Delayed> extends AbstractStripedQueue<E> {

    private static final long serialVersionUID = 4581905065315053563L;

    public StripedDelayQueue() {
        super(0);
    }

    public StripedDelayQueue(int stripes) {
        super(0, stripes);
    }

    @Override
    protected Queue<E> newQueue(int capacity) {
        return new DelayQueue<>();
    }

}
