/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

import org.spec.jbb.core.collections.HashMultiMap;
import org.spec.jbb.core.collections.MultiMap;
import org.spec.jbb.core.collections.queues.QueueFactory;
import org.spec.jbb.core.comm.LocationInfo;
import org.spec.jbb.infra.IterationStatus;
import org.spec.jbb.infra.TimeData;
import org.spec.jbb.infra.validation.ValidationReport;
import org.spec.jbb.util.JbbProperties;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class StreamingSourceData implements SourceData {

    private final Map<String, String> marks;
    private final MultiMap<String, LocationInfo> agentInfo;
    private final String source;

    private final Queue<VisitorTicket> processQueue;
    private final ScheduledExecutorService executor;
    private final AtomicInteger readRequests;
    private final AtomicInteger readActual;
    private volatile boolean isDataValid;

    public StreamingSourceData(String source) {
        this.source = source;
        this.marks = new HashMap<>();
        this.agentInfo = new HashMultiMap<>();

        processQueue = QueueFactory.getUnboundedQueue();
        readRequests = new AtomicInteger();
        readActual = new AtomicInteger();

        executor = Executors.newScheduledThreadPool(Runtime.getRuntime().availableProcessors());
        executor.scheduleAtFixedRate(new ReadDataTask(), 100, 100, TimeUnit.MILLISECONDS);
    }

    @Override
    public void ensureRead() {
        // pre-read marks only

        RunDataReader reader = new RunDataReader(source);
        Frame data;
        while((data = reader.getNextPoint()) != null) {
            if (data instanceof MarkFrame) {
                marks.put(((MarkFrame) data).getKey(), ((MarkFrame) data).getValue());
            }
            if (data instanceof AgentInfoFrame) {
                agentInfo.putAll(((AgentInfoFrame) data).getAgent(), ((AgentInfoFrame) data).getLocations());
            }
        }

        isDataValid = reader.isDataValid();
        reader.close();
    }

    @Override
    public void runPass(Collection<? extends Visitor> visitors) {

       List<Visitor> acceptedVisitors = new ArrayList<>();
        for (Visitor visitor : visitors) {
            if (visitor.shouldRun()) {
                acceptedVisitors.add(visitor);
            }
        }

        List<VisitorTicket> tickets = new ArrayList<>();
        for (Visitor visitor : acceptedVisitors) {
            VisitorTicket ticket = new VisitorTicket(visitor);
            processQueue.add(ticket);
            tickets.add(ticket);
        }

        readRequests.incrementAndGet();

        // Using ManagedBlocker below instantiates new helper thread
        // when one is waiting on I/O to be processed. This enables more
        // requests coming here, and more I/O merged together. While technically
        // the number of blocked threads is unbounded, it is capped by maximum
        // parallelism exploitable in data (which is not high).

        for (VisitorTicket ticket : tickets) {
            try {
                ForkJoinPool.managedBlock(new ForkJoinLatchWaiter(ticket.latch));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }

    }

    @Override
    public final void runPass(Collection<? extends Visitor>... visitors) {
        List<Visitor> composite = new ArrayList<>();
        for (Collection<? extends Visitor> coll : visitors) {
            composite.addAll(coll);
        }
        runPass(composite);
    }

    private class ReadDataTask implements Runnable {

        @Override
        public void run() {
            List<VisitorTicket> tickets = new ArrayList<>();
            VisitorTicket cur;
            while ((cur = processQueue.poll()) != null) {
                tickets.add(cur);
            }

            if (tickets.size() > 0) {
                readActual.incrementAndGet();
                
                RunDataReader reader = new RunDataReader(source);
                Frame data;
                while((data = reader.getNextPoint()) != null) {
                    if (data instanceof StatsFrame) {
                        for (VisitorTicket ticket : tickets) {
                            ticket.visitor.visit((StatsFrame) data);
                        }
                    }
                }
                reader.close();

                for (VisitorTicket ticket : tickets) {
                    ticket.latch.countDown();
                }
            }
        }
    }
    
    private static class VisitorTicket {
        private final Visitor visitor;
        private final CountDownLatch latch;
        
        public VisitorTicket(Visitor visitor) {
            this.visitor = visitor;
            this.latch = new CountDownLatch(1);
        }
        
    }

    @Override
    public void runPass(Visitor... visitors) {
        runPass(Arrays.asList(visitors));
    }

    @Override
    public void shutdown() {
        System.err.println("I/O merges: file read requests = " + readRequests + ", actual reads = " + readActual.intValue());
        
        executor.shutdownNow();
    }

    @Override
    public Iterable<LogRecordFrame.LogDataChunk> getLogRecords() {
        return new Iterable<LogRecordFrame.LogDataChunk>() {
            @Override
            public Iterator<LogRecordFrame.LogDataChunk> iterator() {
                return new Iterator<LogRecordFrame.LogDataChunk>() {

                    private FrameIterator<LogRecordFrame> iterator = new FrameIterator<>(source, LogRecordFrame.class);

                    @Override
                    public boolean hasNext() {
                        return iterator.hasNext();
                    }

                    @Override
                    public LogRecordFrame.LogDataChunk next() {
                        return iterator.next().getData();
                    }

                    @Override
                    public void remove() {
                        iterator.remove();
                    }
                };
            }
        };
    }

    @Override
    public Iterable<ValidationReport> getValidationReports() {
        return new Iterable<ValidationReport>() {

            @Override
            public Iterator<ValidationReport> iterator() {
                return new Iterator<ValidationReport>() {
                    private FrameIterator<ValidationFrame> iterator = new FrameIterator<>(source, ValidationFrame.class);

                    @Override
                    public boolean hasNext() {
                        return iterator.hasNext();
                    }

                    @Override
                    public ValidationReport next() {
                        return iterator.next().getReport();
                    }

                    @Override
                    public void remove() {
                        iterator.remove();
                    }
                };
            }
            
        };
    }
    
    public Iterable<Map<String, JbbProperties>> getProperties() {
        return new Iterable<Map<String, JbbProperties>>() {
            @Override
            public Iterator<Map<String, JbbProperties>> iterator() {
                return new Iterator<Map<String, JbbProperties>>() {

                    private FrameIterator<PropertiesFrame> iterator = new FrameIterator<>(source, PropertiesFrame.class);

                    @Override
                    public boolean hasNext() {
                        return iterator.hasNext();
                    }

                    @Override
                    public Map<String, JbbProperties> next() {
                        return iterator.next().getPropsMap();
                    }

                    @Override
                    public void remove() {
                        iterator.remove();
                    }
                };
            }
        };
    }

    @Override
    public Iterable<IterationStatus> getStatuses() {
        return new Iterable<IterationStatus>() {
            @Override
            public Iterator<IterationStatus> iterator() {
                return new Iterator<IterationStatus>() {

                    private FrameIterator<RunStatusFrame> iterator = new FrameIterator<>(source, RunStatusFrame.class);

                    @Override
                    public boolean hasNext() {
                        return iterator.hasNext();
                    }

                    @Override
                    public IterationStatus next() {
                        return iterator.next().getStatus();
                    }

                    @Override
                    public void remove() {
                        iterator.remove();
                    }
                };
            }
        };
    }

    @Override
    public Map<String, String> getMarks() {
        return marks;
    }

    @Override
    public Iterable<TimeData> getTimeData() {
        return new Iterable<TimeData>() {
            @Override
            public Iterator<TimeData> iterator() {
                return new Iterator<TimeData>() {

                    private FrameIterator<TimeDataFrame> iterator = new FrameIterator<>(source, TimeDataFrame.class);

                    @Override
                    public boolean hasNext() {
                        return iterator.hasNext();
                    }

                    @Override
                    public TimeData next() {
                        return iterator.next().getTimeData();
                    }

                    @Override
                    public void remove() {
                        iterator.remove();
                    }
                };
            }
        };
    }

    @Override
    public boolean isDataValid() {
        return isDataValid;
    }

    @Override
    public MultiMap<String, LocationInfo> getAgentInfos() {
        return agentInfo;
    }

    protected static class FrameIterator<C extends Frame> implements Iterator<C> {

        private final RunDataReader reader;
        private final String source;
        private final Class<C> filter;

        private C nextPoint;
        
        public FrameIterator(String source, Class<C> filter) {
            this.source = source;
            this.filter = filter;
            reader = new RunDataReader(this.source);
        }
        
        private void readNext() {
            if (nextPoint == null) {
                C frame;
                while ((frame = (C) reader.getNextPoint()) != null) {
                    if (filter.isAssignableFrom(frame.getClass())) {
                        nextPoint = frame;
                        return;
                    }
                }
            }
        }

        @Override
        public boolean hasNext() {
            readNext();
            return (nextPoint != null);
        }

        @Override
        public C next() {
            readNext();
            C answer = nextPoint;
            nextPoint = null;
            return answer;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }
    
    private static class ForkJoinLatchWaiter implements ForkJoinPool.ManagedBlocker {
        private final CountDownLatch latch;

        public ForkJoinLatchWaiter(CountDownLatch latch) {
            this.latch = latch;
        }

        @Override
        public boolean block() throws InterruptedException {
            latch.await();
            return true;
        }

        @Override
        public boolean isReleasable() {
            return latch.getCount() == 0;
        }
    }
}
