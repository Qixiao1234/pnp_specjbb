/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.spi;

import org.spec.jbb.core.cache.Cache;
import org.spec.jbb.core.cache.Connector;
import org.spec.jbb.core.cache.HardReferenceCache;
import org.spec.jbb.core.collections.Pair;

import java.util.Collection;
import java.util.HashSet;
import java.util.ServiceLoader;
import java.util.Set;

public class SpiFactory<T extends LoadableProvider> {

    private final ServiceLoader<T> loader;
    private final Cache<Void, String, T> cache;

    public SpiFactory(Class<T> klass) {
        loader = ServiceLoader.load(klass);
        cache = new HardReferenceCache<>();
        cache.setConnector(new Connector<Void, String, T>() {
            @Override
            public T read(Void ctx, String key) {
                for (T provider : loader) {
                    if (provider.getName().equalsIgnoreCase(key)) {
                        return provider;
                    }
                }
                throw new IllegalStateException(key + " is not available");
            }

            @Override
            public void write(Void ctx, String key, T value) {
                throw new UnsupportedOperationException("Unsupported operation");
            }

            @Override
            public int getPriority(Void ctx, String key) {
                return 0;
            }
        });
    }

    public void shutdown() {
        for (T provider : loader) {
            provider.shutdown();
        }
    }

    protected T get(String name) {
        return cache.get(null, name);
    }

    public Collection<String> listProviders() {
        Set<String> result = new HashSet<>();
        for(T provider : loader) {
            result.add(provider.getName());
        }
        return result;
    }

    public Collection<Pair<String, String>> listProvidersWithDesc() {
        Set<Pair<String, String>> result = new HashSet<>();
        for(T provider : loader) {
            result.add(new Pair<>(provider.getName(), provider.getDescription()));
        }
        return result;
    }


}
