/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

import org.spec.jbb.core.collections.MultiMap;
import org.spec.jbb.core.comm.LocationInfo;
import org.spec.jbb.infra.IterationStatus;
import org.spec.jbb.infra.TimeData;
import org.spec.jbb.infra.validation.ValidationReport;
import org.spec.jbb.util.JbbProperties;

import java.util.Collection;
import java.util.Map;

public interface SourceData {
    void ensureRead();

    void runPass(Collection<? extends Visitor> visitors);

    void runPass(Collection<? extends Visitor>... visitors);

    void runPass(Visitor... visitors);

    void shutdown();

    Iterable<LogRecordFrame.LogDataChunk> getLogRecords();

    Iterable<Map<String, JbbProperties>> getProperties();

    Iterable<IterationStatus> getStatuses();
    
    MultiMap<String, LocationInfo> getAgentInfos();
    
    Iterable<ValidationReport> getValidationReports();
    
    Iterable<TimeData> getTimeData();

    Map<String, String> getMarks();

    boolean isDataValid();

}
