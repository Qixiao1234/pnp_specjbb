/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

import java.util.Map;

import org.spec.jbb.util.JbbProperties;

public class PropertiesFrame implements Frame {

    public static final long serialVersionUID = 1L;

    private final Map<String, JbbProperties> agentPropertiesMap;

    public PropertiesFrame(Map<String, JbbProperties> agentPropertiesMap) {
        this.agentPropertiesMap = agentPropertiesMap;
    }

    public Map<String, JbbProperties> getPropsMap() {
        return agentPropertiesMap;
    }
    
    @Override
    public Frame cleanForSubmission(CleanForSubmissionContext ctx) {
        boolean isDiffer = false;
        JbbProperties controller = agentPropertiesMap.get("Controller");
        for (Map.Entry<String, JbbProperties> entry : agentPropertiesMap.entrySet()) {
            if (!entry.getKey().equals("Controller")) {
                if (entry.getValue().equals(controller)) {
                    entry.setValue(controller);
                } else {
                    isDiffer = true;
                }
            }
        }
        if(!ctx.isDefaultPropertiesSkipped()) {
            ctx.setDefaultPropertiesSkipped();
        } else {
            if (!isDiffer) {
                JbbProperties master = ctx.getMasterControllerProperties();
                if (master == null) {
                    ctx.setMasterControllerProperties(controller);
                } else {
                    if (master.equals(controller)) {
                        return null;
                    }
                }
            }
        }
        return this;
    }

    @Override
    public String toString() {
        return "Properties: " + agentPropertiesMap;
    }
}
