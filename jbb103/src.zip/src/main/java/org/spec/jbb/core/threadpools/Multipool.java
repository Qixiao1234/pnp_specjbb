/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

/**
 * MultiPool is Pool implementation which aggregates several threadpools and enforces scheduling policy around them.
 * Exact scheduling is due to final implementation.
 */
public interface Multipool extends Pool {

    void addPool(Pool pool);

}
