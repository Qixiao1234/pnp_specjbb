/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.probe;

public class NonIntrusiveProbe extends IntrusiveProbe {

    @Override
    public void inc(String label) {
        // do nothing
    }

    @Override
    public void add(String label, long inc) {
        // do nothing
    }

    @Override
    public void countType(String label, Object o) {
        // do nothing
    }

    @Override
    public void countType(String label, Object o, long inc) {
        // do nothing
    }

    @Override
    public Probe getChild(String prefix) {
        return register(prefix, new NonIntrusiveProbe());
    }

    @Override
    public boolean shouldGoInsane() {
        return false;
    }
}
