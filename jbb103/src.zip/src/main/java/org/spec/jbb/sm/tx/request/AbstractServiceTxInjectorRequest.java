/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.request;

public abstract class AbstractServiceTxInjectorRequest extends AbstractTxInjectorRequest {
    private static final long serialVersionUID = 7688378969744335945L;

    protected AbstractServiceTxInjectorRequest() {
    }

}
