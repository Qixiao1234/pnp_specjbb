/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

public class ChecksumFrame implements Frame {
    private static final long serialVersionUID = 1L;

    private final long checksum;

    public ChecksumFrame(long checksum) {
        this.checksum = checksum;
    }

    public long getChecksum() {
        return checksum;
    }

    @Override
    public Frame cleanForSubmission(CleanForSubmissionContext ctx) {
        return this;
    }

    @Override
    public String toString() {
        return "Checksum: " + checksum;
    }
}
