/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.discount;

import java.util.List;

/**
 * This is discount agent.
 * It is responsible for preparation data required for issuing discount,
 * keeping the list of issued discounts and purging it. 
 *
 */
public interface DiscountAgent {
    /**
     * Add issued Discount batch to storage
     * 
     * @param batch issued discount batch
     */
    public void addDiscountBatch(List<Discount> batch);
    /**
     * Prepare the list of discounts.
     * 
     * @return discount batch ready to be issued
     */
    public List<Discount> createDiscountBatch();
    /**
     * Returns the oldest Discount batch and remove it from storage
     * 
     * @return oldest discount batch or null is there is no issued Discount batches
     */
    public List<Discount> pollDiscountBatch();
    
    /**
     * Reserve the slot for storing issued Discount batch.
     * 
     * @return true if slot is available
     */
    public boolean reserveSlot();
}
