/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.request.FindCustomerZipRequest;
import org.spec.jbb.hq.tx.response.FindCustomerZipResponse;

public class FindCustomerZipTransaction extends AbstractTransaction {

    private final HQ hq;
    private final long customerId;

    public FindCustomerZipTransaction(HQ hq, FindCustomerZipRequest req, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        this.customerId = req.getCustomerId();
    }

    @Override
    public Response execute() throws TransactionException {
        return new FindCustomerZipResponse(hq.getCustomerZipCode(customerId));
    }

    @Override
    public String toString() {
        return "FindCustomerZipTransaction: customer={" + customerId + "}";
    }
}
