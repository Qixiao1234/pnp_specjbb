/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.request;

import org.spec.jbb.core.comm.AbstractMessage;
import org.spec.jbb.core.comm.transport.TransportType;
import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.CustomerRefundTransaction;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.math.BigDecimal;
import java.util.Objects;

@XmlRootElement
public class CustomerRefundMessage extends AbstractMessage {

    private static final long serialVersionUID = -6661587646020361083L;
    @XmlElement
    private final long customerId;
    
    @XmlElement
    private final BigDecimal amount;
   
    private CustomerRefundMessage() {
        // JAXB
        this(0L, null);
    }
   
    public CustomerRefundMessage(long customerId, BigDecimal amount) {
        super();
        this.customerId = customerId;
        this.amount = amount;
    }

    public long getCustomerId() {
        return customerId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    @Override
    public boolean isDurable() {
        return true;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CustomerRefundMessage that = (CustomerRefundMessage) o;

        if (customerId != that.customerId) {
            return false;
        }
        
        if (amount != null ? !amount.equals(that.amount) : that.amount != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(customerId, amount);
    }

    @Override
    public Transaction getTransaction(HQ hq, TransactionContext ctx) {
        return new CustomerRefundTransaction(hq, this, ctx);
    }

    @Override
    public String toString() {
        return "Customer refund, customerId = {" + customerId + "}, amount = {" + amount.toString() + "}" ;
    }

    @Override
    public TransportType getTransportHint() {
        return TransportType.SERIALIZED_ENCRYPTED;
    }

}
