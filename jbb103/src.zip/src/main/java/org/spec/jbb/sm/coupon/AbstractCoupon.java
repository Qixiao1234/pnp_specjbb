/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.coupon;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

/**
 * Abstract implementation of the coupon which handles expiration and percent 
 * attributes of the coupon
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
public abstract class AbstractCoupon implements Coupon {

    private static final long serialVersionUID = -5595664755301637122L;
    /**
     *  The date when this coupon is expired
     */
    @XmlElement
    private final Date expirationDate;
    /**
     * The percent of reducing the price if the coupon is applied
     */
    @XmlElement
    private final int percent;

    @XmlElement
    private final BigDecimal multiplier;
    
    protected AbstractCoupon() {
        this(null, 0);
    }

    public AbstractCoupon(Date expirationDate, int percent) {
        this.expirationDate = expirationDate;
        this.percent = percent;
        this.multiplier = BigDecimal.ONE.subtract(BigDecimal.valueOf(percent, 2));
    }

    @Override
    public Date getExpirationDate() {
        return expirationDate;
    }

    @Override
    public boolean isExpired(Date compareTo) {
        return expirationDate.before(compareTo);
    }

    @Override
    public int getPercent() {
        return percent;
    }

    @Override
    public BigDecimal getMultiplier() {
        return multiplier;
    }

    @Override
    public int compareTo(Coupon c) {
        return expirationDate.compareTo(c.getExpirationDate());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        AbstractCoupon c = (AbstractCoupon) o;
        if (this.percent != c.percent) {
            return false;
        }
        if (expirationDate != null ? !expirationDate.equals(c.expirationDate) : c.expirationDate != null) {
            return false;
        }
        
        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(percent, expirationDate);
    }

    @Override
    public String toString() {
        return "percent=" + percent + ", expiration date=" + expirationDate;
    }

}
