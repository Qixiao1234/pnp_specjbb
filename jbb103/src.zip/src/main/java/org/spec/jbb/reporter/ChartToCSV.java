/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryMarker;
import org.jfree.chart.plot.IntervalMarker;
import org.jfree.chart.plot.Marker;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.Layer;
import org.spec.jbb.core.collections.CollectionUtils;
import org.spec.jbb.core.collections.HashMultiMap;
import org.spec.jbb.core.collections.MultiMap;
import org.spec.jbb.core.collections.UnaryFunction;

public class ChartToCSV {
    private final Reporter reporter;

    public ChartToCSV(Reporter reporter) {
        this.reporter = reporter;
    }

    public void writeChart(File file, JFreeChart chart) {
        if(!reporter.createResDir(image2data(Paths.get(reporter.getTarget()).relativize(file.getParentFile().toPath())).toString())) {
            return;
        }
        try (
            PrintWriter pw = new PrintWriter(image2data(file.toPath()).toFile());
        ) {
            pw.println(chart.getTitle().getText());
            try {
                XYPlot plot = chart.getXYPlot();
                int datasetCount = plot.getDatasetCount();
                for (int d = 0; d < datasetCount; d++) {
                    pw.println("===================================");
                    printMarkers(pw, "Domain Marker", plot.getDomainMarkers(d, Layer.FOREGROUND));
                    printMarkers(pw, "Domain Marker", plot.getDomainMarkers(d, Layer.BACKGROUND));
                    printMarkers(pw, "Range Marker", plot.getRangeMarkers(d, Layer.FOREGROUND));
                    printMarkers(pw, "Range Marker", plot.getRangeMarkers(d, Layer.BACKGROUND));
                    XYDataset set = plot.getDataset(d);
                    int serCount = set.getSeriesCount();
                    
                    List<MultiMap<Number, Number>> data = new ArrayList<>();
                    Set<Number> xValuesSet = new HashSet<>();
                    pw.print(plot.getDomainAxisForDataset(d).getLabel());
                    for (int s = 0; s < serCount; s++) {
                        pw.print(";" + set.getSeriesKey(s));
                        
                        MultiMap<Number, Number> values = new HashMultiMap<>();
                        data.add(values);
                        for (int i = 0; i < set.getItemCount(s); i++) {
                            Number x = set.getX(s, i);
                            xValuesSet.add(x);
                            values.put(x, set.getY(s, i));
                        }
                    }
                    pw.println();
                    
                    List<Number> xValues = new ArrayList<>(xValuesSet);
                    Collections.sort(xValues, new Comparator<Number>() {

                        @Override
                        public int compare(Number o1, Number o2) {
                            return Double.compare(o1.doubleValue(), o2.doubleValue());
                        }
                    });
                    for (Number n : xValues) {
                        int maxX = Collections.max(CollectionUtils.map(data, new GetSizeFunction(n)));
                        List<Iterator<Number>> iterators = CollectionUtils.map(data, new GetIteratorFunction(n));
                        for (int j = 0; j < maxX; j++) {
                            pw.print(n);
                            for (int s = 0; s < serCount; s++) {
                                pw.print(';');
                                if (iterators.get(s).hasNext()) {
                                    pw.print(iterators.get(s).next());
                                }
                            }
                            pw.println();
                        }
                    }
                }
            } catch (ClassCastException exc) {
                pw.println("Not XY plot, nothing to do");
                reporter.getPw().println("Not XY plot, nothing to do for " + file);
            }
            reporter.getResources().addResource(image2data(file.toPath()).toFile());
        } catch (IOException io) {
        }
    }

    private void printMarkers(PrintWriter pw, String label, Collection markers) {
        if (markers != null) {
            for (Object marker : markers) {
                pw.print(label + ";" + ((Marker) marker).getLabel() + ";");
                if (marker instanceof CategoryMarker) {
                    pw.println(((CategoryMarker) marker).getKey());
                } else if (marker instanceof ValueMarker) {
                    pw.println(((ValueMarker) marker).getValue());
                } else if (marker instanceof IntervalMarker) {
                    IntervalMarker im = (IntervalMarker) marker;
                    pw.println(im.getStartValue() + ";" + im.getEndValue());
                } else {
                    pw.println(marker.getClass());
                }
            }
        }
    }

    private Path image2data(Path p) {
        Path result = null;
        for(int idx = 0; idx < p.getNameCount(); idx++) {
            String name = p.getName(idx).toString();
            if("images".equals(name)) {
                result = result == null ? Paths.get("data") : result.resolve("data");
            } else {
                result = result == null ? Paths.get(name) : result.resolve(name);
            }
        }
        return result == null ? p : result;
    }
    
    private static final class GetSizeFunction implements UnaryFunction<MultiMap<Number, Number>, Integer> {

        private final Number x;

        public GetSizeFunction(Number x) {
            this.x = x;
        }

        @Override
        public Integer apply(MultiMap<Number, Number> value) {
            return value.get(x).size();
        }
    }

    private static final class GetIteratorFunction implements UnaryFunction<MultiMap<Number, Number>, Iterator<Number>> {

        private final Number x;

        public GetIteratorFunction(Number x) {
            this.x = x;
        }

        @Override
        public Iterator<Number> apply(MultiMap<Number, Number> value) {
            return value.get(x).iterator();
        }
    }

}
