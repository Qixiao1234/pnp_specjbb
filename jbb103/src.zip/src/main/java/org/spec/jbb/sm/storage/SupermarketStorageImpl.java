/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.storage;

import org.spec.jbb.core.cache.Cache;
import org.spec.jbb.core.cache.WriteBackCache;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.sequencer.Sequencer;
import org.spec.jbb.core.sequencer.SequencerFactory;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.entity.CustomerProfile;
import org.spec.jbb.hq.entity.Product;
import org.spec.jbb.sm.advertisement.AdvertisementAgent;
import org.spec.jbb.sm.advertisement.Advertisements;
import org.spec.jbb.sm.discount.DiscountAgent;
import org.spec.jbb.sm.inventory.Inventory;

import java.io.Serializable;

/**
 * Supermarket storage stores all mutable business data in Supermarket
 */
public class SupermarketStorageImpl implements Serializable, SupermarketStorage {

    private static final long serialVersionUID = -1715645584054310723L;
    private final Sequencer<Long> receiptSequencer = SequencerFactory.getDefaultSequencer();

    private final Cache<TransactionContext, Long, Product> productCache;

    private final Cache<TransactionContext, Long, String> customerCache;

    private final Inventory inventory;

    private final WriteBackCache<TransactionContext, Long, CustomerProfile> customerProfileCache;

    /**
     * Discount agent is responsible for generating discounts
     * Each SM has got separate agent.
     */
    private final DiscountAgent discountAgent;

    /**
     * Advertisement agent is responsible for generating advertisements
     * Each SM has got separate agent.
     */
    private final AdvertisementAgent advertisementAgent;

    /**
     * Available Advertisements in this SM
     */
    private final Advertisements advertisements;

    public SupermarketStorageImpl(
            Inventory inventory,
            Cache<TransactionContext, Long, Product> productCache,
            Cache<TransactionContext, Long, String> customerCache,
            WriteBackCache<TransactionContext, Long, CustomerProfile> customerProfileCache,
            DiscountAgent discountAgent,
            AdvertisementAgent advertisementAgent,
            Advertisements advertisements) {
        this.inventory = inventory;
        this.productCache = productCache;
        this.customerCache = customerCache;
        this.customerProfileCache = customerProfileCache;
        this.discountAgent = discountAgent;
        this.advertisementAgent = advertisementAgent;
        this.advertisements = advertisements;
    }

    @Override
    public Sequencer<Long> getReceiptSequencer() {
        return receiptSequencer;
    }

    /*
     * Product cache
     */
    @Override
    public Cache<TransactionContext, Long, Product> getProductCache() {
        return productCache;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    @Override
    public WriteBackCache<TransactionContext, Long, CustomerProfile> getCustomerProfileCache() {
        return customerProfileCache;
    }

    @Override
    public Cache<TransactionContext, Long, String> getCustomerCache() {
        return customerCache;
    }

    @Override
    public AdvertisementAgent getAdvertisementAgent() {
        return advertisementAgent;
    }

    @Override
    public Advertisements getAdvertisements() {
        return advertisements;
    }

    @Override
    public DiscountAgent getDiscountAgent() {
        return discountAgent;
    }

    @Override
    public void instrument(Probe probe) {
        customerProfileCache.instrument(probe.getChild("customerProfileCache"));
        customerCache.instrument(probe.getChild("customerCache"));
        productCache.instrument(probe.getChild("productCache"));
        inventory.instrument(probe.getChild("inventory"));
    }

    @Override
    public void sample() {
        customerProfileCache.sample();
        customerCache.sample();
        productCache.sample();
        inventory.sample();
    }

    @Override
    public void preSnapshot() {
        // do nothing
    }

    @Override
    public void postSnapshot() {
        // do nothing
    }

    @Override
    public void postRecover() {
        // do nothing
    }
}
