/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.scheduler;

import org.spec.jbb.core.threadpools.ThreadUtils;
import org.spec.jbb.util.random.SpecRandom;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import org.spec.jbb.core.collections.CollectionUtils;
import org.spec.jbb.util.JbbProperties;

/**
 * LoopTimerQueuedScheduler uses spinloop-ed threads to produce timing events for scheduling tasks.
 * The work is done in worker threads in separate pool.
 */
public class LoopTimerQueuedScheduler implements Scheduler {

    /**
     * Minimal time to sleep.
     */
    private static final long SLEEP_THRESHOLD_NSEC = TimeUnit.MILLISECONDS.toNanos(20);

    /**
     * Maximum number of quartz threads
     */
    private static final long MAX_QUARTZ_THREADS = 512;

    /**
     * Number of quartzes active
     */
    private AtomicInteger activeQuartzes = new AtomicInteger();

    /**
     * Worker pool
     */
    private ThreadPoolExecutor workerPool;

    /**
     * Quartzes for concrete task
     */
    private ConcurrentMap<ScheduledTask, QuartzTask> quartzes;

    private Lock globalLock;

    /**
     * Thread factory to use
     */
    private final ThreadFactory factory;

    public LoopTimerQueuedScheduler(int threads, ThreadFactory factory) {
        this.factory = factory;
        this.globalLock = new ReentrantLock();
        this.workerPool = new ThreadPoolExecutor(threads, threads,
                0L, TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<Runnable>(
                        CollectionUtils.integerSaturate((long) threads * JbbProperties.getInstance().getCustomerDriverQueueMultiplier())),
                factory);
        quartzes = new ConcurrentHashMap<>();
    }

    @Override
    public void register(ScheduledTask task, SpecRandom delayRandom, DelayType delayType) {
        globalLock.lock();
        try {
            QuartzTask quartz = new QuartzTask(task, delayRandom, delayType);
            QuartzTask existing = quartzes.put(task, quartz);
            if (existing != null) {
                existing.disable(true);
            }

            if (activeQuartzes.get() > MAX_QUARTZ_THREADS) {
                throw new IllegalStateException("Too many quartzes: tasks = " + quartzes.size() + ", quartzes = " + activeQuartzes.get() + ", max = " + MAX_QUARTZ_THREADS);
            }
        } finally {
            globalLock.unlock();
        }
    }

    @Override
    public void remove(ScheduledTask task) {
        disable(task);
        quartzes.remove(task);
    }

    @Override
    public void enable(ScheduledTask task) {
        globalLock.lock();
        try {
            QuartzTask quartz = quartzes.get(task);
            quartz.enable();
        } finally {
            globalLock.unlock();
        }
    }

    @Override
    public void disable(ScheduledTask task) {
        globalLock.lock();
        try {
            QuartzTask quartz = quartzes.get(task);
            quartz.disable(true);
        } finally {
            globalLock.unlock();
        }
    }

    @Override
    public void zap() {
        workerPool.getQueue().clear();
    }

    @Override
    public void shutdown() {
        globalLock.lock();
        try {
            for (QuartzTask quartz : quartzes.values()) {
                quartz.disable(false);
            }
            ThreadUtils.terminatePool(workerPool);
        } finally {
            globalLock.unlock();
        }
    }

    /**
     * Quartz task.
     */
    private class QuartzTask implements Runnable {

        private final ScheduledTask task;
        private final SpecRandom random;
        private final List<Thread> threads;
        private final int quartzCount;

        public QuartzTask(ScheduledTask task, SpecRandom delayRandom, DelayType delayType) {
            this.task = task;
            this.random = delayRandom;

            threads = new ArrayList<>();

            quartzCount = (int) ((SLEEP_THRESHOLD_NSEC / delayRandom.getMean()) + 1);
        }

        @Override
        public void run() {
            try {
                TimeUnit.NANOSECONDS.sleep(nextSleepInterval());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }

            /**
             * Spin-loop until terminated
             */
            long nextEntry = System.nanoTime();
            while (!Thread.currentThread().isInterrupted()) {

                nextEntry = nextEntry + nextSleepInterval();

                try {
                    /**
                     * Submit the job and count time to compensate possible stalls.
                     */
                    workerPool.submit(task.getRunTask());
                } catch (RejectedExecutionException e) {
                    // swallow
                }

                long sleep = nextEntry - System.nanoTime();

                try {
                    TimeUnit.NANOSECONDS.sleep(sleep);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
        }

        private long nextSleepInterval() {
            return random.nextLong() * quartzCount;
        }

        private Lock transitionLock = new ReentrantLock();

        public void enable() {
            transitionLock.lock();
            try {
                for (int c = 0; c < quartzCount; c++) {
                    Thread thread = factory.newThread(this);
                    thread.setName(thread.getName() + ".quartz");
                    threads.add(thread);
                    thread.start();
                }

                activeQuartzes.addAndGet(quartzCount);
            } finally {
                transitionLock.unlock();
            }
        }

        public void disable(boolean shouldCleanup) {
            transitionLock.lock();
            try {
                activeQuartzes.addAndGet(-quartzCount);
                for (Thread thread : threads) {
                    ThreadUtils.terminateThread(thread);
                }
                threads.clear();
                if (shouldCleanup) {
                    task.cleanup();
                }
            } finally {
                transitionLock.unlock();
            }
        }
    }

}
