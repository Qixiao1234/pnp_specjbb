/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.advertisement;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.tx.request.GetSuggestedAdvertisementRequest;
import org.spec.jbb.hq.tx.response.SuggestedAdvertisementResponse;
import org.spec.jbb.sm.SM;

public class HQAdvertisementAgent extends BasicAdvertisementAgent {

    private static final long serialVersionUID = 4904041452880865280L;

    public HQAdvertisementAgent() {
        super();
    }

    @Override
    public IssuedAdvertisement createAdvertisementBatch(TransactionContext ctx, SM sm) {
        Response r = ctx.sendRequest(sm.getOwningHQname(), new GetSuggestedAdvertisementRequest(sm.getName()));
        if (r instanceof SuggestedAdvertisementResponse) {
            IssuedAdvertisement adv = ((SuggestedAdvertisementResponse) r).getSuggestedAdvertisement();
            if (adv != null) {
                return adv;
            }
        }
        return super.createAdvertisementBatch(ctx, sm);
    }

}
