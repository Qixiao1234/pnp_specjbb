/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class ListMix<T> implements Mix<T>, Serializable {

    private static final long serialVersionUID = -5724679426683982666L;
    private final Random random;
    private final List<Tick<T>> ticks = new ArrayList<>();
    private int max = 0;

    private ReadWriteLock rwl = new ReentrantReadWriteLock();

    public ListMix() {
        this.random = null;
    }

    public ListMix(Random random) {
        this.random = random;
    }

    public ListMix(Random random, Collection<T> names) {
        this(random);
        for (T element : names) {
            update(element, 1, false);
        }
    }

    public ListMix(Collection<T> names) {
        this();
        for (T element : names) {
            update(element, 1, false);
        }
    }

    public ListMix(ListMix<T> src) {
        this();
        if (src != null) {
            for (Tick<T> tick : src.ticks) {
                update(tick.getLabel(), tick.getWeight(), false);
            }
        }
    }

    public ListMix(Random random, ListMix<T> src) {
        this(random);
        if (src != null) {
            for (Tick<T> tick : src.ticks) {
                update(tick.getLabel(), tick.getWeight(), false);
            }
        }
    }

    private int nextRandomInt(int max) {
        return random == null ? ThreadLocalRandom.current().nextInt(max) : random.nextInt(max);
    }

    /**
     * Returns index of the given label, -1 otherwise
     *
     * @param label label to search
     * @return
     */
    private int findIndex(T label) {
        for (int i = 0; i < ticks.size(); i++) {
            if (ticks.get(i).getLabel().equals(label)) {
                return i;
            }
        }
        return -1;
    }

    private void recalculatePartialSums(int fromIndex) {
        if (fromIndex < ticks.size()) {
            int prevSum = (fromIndex == 0) ? 0 : ticks.get(fromIndex - 1).getUpperBound();
            for (int i = fromIndex; i < ticks.size(); i++) {
                Tick<T> tick = ticks.get(i);
                tick.setLowerBound(prevSum);
                prevSum = tick.getUpperBound();
            }
        }
    }

    /**
     * Add value to the mix with appropriate label.
     *
     * @param label  label value
     * @param weight relative weight ( weight(label)+=weight )
     */
    public void add(T label, int weight) {
        rwl.writeLock().lock();
        try {
            update(label, weight, false);
        } finally {
            rwl.writeLock().unlock();
        }
    }

    /**
     * Add value to the mix with appropriate label.
     *
     * @param label  label value
     * @param weight absolute weight ( weight(label)=weight )
     */
    public void set(T label, int weight) {
        rwl.writeLock().lock();
        try {
            update(label, weight, true);
        } finally {
            rwl.writeLock().unlock();
        }
    }


    /**
     * @param label  label
     * @param weight - isSet ? weight(label)=weight : weight(label)+=weight
     * @param isSet
     */
    private void update(T label, int weight, boolean isSet) {
        if (label == null) {
            throw new NullPointerException();
        }
        int idx = findIndex(label);
        if (idx >= 0) {
            Tick<T> tick = ticks.get(idx);
            int newWeight = isSet ? weight : tick.getWeight() + weight;
            if (newWeight <= 0) {
                ticks.remove(idx);
                recalculatePartialSums(idx);
            } else {
                tick.setWeight(newWeight);
                recalculatePartialSums(idx + 1);
            }
            max = ticks.isEmpty() ? 0 : ticks.get(ticks.size() - 1).getUpperBound();
        } else {
            if (weight > 0) {
                ticks.add(new Tick<>(label, weight, max));
                max += weight;
            }
        }
    }

    @Override
    public boolean isEmpty() {
        rwl.readLock().lock();
        try {
            return ticks.isEmpty();
        } finally {
            rwl.readLock().unlock();
        }
    }

    /**
     * Get next value from the mix.
     * Asymptotically, the values will be distributed according to their weights.
     *
     * @return label
     */
    @Override
    public T next() {
        rwl.readLock().lock();
        try {
            if (ticks.isEmpty()) {
                throw new NoSuchElementException();
            }
            assert max > 0;
            if (ticks.size() == 1) {
                return ticks.get(0).getLabel();
            } else {
                return get(nextRandomInt(max));
            }
        } finally {
            rwl.readLock().unlock();
        }
    }

    /**
     * Get next value from the mix.
     *
     * @param range the random value
     * @return label
     */
    private T get(int range) {
        int idx = Collections.binarySearch(ticks, new Tick<T>(null, 0, range), Tick.COMPARATOR);
        if (idx >= 0) {
            return ticks.get(idx).getLabel();
        }
        throw new IllegalStateException(); // shouldn't be here
    }

    /**
     * Returns sum of all weights
     *
     * @return sum of all weights
     */
    @Override
    public int getMixWeight() {
        rwl.readLock().lock();
        try {
            return max;
        } finally {
            rwl.readLock().unlock();
        }
    }

    private static class Tick<T> implements Serializable {
        private static final long serialVersionUID = 6682367761580206799L;
        
        private static final Comparator<Tick> COMPARATOR = new TickComparator();

        private final T label;
        private int weight;
        private int prevSum;

        public Tick(T label, int weight, int prevSum) {
            this.label = label;
            this.weight = weight;
            this.prevSum = prevSum;
        }

        public T getLabel() {
            return label;
        }

        public int getWeight() {
            return weight;
        }

        public void setWeight(int weight) {
            this.weight = weight;
        }

        public void setLowerBound(int bound) {
            this.prevSum = bound;
        }

        public int getLowerBound() {
            return prevSum;
        }

        public int getUpperBound() {
            return prevSum + weight;
        }

        public String toString() {
            return label + "(" + weight + ")";
        }

        public static class TickComparator implements Comparator<Tick>, Serializable {
            private static final long serialVersionUID = -3830564243172597216L;

            @Override
            public int compare(Tick o1, Tick o2) {
                if (o2.getLowerBound() < o1.getLowerBound()) {
                    return 1;
                } else if (o2.getUpperBound() >= o1.getUpperBound()) {
                    return -1;
                } else {
                    return 0;
                }
            }
        }

    }

    public String toString() {
        return ticks.toString();
    }

}
