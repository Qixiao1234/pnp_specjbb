/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.response.ErrorResponse;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.request.DrawCreditRequest;

import java.math.BigDecimal;

public class DrawCreditTransaction extends AbstractTransaction {

    private final HQ hq;
    private long customerId;
    private BigDecimal totalPrice;

    public DrawCreditTransaction(HQ hq, DrawCreditRequest req, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        customerId = req.getCustomerId();
        totalPrice = req.getTotalPrice();
    }

    @Override
    public Response execute() {
        boolean successful = hq.drawCredit(customerId, totalPrice);

        if (successful) {
            return new OkResponse();
        } else {
            return new ErrorResponse("Not enough credit");
        }
    }

    @Override
    public String toString() {
        return "DrawCreditTx: customerId={" + customerId + "}, totalPrice = {" + totalPrice + "}";
    }

}
