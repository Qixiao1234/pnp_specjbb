/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.request;

import org.spec.jbb.core.comm.AbstractRequest;
import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.ProductReviewScoreTransaction;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class GetProductReviewScoreRequest extends AbstractRequest {

    private static final long serialVersionUID = 2032957961870326031L;
    @XmlElement
    private final long barcode;

    private GetProductReviewScoreRequest() {
        // JAXB
        this(0);
    }

    public GetProductReviewScoreRequest(long barcode) {
        this.barcode = barcode;
    }

    public long getBarcode() {
        return barcode;
    }

    @Override
    public Transaction getTransaction(HQ hq, TransactionContext ctx) {
        return new ProductReviewScoreTransaction(hq, this, ctx);
    }

    @Override
    public String toString() {
        return "Get Product Review Score: barcode = " + barcode;
    }

}
