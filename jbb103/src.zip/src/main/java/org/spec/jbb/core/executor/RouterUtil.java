/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.executor;

import org.spec.jbb.core.comm.ConnectionClient;

import java.util.ArrayList;
import java.util.List;

public class RouterUtil {

    private RouterUtil() {
        
    }

    public static List<String> getNames(List<? extends ConnectionClient> clients) {
        List<String> result = new ArrayList<>();
        for(ConnectionClient client : clients) {
            result.add(client.getName());
        }
        return result;
    }

    public static String[] getNamesArray(List<? extends ConnectionClient> clients) {
        return getNames(clients).toArray(new String[clients.size()]);
    }

}
