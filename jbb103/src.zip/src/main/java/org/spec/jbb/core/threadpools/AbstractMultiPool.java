/*
 * Copyright (c) 2012-2014 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

import org.spec.jbb.core.probe.Probe;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractMultiPool implements Multipool {

    private final List<Pool> pools;

    /**
     * Creates new pool.
     *
     * @param name
     */
    public AbstractMultiPool(String name) {
        pools = new ArrayList<>();
    }

    @Override
    public void addPool(Pool pool) {
        pools.add(pool);
    }

    protected List<Pool> getPools() {
        return pools;
    }

    @Override
    public void shutdown() {
        for (Pool p : pools) {
            p.shutdown();
        }
    }

    @Override
    public void start() {
        for (Pool p : pools) {
            p.start();
        }
    }

    @Override
    public void instrument(Probe probe) {
        int c = 0;
        for (Pool p : pools) {
            p.instrument(probe.getChild("pool" + c));
            c++;
        }
    }

    @Override
    public void sample() {
        for (Pool p : pools) {
            p.sample();
        }
    }

    @Override
    public PoolPerfomanceData getProcessedCount() {
        long success = 0;
        long partial = 0;
        long failed = 0;
        long totalProcesssed = 0;
        for (Pool p : pools) {
            PoolPerfomanceData data = p.getProcessedCount();
            success += data.getSuccessful();
            partial += data.getPartial();
            failed += data.getFailed();
            totalProcesssed += data.getTotalProcessed();
        }
        return new PoolPerfomanceData(success, partial, failed, totalProcesssed);
    }

}
