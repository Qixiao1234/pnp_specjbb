/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

public abstract class AbstractMultiMap<K, V> implements MultiMap<K, V>, Serializable {

    private static final long serialVersionUID = 6569427800249471349L;
    Map<K, Collection<V>> backingMap;

    AbstractMultiMap(Map<K, Collection<V>> backingMap) {
        this.backingMap = backingMap;
    }

    @Override
    public void put(K key, V value) {
        getOrCreate(key).add(value);
    }

    @Override
    public void putAll(K key, Iterable<V> values) {
        Collection<V> coll = getOrCreate(key);
        for (V value : values) {
            coll.add(value);
        }
    }

    @Override
    public void putAll(MultiMap<K, V> map) {
        for(K k : map.keySet()) {
            putAll(k, map.get(k));
        }
    }

    abstract Collection<V> getOrCreate(K key);

    @Override
    public Collection<V> get(K key) {
        Collection<V> coll = backingMap.get(key);
        if (coll != null) {
            return Collections.unmodifiableCollection(coll);
        } else {
            return Collections.emptyList();
        }
    }

    @Override
    public Map<K, Collection<V>> asMap() {
        return backingMap;
    }

    private void checkEmpty(Object key, Collection<V> coll) {
        if (coll.isEmpty()) {
            backingMap.remove(key);
        }
    }

    @Override
    public Collection<V> removeAll(K key){
        Collection<V> coll = backingMap.remove(key);
        if (coll != null) {
            return coll;
        } else {
            return Collections.emptyList();
        }
    }

    @Override
    public boolean remove(Object key, Object value) {
        Collection<V> coll = backingMap.get(key);
        if (coll != null) {
            boolean result = coll.remove(value);
            checkEmpty(key, coll);
            return result;
        }
        return false;
    }

    @Override
    public boolean remove(K key, Collection<V> values) {
        if(!values.isEmpty()){
            Collection<V> coll = backingMap.get(key);
            if (coll != null) {
                boolean wasRemoved = false;
                for(V v : values) {
                    wasRemoved |= coll.remove(v);
                }
                checkEmpty(key, coll);
                return wasRemoved;
            }
        }
        return false;
    }

    @Override
    public Set<K> keySet() {
        return backingMap.keySet();
    }

    @Override
    public Iterable<V> values() {
        return new Iterable<V>() {
            @Override
            public Iterator<V> iterator() {
                return new Iterator<V>() {

                    Iterator<K> keyIterator;
                    Iterator<V> valueIterator;

                    {
                        keyIterator = backingMap.keySet().iterator();
                        if (keyIterator.hasNext()) {
                            valueIterator = backingMap.get(keyIterator.next()).iterator();
                        }
                    }

                    @Override
                    public boolean hasNext() {
                        return keyIterator.hasNext() || (valueIterator != null && valueIterator.hasNext());
                    }

                    @Override
                    public V next() {
                        do {
                            if (valueIterator.hasNext()) {
                                return valueIterator.next();
                            }
                            if (keyIterator.hasNext()) {
                                valueIterator = backingMap.get(keyIterator.next()).iterator();
                            } else {
                                throw new NoSuchElementException();
                            }
                        } while (true);
                    }

                    @Override
                    public void remove() {
                        throw new UnsupportedOperationException("MultiMap values iterator does not support modification");
                    }
                };
            }
        };
    }


    @Override
    public int size() {
        int total = 0;
        for (Collection<V> coll : backingMap.values()) {
            total += coll.size();
        }
        return total;
    }

    @Override
    public int hashCode() {
        return backingMap.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (!(o instanceof MultiMap))
            return false;
        return backingMap.equals(((MultiMap<K,V>) o).asMap());
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for(Map.Entry<K, Collection<V>> entry : backingMap.entrySet()) {
            sb.append(entry.getKey())
                    .append(" -> (")
                    .append(entry.getValue().size())
                    .append(") ")
                    .append(entry.getValue().toString())
                    .append("\n");
        }
        return sb.toString();
    }

    @Override
    public void clear() {
        backingMap.clear();
    }

    @Override
    public boolean isEmpty() {
        return backingMap.isEmpty();
    }
}
