/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core;

public enum ResetMode {

    /**
     * Reset only static counters, which are not processed in the same instance.
     * This might only make sense on run initialization.
     */
    STATIC,

    /**
     * Reset only dynamic counters, which are processed in the same instance.
     * Examples include any time interval-based characteristic, like queue utilization over time, etc.
     */
    DYNAMIC,

}
