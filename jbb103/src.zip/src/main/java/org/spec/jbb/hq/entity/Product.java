/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;
import java.util.Set;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Product implements Serializable {

    private static final long serialVersionUID = 4615250933424324324L;
    @XmlElement
    private final long barcode;

    @XmlElement
    private final String name;

    @XmlElement
    private final BigDecimal price;

    @XmlElement
    private final int productQuantity;

    @XmlElement
    private final int orderQuantity;

    @XmlElement
    private final String supplierName;
    
    @XmlElementWrapper
    private final Set<Category> categories;

    private Product() {
        // JAXB
        this(0, "", BigDecimal.ZERO, 0, 0, "", null);
    }

    public Product(long barcode, String name, BigDecimal price, int productQuantity, int orderQuantity, String supplierName, Set<Category> categories) {
        this.barcode = barcode;
        this.name = name;
        this.price = price;
        this.productQuantity = productQuantity;
        this.orderQuantity = orderQuantity;
        this.supplierName = supplierName;
        this.categories = categories;
    }

    public long getBarcode() {
        return barcode;
    }

    public String getName() {
        return name;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public int getProductQuantity() {
        return productQuantity;
    }

    public int getOrderQuantity() {
        return orderQuantity;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public boolean isInCategory(Category c) {
        return categories.contains(c);
    }
    
    public Collection<Category> getCategories() {
        return Collections.unmodifiableCollection(categories);
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Product product = (Product) o;

        if (barcode != product.barcode) {
            return false;
        }

        if (name != null ? !name.equals(product.name) : product.name != null) {
            return false;
        }

        if (productQuantity != product.productQuantity) {
            return false;
        }

        if (orderQuantity != product.orderQuantity) {
            return false;
        }

        if (price != null ? !price.equals(product.price) : product.price != null) {
            return false;
        }

        if (supplierName != null ? !supplierName.equals(product.supplierName) : product.supplierName != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(barcode, name, productQuantity, orderQuantity, price, supplierName);
    }

    @Override
    public String toString() {
        return "Product{" + "barcode=" + barcode + ", name='" + name + '\''
                + ", price=" + price + ", category=" + categories + '}';
    }

}