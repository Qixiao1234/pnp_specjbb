/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter.data;

import org.spec.jbb.core.comm.AbstractRequest;

public class DemoAttachRequest extends AbstractRequest {
    private static final long serialVersionUID = -3489013233263200289L;
}
