/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core;

import org.spec.jbb.core.probe.Probe;

/**
 * Implementors of this interface provide the means of collecting profile.
 */
public interface Measurable {

    /**
     * Instrument with probe
     * @param probe to instrument with
     */
    void instrument(Probe probe);

    /**
     * Dump sampling data to probe
     */
    void sample();

}
