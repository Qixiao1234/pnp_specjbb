/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.purchase;

import org.spec.jbb.hq.entity.CustomerProfile;

import java.util.Collection;
import java.util.List;

/**
 * An interface which provides the selection of a Supermarket Product.
 * <p/>
 * PurchaseAgent implementations may employ different strategies
 * as to the next Product bar code to return as the next Product
 * to be purchased from an Inventory.  For example, there may be
 * some kind of bias or "hot-ness" built into a PurchaseAgent's
 * implementation which returns some set of Product products
 * more frequently than others.
 */
public interface PurchaseAgent {

    /**
     * An enumeration which encapsulates different PurchaseAgent
     * strategies.  Some PurchaseAgent implementations may employ
     * a biasing strategy to create a notion of "hot products"
     * by returning a Product bar code from a set of Product
     * products more often than other Product products found in
     * an Inventory.
     */
    public enum Type {
        UNIFORM_BIAS,
        SIN_CURVE_BIAS,
        ARRAY_BASED,
        ARRAY_BASED_HOT,
        PARETO_BIAS,
        CUSTOMER_SPECIFIC
    }
    
    /**
     * Get the collection of next Product barcode to purchase from an Inventory.
     * 
     * @param cp customer profile which may affect the strategy to choose the product
     * @return - collection of barcodes and quantities for next Purchase operation.
     */
    Collection<PurchaseItem> getNextProducts(CustomerProfile cp);

    /**
     * Get next purchase size.
     * @return next purchase size.
     */
    int getPurchaseSize();

    /**
     * Update hotness for specified the list of barcodes.
     * 
     * @param barcodes list of barcodes to update hotness
     * @param shift the 
     */
    void updateHotness(List<Long> barcodes, int shift);
}
