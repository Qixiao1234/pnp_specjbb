/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity;

import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.spi.LoadableProvider;

/**
 * Basic SPI interface for Connectivity Provider.
 * The role for provider is to get client-server pair which can be used to transfer data
 * between JVMs.
 */
public interface ConnectivityProvider extends LoadableProvider, Measurable {

    /**
     * Create new server
     * @param port port at which server should listen
     * @param callback callback server should invoke upon receiving data
     * @return server instance
     */
    Server newServer(int port, ServerCallback callback);

    /**
     * Create new client.
     * @param hostname server hostname to connect to
     * @param port server port to connect to
     * @return client instance
     */
    Client newClient(String hostname, int port);

}
