/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.request;

import org.spec.jbb.core.comm.AbstractMessage;
import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.CustomerProductReviewTransaction;
import org.spec.jbb.sm.entity.Order;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
public class CustomerProductReviewMessage extends AbstractMessage {

    private static final long serialVersionUID = -4594587193016276426L;
    @XmlElement
    private final Order order;

    @SuppressWarnings("unused")
    private CustomerProductReviewMessage() {
        this(null);
    }

    public CustomerProductReviewMessage(Order order) {
        this.order = order;
    }

    public Order getOrder() {
        return order;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CustomerProductReviewMessage customerProductReviewMessage = (CustomerProductReviewMessage) o;

        if (order != null ? !order
                .equals(customerProductReviewMessage.order)
                : customerProductReviewMessage.order != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(order);
    }

    @Override
    public Transaction getTransaction(HQ hq, TransactionContext ctx) {
        return new CustomerProductReviewTransaction(hq, this, ctx);
    }

    @Override
    public String toString() {
        return "Customer product review, order=" + order;
    }
}
