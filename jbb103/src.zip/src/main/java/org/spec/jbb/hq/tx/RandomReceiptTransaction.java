/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.entity.Receipt;
import org.spec.jbb.hq.tx.request.RandomReceiptRequest;
import org.spec.jbb.hq.tx.response.RandomReceiptResponse;

public class RandomReceiptTransaction extends AbstractTransaction {

    private HQ hq;

    public RandomReceiptTransaction(HQ hq, RandomReceiptRequest request, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
    }

    @Override
    public Response execute() {
        Receipt r = hq.selectRandomReceipt();
        return new RandomReceiptResponse(r);
    }

    @Override
    public String toString() {
        return "RandomReceiptTx";
    }

}
