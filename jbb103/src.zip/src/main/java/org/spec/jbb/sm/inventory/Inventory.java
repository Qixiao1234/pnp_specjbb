/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.inventory;

import org.spec.jbb.core.Measurable;
import org.spec.jbb.sm.discount.Discount;

import java.util.List;


/**
 * An interface representing an Inventory of Products.
 * <p/>
 * Operations supported are:
 * o Add a new Product to the Inventory, requires a Product and Product barcode
 * o Retrieve (get) a Product from the Inventory by Product's barcode.
 * o Retrieve (get) a Product from the Inventory by Product.
 * o Remove a Product from the Inventory by Product's barcode.
 * o Remove a Product from the Inventory by Product.
 *
 * @author Charlie Hunt
 */

public interface Inventory extends Measurable {

    /**
     * Move in some quantity of Product to the Inventory.
     * If the product does not exist, it's created automatically.
     *
     * @param barcode  - barcode to add to Inventory
     * @param quantity - Quantity to add
     * @return quantity added
     * @throws IllegalArgumentException if quantity is negative
     */
    int moveIn(long barcode, int quantity);

    /**
     * Reserve some quantity of Product in the Inventory.
     * Once reserved, this quantity of product is available for moving out.
     * It can be unreserved via call to unreserve()
     *
     * @param barcode  - Product to reserve in Inventory
     * @param quantity - Quantity to reserve
     * @return - actual quantity reserved, 0 if Product is not available
     * @throws IllegalArgumentException if quantity is negative
     * @throws IllegalStateException if barcode is not exists
     */
    int reserve(long barcode, int quantity);

    /**
     * Unreserve some quantity of Product in the Inventory.
     * Once unreserved, this quantity of product is available for reserving again.
     *
     * @param barcode  - Product to unreserve in Inventory
     * @param quantity - Quantity to unreserve
     * @return actual quantity unreserved, 0 if Product was not reserved
     * @throws IllegalArgumentException if quantity is negative
     * @throws IllegalStateException if barcode is not exists
     */
    int unreserve(long barcode, int quantity);

    /**
     * Move out some quantity of Product from Inventory.
     * The desired amount of Product should be reserved first.
     *
     * @param barcode  - Product to move out from Inventory
     * @param quantity - Quantity to move out
     * @return - actual quantity moved out
     * @throws IllegalArgumentException if quantity is negative
     * @throws IllegalStateException if barcode is not exists
     */
    int moveOut(long barcode, int quantity);

    /**
     * Return a List of Products currently in the Inventory
     *
     * @return a List of Products currently in the Inventory
     */
    List<Long> toList();

    /**
     * Current size of the Inventory
     *
     * @return size of Inventory
     */
    int size();

    /**
     * Get remaining quantity of product in the Inventory
     *
     * @param barcode product to look up
     * @return quantity available
     */
    int getQuantity(long barcode);

    /**
     * Add discount for a product
     * 
     * @param discount specifies the discount
     * @throws IllegalStateException if barcode is not exists
     */
    void setDiscount(Discount discount);

    /**
     * clear discount for a product
     * 
     * @param discount specifies the discount set by setDiscount
     * @throws IllegalStateException if barcode is not exists
     */
    void clearDiscount(Discount discount);

    /**
     * get discount for a product
     * 
     * @param barcode product to look up
     * @return discount; null if no discount associated, or product not found
     */
    Discount getDiscount(long barcode);
    
    /**
     * Update the current replenishing quantity in the flight.
     * 
     * @param barcode product to update replenish quantity
     * @param quantity number of items in replenish operation
     * @return replenish quantity prior update
     * @throws IllegalArgumentException if quantity is negative
     * @throws IllegalStateException if barcode is not exists
     */
    int updateReplenishInFlightQuantity(long barcode, int quantity);

    /**
     * Returns the current replenishing quantity in the flight.
     * 
     * @param barcode product to get replenish quantity
     * @return current replenishing quantity
     * @throws IllegalStateException if barcode is not exists
     */
    int getReplenishInFlightQuantity(long barcode);
}
