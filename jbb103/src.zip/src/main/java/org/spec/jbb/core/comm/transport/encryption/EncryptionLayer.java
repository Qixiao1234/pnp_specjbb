/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport.encryption;

import org.spec.jbb.core.comm.transport.Data;
import org.spec.jbb.core.comm.transport.Layer;

public interface EncryptionLayer extends Layer<Data, Data> {
}
