/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections.sampling;

public enum SamplingBufferType {

    QUEUED,

    CIRCULAR_ARRAY,

    RANDOM_ARRAY,

}
