/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.time;

final public class JavaSystemStopWatch implements StopWatch {

    long totalTime;

    long lastTime;

    boolean isStarted;

    public JavaSystemStopWatch(long initValue) {
        reset();
        totalTime = initValue;
    }

    @Override
    public void reset() {
        stop();
        totalTime = 0;
    }

    @Override
    public void start() {
        lastTime = System.nanoTime();
        isStarted = true;
    }

    @Override
    public void stop() {
        if (isStarted) {
            totalTime += System.nanoTime() - lastTime;
            isStarted = false;
        }
    }

    @Override
    public long getElapsedNsecs() {
        return totalTime + (isStarted ? System.nanoTime() - lastTime : 0);
    }

    @Override
    public long getElapsedMsecs() {
        return getElapsedNsecs() / 1000 / 1000;
    }
}
