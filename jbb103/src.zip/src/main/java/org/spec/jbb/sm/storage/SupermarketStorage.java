/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.storage;

import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.cache.Cache;
import org.spec.jbb.core.cache.WriteBackCache;
import org.spec.jbb.core.sequencer.Sequencer;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.entity.CustomerProfile;
import org.spec.jbb.hq.entity.Product;
import org.spec.jbb.infra.snapshot.Snapshottable;
import org.spec.jbb.sm.advertisement.AdvertisementAgent;
import org.spec.jbb.sm.advertisement.Advertisements;
import org.spec.jbb.sm.discount.DiscountAgent;
import org.spec.jbb.sm.inventory.Inventory;

public interface SupermarketStorage extends Measurable, Snapshottable {
    /**
     * Next receipt number generated within this supermarket.  The receipt number
     * is unique within a supermarket, and when paired with the supermarket id is
     * unique within an HQ.
     */
    Sequencer<Long> getReceiptSequencer();

    /*
    * Product cache
    */
    Cache<TransactionContext, Long, Product> getProductCache();

    /**
     * Supermarket's inventory
     */
    Inventory getInventory();

    /**
     * Customer profile cache
     */
    WriteBackCache<TransactionContext, Long, CustomerProfile> getCustomerProfileCache();

    Cache<TransactionContext, Long, String> getCustomerCache();

    AdvertisementAgent getAdvertisementAgent();

    Advertisements getAdvertisements();

    DiscountAgent getDiscountAgent();

}
