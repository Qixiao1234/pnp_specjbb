/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.response;

import org.spec.jbb.core.comm.AbstractResponse;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class NotEnoughCreditResponse extends AbstractResponse {
    private static final long serialVersionUID = -85652792436872596L;

    @Override
    public String toString() {
        return "Not enough credit";
    }
}
