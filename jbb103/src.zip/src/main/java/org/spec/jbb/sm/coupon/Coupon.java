/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.coupon;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Describes the coupon.
 *
 */
public interface Coupon extends Comparable<Coupon>, Serializable {
    /**
     * Return the date when this coupon is expired
     * 
     * @return the date when this coupon is expired
     */
    Date getExpirationDate();
    /**
     * Check whether the coupon is expired in the moment represented by
     * compareTo argument.
     * 
     * @param compareTo specifies the date to verify the coupon is expired at that moment
     * @return true if this coupon is expired at the moment represented by compareTo argument
     */
    boolean isExpired(Date compareTo);
    /**
     * Returns the percent of discount if this coupon is applied
     * 
     * @return the percent of discount if this coupon is applied
     */
    int getPercent();
    /**
     * Return the value the price should be multiplied to
     * 
     * @return the value the price should be multiplied to
     */
    BigDecimal getMultiplier();
}
