/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

import org.spec.jbb.core.Conventions;
import org.spec.jbb.core.ExecutionHandler;
import org.spec.jbb.core.comm.Incoming;
import org.spec.jbb.core.comm.Response;
import org.spec.jbb.util.JbbProperties;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * java.util.concurrent-based thread pool executor.
 */
public class JUCThreadPool extends AbstractPool {

    private final JUCThreadPoolExecutor batchExecutor;
    private JUCThreadPoolExecutor subBatchExecutor;

    private final int batchQueueSize;
    private final int subBatchQueueSize;
    private final int txPerSubBatch;

    /**
     * Create pool. Do not start yet.
     */
    public JUCThreadPool(String name, BlockingQueue<Runnable> batchQueue, BlockingQueue<Runnable> subbatchQueue) {
        super(name);

        String poolID = Conventions.getPoolID(name);
        int minSubBatchThreadsPerPool = JbbProperties.getInstance().getMinSubBatchWorkerCountFor(poolID);
        int minBatchThreadsPerPool = JbbProperties.getInstance().getMinBatchWorkerCountFor(poolID);
        int batchThreads = JbbProperties.getInstance().getBatchWorkerCountFor(poolID);
        int subBatchThreads = JbbProperties.getInstance().getSubBatchWorkerCountFor(poolID);

        this.batchQueueSize = JbbProperties.getInstance().getQueueSizeFor(poolID);
        this.subBatchQueueSize = JbbProperties.getInstance().getSubQueueSizeFor(poolID);

        boolean queueFair = JbbProperties.getInstance().isFair(poolID);

        /**
         * Need separate executors for batch processing and subbatch processing.
         * Each batch processing worker spawns several subbatch processing workers, so with single executor
         * deadlock is possible when all active threads are executing batch processing and waiting for the same executor
         * to accept subbatch executor.
         */
        this.batchExecutor = new JUCThreadPoolExecutor(name + ".batch", minBatchThreadsPerPool, batchThreads, batchQueue, queueFair);
        this.subBatchExecutor = new JUCThreadPoolExecutor(name + ".subbatch", minSubBatchThreadsPerPool, subBatchThreads, subbatchQueue, queueFair);

        txPerSubBatch = JbbProperties.getInstance().getTxPerSubBatch();
    }

    @Override
    public void sample() {
        super.sample();

        probe.sample("batch.queue.total", batchQueueSize);
        probe.sample("batch.queue.active", batchExecutor.getQueue().size());
        probe.sample("batch.threadpool.min", batchExecutor.getCorePoolSize());
        probe.sample("batch.threadpool.max", batchExecutor.getMaximumPoolSize());
        probe.sample("batch.threadpool.alive", batchExecutor.getPoolSize());
        probe.sample("batch.threadpool.active", batchExecutor.getActiveCount());

        probe.sample("subbatch.queue.total", subBatchQueueSize);
        probe.sample("subbatch.queue.active", subBatchExecutor.getQueue().size());
        probe.sample("subbatch.threadpool.min", subBatchExecutor.getCorePoolSize());
        probe.sample("subbatch.threadpool.max", subBatchExecutor.getMaximumPoolSize());
        probe.sample("subbatch.threadpool.alive", subBatchExecutor.getPoolSize());
        probe.sample("subbatch.threadpool.active", subBatchExecutor.getActiveCount());
    }

    @Override
    public Future<List<Response>> enqueueBatch(int tier, ExecutionHandler handler, List<? extends Incoming> b) {
        probe.inc("batches.received");

        Future<List<Future<List<Response>>>> future;
        future = batchExecutor.trySubmit(new BatchSplitTask(tier, handler, b));

        if (future != null) {
            probe.inc("batches.accepted");
            return new AggregateFutureAdapter(future);
        } else {
            probe.inc("batches.rejected");
            throw new RejectedExecutionException();
        }
    }

    @Override
    public Future<List<Response>> forceBatch(int tier, ExecutionHandler handler, List<? extends Incoming> b) throws InterruptedException {
        probe.inc("batches.received");
        Future<List<Response>> future = new AggregateFutureAdapter(batchExecutor.submit(new BatchSplitTask(tier, handler, b)));
        probe.inc("batches.accepted");
        return future;
    }

    @Override
    public void start() {
    }

    @Override
    public void shutdown() {
        batchExecutor.shutdownNow();
        subBatchExecutor.shutdownNow();
    }

    @Override
    public void assistExecute(Runnable runnable) {
        subBatchExecutor.submit(runnable);
    }

    /**
     * Concurrent task to split batch into subbatches and submit those further.
     */
    private class BatchSplitTask implements Callable<List<Future<List<Response>>>> {
        private final int tier;
        private final ExecutionHandler handler;
        private final List<? extends Incoming> batch;

        public BatchSplitTask(int tier, ExecutionHandler handler, List<? extends Incoming> batch) {
            this.tier = tier;
            this.handler = handler;
            this.batch = batch;
        }

        @Override
        public List<Future<List<Response>>> call() throws Exception {

            /**
             * Completion flags will tell us whether sub-batch execution is over or not.
             */
            List<Future<List<Response>>> completionFlags = new ArrayList<>();


            /**
             * Divide current batch into sub-batches and submit them for execution.
             * Sub-batch workers have different responsibilities:
             *  - first worker in batch should deliver STARTED event for batch
             *  - last worker should deliver FINISHED event for batch, after waiting for other sub-batch workers to
             *    finish execution
             */
            if (txPerSubBatch > 0) {
                int requestCount = batch.size();
                for (int c = 0; c < requestCount / txPerSubBatch; c++) {
                    try {
                        Future<List<Response>> future = subBatchExecutor.submit(new ProcessingTask(tier, handler, batch, c * txPerSubBatch, (c + 1) * txPerSubBatch));
                        completionFlags.add(future);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        throw e;
                    }
                }

                int remainder = requestCount % txPerSubBatch;
                if (remainder != 0) {
                    try {
                        Future<List<Response>> future = subBatchExecutor.submit(new ProcessingTask(tier, handler, batch, (requestCount / txPerSubBatch) * txPerSubBatch, requestCount));
                        completionFlags.add(future);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        throw e;
                    }
                }
            }

            return completionFlags;
        }

    }

    /**
     * Concurrent task to process one subbatch
     */
    public class ProcessingTask implements Callable<List<Response>> {

        private final int tier;
        private final ExecutionHandler handler;
        private final List<? extends Incoming> batch;
        private final int from;
        private final int to;

        public ProcessingTask(int tier, ExecutionHandler handler, List<? extends Incoming> batch, int from, int to) {
            this.tier = tier;
            this.handler = handler;
            this.batch = batch;
            this.from = from;
            this.to = to;
        }

        @Override
        public List<Response> call() throws Exception {
            List<? extends Incoming> subBatch = batch.subList(from, to);
            onBatchStart(subBatch);
            List<Response> responses =  process(tier, handler, batch, from, to);
            onBatchCompletion(subBatch, responses);
            return responses;
        }

    }

    private static class AggregateFutureAdapter implements Future<List<Response>> {

        private Future<List<Future<List<Response>>>> future;

        public AggregateFutureAdapter(Future<List<Future<List<Response>>>> future) {
            this.future = future;
        }

        @Override
        public boolean cancel(boolean mayInterruptIfRunning) {
            // hopefully no one will require interrupting underlying futures
            return future.cancel(mayInterruptIfRunning);
        }

        @Override
        public boolean isCancelled() {
            return future.isCancelled();
        }

        @Override
        public boolean isDone() {
            return future.isDone();
        }

        @Override
        public List<Response> get() throws InterruptedException, ExecutionException {
            List<Response> responses = new ArrayList<>();
            List<Future<List<Response>>> list = future.get();
            for (Future<List<Response>> inner : list) {
                responses.addAll(inner.get());
            }
            return responses;
        }

        @Override
        public List<Response> get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
            List<Response> responses = new ArrayList<>();
            List<Future<List<Response>>> list = future.get(timeout, unit);
            for (Future<List<Response>> inner : list) {
                responses.addAll(inner.get(timeout, unit));
            }
            return responses;
        }
    }

}
