/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.cache;

import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.probe.ProbeFactory;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.ref.SoftReference;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Unbounded soft reference cache.
 * <p/>
 * Implementation note #1:
 *   This cache implementation is racy when two threads are going for the same key.
 *   It might cause both threads to read connector, and only one thread will succeed
 *   to populate the cache.
 * <p/>
 * Implementation note #2:
 *   Map is only cleaned up on get() request. If references are purged after get(),
 *   this cache will still have empty SoftReferences in map.
 * <p/>
 * Implementation note #3:
 *   Since GC is only doing best-effort in working with SoftReferences, do not expect
 *   fair LRU policy for replacing entries. One should only use this cache to protect
 *   from OOME (basically letting GC to purge caches when memory is short).
 *
 * @param <C> context to run in
 * @param <K> key type
 * @param <V> value type
 */
public class SoftReferenceCache<C, K, V> implements Cache<C, K, V>, Serializable {

    private static final long serialVersionUID = -1549537094537821634L;

    private transient volatile ConcurrentHashMap<K, SoftReference<V>> backingMap;
    private transient volatile Connector<C, K, V> connector;
    private transient volatile Probe probe;

    public SoftReferenceCache() {
        this.backingMap = new ConcurrentHashMap<>();
        this.probe = ProbeFactory.getDefaultProbe();
    }

    @Override
    public void setConnector(Connector<C, K, V> connector) {
        if (connector == null) {
            throw new IllegalArgumentException("connector is null");
        }
        this.connector = connector;
    }

    @Override
    public V get(C ctx, K key) {
        SoftReference<V> softRef = backingMap.get(key);

        V v = (softRef != null ? softRef.get() : null);

        if (v == null) {
            v = connector.read(ctx, key);
            backingMap.put(key, new SoftReference<>(v));
            probe.inc("miss");
        } else {
            probe.inc("hit");
        }

        return v;
    }

    @Override
    public void flush(C ctx) {
        backingMap.clear();
    }

    private void writeObject(ObjectOutputStream oos) throws IOException {
        Map<K, V> map = new HashMap<>();
        for (Map.Entry<K, SoftReference<V>> entry : backingMap.entrySet()) {
            K key = entry.getKey();
            V value = entry.getValue().get();
            if (value != null) {
                map.put(key, value);
            }
        }
        oos.writeObject(map);
        oos.defaultWriteObject();
    }

    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
        backingMap = new ConcurrentHashMap<>();
        Map<K,V> map = (Map<K, V>) ois.readObject();
        for (Map.Entry<K, V> entry : map.entrySet()) {
            backingMap.put(entry.getKey(), new SoftReference<V>(entry.getValue()));
        }
        ois.defaultReadObject();
        probe = ProbeFactory.getDefaultProbe();
    }

    @Override
    public void instrument(Probe probe) {
        this.probe = probe;
    }

    @Override
    public void sample() {
        // do nothing
    }
}
