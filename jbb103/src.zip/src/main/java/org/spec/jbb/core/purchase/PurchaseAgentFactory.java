/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.purchase;

import org.spec.jbb.util.JbbProperties;

/**
 * A factory to produce PurchaseAgents, an interface which provides a
 * purchase selection, a product bar code from a Supermarket's inventory.
 */

public class PurchaseAgentFactory {

    public static PurchaseAgent makePurchaseAgent() {
        PurchaseAgent result;
        PurchaseAgent.Type agentType = JbbProperties.getInstance().getPurchaseAgentType();

        switch (agentType) {
            case UNIFORM_BIAS:
                result = new UniformBiasedPurchaseAgent();
                break;
            case SIN_CURVE_BIAS:
                result = new SinBiasedPurchaseAgent();
                break;
            case ARRAY_BASED:
                result = new UniformPurchaseAgentArrayBased();
                break;
            case ARRAY_BASED_HOT:
                result = new PurchaseAgentBiased();
                break;
            case PARETO_BIAS:
                result = new ParetoBiasedPurchaseAgent();
                break;
            case CUSTOMER_SPECIFIC:
                result = new CustomerSpecificPurchaseAgent();
                break;
            default:
                throw new UnsupportedOperationException("Unsupported " +
                        "'PurchaseAgentType=" + agentType +
                        "', check jbb property file for correct usage.");
        }
        return result;
    }
}
