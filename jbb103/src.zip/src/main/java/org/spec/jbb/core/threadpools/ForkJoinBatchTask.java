
/*
 * Copyright (c) 2012-2014 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

import org.spec.jbb.core.ExecutionHandler;
import org.spec.jbb.core.comm.Incoming;
import org.spec.jbb.core.comm.Response;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;

/**
 * Batch processing task to run in a ForkJoinPool.  To deal better
 * with batches containing one or a few straggling time-consuming
 * actions that other workers cannot help with, this splits batches
 * into individual actions, using a bottom-up join technique to allow
 * release of all but still-active threads working on a batch.
 * Implicit joins use a joinCount to count completions of the two
 * subtasks. The first arriving thread CAS's from 0 to 1. The second
 * moves up to complete parent, or ultimately sets batch task
 * completion. The mechanics are simpler than seen in other bottom-up
 * join designs because we know that AbractPool.processOne traps all
 * possible exceptions in base actions.
 */
final class  ForkJoinBatchTask extends ForkJoinTask<List<Response>> {
    private static final long serialVersionUID = 4979389378257068423L;
    private final int tier;
    final ExecutionHandler handler;
    final List<? extends Incoming> batch;
    final Response[] responses;
    final AbstractPool pool;
    ForkJoinBatchTask parent; // nulled on completion to avoid garbage buildup
    final int from;
    final int to;
    final int threshold;

    volatile int joinCount;
    static final AtomicIntegerFieldUpdater<ForkJoinBatchTask> joinCountUpdater =
        AtomicIntegerFieldUpdater.newUpdater(ForkJoinBatchTask.class, "joinCount");

    public ForkJoinBatchTask(int tier, ExecutionHandler handler, List<? extends Incoming> batch,
                             Response[] responses,
                             AbstractPool pool,
                             ForkJoinBatchTask parent,
                             int from, int to, int threshold) {
        this.tier = tier;
        this.handler = handler;
        this.batch = batch;
        this.responses = responses;
        this.pool = pool;
        this.parent = parent;
        this.from = from;
        this.to = to;
        this.threshold = threshold;
    }
    
    public final List<Response> getRawResult() { 
        return Arrays.asList(responses);
    }
    
    // required but unused
    public final void setRawResult(List<Response> x) { } 
    
    public final boolean exec() {
        ForkJoinBatchTask p = parent;
        if (p == null)
            pool.onBatchStart(batch);
        else if (p.isDone())
            return true;
        ForkJoinBatchTask t = this;
        int l = from;
        int h = to;
        int mid;
        while ((mid = (l + h) >>> 1) > l + threshold) {
            new ForkJoinBatchTask(tier, handler, batch, responses, pool, t, mid, h, threshold).fork();
            t = new ForkJoinBatchTask(tier, handler, batch, responses, pool, t, l, mid, threshold);
            h = mid;
        }
        for (int c = l; c < h; c++) {
            try {
                responses[c] = (Response)pool.processOne(tier, handler, batch.get(c));
            } catch (Throwable ex) {
                upwardFail(t, ex);
                return true;
            }
        }
        upwardJoin(t);
        return false;
    }

    /**
     * Signals parent that task t is done.  If at root (null parent),
     * completes batch. Otherwise, if both children done, moves up to
     * parent.  Nulls out parent field while advancing, to avoid
     * garbage buildup.
     */
    private static void upwardJoin(ForkJoinBatchTask t) {
        while (t != null) {
            ForkJoinBatchTask p = t.parent;
            if (p == null) { // t is root task
                t.pool.onBatchCompletion(t.batch, t.getRawResult());
                t.complete(null);
                break; 
            }
            else if (p.joinCount == 0) {
                if (joinCountUpdater.compareAndSet(p, 0, 1)) {
                    t.parent = null;
                    break;
                }
            }
            else {
                t.parent = null;
                t = p;
            }
        }
    }

    /**
     * Propagates an exception to root task
     */
    private static void upwardFail(ForkJoinBatchTask t, Throwable ex) {
        while (t != null) {
            t.completeExceptionally(ex);
            t = t.parent;
        }
    }


}

