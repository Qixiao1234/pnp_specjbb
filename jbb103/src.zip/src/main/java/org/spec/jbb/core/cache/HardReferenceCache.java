/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.cache;

import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.probe.ProbeFactory;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Unbounded hard reference cache.
 * <p/>
 * Implementation note:
 *   This cache implementation is racy when two threads are going for the same key.
 *   It might cause both threads to read connector, and only one thread will succeed
 *   to populate the cache.
 *
 * @param <C> context to run in
 * @param <K> key type
 * @param <V> value type
 */
public class HardReferenceCache<C, K, V> implements Cache<C, K, V>, Serializable {

    private static final long serialVersionUID = 4724848482846548416L;

    private final ConcurrentHashMap<K, V> backingMap;
    private transient volatile Connector<C, K, V> connector;
    private transient volatile Probe probe;

    public HardReferenceCache() {
        this.backingMap = new ConcurrentHashMap<>();
        this.probe = ProbeFactory.getDefaultProbe();
    }

    @Override
    public void setConnector(Connector<C, K, V> connector) {
        if (connector == null) {
            throw new IllegalArgumentException("connector is null");
        }
        this.connector = connector;
    }

    @Override
    public V get(C ctx, K key) {
        V v = backingMap.get(key);
        if (v == null) {
            v = connector.read(ctx, key);
            backingMap.put(key, v);
            probe.inc("miss");
        } else {
            probe.inc("hit");
        }
        return v;
    }

    @Override
    public void flush(C ctx) {
        backingMap.clear();
    }

    @Override
    public void instrument(Probe probe) {
        this.probe = probe;
    }

    @Override
    public void sample() {
        // do nothing
    }

    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
        ois.defaultReadObject();
        probe = ProbeFactory.getDefaultProbe();
    }

}
