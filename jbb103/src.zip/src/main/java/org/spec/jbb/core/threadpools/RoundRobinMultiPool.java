/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

import org.spec.jbb.core.ExecutionHandler;
import org.spec.jbb.core.comm.Incoming;
import org.spec.jbb.core.comm.Response;

import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;

/**
 * This implementation makes multiple threadpools and forwards requests to them in round-robin fashion.
 * <p/>
 * It tries to submit the batch for execution into all threadpools, gradually shifting first pool to submit to
 * with each new incoming.
 *
 * @see FirstOpportunityMultiPool
 */
public class RoundRobinMultiPool extends AbstractMultiPool {

    private int currentPool;

    public RoundRobinMultiPool(String name) {
        super(name);
        currentPool = 0;
    }


    @Override
    public Future<List<Response>> enqueueBatch(int tier, ExecutionHandler handler, List<? extends Incoming> b) {
        List<Pool> pools = getPools();

        currentPool = (currentPool + 1) % pools.size();

        RejectedExecutionException up = null;
        for (int c = 0; c < pools.size(); c++) {
            int poolId = (currentPool + c) % pools.size();
            try {
                Future<List<Response>> future = pools.get(poolId).enqueueBatch(tier, handler, b);
                return future;
            } catch(RejectedExecutionException e) {
                up = e;
            }
        }

        throw up; // whoops
    }

    @Override
    public Future<List<Response>> forceBatch(int tier, ExecutionHandler handler, List<? extends Incoming> batch) throws InterruptedException {
        List<Pool> pools = getPools();
        currentPool = (currentPool + 1) % pools.size();
        return pools.get(currentPool).forceBatch(tier, handler, batch);
    }

    @Override
    public List<Response> processLocally(int tier, ExecutionHandler handler, List<? extends Incoming> requests) {
        List<Pool> pools = getPools();
        currentPool = (currentPool + 1) % pools.size();
        return pools.get(currentPool).processLocally(tier, handler, requests);
    }

    @Override
    public void assistExecute(Runnable runnable) {
        List<Pool> pools = getPools();
        currentPool = (currentPool + 1) % pools.size();
        pools.get(currentPool).assistExecute(runnable);
    }
}
