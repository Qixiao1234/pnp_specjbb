/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.request;

import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.tx.AdvertisementRemoveTransaction;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class AdvertisementRemoveRequest extends AbstractServiceTxInjectorRequest {

    private static final long serialVersionUID = -1722578933523327137L;

    @Override
    public String toString() {
        return "AdvertisementRemoveRequest";
    }

    @Override
    public Transaction getTransaction(SM sm, TransactionContext ctx) {
        return new AdvertisementRemoveTransaction(sm, this, ctx);
    }
}
