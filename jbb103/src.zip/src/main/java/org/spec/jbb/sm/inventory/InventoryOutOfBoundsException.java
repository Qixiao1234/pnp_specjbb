/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.inventory;

/**
 * An expection representing an exception condition where access to a
 * Product's barcode in the Inventory was not accepted due to the
 * Product's barcode trying to access a Product outside the range of
 * Product barcodes in the Inventory.
 */

class InventoryOutOfBoundsException extends RuntimeException {
    private static final long serialVersionUID = -7291859806057782076L;
    final private int index;
    final private int numberOfBuckets;

    /**
     * Constructor
     *
     * @param index           - the index to a bucket in the Inventory
     * @param numberOfBuckets - total number of buckets in the Inventory
     */
    public InventoryOutOfBoundsException(int index, int numberOfBuckets) {
        this.index = index;
        this.numberOfBuckets = numberOfBuckets;
    }

    /**
     * A String describing this Exception condition.
     *
     * @return
     */
    @Override
    public String toString() {
        String s = "Index (" + index +
                ") out of range for Inventory's range of buckets (" +
                numberOfBuckets + ")";
        return s;
    }
}
