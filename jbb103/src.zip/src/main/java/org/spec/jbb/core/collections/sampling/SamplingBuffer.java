/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections.sampling;

import java.util.Collection;
import java.util.List;

/**
 * Interface for SamplingBuffer implementations.
 *
 * @param <T> type to store
 */
public interface SamplingBuffer<T> {

    /**
     * Put one element, possibly OVERWRITING some entry.
     * @param element element to store
     */
    void put(T element);

    /**
     * Bulk put elements.
     *
     * @see SamplingBuffer#put(Object)
     * @param elements to store
     */
    void putAll(Collection<T> elements);

    /**
     * Answer the estimate for current buffer occupancy.
     * This method is intended for debugging and monitoring only.
     *
     * @return estimate for buffer size
     */
    int size();

    /**
     * Answers the copy of current buffer contents.
     * @return snapshot copy of this buffer.
     */
    List<T> snapshot();

    /**
     * Answer some element from the buffer
     * @return element
     */
    T get();
}
