/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections.queues;

import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;

public class StripedArrayBlockingQueue<E> extends AbstractStripedQueue<E> {

    private static final long serialVersionUID = -5677108395966104128L;

    public StripedArrayBlockingQueue(int capacity) {
        super(capacity);
    }

    public StripedArrayBlockingQueue(int capacity, int stripes) {
        super(capacity, stripes);
    }

    @Override
    protected Queue<E> newQueue(int capacity) {
        return new ArrayBlockingQueue<>(capacity);
    }

}
