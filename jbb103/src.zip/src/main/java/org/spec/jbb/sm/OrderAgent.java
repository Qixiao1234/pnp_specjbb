/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm;

public class OrderAgent {
    private final String targetSupplier;

    public OrderAgent(String targetSupplier) {
        this.targetSupplier = targetSupplier;
    }

    public String getTargetSupplier() {
        return targetSupplier;
    }

}
