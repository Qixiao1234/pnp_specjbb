/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.scheduler;

import org.spec.jbb.core.threadpools.ThreadUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Quartz: invoke handler with specified frequency.
 *
 * This implementation tries to overcome lower limit on Thread.sleep().
 * There are number of threads running with BASE_PERIOD_NSEC, and desired frequency is achieved
 * by superposing all these threads.
 *
 * I.e. for target frequency = 1000 Hz and BASE_PERIOD = 20 msec, 20 threads will do.
 *
 * This implementation also tries to compensate stalls in QuartzHandler,
 * but handlers should not block indefinitely anyway.
 */
public class Quartz {

    private static final Logger LOGGER = Logger.getLogger("org.spec.jbb.scheduler");

    private static final long BASE_PERIOD_NSEC = TimeUnit.MILLISECONDS.toNanos(20);

    private final int frequency;
    private final QuartzHandler handler;
    private List<Thread> workers;

    public Quartz(int frequency, QuartzHandler handler) {
        this.frequency = frequency;
        this.handler = handler;
        this.workers = new ArrayList<>();
    }

    public void start() {
        long period = TimeUnit.SECONDS.toNanos(1) / frequency;

        long numWorkers = BASE_PERIOD_NSEC / period;

        for (int c = 0; c < numWorkers; c++) {
            Thread thread = new Thread(new QuartzTask(BASE_PERIOD_NSEC));
            thread.start();
            workers.add(thread);
        }

        long coveredFrequency = TimeUnit.SECONDS.toNanos(1) * numWorkers / BASE_PERIOD_NSEC;
        long remainingFrequency = frequency - coveredFrequency;
        if (remainingFrequency > 0) {
            long remainingPeriod = TimeUnit.SECONDS.toNanos(1) / remainingFrequency;
            Thread remThread = new Thread(new QuartzTask(remainingPeriod));
            remThread.start();
            workers.add(remThread);
        }
    }

    public void stop() {
        for (Thread thread : workers) {
            ThreadUtils.terminateThread(thread);
        }
    }

    public class QuartzTask implements Runnable {

        private final long basePeriod;

        public QuartzTask(long basePeriod) {
            this.basePeriod = basePeriod;
        }

        @Override
        public void run() {

        while (!Thread.interrupted()) {

            long time = System.nanoTime();

            try {
                handler.fire();
            } catch (Throwable e) {
                LOGGER.log(Level.WARNING, "Exception", e);
            }

            try {
                TimeUnit.NANOSECONDS.sleep(basePeriod - (System.nanoTime() - time));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        }
    }
}
