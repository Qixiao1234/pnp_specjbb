/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport;

/**
 * Transport abstraction: might encompass one or more layers bound together.
 *
 * @param <UT> upper-type, like Request/Response/Message
 * @param <MT> media-type, defines the representation "on-the-wire".
 */
public interface Transport<UT, MT> extends Layer<UT, MT> {
    
}
