/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity.grizzlynio;

import org.spec.jbb.core.comm.connectivity.grizzlynio.proto.ProtocolDataUnit;
import org.spec.jbb.core.threadpools.SettableFuture;

public interface FutureHolder {
    void resetFuture(SettableFuture<ProtocolDataUnit> resultFuture);
}
