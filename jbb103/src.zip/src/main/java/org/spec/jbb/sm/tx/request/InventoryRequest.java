/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.request;

import org.spec.jbb.core.comm.AbstractRequest;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public abstract class InventoryRequest extends AbstractRequest {

    private static final long serialVersionUID = 5301203046341317979L;
    @XmlElement
    private final long barCode;

    @XmlElement
    private final int quantity;

    @SuppressWarnings("unused")
    private InventoryRequest() {
        // JAXB
        this(0,0);
    }

    public InventoryRequest(long barCode, int quantity) {
        this.barCode = barCode;
        this.quantity = quantity;
    }

    public long getBarcode() {
        return barCode;
    }

    public int getQuantity() {
        return quantity;
    }

    @Override
    public String toString() {
        return "Inventory operation: barcode={" + barCode + "}, quantity={" + quantity + "}";
    }

}
