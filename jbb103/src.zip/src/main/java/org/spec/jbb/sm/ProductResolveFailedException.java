/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm;

import org.spec.jbb.core.tx.TransactionException;

public class ProductResolveFailedException extends TransactionException {

    private static final long serialVersionUID = 2535328838467555733L;

    public ProductResolveFailedException(String message) {
        super(message);
    }
}
