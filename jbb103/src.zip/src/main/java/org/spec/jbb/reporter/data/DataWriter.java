/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter.data;

import java.io.IOException;
import org.spec.jbb.core.comm.ConnectionClient;
import org.spec.jbb.reporter.Frame;

public interface DataWriter {
    void open(ConnectionClient client) throws IOException;
    void write(Frame frame) throws IOException;
    void flush() throws IOException;
    void close();
}
