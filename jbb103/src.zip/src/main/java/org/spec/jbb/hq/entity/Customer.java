/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Objects;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Customer implements Serializable {

    private static final long serialVersionUID = -499088105158948584L;
    @XmlElement
    private final long id;

    @XmlElement
    private final String firstName;

    @XmlElement
    private final String lastName;

    @XmlElement
    private final Address address;

    @XmlElement
    private final CreditCard creditCard;

    @XmlElement
    private final String owningHq;

    private Customer() {
        // JAXB
        this(0, "", "", null, null, "");
    }

    public Customer(long id, String firstName, String lastName, Address address, CreditCard creditCard, String owningHq) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.creditCard = creditCard;
        this.owningHq = owningHq;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public Address getAddress() {
        return address;
    }

    public CreditCard getCreditCard() {
        return creditCard;
    }

    @Override
    public String toString() {
        return "Customer{"+ id +'}';
    }

    public long getId() {
        return id;
    }

    public String getOwningHQ() {
        return owningHq;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Customer customer = (Customer) o;

        if (id != customer.id) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

}
