/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.request;

import org.spec.jbb.core.comm.AbstractMessage;
import org.spec.jbb.core.comm.transport.TransportType;
import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.SupplierReceiptTransaction;
import org.spec.jbb.sp.Invoice;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
public class SupplierReceiptMessage extends AbstractMessage {

    private static final long serialVersionUID = -8765639327236966749L;
    @XmlElement
    private final Invoice invoice;

    private SupplierReceiptMessage() {
        // JAXB
        this(null);
    }

    public SupplierReceiptMessage(Invoice invoice) {
        this.invoice = invoice;
    }

    @Override
    public boolean isDurable() {
        return true;
    }

    public Invoice getInvoice() {
        return invoice;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        SupplierReceiptMessage that = (SupplierReceiptMessage) o;

        if (invoice != null ? !invoice.equals(that.invoice) : that.invoice != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(invoice);
    }

    @Override
    public String toString() {
        return "Supplier Invoice, " + invoice;
    }

    @Override
    public Transaction getTransaction(HQ hq, TransactionContext ctx) {
        return new SupplierReceiptTransaction(hq, this, ctx);
    }

    @Override
    public TransportType getTransportHint() {
        return TransportType.XML;
    }


}
