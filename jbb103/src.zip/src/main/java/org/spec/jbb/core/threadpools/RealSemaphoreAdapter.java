/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

import java.util.concurrent.Semaphore;

class RealSemaphoreAdapter implements SemaphoreAdapter {

    private final Semaphore semaphore;

    public RealSemaphoreAdapter(int permits, boolean fair) {
        semaphore = new Semaphore(permits, fair);
    }

    @Override
    public boolean tryAcquire() {
        return semaphore.tryAcquire();
    }

    @Override
    public void acquire() throws InterruptedException {
        semaphore.acquire();
    }

    @Override
    public void release() {
        semaphore.release();
    }

    @Override
    public int availablePermits() {
        return semaphore.availablePermits();
    }

    @Override
    public int getQueueLength() {
        return semaphore.getQueueLength();
    }
}
