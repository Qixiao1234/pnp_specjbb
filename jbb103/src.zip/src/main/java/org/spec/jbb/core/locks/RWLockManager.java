/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.locks;

import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.probe.Probe;

import java.util.concurrent.locks.ReadWriteLock;

public interface RWLockManager<K> extends Measurable {
    /**
     * Get read lock associated with key.
     * It's always guaranteed two concurrent calls for the same key will yield the same lock.
     * It's also guaranteed two concurrent calls for read and write locks will yield the same lock.
     *
     * @param key key to look up key for
     * @return lock
     */
    ReadWriteLock getRWLock(K key);

    @Override
    void instrument(Probe probe);

    @Override
    void sample();
}
