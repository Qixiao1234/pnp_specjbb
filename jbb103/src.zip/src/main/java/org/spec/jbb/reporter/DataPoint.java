/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

import java.io.Serializable;

public class DataPoint implements Comparable<DataPoint>, Serializable {
    private static final long serialVersionUID = -5449986083788017113L;
    private final long time;
    private final double value;

    public DataPoint(long time, double value) {
        this.time = time;
        this.value = value;
    }

    public long getTime() {
        return time;
    }

    public double getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.format("%.2f@%d", value, time);
    }

    @Override
    public int compareTo(DataPoint o) {
        return Long.compare(time, o.time);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DataPoint dataPoint = (DataPoint) o;

        if (time != dataPoint.time) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return (int) (time ^ (time >>> 32));
    }

}
