/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.request;

import org.spec.jbb.core.comm.AbstractMessage;
import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.tx.MoveInInventoryTransaction;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class MoveInInventoryMessage extends AbstractMessage {

    private static final long serialVersionUID = -7366463417678309202L;
    @XmlElement
    private final long barcode;

    @XmlElement
    private final int quantity;

    @SuppressWarnings("unused")
    private MoveInInventoryMessage() {
        // JAXB
        this(0, 0);
    }

    public MoveInInventoryMessage(long barcode, int quantity) {
        this.barcode = barcode;
        this.quantity = quantity;
    }

    @Override
    public boolean isDurable() {
        return true;
    }

    public long getBarcode() {
        return barcode;
    }

    public int getQuantity() {
        return quantity;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        MoveInInventoryMessage moveInInventoryMessage = (MoveInInventoryMessage) o;

        if (quantity != moveInInventoryMessage.quantity) {
            return false;
        }

        if (barcode != moveInInventoryMessage.barcode) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(barcode, quantity);
    }

    @Override
    public Transaction getTransaction(SM sm, TransactionContext ctx) {
        return new MoveInInventoryTransaction(sm, this, ctx);
    }

    @Override
    public String toString() {
        return "Move to inventory: barcode={" + barcode + "}, quantity = {" + quantity + "}";
    }

}
