/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.executor;

import org.spec.jbb.core.comm.Message;
import org.spec.jbb.core.comm.Request;
import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.comm.Uplink;

import java.util.List;

public class SimpleRoundRobinBatchRouter extends AbstractBatchRouter {

    private int executor_pos;
    private Uplink link;

    public SimpleRoundRobinBatchRouter(String name, String... targetNames) {
        super(name, targetNames);
        this.executor_pos = 0;
    }

    @Override
    public List<Response> handle(String from, List<Request> requests, int currentTier, int targetTier) {
        String[] targets = getTargets();
        String target = targets[executor_pos];

        executor_pos = (executor_pos + 1) % targets.length;

        List<Response> responseList = link.sendRequest(target, targetTier, requests);
        return responseList;
    }

    @Override
    public void handleMessage(String from, List<Message> messages, int currentTier, int targetTier) {
        String[] targets = getTargets();
        String target = targets[executor_pos];

        executor_pos = (executor_pos + 1) % targets.length;

        link.sendMessage(target, targetTier, messages);
    }

    @Override
    public void setUplink(Uplink link) {
        this.link = link;
    }

    @Override
    public Uplink getLink() {
        return link;
    }
}
