/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.scheduler;

import org.spec.jbb.core.threadpools.ThreadUtils;
import org.spec.jbb.util.random.SpecRandom;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import org.spec.jbb.core.collections.CollectionUtils;
import org.spec.jbb.util.JbbProperties;

public class PLLScheduler implements Scheduler {

    // Important: This implementation assumes frequency is always 1 Khz.
    //        It helps to convert for millisecond-valued random generators.
    private static final int QUARTZ_FREQUENCY_HZ = 1000;

    private final Quartz quartz;
    private final ThreadPoolExecutor workerPool;
    private final ConcurrentMap<ScheduledTask, SaturateCounter> counters;

    public PLLScheduler(int threads, ThreadFactory factory) {
        this.counters = new ConcurrentHashMap<>();

        this.workerPool = new ThreadPoolExecutor(threads, threads,
                0L, TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<Runnable>(
                        CollectionUtils.integerSaturate((long) threads * JbbProperties.getInstance().getCustomerDriverQueueMultiplier())),
                factory);

        quartz = new Quartz(QUARTZ_FREQUENCY_HZ, new TickHandler());
        quartz.start();
    }

    @Override
    public void register(ScheduledTask task, SpecRandom delayRandom, DelayType delayType) {
        counters.put(task, new SaturateCounter(task, delayRandom, delayType));
    }

    @Override
    public void remove(ScheduledTask task) {
        disable(task);
        counters.remove(task);
    }

    @Override
    public void shutdown() {
        quartz.stop();
        ThreadUtils.terminatePool(workerPool);
    }

    @Override
    public void enable(ScheduledTask task) {
        counters.get(task).enable();
    }

    @Override
    public void disable(ScheduledTask task) {
        counters.get(task).disable();
    }

    @Override
    public void zap() {
        workerPool.getQueue().clear();
    }

    private class TickHandler implements QuartzHandler {
        @Override
        public void fire() {
            for (SaturateCounter counter : counters.values()) {
                counter.tick();
            }
        }
    }

    /**
     * Saturate counter.
     * Assumed to receive ticks from quartz.
     * Submits another job when internal counter overflows.
     */
    private class SaturateCounter {

        private AtomicLong count;
        private volatile long limit;
        private final ScheduledTask task;
        private final SpecRandom random;
        private final DelayType delayType;
        private volatile boolean enabled;
        private volatile Future<?> future;

        public SaturateCounter(ScheduledTask task, SpecRandom random, DelayType delayType) {
            this.task = task;
            this.random = random;
            this.delayType = delayType;
            this.count = new AtomicLong();
            this.limit = TimeUnit.NANOSECONDS.toMillis(random.nextLong());
        }

        public void tick() {
            if (!enabled) {
                return;
            }

            /**
             * Hold off submission if previous task is not completed.
             */
            if (delayType == DelayType.DELAY) {
                if (future != null && !future.isDone()) {
                    return;
                }
            }

            if (count.incrementAndGet() >= limit) {
                count.set(0);
                limit = TimeUnit.NANOSECONDS.toMillis(random.nextLong());

                try {
                    future = workerPool.submit(task.getRunTask());
                } catch (RejectedExecutionException e) {
                    // try next time
                }
            }
        }

        public void enable() {
            enabled = true;
        }

        public void disable() {
            enabled = false;
            task.cleanup();
        }
    }

}
