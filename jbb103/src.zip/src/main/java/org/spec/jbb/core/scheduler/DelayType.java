/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.scheduler;

/**
 * Delay type.
 */
public enum DelayType {

    /**
     * This delay type is adherent to {@link java.util.concurrent.ScheduledThreadPoolExecutor}.scheduleAtFixedRate()
     * Driver will try to maintain the specific mean rate.
     */
    RATE,

    /**
     * This delay type is adherent to {@link java.util.concurrent.ScheduledThreadPoolExecutor}.scheduleAtFixedDelay()
     * Driver will try to maintain the specific mean delays between requests
     */
    DELAY,
}
