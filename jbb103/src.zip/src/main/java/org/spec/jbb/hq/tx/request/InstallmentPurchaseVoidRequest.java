/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.request;

import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.InstallmentPurchaseVoidTransaction;
import org.spec.jbb.sm.tx.request.AbstractServiceTxInjectorRequest;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class InstallmentPurchaseVoidRequest extends AbstractServiceTxInjectorRequest {

    private static final long serialVersionUID = -7008435400348962988L;

    @Override
    public Transaction getTransaction(HQ hq, TransactionContext ctx) {
        return new InstallmentPurchaseVoidTransaction(hq, this, ctx);
    }

    @Override
    public String toString() {
        return "Installment purchase void";
    }

}
