/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Specialized form of future allowing to set the result.
 *
 * @param <V>
 */
public class SettableFuture<V> extends FutureTask<V> {

    /**
     * Implementation notes:
     *
     * This implementation also accounts for known bug in FutureTask:
     * http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=7132378
     *
     * We compensate for possible race by making sure set() had
     * completed before returning from get(). Since get() is
     * blocking operation, we first wait without any synchronization,
     * and then do get() again synchronizing with set() to make sure
     * set() had indeed completed.
     *
     * This bails out earlier on exception or if the timeout had expired.
     */

    /**
     * Dummy callable so that underlying implementation will not complain.
     */
    private static final Callable DUMMY = new Callable() {
        @Override
        public Object call() throws Exception {
            throw new IllegalStateException("Trying to read from dummy callable in SettableFuture");
        }
    };

    public SettableFuture() {
        super(DUMMY);
    }

    @Override
    public void set(V v) {
        synchronized (this) {
            super.set(v);
        }
    }

    @Override
    public void setException(Throwable t) {
        synchronized (this) {
            super.setException(t);
        }
    }

    @Override
    public V get() throws InterruptedException, ExecutionException {
        super.get();
        synchronized (this) {
            return super.get();
        }
    }

    @Override
    public V get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
        super.get(timeout, unit);
        synchronized (this) {
            return super.get();
        }
    }
}
