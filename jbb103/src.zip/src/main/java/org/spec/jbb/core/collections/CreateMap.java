/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

import java.util.Map;

public interface CreateMap <K,V> extends Map<K,V> {

    /**
     * Returns the value to which the specified key is mapped,
     * or create new value and put it in the map for the specified key
     * @param key - key
     * @return value
     */
    public V getOrCreate(Object key);

}
