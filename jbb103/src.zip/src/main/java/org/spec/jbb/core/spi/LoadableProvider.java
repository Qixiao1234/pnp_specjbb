/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.spi;

public interface LoadableProvider {

    /**
     * Unique ID for provider.
     * @return id
     */
    String getName();

    /**
     * Human-readable description for provider
     * @return description
     */
    String getDescription();

    /**
     * Shutdown provider, doing any sort of deferred cleanup.
     */
    void shutdown();

}
