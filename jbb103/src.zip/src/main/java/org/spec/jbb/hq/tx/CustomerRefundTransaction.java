/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.request.CustomerRefundMessage;

import java.math.BigDecimal;

public class CustomerRefundTransaction extends AbstractTransaction {

    private final HQ hq;
    private final long customerId;
    private final BigDecimal amount;

    public CustomerRefundTransaction(HQ hq, CustomerRefundMessage msg, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        customerId = msg.getCustomerId();
        amount = msg.getAmount();
    }

    @Override
    public Response execute() {
        hq.refundCustomer(customerId, amount);
        return new OkResponse();
    }
    @Override
    public String toString() {
        return "CustomerRefundTx: customerId = {" + customerId + "}, amount = {" + amount.toString() + "}" ;
    }

}
