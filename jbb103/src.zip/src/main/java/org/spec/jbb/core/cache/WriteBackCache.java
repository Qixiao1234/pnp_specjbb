/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.cache;

import org.spec.jbb.core.Measurable;

/**
 * Interface for write-back cache.
 * Write-back cache is decorating some other heavy entity:
 *  - reading from it if necessary
 *  - writing back on eviction
 *
 * @param <C> context
 * @param <K> key type
 * @param <V> value type
 */
public interface WriteBackCache<C,K,V> extends Measurable {

    /**
     * Set connector to cooperate with decorated entity.
     * @param connector connector
     */
    void setConnector(Connector<C, K, V> connector);

    /**
     * Get the value. If value is not in the cache, connector will be asked to provide
     * value, and new value will be cached. One should always call release() after
     * completing working with key, in order to let cache write-back if necessary.
     *
     * @param context to run in
     * @param key key to get to
     * @return value; null if connector returns null.
     * @see #release(Object)
     */
    V get(C ctx, K key);

    /**
     * Update the value in the cache.
     * Value can be updated in decorated entity lazily.
     *
     * @param ctx context to run in
     * @param key key to write
     * @param value value to write
     */
    void update(C ctx, K key, V value);

    /**
     * Marks entity as not used, and hence ready for eviction.
     *
     * @param ctx context to run in
     * @param key key to release
     * @see #get(Object)
     */
    void release(C ctx, K key);

}
