/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.advertisement;

import org.spec.jbb.core.collections.ConcurrentMultiMap;
import org.spec.jbb.core.collections.MultiMap;
import org.spec.jbb.hq.entity.Category;
import org.spec.jbb.hq.entity.Product;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * This class represents available advertisement in SM.
 * 
 */
public class Advertisements implements Serializable {
    private static final long serialVersionUID = -2164327864709758255L;
    private final MultiMap<Category,Long> advertisements;

    public Advertisements() {
        advertisements = new ConcurrentMultiMap<>();
    }

    public void addAdvertisements(IssuedAdvertisement adv) {
        advertisements.putAll(adv.getCategory(), adv.getBarcodes());
    }

    public void removeAdvertisements(IssuedAdvertisement adv) {
        if (adv != IssuedAdvertisement.EMPTY) {
            advertisements.remove(adv.getCategory(), adv.getBarcodes());
        }
    }

    public List<Long> getAdvertisements(Product p) {
        List<Long> list = new ArrayList<>();
        for (Category c : p.getCategories()){
            list.addAll(advertisements.get(c));
        }
        return list;
    }

}
