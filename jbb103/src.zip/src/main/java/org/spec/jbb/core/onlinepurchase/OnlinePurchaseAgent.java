/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.onlinepurchase;

import org.spec.jbb.sm.SM;

/**
 * The goal for OnlinePurchaseAgent is to provide
 */

public interface OnlinePurchaseAgent {
    
    /**
     * Returns SM name to use for remote inventory lookups
     * 
     * @param sm source SM for online purchase transaction.
     * @return sm name to use for inventory in online purchase transaction
     */
    public String getSM(SM sm);
    
    
    /**
     * @return true, if the online purchase is a in store pickup or needs shipping to the customer address
     */
    public boolean isInstorePickup();
    
}
