/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.request;

import org.spec.jbb.core.comm.AbstractMessage;
import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.HQ.SMInventoryDirection;
import org.spec.jbb.hq.entity.Receipt;
import org.spec.jbb.hq.tx.AdjustSupermarketInventoryTransaction;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
public class AdjustSupermarketInventoryMessage extends AbstractMessage {
    private static final long serialVersionUID = 2108003649404696771L;
    @XmlElement
    private final Receipt receipt;
    
    @XmlElement
    private final SMInventoryDirection direction; 
   
    private AdjustSupermarketInventoryMessage() {
        // JAXB
        this(null, null);
    }
   
    public AdjustSupermarketInventoryMessage(Receipt receipt, SMInventoryDirection direction) {
        super();
        this.receipt = receipt;
        this.direction = direction;
    }

    @Override
    public boolean isDurable() {
        return true;
    }

    public Receipt getReceipt() {
        return receipt;
    }

    public SMInventoryDirection getDirection() {
        return direction;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        AdjustSupermarketInventoryMessage that = (AdjustSupermarketInventoryMessage) o;

        if (receipt != null ? !receipt.equals(that.receipt) : that.receipt != null) {
            return false;
        }

        if (direction != that.direction) {
            return false;
        }
        
        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                receipt,
                direction
        );
    }
    
    @Override
    public Transaction getTransaction(HQ hq, TransactionContext ctx) {
        return new AdjustSupermarketInventoryTransaction(hq, this, ctx);
    }
    
    @Override
    public String toString() {
        return "Adjust Supermarket Inventory Message, receipt = {" + receipt + "}, direction = {" + direction + "}" ;
    }
}
