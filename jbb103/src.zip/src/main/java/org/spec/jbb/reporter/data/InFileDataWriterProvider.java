/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter.data;

public class InFileDataWriterProvider implements DataWriterProvider {

    @Override
    public DataWriter newProvider(String fileName, int compressionLevel) {
        return new InFileDataWriter(fileName, compressionLevel);
    }

    @Override
    public String getName() {
        return "InFile";
    }

    @Override
    public String getDescription() {
        return "Writing Data into file";
    }

    @Override
    public void shutdown() {
    }
    
}
