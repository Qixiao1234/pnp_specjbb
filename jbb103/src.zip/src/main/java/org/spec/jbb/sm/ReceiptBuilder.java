/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm;

import org.spec.jbb.core.Topology;
import org.spec.jbb.core.collections.CollectionUtils;
import org.spec.jbb.core.collections.HashMultiMap;
import org.spec.jbb.core.collections.Mix;
import org.spec.jbb.core.purchase.PurchaseAgent;
import org.spec.jbb.core.purchase.PurchaseAgentFactory;
import org.spec.jbb.hq.entity.Receipt;
import org.spec.jbb.hq.entity.ReceiptLine;
import org.spec.jbb.sm.coupon.CouponFactory;
import org.spec.jbb.sm.coupon.GenericCoupon;
import org.spec.jbb.util.JbbProperties;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.RecursiveTask;
import java.util.concurrent.ThreadLocalRandom;

public class ReceiptBuilder {

    private ReceiptBuilder() {
        // prevent instantiation
    }

    public static Receipt build(long receiptNumber, ShoppingCart cart, String smName, GenericCoupon coupon) {
        BigDecimal totalPrice = BigDecimal.ZERO;

        HashMultiMap<String, ReceiptLine> receiptLines = new HashMultiMap<>();
        Set<Long> localBarcodes = new HashSet<>();
        Set<Long> allBarcodes = new HashSet<>();
        for (ShoppingCartItem item : cart) {
            ReceiptLine line = new ReceiptLine(item.getBarcode(), item.getQuantity(), item.getPrice(), item.getSpecificCoupon());
            totalPrice = totalPrice.add(item.getPrice().multiply(BigDecimal.valueOf(item.getQuantity(), 2)).setScale(2, BigDecimal.ROUND_HALF_EVEN));
            receiptLines.put(item.getSmName(), line);
            allBarcodes.add(item.getBarcode());
            if (smName.equals(item.getSmName())) {
                localBarcodes.add(item.getBarcode());
            }
        }

        if (cart.getInstallmentFee() != null) {
            totalPrice = totalPrice.add(cart.getInstallmentFee());
        }

        if (coupon != null) {
            totalPrice = totalPrice.multiply(coupon.getMultiplier()).setScale(2, BigDecimal.ROUND_HALF_EVEN);
        }

        return new Receipt(
                receiptNumber,
                smName,
                cart.getCustomerId(),
                receiptLines,
                localBarcodes,
                allBarcodes,
                System.nanoTime(),
                totalPrice,
                coupon
        );
    }

    /**
     * Generate a number of dummy "look like real" receipts, without executing actual transactions.
     * @param count number of receipts to generate
     * @return generated receipts
     */
    public static Collection<Receipt> generateReceipts(int count) {
        Source source = new Source();

        ForkJoinPool pool = new ForkJoinPool();
        Receipt[] result = pool.invoke(new GenerateReceiptsTask(source, new Receipt[count], 0, count));

        pool.shutdown();
        
        return Arrays.asList(result);
    }

    public static class Source {

        private final Mix<String> smMix;
        private final CouponFactory couponFactory;
        private final PurchaseAgent agent;
        private final int prop_minProductPriceInCents;
        private final int prop_maxProductPriceInCents;

        public Source() {
            agent = PurchaseAgentFactory.makePurchaseAgent();
            couponFactory = new CouponFactory();

            prop_minProductPriceInCents = JbbProperties.getInstance().getMinProductPriceInCents();
            prop_maxProductPriceInCents = JbbProperties.getInstance().getMaxProductPriceInCents();

            smMix = CollectionUtils.getMix(new Topology().getSMnames());
        }
        
        public BigDecimal nextPrice() {
            int price = ThreadLocalRandom.current().nextInt(prop_minProductPriceInCents, prop_maxProductPriceInCents);
            return BigDecimal.valueOf(price, 2);
        }
        
        public String nextSM() {
            return smMix.next();
        }

        public GenericCoupon nextCoupon() {
            return couponFactory.createGenericCoupon();
        }
        
        public int nextPurchaseSize() {
            return agent.getPurchaseSize();
        }
        
        public long nextBarcode() {
            return ThreadLocalRandom.current().nextLong();
        }

    }

    /**
     * Heavily optimized fork-join task for generating sublist of receipts.
     */
    public static class GenerateReceiptsTask extends RecursiveTask<Receipt[]> {

        private static final long serialVersionUID = 5877674041862259956L;

        /**
         * Hardcoded division threshold.
         * It does not make sense to make it adjustable.
         */
        private static final int THRESHOLD = 1000;

        private final Source source;
        private final Receipt[] result;
        private final int start;
        private final int end;

        public GenerateReceiptsTask(Source source, Receipt[] result, int start, int end) {
            this.source = source;
            this.result = result;
            this.start = start;
            this.end = end;
        }
        
        @Override
        protected Receipt[] compute() {
            int count = end - start;
            if (count < THRESHOLD) {
                generate(start, count);
            } else {
                GenerateReceiptsTask t1 = new GenerateReceiptsTask(source, result, start, (start + end) / 2);
                GenerateReceiptsTask t2 = new GenerateReceiptsTask(source, result, (start + end) / 2, end);
                ForkJoinTask.invokeAll(t1, t2);
            }
            return result;
        }

        private void generate(int start, int count) {
            long time = System.nanoTime();
            for (int c = 0; c < count; c++) {
                GenericCoupon genericCoupon = source.nextCoupon();
                String smName = source.nextSM();

                HashMultiMap<String, ReceiptLine> receiptLines = new HashMultiMap<>();
                Set<Long> allBarcodes = new HashSet<>();
                Set<Long> localBarcodes = new HashSet<>();

                int purchaseSize = source.nextPurchaseSize();
                for (int p = 0; p < purchaseSize; p++) {
                    long barcode = source.nextBarcode();
                    BigDecimal price = source.nextPrice();

                    // pretend all barcodes are local
                    receiptLines.put(smName, new ReceiptLine(barcode, -1, price, null));
                    localBarcodes.add(barcode);
                    allBarcodes.add(barcode);
                }

                // skip computing total price, it would be the same scale BigDecimal anyway.
                BigDecimal totalPrice = source.nextPrice();

                result[start + c] = new Receipt(
                        (start + c),
                        smName,
                        -1,
                        receiptLines,
                        localBarcodes,
                        allBarcodes,
                        time,
                        totalPrice,
                        genericCoupon
                );
            }
        }
    }

}
