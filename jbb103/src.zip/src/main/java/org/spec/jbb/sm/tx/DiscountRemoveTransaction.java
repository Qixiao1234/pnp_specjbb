/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.discount.Discount;
import org.spec.jbb.sm.discount.DiscountAgent;
import org.spec.jbb.sm.tx.request.DiscountRemoveRequest;

import java.util.ArrayList;
import java.util.List;

public class DiscountRemoveTransaction extends AbstractSMTransaction {

    private final DiscountAgent agent;

    public DiscountRemoveTransaction(SM sm, DiscountRemoveRequest req, TransactionContext ctx) {
        super(sm, ctx);
        this.agent = storage.getDiscountAgent();
    }

    @Override
    public Response execute() throws TransactionException {
        List<Discount> batch = agent.pollDiscountBatch();
        if (batch != null) {
            List<Long> barcodes = new ArrayList<>(batch.size());
            for (Discount d : batch) {
                inventory.clearDiscount(d);
                barcodes.add(d.getBarcode());
            }
            purchaseAgent.updateHotness(barcodes, -sm.getDiscountHotnessShift());
        }
        return new OkResponse();
    }

    @Override
    public String toString() {
        return "DiscountRemoveTx";
    }

}
