/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class CreditCard implements Serializable {

    private static final long serialVersionUID = -5625165544944704164L;
    @XmlElement
    private final long accountNumber;

    @XmlElement
    private final String cardCompany;

    @XmlElement
    private final String firstName;

    @XmlElement
    private final String lastName;

    @XmlElement
    private final Address address;

    @XmlElement
    private final BigDecimal balance;

    @XmlElement
    private final int PIN;

    private CreditCard() {
        // JAXB
        this(0, "", "", "", null, BigDecimal.ZERO, 0);
    }

    public CreditCard(long accountNumber, String cardCompany, String firstName, String lastName, Address address, BigDecimal balance, int pin) {
        this.accountNumber = accountNumber;
        this.cardCompany = cardCompany;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.balance = balance;
        PIN = pin;
    }

    public long getAccountNumber() {
        return accountNumber;
    }

    public String getCardCompany() {
        return cardCompany;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public Address getAddress() {
        return address;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public int getPIN() {
        return PIN;
    }

    @Override
    public String toString() {
        return "CreditCard{" +
                "accountNumber=" + accountNumber +
                ", cardCompany='" + cardCompany + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", address=" + address +
                ", balance=" + balance +
                ", PIN=" + PIN +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CreditCard that = (CreditCard) o;

        if (PIN != that.PIN) {
            return false;
        }
        if (accountNumber != that.accountNumber) {
            return false;
        }
        if (address != null ? !address.equals(that.address) : that.address != null) {
            return false;
        }
        if (balance != null ? !balance.equals(that.balance) : that.balance != null) {
            return false;
        }
        if (cardCompany != null ? !cardCompany.equals(that.cardCompany) : that.cardCompany != null) {
            return false;
        }
        if (firstName != null ? !firstName.equals(that.firstName) : that.firstName != null) {
            return false;
        }
        if (lastName != null ? !lastName.equals(that.lastName) : that.lastName != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                accountNumber,
                cardCompany,
                firstName,
                lastName,
                address,
                balance,
                PIN
        );
    }
}