/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity.grizzlynio.proto;

import org.spec.jbb.core.comm.Packet;
import org.spec.jbb.core.comm.transport.Data;
import org.spec.jbb.core.comm.transport.Transport;
import org.spec.jbb.core.comm.transport.TransportFactory;
import org.spec.jbb.core.comm.transport.TransportType;

import java.io.IOException;
import java.util.Arrays;
import java.util.Objects;

public class ProtocolDataUnit {

    static final byte[] MAGIC = new byte[]{0x50, 0x52, 0x45, 0x56, 0x45, 0x44, 0x21};

    private static final Transport<Packet.Header, Data> transport = TransportFactory.getInstance().getByteTransport(TransportType.SERIALIZED);

    private Type type;
    private int headerLength;
    private byte[] header;
    private int bodyLength;
    private byte[] body;

    public ProtocolDataUnit() {
    }

    public ProtocolDataUnit(Packet packet) {
        this(ProtocolDataUnit.Type.DATA, transport.convertDown(packet.getHeader()).getArray(), packet.getData().getArray());
    }

    public Packet toPacket() throws IOException {
        if (type != Type.ERROR) {
            return new Packet(transport.convertUp(Data.wrap(header)), Data.wrap(body));
        } else {
            throw new IOException(new String(body));
        }
    }

    public ProtocolDataUnit(Type type, byte[] header, byte[] body) {
        this.type = type;
        this.header = (header != null) ? header : new byte[0];
        this.body = (body != null) ? body : new byte[0];
        this.headerLength = this.header.length;
        this.bodyLength = this.body.length;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public byte[] getMagic() {
        return MAGIC;
    }

    public int getBodyLength() {
        return bodyLength;
    }

    public byte[] getBody() {
        return body;
    }

    public void setBody(byte[] body) {
        this.body = body;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ProtocolDataUnit that = (ProtocolDataUnit) o;

        if (bodyLength != that.bodyLength) {
            return false;
        }
        if (!Arrays.equals(body, that.body)) {
            return false;
        }
        if (type != that.type) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(type, bodyLength, body);
    }

    public void compareMagic(byte[] magic) {
        if (MAGIC.length != magic.length) {
            throw new ProtocolDataUnitException("Message header length invalid!",
                    magic.length);
        }
        for (int i = 0; i < MAGIC.length; i++) {
            if (magic[i] != MAGIC[i]) {
                throw new ProtocolDataUnitException("Message header invalid!",
                        i, magic[i], MAGIC[i]);
            }
        }
    }

    public void setBodyLength(int bodyLength) {
        this.bodyLength = bodyLength;
    }

    @Override
    public String toString() {
        return "ProtocolDataUnit{" +
                "body=" + Arrays.toString(body) +
                ", magic=" + Arrays.toString(MAGIC) +
                ", length=" + bodyLength +
                '}';
    }

    public byte[] getHeader() {
        return header;
    }

    public void setHeaderLength(int headerLength) {
        this.headerLength = headerLength;
    }

    public int getHeaderLength() {
        return headerLength;
    }

    public void setHeader(byte[] header) {
        this.header = header;
    }

    private static class ProtocolDataUnitException extends RuntimeException {
        private static final long serialVersionUID = 2037087996165827313L;
        private String message;

        ProtocolDataUnitException(String s, int length) {
            super();
            message = s + ", MAGIC length=" + MAGIC.length +
                    ", magic length=" + length;
        }

        ProtocolDataUnitException(String s, int index,
                                  byte m1Byte, byte m2Byte) {
            super();
            message = s + ", bytes at index " + index + " differ: " +
                    "incoming magic byte, " + m1Byte +
                    " != MAGIC byte, " + m2Byte;
        }

        @Override
        public String toString() {
            return message;
        }
    }

    public static enum Type {
        IP_REQUEST,
        IP_DATA,
        DATA, ERROR,
    }
}