/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity;

public enum ConnectivityType {

    NIO_GRIZZLY,

    HTTP_GRIZZLY,

    HTTP_JETTY,

}
