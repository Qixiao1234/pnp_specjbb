/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.probe;

import org.spec.jbb.core.Conventions;
import org.spec.jbb.core.ResetMode;
import org.spec.jbb.core.collections.ConcurrentCounterMap;

import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class IntrusiveProbe implements Probe {

    private ConcurrentCounterMap<String> counters = new ConcurrentCounterMap<>();
    private ConcurrentCounterMap<String> types = new ConcurrentCounterMap<>();
    private ConcurrentMap<String, Object> samples = new ConcurrentHashMap<>();

    private ConcurrentMap<String, Probe> childProbes = new ConcurrentHashMap<>();

    @Override
    public void inc(String label) {
        counters.getOrCreate(label).inc(1);
    }

    @Override
    public void add(String label, long inc) {
        counters.getOrCreate(label).inc(inc);
    }

    @Override
    public void countType(String label, Object o) {
        countType(label, o, 1);
    }

    @Override
    public void countType(String label, Object o, long inc) {
        types.getOrCreate(label + Conventions.getDataSeparator() + o.getClass().getSimpleName()).inc(inc);
    }

    @Override
    public void sample(String label, Object object) {
        samples.put(label, object);
    }

    @Override
    public boolean shouldGoInsane() {
        return true;
    }

    @Override
    public Probe getChild(String prefix) {
        return register(prefix, new IntrusiveProbe());
    }

    protected Probe register(String prefix, Probe probe) {
        Probe existingProbe = childProbes.putIfAbsent(prefix, probe);
        if (existingProbe != null) {
            return existingProbe;
        } else {
            return probe;
        }
    }


    @Override
    public void reset(ResetMode mode) {
        if (mode == ResetMode.STATIC) {
            counters.clear();
            types.clear();
            samples.clear();
        }
    }

    @Override
    public Map<String, Object> get() {
        Map<String, Object> result = new TreeMap<>();

        for (Map.Entry<String, Probe> entry : childProbes.entrySet()) {
            for (Map.Entry<String, Object> childEntry : entry.getValue().get().entrySet()) {
                result.put(entry.getKey() + Conventions.getDataSeparator() + childEntry.getKey(), childEntry.getValue());
            }
        }

        for (String entry : counters.keySet()) {
            result.put(entry, counters.get(entry).get());
        }

        for (String entry : types.keySet()) {
            result.put(entry, types.get(entry).get());
        }

        for (Map.Entry<String, Object> entry : samples.entrySet()) {
            result.put(entry.getKey(), entry.getValue());
        }

        return result;
    }
}
