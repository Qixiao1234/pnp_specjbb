/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.tx;

public class TransactionException extends RuntimeException {
    private static final long serialVersionUID = 586719337115728000L;

    public TransactionException(String message) {
        super(message);
    }
}
