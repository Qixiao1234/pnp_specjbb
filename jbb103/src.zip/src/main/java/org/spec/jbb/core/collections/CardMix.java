/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class CardMix<E> implements Mix<E> {

    private final List<List<E>> elementGroups;
    private final List<Integer> partialSums;
    private final int size;

    /**
     * Package private constructor, doesn't perform lists copying and
     * should not be used outside trusted places.
     * @param elements
     * @param weights
     */
    CardMix(List<List<E>> elements, List<Integer> weights) {
        if (elements.size() != weights.size()) {
            throw new IllegalArgumentException("elements.length!=weights.length");
        }
        this.elementGroups = elements;
        this.partialSums = new ArrayList<>(weights.size());
        int sum = 0;
        for (int i = 0; i < weights.size(); i++) {
            if (weights.get(i) < 0) {
                throw new IllegalArgumentException("weight[" + i + "]=" + weights.get(i) + " (should be non-negative)");
            }
            sum += weights.get(i) * elements.get(i).size();
            partialSums.add(sum);
        }
        this.size = sum;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public E next() {
        if (this.isEmpty()) {
            return null;
        }
        List<E> tick;
        if (elementGroups.size() == 1) {
            tick = elementGroups.get(0);
        } else {
            int rnd = ThreadLocalRandom.current().nextInt(size);
            int index = Collections.binarySearch(partialSums, rnd);
            if (index >= 0) {
                tick = elementGroups.get(index + 1);
            } else {
                tick = elementGroups.get(-(index + 1));
            }
        }
        return CollectionUtils.getRandomElement(tick);
    }

    @Override
    public int getMixWeight() {
        return size;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append('[');
        int prevWieghts = 0;
        for (int i = 0; i < elementGroups.size(); i++) {
            int weight = (partialSums.get(i) - prevWieghts) / elementGroups.get(i).size();
            prevWieghts = partialSums.get(i);
            for (E label : elementGroups.get(i)) {
                sb.append(label).append("(").append(weight).append("), ");
            }
        }
        sb.append(']');
        return sb.toString();
    }

}

