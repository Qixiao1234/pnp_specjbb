/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity.grizzlynio.proto;

import org.glassfish.grizzly.AbstractTransformer;
import org.glassfish.grizzly.Buffer;
import org.glassfish.grizzly.TransformationException;
import org.glassfish.grizzly.TransformationResult;
import org.glassfish.grizzly.attributes.AttributeStorage;

public class ProtocolDataUnitEncoder extends AbstractTransformer<ProtocolDataUnit, Buffer> {

    @Override
    protected TransformationResult<ProtocolDataUnit, Buffer> transformImpl(
            final AttributeStorage storage,
            final ProtocolDataUnit input) throws TransformationException {

        final int size = input.getMagic().length + 4 + 4 + input.getHeaderLength() +  4 + input.getBodyLength();
        final Buffer output = obtainMemoryManager(storage).allocate(size);
        output.allowBufferDispose(true);

        // Magic
        output.put(input.getMagic());

        // Type
        output.putInt(input.getType().ordinal());

        // Header Length
        output.putInt(input.getHeaderLength());

        // Header
        output.put(input.getHeader());

        // Length
        output.putInt(input.getBodyLength());

        // Body
        output.put(input.getBody());

        return TransformationResult.createCompletedResult(
                output.flip(), null);
    }

    @Override
    public String getName() {
        return "ProtocolDataUnitEncoder";
    }

    @Override
    public boolean hasInputRemaining(AttributeStorage storage, ProtocolDataUnit input) {
        return false;
    }
}
