/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */
package org.spec.jbb.sm.tx;

import org.spec.jbb.core.tx.TransactionException;

public class IncorrectUnreserveException extends TransactionException {

    private static final long serialVersionUID = -8227041075559455278L;

    public IncorrectUnreserveException(String message) {
        super(message);
    }
}
