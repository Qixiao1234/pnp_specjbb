/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.request;

import org.spec.jbb.core.comm.AbstractRequest;
import org.spec.jbb.core.comm.transport.TransportType;
import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.FindCustomerZipTransaction;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class FindCustomerZipRequest extends AbstractRequest {

    private static final long serialVersionUID = -2020229942044014520L;
    @XmlElement
    private final long customerId;

    @SuppressWarnings("unused")
    private FindCustomerZipRequest() {
        // JAXB
        this(0);
    }

    public FindCustomerZipRequest(long customerId) {
        this.customerId = customerId;
    }

    public long getCustomerId() {
        return customerId;
    }

    @Override
    public Transaction getTransaction(HQ hq, TransactionContext ctx) {
        return new FindCustomerZipTransaction(hq, this, ctx);
    }

    @Override
    public String toString() {
        return "Find customer zip, id = " + customerId;
    }

    @Override
    public TransportType getTransportHint() {
        return TransportType.SERIALIZED_ENCRYPTED;
    }

}
