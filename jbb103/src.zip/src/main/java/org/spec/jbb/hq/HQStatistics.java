/*
 * Copyright (c) 2014 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq;

import java.io.Serializable;

public class HQStatistics implements Serializable {

    private static final long serialVersionUID = -6334557820345342413L;

    private final long numberOfReceipts;
    private final long numberOfBarcodesInAllReceitps;

    public HQStatistics(long numberOfReceipts, long numberOfBarcodesInAllReceitps) {
        this.numberOfReceipts = numberOfReceipts;
        this.numberOfBarcodesInAllReceitps = numberOfBarcodesInAllReceitps;
    }

    public long getReceiptsNum() {
        return numberOfReceipts;
    }

    public long getBarcodesNum() {
        return numberOfBarcodesInAllReceitps;
    }

    @Override
    public String toString() {
        return "(" + numberOfReceipts + ", " + numberOfBarcodesInAllReceitps + ")";
    }

}
