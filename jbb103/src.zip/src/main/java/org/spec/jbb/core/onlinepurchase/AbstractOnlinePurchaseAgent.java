/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.onlinepurchase;

import org.spec.jbb.sm.SM;

public abstract class AbstractOnlinePurchaseAgent implements
        OnlinePurchaseAgent {

    public enum OnlineType {
        SAME_SM, SAME_HQ, DIFFERENT_HQ
    }

    @Override
    public abstract String getSM(SM sm);

    @Override
    public abstract boolean isInstorePickup();
}
