/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport;

import org.spec.jbb.core.comm.Incoming;
import org.spec.jbb.core.comm.Outgoing;
import org.spec.jbb.core.comm.transport.compression.GZipCompressionLayer;
import org.spec.jbb.core.comm.transport.encapsulation.JAXBEncapsulationLayer;
import org.spec.jbb.core.comm.transport.encapsulation.JavaSerializationEncapsulationLayer;
import org.spec.jbb.core.comm.transport.encapsulation.PooledJAXBEncapsulationLayer;
import org.spec.jbb.core.comm.transport.encryption.JavaSecurityEncryptionLayer;
import org.spec.jbb.core.comm.transport.encryption.PooledJavaSecurityEncryptionLayer;
import org.spec.jbb.util.JbbProperties;

import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;

public class TransportFactory {

    private final Map<TransportType, Transport<Incoming, Data>> incomingTransportCache;
    private final Map<TransportType, Transport<Outgoing, Data>> outgoingTransportCache;

    public static TransportFactory getInstance() {
        return new TransportFactory();
    }

    private TransportFactory() {
        EnumMap<TransportType, Transport<Incoming, Data>> incomingCache = new EnumMap<>(TransportType.class);
        EnumMap<TransportType, Transport<Outgoing, Data>> outgoingCache = new EnumMap<>(TransportType.class);
        for(TransportType type : TransportType.values()) {
            incomingCache.put(type, TransportFactory.<Incoming>getTransport(type));
            outgoingCache.put(type, TransportFactory.<Outgoing>getTransport(type));
        }
        incomingTransportCache = Collections.unmodifiableMap(incomingCache);
        outgoingTransportCache = Collections.unmodifiableMap(outgoingCache);
    }

    public Transport<Incoming, Data> getIncomingTransport(TransportType type) {
        return incomingTransportCache.get(type);
    }

    public Transport<Outgoing, Data> getOutgoingTransport(TransportType type) {
        return outgoingTransportCache.get(type);
    }

    public static <CT> Transport<CT, Data> getByteTransport(TransportType type) {
        Layer<CT, Data> encapsulator = getEncapsulationLayer(type.getEncapsulationType());
        Layer<Data, Data> compressor = getCompressionLayer(type.getCompressionType());
        Layer<Data, Data> encryptor = getEncryptionLayer(type.getCryptoType());

        return new TransportPipeline<>(encapsulator, encryptor, compressor);
    }

    private static <CT> Transport<CT, Data> getFallthroughTransport(TransportType type) {
        if (type.getCompressionType() != TransportType.CompressionType.NONE) {
            throw new IllegalStateException(type + " can not be combined with " + type.getCompressionType());
        }

        if (type.getCryptoType() != TransportType.EncryptionType.NONE) {
            throw new IllegalStateException(type + " can not be combined with " + type.getCryptoType());
        }

        return new EmptyTransport<>();
    }

    private static <CT> Transport<CT, Data> getTransport(TransportType type) {
        switch (type) {
            case NULL:
                return new NullTransport<>();
            case PLAIN:
                return getFallthroughTransport(type);
            default:
                return getByteTransport(type);
        }
    }

    private static Layer<Data, Data> getCompressionLayer(TransportType.CompressionType type) {
        switch (type) {
            case NONE:
                return new EmptyLayer();
            case GZIP:
                return new GZipCompressionLayer();
            default:
                throw new IllegalStateException(type + " compression is not supported");
        }
    }

    private static Layer<Data, Data> getEncryptionLayer(TransportType.EncryptionType type) {
        switch (type) {
            case NONE:
                return new EmptyLayer();
            case AES:
                return JbbProperties.getInstance().isJCETransportPooled() ?
                        new PooledJavaSecurityEncryptionLayer("AES", "CBC", "PKCS5Padding") :
                        new JavaSecurityEncryptionLayer("AES", "CBC", "PKCS5Padding");
            case RSA:
                return JbbProperties.getInstance().isJCETransportPooled() ?
                        new PooledJavaSecurityEncryptionLayer("RSA", "", "") :
                        new JavaSecurityEncryptionLayer("RSA", "", "");
            case DES:
                return JbbProperties.getInstance().isJCETransportPooled() ?
                        new PooledJavaSecurityEncryptionLayer("DES", "ECB", "PKCS5Padding") :
                        new JavaSecurityEncryptionLayer("DES", "ECB", "PKCS5Padding");
            default:
                throw new IllegalStateException(type + " encryption is not supported");
        }
    }

    private static <CT> Layer<CT, Data> getEncapsulationLayer(TransportType.EncapsulationType type) {
        switch (type) {
            case NONE:
                throw new IllegalStateException("NONE encapsulation is not supported");
            case SERIALIZED:
                return new JavaSerializationEncapsulationLayer<>();
            case XML_JAXB:
                return JbbProperties.getInstance().isJAXBTransportPooled() ?
                        new PooledJAXBEncapsulationLayer<CT>() :
                        new JAXBEncapsulationLayer<CT>();
            default:
                throw new IllegalStateException(type + " encapsulation is not supported");
        }
    }

}
