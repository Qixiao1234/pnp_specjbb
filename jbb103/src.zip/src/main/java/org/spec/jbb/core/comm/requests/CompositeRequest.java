/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.requests;

import org.spec.jbb.core.comm.AbstractRequest;
import org.spec.jbb.core.comm.Request;

import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import java.util.Objects;

@XmlRootElement
public class CompositeRequest extends AbstractRequest {
    private static final long serialVersionUID = 634739576069378907L;

    @XmlElementWrapper
    private final List<Request> requests;

    private CompositeRequest() {
        // JAXB
        this(null);
    }

    public CompositeRequest(List<Request> requests) {
        this.requests = requests;
    }

    public List<Request> getRequests() {
        return requests;
    }

    @Override
    public boolean isRequiresResponse() {
        for (Request request : requests) {
            if (request.isRequiresResponse()) {
                return true;
            }

        }
        return false;
    }

    @Override
    public boolean isDurable() {
        for (Request request : requests) {
            if (request.isDurable()) {
                return true;
            }

        }
        return false;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CompositeRequest that = (CompositeRequest) o;

        if (requests != null ? !requests.equals(that.requests) : that.requests != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(requests);
    }

    @Override
    public String toString() {
        return "CompositeRequest{" +
                "requests=" + requests +
                '}';
    }

}
