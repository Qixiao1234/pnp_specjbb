/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.time;

public class JavaSystemClock implements Clock {

    @Override
    public long getTimeMsec() {
        return System.currentTimeMillis();
    }

}
