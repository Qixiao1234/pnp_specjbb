/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

public class HashMultiMap<K, V> extends AbstractMultiMap<K,V> {

    private static final long serialVersionUID = 7945377668452863760L;

    public HashMultiMap() {
        super(new HashMap<K, Collection<V>>());
    }

    public HashMultiMap(MultiMap<K, V> map) {
        this();
        putAll(map);
    }

    @Override
    Collection<V> getOrCreate(K key) {
        Collection<V> coll = backingMap.get(key);
        if (coll == null) {
            coll = new ArrayList<>();
            backingMap.put(key, coll);
        }
        return coll;
    }

}
