/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections.sampling;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Array-backed sampling buffer with random insertions.
 *
 * @param <T>
 */
public class RandomArraySamplingBuffer<T> implements SamplingBuffer<T>, Serializable {

    private static final long serialVersionUID = 6872433981540303407L;

    /**
     * This implementation avoids most of the contention by inserting into random position
     * in the target array. This will require removing nulls when doing get()/snapshot(), but
     * in most cases snapshot will hit fully-occupied data.
     */

    private final int capacity;

    private final T[] data;

    private boolean isFull;

    public RandomArraySamplingBuffer(int capacity) {
        this.capacity = capacity;
        this.data = (T[]) new Object[capacity];
    }

    @Override
    public void put(T element) {
        if (element == null) {
            throw new NullPointerException();
        }

        int index = ThreadLocalRandom.current().nextInt(capacity);
        data[index] = element;
    }

    @Override
    public void putAll(Collection<T> elements) {
        int start = ThreadLocalRandom.current().nextInt(capacity);

        int c = 0;
        for (T element : elements) {
            data[(start + c) % capacity] = element;
            c++;
        }
    }

    @Override
    public T get() {
        int start = ThreadLocalRandom.current().nextInt(capacity);
        for (int c = 0; c < capacity; c++) {
            int nextIndex = (start + c) % capacity;
            if (data[nextIndex] != null) {
                return data[nextIndex];
            }
        }
        return null;
    }

    @Override
    public int size() {
        return capacity;
    }

    @Override
    public List<T> snapshot() {
        if (!isFull) {
            List<T> result = new ArrayList<>();
            for (T element : data) {
                if (element != null) {
                    result.add(element);
                }
            }

            isFull = (result.size() == data.length);
            return result;
        } else {
            return new ArrayList<>(Arrays.asList(data));
        }
    }

    public String toString() {
        return "RASB{" + snapshot().size() + "}";
    }
    
}
