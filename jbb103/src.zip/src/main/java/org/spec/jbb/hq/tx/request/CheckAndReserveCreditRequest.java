/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.request;

import org.spec.jbb.core.comm.AbstractRequest;
import org.spec.jbb.core.comm.transport.TransportType;
import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.CheckAndReserveCreditTransaction;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.math.BigDecimal;
import java.util.Objects;

@XmlRootElement
public class CheckAndReserveCreditRequest extends AbstractRequest {

    private static final long serialVersionUID = 7995658204682951878L;
    @XmlElement
    private final long customerId;

    @XmlElement
    private final BigDecimal amount;

    private CheckAndReserveCreditRequest() {
        // JAXB constructor
        this(0, BigDecimal.ZERO);
    }

    public CheckAndReserveCreditRequest(long customerId, BigDecimal amount) {
        this.customerId = customerId;
        this.amount = amount;
    }

    public long getCustomerId() {
        return customerId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CheckAndReserveCreditRequest that = (CheckAndReserveCreditRequest) o;

        if (customerId != that.customerId) {
            return false;
        }
        if (amount != null ? !amount.equals(that.amount) : that.amount != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(customerId, amount);
    }

    @Override
    public String toString() {
        return "Check and reserve credit for customer #" + customerId + ", $" + amount;
    }

    @Override
    public Transaction getTransaction(HQ hq, TransactionContext ctx) {
        return new CheckAndReserveCreditTransaction(hq, this, ctx);
    }

    @Override
    public TransportType getTransportHint() {
        return TransportType.SERIALIZED_ENCRYPTED;
    }

}
