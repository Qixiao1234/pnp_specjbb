/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.tx;

import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.comm.Response;

public interface TransactionExecutor extends Measurable {

    Response execute(Transaction transaction) throws TransactionException;

}
