/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity.grizzlynio;

import org.glassfish.grizzly.filterchain.FilterChainBuilder;
import org.glassfish.grizzly.filterchain.TransportFilter;
import org.glassfish.grizzly.nio.transport.TCPNIOServerConnection;
import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.comm.connectivity.Server;
import org.spec.jbb.core.comm.connectivity.ServerCallback;
import org.spec.jbb.core.comm.connectivity.grizzlynio.proto.ProtocolDataUnitFilter;
import org.spec.jbb.core.comm.connectivity.grizzlynio.proto.ServerProtocolDataUnitFilter;
import org.spec.jbb.core.probe.Probe;

import java.io.IOException;
import java.net.InetSocketAddress;


public class GrizzlyNioServer implements Server, Measurable {

    private int port;
    private final GrizzlyTransport wrapper;

    public GrizzlyNioServer(int port, ServerCallback callback) {
        this.port = port;
        wrapper = new GrizzlyTransport();

        FilterChainBuilder builder = FilterChainBuilder.stateless();
        builder.add(new TransportFilter());
        builder.add(new ProtocolDataUnitFilter());
        builder.add(new ServerProtocolDataUnitFilter(callback));

        wrapper.setProcessor(builder.build());
    }

    @Override
    public void open() throws IOException {
        TCPNIOServerConnection connection = wrapper.bind(port);
        wrapper.start();
        port = ((InetSocketAddress) connection.getLocalAddress()).getPort();
    }

    @Override
    public void close() {
        wrapper.shutdown();
    }

    @Override
    public int getLocalPort() {
        return port;
    }

    @Override
    public String toString() {
        return ":" +  port;
    }

    @Override
    public void instrument(Probe probe) {
        wrapper.instrument(probe);
    }

    @Override
    public void sample() {
        wrapper.sample();
    }
}
