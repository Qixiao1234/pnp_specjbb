/*
 * Copyright (c) 2012-2014 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

import org.spec.jbb.core.ExecutionHandler;
import org.spec.jbb.core.comm.Incoming;
import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.probe.Probe;

import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;

public class EmptyMultiPool implements Multipool {

    private Pool pool;

    public EmptyMultiPool() {
    }

    @Override
    public void addPool(Pool pool) {
        if (pool != null) {
            this.pool = pool;
        } else {
            throw new IllegalStateException("Tried to add another pool");
        }
    }

    @Override
    public Future<List<Response>> enqueueBatch(int tier, ExecutionHandler handler, List<? extends Incoming> incomings) throws RejectedExecutionException {
        return pool.enqueueBatch(tier, handler, incomings);
    }

    @Override
    public Future<List<Response>> forceBatch(int tier, ExecutionHandler handler, List<? extends Incoming> incomings) throws InterruptedException {
        return pool.forceBatch(tier, handler, incomings);
    }

    @Override
    public void start() {
        pool.start();
    }

    @Override
    public void shutdown() {
        pool.shutdown();
    }

    @Override
    public PoolPerfomanceData getProcessedCount() {
        return pool.getProcessedCount();
    }

    @Override
    public List<Response> processLocally(int tier, ExecutionHandler handler, List<? extends Incoming> requests) {
        return pool.processLocally(tier, handler, requests);
    }

    @Override
    public void assistExecute(Runnable runnable) {
        pool.assistExecute(runnable);
    }

    @Override
    public void instrument(Probe probe) {
        pool.instrument(probe);
    }

    @Override
    public void sample() {
        pool.sample();
    }
}
