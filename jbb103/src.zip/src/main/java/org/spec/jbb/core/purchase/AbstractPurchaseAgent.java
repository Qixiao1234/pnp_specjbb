/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */
package org.spec.jbb.core.purchase;

import org.spec.jbb.util.JbbProperties;
import org.spec.jbb.util.random.SpecRandom;
import org.spec.jbb.util.random.TriangleRandom;
import org.spec.jbb.util.random.TruncatedExponentialRandom;

import java.util.List;

public abstract class AbstractPurchaseAgent implements PurchaseAgent {

    private final SpecRandom purchaseSize;
    private final SpecRandom quantityNumber;

    protected AbstractPurchaseAgent() {
        int max = JbbProperties.getInstance().getMaxQuantityNumber();
        quantityNumber = new TruncatedExponentialRandom(null, TruncatedExponentialRandom.getMeanForMax(1, max), 1, max);
        purchaseSize = new TriangleRandom(null,
                (JbbProperties.getInstance().getMinPurchaseSize() +
                JbbProperties.getInstance().getMaxPurchaseSize()) / 2.0,
                JbbProperties.getInstance().getMinPurchaseSize(),
                JbbProperties.getInstance().getMaxPurchaseSize());
    }

    @Override
    public int getPurchaseSize() {
        return purchaseSize.nextInt();
    }

    protected int getQuantityNumber() {
        return quantityNumber.nextInt();
    }

    @Override
    public void updateHotness(List<Long> barcodes, int shift) {
        // does not support
    }
}
