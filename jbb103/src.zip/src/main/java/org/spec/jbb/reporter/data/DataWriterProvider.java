/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter.data;

import org.spec.jbb.core.spi.LoadableProvider;

public interface DataWriterProvider extends LoadableProvider {
    DataWriter newProvider(String fileName, int compressionLevel);
}
