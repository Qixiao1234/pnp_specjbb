/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.purchase;

import org.spec.jbb.util.random.ParetoRandom;

public class ParetoBiasedPurchaseAgent extends PurchaseAgentArrayBased {

    public ParetoBiasedPurchaseAgent() {
        super();
        random = new ParetoRandom(0, barcodes.size() - 1);
    }
    
}
