/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.time;

public class TimeFactory {

    private TimeFactory() {

    }

    public static Clock getClock() {
        return new JavaSystemClock();
    }

    public static StopWatch getStopwatch(long initValue) {
        return new JavaSystemStopWatch(initValue);
    }

    public static StopWatch getStopwatch() {
        return getStopwatch(0);
    }


}
