/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport.encapsulation;

import org.spec.jbb.core.comm.transport.Data;
import org.spec.jbb.util.ReflectionUtils;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class JAXBEncapsulationLayer<T> implements EncapsulationLayer<T> {

    private static final JAXBContext context;

    static {
        try {
            context = JAXBContext.newInstance(ReflectionUtils.findJAXBenabledClasses());
        } catch (JAXBException e) {
            throw new IllegalStateException("Exception during JAXB init", e);
        }
    }

    @Override
    public Data convertDown(T topInstance) {
        try {
            Marshaller m = context.createMarshaller();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            m.setProperty(Marshaller.JAXB_FRAGMENT, true);
            m.marshal(topInstance, baos);
            return Data.wrap(baos);
        } catch (JAXBException e) {
            throw new IllegalStateException("JAXB transport encountered exception", e);
        }

    }

    @Override
    public T convertUp(Data bottomInstance) {
        try {
            Unmarshaller u = context.createUnmarshaller();
            InputStream bais = bottomInstance.getStream();
            return (T) u.unmarshal(bais);
        } catch (JAXBException | ClassCastException e) {
            throw new IllegalStateException("JAXB transport encountered exception", e);
        }
    }

}
