/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.inventory;

import org.spec.jbb.core.locks.LockManager;
import org.spec.jbb.core.locks.LockManagerFactory;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.sm.discount.Discount;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.locks.Lock;

/**
 * A class representing a Supermarket Inventory of Products using
 * a ConcurrentHashMap as the backing storage for the Products.
 * <p/>
 * Note: ConcurrentHashMap preserves atomicity when looking up and creating
 * QuantityInfo objects, then QuantityInfo preserves atomicity while
 * updating quantity counters.
 */
public class LockedRandomBarcodeInventory implements Inventory, Serializable {

    private static final long serialVersionUID = -1985234319196929093L;

    private final ConcurrentMap<Long, QuantityInfo> inventory;

    private transient volatile LockManager<Long> lockManager;

    public LockedRandomBarcodeInventory(int size) {
        this.lockManager = LockManagerFactory.getLockManager();
        this.inventory = new ConcurrentHashMap<>(size);
    }

    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
        ois.defaultReadObject();
        lockManager = LockManagerFactory.getLockManager();
    }

    @Override
    public int moveIn(long barcode, int quantity) {
        checkQuantity(quantity);
        QuantityInfo quantityInfo = lookup(barcode, true);
        quantityInfo.in(quantity);
        return quantity;
    }

    private void checkQuantity(int quantity) {
        if (quantity < 0) {
            throw new IllegalArgumentException("quantity is negative");
        }
    }

    private QuantityInfo lookupOrFail(long barcode) {
        QuantityInfo quantityInfo = lookup(barcode, false);
        if (quantityInfo == null) {
            throw new IllegalStateException("Product record is not existent");
        }
        return quantityInfo;
    }

    private QuantityInfo lookup(long barcode, boolean canCreate) {
        QuantityInfo info = inventory.get(barcode);
        if (info == null && canCreate) {
            Lock lock = lockManager.getLock(barcode);
            QuantityInfo newInfo = new QuantityInfo(lock);
            QuantityInfo extInfo = inventory.putIfAbsent(barcode, newInfo);
            info = (extInfo != null) ? extInfo : newInfo;
        }
        return info;
    }

    @Override
    public int reserve(long barcode, int quantity) {
        checkQuantity(quantity);
        QuantityInfo quantityInfo = lookupOrFail(barcode);
        return quantityInfo.reserve(quantity);
    }

    @Override
    public int unreserve(long barcode, int quantity) {
        checkQuantity(quantity);
        QuantityInfo quantityInfo = lookupOrFail(barcode);
        return quantityInfo.unreserve(quantity);
    }

    @Override
    public int moveOut(long barcode, int quantity) {
        checkQuantity(quantity);
        QuantityInfo quantityInfo = lookupOrFail(barcode);
        return quantityInfo.out(quantity);
    }

    @Override
    public int getQuantity(long barcode) {
        QuantityInfo quantityInfo = lookup(barcode, false);
        return quantityInfo == null ? 0 : quantityInfo.getTotal();
    }

    @Override
    public List<Long> toList() {
        List<Long> result = new ArrayList<>();
        result.addAll(inventory.keySet());
        return result;
    }

    @Override
    public int size() {
        return inventory.size();
    }

    @Override
    public void clearDiscount(Discount discount) {
        QuantityInfo quantityInfo = lookupOrFail(discount.getBarcode());
        quantityInfo.clearDiscount(discount);
    }

    @Override
    public void setDiscount(Discount discount) {
        QuantityInfo quantityInfo = lookupOrFail(discount.getBarcode());
        quantityInfo.setDiscount(discount);
    }

    @Override
    public Discount getDiscount(long barcode) {
        QuantityInfo quantityInfo = lookup(barcode, false);
        return quantityInfo == null ? null : quantityInfo.getDiscount();
    }

    @Override
    public void instrument(Probe probe) {
        lockManager.instrument(probe.getChild("lockmanager"));
    }

    @Override
    public void sample() {
        lockManager.sample();
    }

    @Override
    public int updateReplenishInFlightQuantity(long barcode, int quantity) {
        QuantityInfo quantityInfo = lookupOrFail(barcode);
        return quantityInfo.updateReplenishInFlightQuantity(quantity);
    }

    @Override
    public int getReplenishInFlightQuantity(long barcode) {
        QuantityInfo quantityInfo = lookupOrFail(barcode);
        return quantityInfo.getReplenishInFlightQuantity();
    }

    private static class QuantityInfo implements Serializable {

        private static final long serialVersionUID = -3273987435876236532L;
        private int available;
        private int reserved;
        private Discount discount;
        private int replenishQuantityInFlight;
        private final Lock lock;

        public QuantityInfo(Lock lock) {
            this.lock = lock;
        }

        public void in(int quantity) {
            lock.lock();
            try {
                available += quantity;
            } finally {
                lock.unlock();
            }
        }

        public int reserve(int quantity) {
            lock.lock();
            try {
                int toReserve = Math.min(available, quantity);
                available -= toReserve;
                reserved += toReserve;
                return toReserve;
            } finally {
                lock.unlock();
            }
        }

        public int unreserve(int quantity) {
            lock.lock();
            try {
                int toUnreserve = Math.min(reserved, quantity);
                reserved -= toUnreserve;
                available += toUnreserve;
                return toUnreserve;
            } finally {
                lock.unlock();
            }
        }

        public int out(int quantity) {
            lock.lock();
            try {
                int toOut = Math.min(reserved, quantity);
                reserved -= toOut;
                return toOut;
            } finally {
                lock.unlock();
            }
        }

        public void setDiscount(Discount discount) {
            lock.lock();
            try {
                this.discount = discount;
            } finally {
                lock.unlock();
            }
        }

        public void clearDiscount(Discount discount) {
            lock.lock();
            try {
                if (discount.equals(this.discount)) {
                    this.discount = null;
                }
            } finally {
                lock.unlock();
            }
        }

        public Discount getDiscount() {
            lock.lock();
            try {
                return this.discount;
            } finally {
                lock.unlock();
            }
        }

        public int getTotal() {
            lock.lock();
            try {
                return available + reserved;
            } finally {
                lock.unlock();
            }
        }

        private int updateReplenishInFlightQuantity(int quantity) {
            lock.lock();
            try {
                int previousValue = replenishQuantityInFlight;
                replenishQuantityInFlight += quantity;
                return previousValue;
            } finally {
                lock.unlock();
            }
        }

        private int getReplenishInFlightQuantity() {
            return replenishQuantityInFlight;
        }
    }

}
