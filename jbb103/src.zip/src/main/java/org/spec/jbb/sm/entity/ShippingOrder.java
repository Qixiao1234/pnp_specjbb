/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.entity;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public final class ShippingOrder extends Order {
    private static final long serialVersionUID = 6730813070870660475L;
    @XmlElement
    private final String zipcode;

    @SuppressWarnings("unused")
    private ShippingOrder() {
        this(1, null);
    }

    public ShippingOrder(long customerId, String zipcode) {
        super(customerId);
        this.zipcode = zipcode;
    }

    public String getZipcode() {
        return zipcode;
    }

    @Override
    public String toString() {
        return "ShippingOrder to " + zipcode;
    }

}
