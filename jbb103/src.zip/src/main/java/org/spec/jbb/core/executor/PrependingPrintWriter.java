/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.executor;

import java.io.PrintWriter;

public class PrependingPrintWriter extends PrintWriter {

    private String prefix;
    private final PrintWriter pw;

    public PrependingPrintWriter(PrintWriter pw, int i) {
        super(pw);
        this.pw = pw;
        this.prefix = "";
        for (int c = 0; c < i; c++) {
            this.prefix += " ";
        }
    }

    @Override
    public void println(String x) {
        pw.println(prefix + x);
    }

    @Override
    public PrintWriter printf(String format, Object... args) {
        return pw.printf(prefix + format, args);
    }
}
