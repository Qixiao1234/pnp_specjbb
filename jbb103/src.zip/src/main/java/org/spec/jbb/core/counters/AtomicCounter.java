/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.counters;

import java.util.concurrent.atomic.AtomicLong;

public class AtomicCounter implements Counter {

    private AtomicLong counter;

    public AtomicCounter() {
        counter = new AtomicLong();
    }

    @Override
    public void inc(long increment) {
        counter.addAndGet(increment);
    }

    @Override
    public long get() {
        return counter.get();
    }

    @Override
    public void reset() {
        counter.set(0);
    }

    @Override
    public long getAndReset() {
        return counter.getAndSet(0);
    }
}
