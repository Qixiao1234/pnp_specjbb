/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.tx.request.SupplierReceiptMessage;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.tx.request.ProductReplenishMessage;
import org.spec.jbb.sp.Invoice;

/**
 * A class representing the notion of a product being replenished via an
 * Inventory operation.
 * This class represents the abstraction of the Inventory being replenished
 * as a result of an order being fulfilled by some Supplier.
 * It is called an "operation" since operations are not counted as a
 * completed SPECjbb transaction.
 */
public class InventoryReplenishOperation extends AbstractSMTransaction {
    private final Invoice invoice;

    public InventoryReplenishOperation(SM sm, ProductReplenishMessage request, TransactionContext ctx) {
        super(sm, ctx);
        this.invoice = request.getInvoice();
    }

    @Override
    public Response execute() throws TransactionException {
        for(long barcode : invoice.getBarcodes()) {
            doReplenish(barcode, invoice.getQuantity(barcode));
        }

        ctx.sendMessage(owningHQ, new SupplierReceiptMessage(invoice));

        return new OkResponse();
    }

    @Override
    public String toString() {
        return "Replenish inventory: " + invoice;
    }

}
