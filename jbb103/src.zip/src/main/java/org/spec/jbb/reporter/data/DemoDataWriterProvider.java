/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter.data;

public class DemoDataWriterProvider implements DataWriterProvider {

    @Override
    public DataWriter newProvider(String fileName, int compressionLevel) {
        return new DemoDataWriter();
    }

    @Override
    public String getName() {
        return "Demo";
    }

    @Override
    public String getDescription() {
        return "Send all frame to listener";
    }

    @Override
    public void shutdown() {
    }
    
}
