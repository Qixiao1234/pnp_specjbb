/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm;

import org.spec.jbb.core.collections.HashMultiSet;
import org.spec.jbb.core.collections.MultiSet;
import org.spec.jbb.hq.entity.CustomerProfile;
import org.spec.jbb.sm.coupon.GenericCoupon;
import org.spec.jbb.sm.coupon.SpecificCoupon;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class ShoppingCart implements Iterable<ShoppingCartItem> {

    private final long customerId;

    private final List<ShoppingCartItem> items;
    private final MultiSet<Long> quantities;

    private BigDecimal installmentFee;
    private CustomerProfile profile;
    
    private GenericCoupon genericCoupon;

    public ShoppingCart(long customerId) {
        this.customerId = customerId;
        this.items = new ArrayList<>();
        this.quantities = new HashMultiSet<> ();
        this.installmentFee = BigDecimal.ZERO;
    }

    @Override
    public Iterator<ShoppingCartItem> iterator() {
        return items.iterator();
    }

    public void add(long barcode, int quantity, BigDecimal price, String smName) {
        add(barcode, quantity, price, smName, null);
    }

    public void add(long barcode, int quantity, BigDecimal price, String smName, SpecificCoupon sc) {
        items.add(new ShoppingCartItem(barcode, quantity, price, sc, smName));
        quantities.add(barcode, quantity);
    }

    public int getQuantity(long barcode) {
        return quantities.count(barcode);
    }

    public long getCustomerId() {
        return customerId;
    }

    public int size() {
        return items.size();
    }

    @Override
    public String toString() {
        return "ShoppingCart{" + "customerId=" + customerId + ", items=" + items.size() + '}';
    }

    public BigDecimal getInstallmentFee() {
        return installmentFee;
    }

    public Set<Long> getBarcodes(){
        return quantities.elementSet();
    }

    public void add(BigDecimal fee) {
        installmentFee = installmentFee.add(fee);
    }

    public CustomerProfile getProfile() {
        return profile;
    }

    public void setProfile(CustomerProfile profile) {
        this.profile = profile;
    }

    public List<ShoppingCartItem> getItemSublist(int fromIndex, int toIndex){
        return items.subList(fromIndex, toIndex);
    }
    
    public void removeItem(ShoppingCartItem item){
        quantities.add(item.getBarcode(), item.getQuantity() * -1);
        items.remove(item);
    }

    public GenericCoupon getGenericCoupon() {
        return genericCoupon;
    }

    public void setGenericCoupon(GenericCoupon genericCoupon) {
        this.genericCoupon = genericCoupon;
    }


}
