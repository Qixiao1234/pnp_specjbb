/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity;

import org.spec.jbb.core.comm.connectivity.grizzlyhttp.GrizzlyHttpServer;
import org.spec.jbb.core.comm.connectivity.plain.PlainHttpClient;
import org.spec.jbb.core.probe.Probe;

public class GrizzlyHttpProvider implements ConnectivityProvider {
    @Override
    public Server newServer(int port, ServerCallback callback) {
        return new GrizzlyHttpServer(port, callback);
    }

    @Override
    public Client newClient(String hostname, int port) {
        return new PlainHttpClient(hostname, port);
    }

    @Override
    public String getName() {
        return "HTTP_Grizzly";
    }

    @Override
    public String getDescription() {
        return "Grizzly HTTP server, JDK HTTP client";
    }

    @Override
    public void shutdown() {
        // do nothing
    }

    @Override
    public void instrument(Probe probe) {
        // do nothing
    }

    @Override
    public void sample() {
        // do nothing
    }
}
