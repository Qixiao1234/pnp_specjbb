/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */
package org.spec.jbb.core.tx.response;

import java.util.Objects;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class FailedTransactionResponse extends FailedResponse {
    private static final long serialVersionUID = -9187070437298653967L;
    
    @XmlElement
    private final String msg;
    
    @XmlElement
    private final String cause;

    private FailedTransactionResponse() {
        // JAXB
        this(null, null);
    }

    public FailedTransactionResponse(String msg) {
        this(msg, null);
    }

    public FailedTransactionResponse(Throwable cause) {
        this(null, cause);
    }

    public FailedTransactionResponse(String msg, Throwable cause) {
        this.msg = msg;
        StringBuilder causeStr = new StringBuilder();
        while(cause != null) {
            if(causeStr.length() != 0) {
                causeStr.append("; caused by ");
            }
            causeStr.append(cause.toString());
            cause = cause.getCause();
        }
        this.cause = causeStr.length() == 0 ? null : causeStr.toString();
    }

    public String getMsg() {
        if(msg == null) {
            return cause;
        }
        if(cause == null) {
            return msg;
        }
        return msg + "; caused by " + cause;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        FailedTransactionResponse that = (FailedTransactionResponse) o;

        if (msg != null ? !msg.equals(that.msg) : that.msg != null) {
            return false;
        }

        if (cause != null ? !cause.equals(that.cause) : that.cause != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), msg, cause);
    }

    @Override
    public String toString() {
        return "Transaction Error: " + getMsg();
    }
    
}
