/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

public interface BinaryFunction<T> {

    public T apply(T v1, T v2);

}
