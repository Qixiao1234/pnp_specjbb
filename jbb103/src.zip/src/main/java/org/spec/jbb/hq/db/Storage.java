/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.db;

import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.collections.ConcurrentCreateHashMap;
import org.spec.jbb.core.collections.CreateHashMap;
import org.spec.jbb.core.collections.CreateMap;
import org.spec.jbb.core.collections.queues.QueueFactory;
import org.spec.jbb.core.collections.sampling.SamplingBuffer;
import org.spec.jbb.core.collections.sampling.SamplingBufferFactory;
import org.spec.jbb.core.locks.LockManager;
import org.spec.jbb.core.locks.LockManagerFactory;
import org.spec.jbb.core.onlinepurchase.ProductReviewScoreBuckets;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.probe.ProbeFactory;
import org.spec.jbb.hq.entity.Category;
import org.spec.jbb.hq.entity.Customer;
import org.spec.jbb.hq.entity.CustomerProfile;
import org.spec.jbb.hq.entity.Product;
import org.spec.jbb.hq.entity.Receipt;
import org.spec.jbb.hq.entity.SMBusinessReport;
import org.spec.jbb.infra.snapshot.Snapshottable;
import org.spec.jbb.sm.InstallmentPurchase;
import org.spec.jbb.sm.ReceiptBuilder;
import org.spec.jbb.sm.entity.InStorePickupOrder;
import org.spec.jbb.sm.entity.Order;
import org.spec.jbb.sm.entity.ShippingOrder;
import org.spec.jbb.sp.Invoice;
import org.spec.jbb.util.InstanceFactory;
import org.spec.jbb.util.JbbProperties;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.Lock;

public class Storage implements Measurable, Snapshottable {

    private static final long serialVersionUID = -3348221108173666236L;
    /**
     * Customers
     */
    private final ConcurrentMap<Long, Customer> customers;
    private final CreateMap<Long, CustomerProfile> customerProfilesMap;
    private final CreateMap<Customer, BigDecimal> balance;
    private final ConcurrentMap<Long, String> owningHQs;

    /**
     * Products
     */
    private final ConcurrentMap<Long, Product> products;
    private final ProductReviewScoreBuckets productReviewScoreBuckets;
    private final CreateMap<Category, Set<Long>> categoryToBarcodes;
    
    /**
     * Supermarket inventory mirror
     */
    private final CreateMap<String, CreateMap<Long, AtomicLong>> smInventory;

    /**
     * Operations logs: receipts
     */
    private transient volatile SamplingBuffer<Receipt> receipts;

    /**
     * Operations logs: invoices;
     */
    private final Queue<Invoice> invoices;

    /**
     * Installment purchases
     */
    private final Queue<InstallmentPurchase> installmentPurchases;

    /*
     * Accumulated SM reports
     */
    private final ConcurrentHashMap<String, SMBusinessReport> smReports;

    /**
     * Delivery orders
     */
    private final Queue<ShippingOrder> shippingOrders;
    private final Queue<InStorePickupOrder> inStorePickups;

    /**
     * Storage of data required for DataMining transactions.
     */
    private final DataMiningManager dataMiningManager;

    private transient LockManager<Long> customerLockManager = LockManagerFactory.getLockManager();
    private transient LockManager<String> supermarketLockManager = LockManagerFactory.getLockManager();

    private transient Probe probe;

    public Storage() {
        this.customers = new ConcurrentHashMap<>();
        this.owningHQs = new ConcurrentHashMap<>();
        this.products = new ConcurrentHashMap<>();
        this.invoices = QueueFactory.getUnboundedQueue();
        this.installmentPurchases = QueueFactory.getUnboundedQueue();
        this.probe = ProbeFactory.getDefaultProbe();
        this.shippingOrders = QueueFactory.getUnboundedQueue();
        this.inStorePickups = QueueFactory.getUnboundedQueue();
        this.productReviewScoreBuckets = new ProductReviewScoreBuckets();

        this.customerProfilesMap = new ConcurrentCreateHashMap<>(
                new InstanceFactory<CustomerProfile>() {
                    private static final long serialVersionUID = -7576421285112398321L;

                    @Override
                    public CustomerProfile getInstance() {
                        return new CustomerProfile();
                    }
                }
        );

        this.smInventory = new ConcurrentCreateHashMap<>(
                new InstanceFactory<CreateMap<Long, AtomicLong>>() {

                    private static final long serialVersionUID = -6493597031844536286L;

                    @Override
                    public CreateMap<Long, AtomicLong> getInstance() {
                        return new ConcurrentCreateHashMap<>(new InstanceFactory<AtomicLong>() {

                            private static final long serialVersionUID = -8413956202734498075L;

                            @Override
                            public AtomicLong getInstance() {
                                return new AtomicLong();
                            }
                        });
                    }
                });

        this.balance = new ConcurrentCreateHashMap<>(
            new InstanceFactory<BigDecimal>() {
                private static final long serialVersionUID = 6521980858693748933L;

                @Override
                public BigDecimal getInstance() {
                    return BigDecimal.ZERO;
                }
            }
        );
        
        categoryToBarcodes = new CreateHashMap<>(new InstanceFactory<Set<Long>>() {
            private static final long serialVersionUID = -6185191185453989373L;

            @Override
            public Set<Long> getInstance() {
                return new HashSet<>();
            }
        });

        this.smReports = new ConcurrentHashMap<>();
        
        dataMiningManager = new DataMiningManager();

        preseedReceipts();
    }

    private void preseedReceipts() {
        int count = JbbProperties.getInstance().getHQAccumulatedReceiptsPurgeThreshold();
        receipts = SamplingBufferFactory.getInstance(count);
        receipts.putAll(ReceiptBuilder.generateReceipts(count));
    }

    public void store(Customer customer) {
        customers.put(customer.getId(), customer);
    }

    public void store(Product product) {
        if (product.getBarcode() == 0) {
            throw new IllegalStateException("Product barcode is not set.");
        }
        products.put(product.getBarcode(), product);
        for(Category c : product.getCategories()) {
            categoryToBarcodes.getOrCreate(c).add(product.getBarcode());
        }
    }

    public void storeCustomerOwner(long customerId, String owner) {
        owningHQs.put(customerId, owner);
    }

    public Product findProduct(long barcode) {
        return products.get(barcode);
    }

    public Customer findCustomer(long customerId) {
        return customers.get(customerId);
    }
    
    public String getCustomerOwner(long customerId) {
        return owningHQs.get(customerId);
    }
    
    public BigDecimal getTotalCustomerCredit() {
        BigDecimal result = BigDecimal.ZERO;
        for (BigDecimal value : balance.values()) {
            result = result.add(value);
        }
        return result;
    }

    @Override
    public void sample() {
        customerLockManager.sample();
        supermarketLockManager.sample();
        productReviewScoreBuckets.sample();
        probe.sample("customers", customers.size());
        probe.sample("invoices.outstanding", invoices.size());
        probe.sample("receipts.outstanding", receipts.size());
        probe.sample("installmentPurchases.outstanding", installmentPurchases.size());
        probe.sample("instorePickups.outstanding", inStorePickups.size());
        probe.sample("shippingOrders.outstanding", shippingOrders.size());
    }

    @Override
    public void instrument(Probe probe) {
        this.probe = probe;
        customerLockManager.instrument(probe.getChild("customer"));
        supermarketLockManager.instrument(probe.getChild("mirror"));
        productReviewScoreBuckets.instrument(probe.getChild("productReview"));
    }

    public Queue<Invoice> getInvoices() {
        return invoices;
    }

    public void addReceipt(Receipt receipt) {
        receipts.put(receipt);
        dataMiningManager.addReceipt(receipt);
    }
    
    public Receipt selectRandomReceipt(String smName) {
        return dataMiningManager.selectRandomReceipt(smName);
    }

    public DataMiningManager getDataMiningManager() {
        return dataMiningManager;
    }

    public void putToQueue(InstallmentPurchase installmentPurchase){
        installmentPurchases.add(installmentPurchase);
    }
    
    public InstallmentPurchase getNextInstallmentPurchase(){
        return installmentPurchases.poll();
    }
    
    public long getInstallmentQueueSize(){
        return installmentPurchases.size();
    }
    
    public Map<Long, AtomicLong> getSupermarketInventory(String name) {
        return smInventory.get(name);
    }
    
    public CustomerProfile getCustomerProfile(long id) {
        // CustomerProfile is mutable, defensively copying
        CustomerProfile storedProfile = customerProfilesMap.getOrCreate(id);
        return new CustomerProfile(storedProfile);
    }

    public void updateCustomerProfile(long id, CustomerProfile profile) {
        // CustomerProfile is mutable, defensively copying
        CustomerProfile storedProfile = new CustomerProfile(profile);
        customerProfilesMap.put(id, storedProfile);
    }

    public void putToQueue(Order order) {
        boolean result;
        if (order instanceof ShippingOrder) {
            result = shippingOrders.offer((ShippingOrder) order);
        } else if (order instanceof InStorePickupOrder) {
            result = inStorePickups.offer((InStorePickupOrder) order);
        } else {
            throw new IllegalArgumentException("Storage does not know how to deal with this order");
        }

        if (!result) {
            throw new IllegalStateException("Storage had rejected order");
        }
    }

    public InStorePickupOrder getNextInStorePickup() {
        return inStorePickups.poll();
    }

    public ShippingOrder getNextShippingOrder() {
        return shippingOrders.poll();
    }

    public void setCustomerReviewScore(long barcode, int score) {
        productReviewScoreBuckets.setScore(barcode, score);
    }

    public Long getCustomerReviewRandomBarcode(int reviewScore) {
        return productReviewScoreBuckets.getRandomBarcode(reviewScore);
    }

    public int getCustomerReviewScore(long barcode) {
        return productReviewScoreBuckets.getScore(barcode);
    }

    public long getOnlinePurchaseShippingQueueSize() {
        return shippingOrders.size();
    }

    public long getOnlinePurchaseInstorePickupQueueSize() {
        return inStorePickups.size();
    }

    public void updateCustomerBalance(long customerId, BigDecimal amount) {
        Lock lock = customerLockManager.getLock(customerId);
        lock.lock();
        try {
            Customer customer = findCustomer(customerId);
            if (customer != null) {
                BigDecimal currentBalance = balance.getOrCreate(customer);
                balance.put(customer, currentBalance.add(amount));
            }
        } finally {
            lock.unlock();
        }

    }

    public BigDecimal getCustomerBalance(long customerId) {
        Lock lock = customerLockManager.getLock(customerId);
        lock.lock();
        try {
            Customer customer = findCustomer(customerId);
            if (customer != null) {
                return balance.getOrCreate(customer);
            }
        } finally {
            lock.unlock();
        }
        return BigDecimal.ZERO;
    }

    public void adjustSupermarketInventory(String supermarket, long barcode, int delta) {
        smInventory.getOrCreate(supermarket).getOrCreate(barcode).addAndGet(delta);
    }

    public SMBusinessReport putSMReport(SMBusinessReport smReport) {
        return smReports.put(smReport.getSmName(), smReport);
    }

    public ConcurrentHashMap<String, SMBusinessReport> getSMReports() {
        return smReports;
    }
    
    public Set<Long> getBarcodesForCategory(Category c) {
        return Collections.unmodifiableSet(categoryToBarcodes.get(c));
    }

    @Override
    public void preSnapshot() {
        // do nothing
    }

    @Override
    public void postSnapshot() {
        // do nothing
    }

    @Override
    public void postRecover() {
        customerLockManager = LockManagerFactory.getLockManager();
        supermarketLockManager = LockManagerFactory.getLockManager();
        probe = ProbeFactory.getDefaultProbe();
        preseedReceipts();
    }

}
