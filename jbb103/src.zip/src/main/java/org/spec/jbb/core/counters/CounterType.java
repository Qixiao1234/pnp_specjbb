/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.counters;

public enum CounterType {

    ATOMIC,

    THREAD_LOCAL,

    THREAD_HASHED,

    THREAD_HASHED_PADDED,

}
