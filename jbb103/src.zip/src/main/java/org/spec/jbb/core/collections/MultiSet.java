/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

import java.util.Collection;
import java.util.Set;

/**
 * MultiSet: Set-like collection which permits adding more than one element.
 *
 * @param <E> type
 */
public interface MultiSet<E> {

    /**
     * Add element to set.
     * @param element element to add
     */
    public void add(E element);

    /**
     * Add "occurence" number of elements to set.
     * Occurrence may be negative, so add(x,i) == remove(x,-i)
     * @param element element to modify
     * @param occurrence count to modify
     */
    public void add(E element, int occurrence);

    /**
     * Add all elements from given collection.
     * @param elements source collection.
     */
    public void addAll(Collection<E> elements);

    /**
     * Add all elements from given collection "occurrence" times
     * @param elements source collection.
     * @param occurrence how many times to add element
     */
    public void addAll(Collection<E> elements, int occurrence);

    /**
     * Checks if element is in collection.
     *
     * @param element element to check
     * @return true, if at least one element is present
     */
    public boolean contains(Object element);

    /**
     * Answers the count of elements in multiset.
     *
     * @param element element to count
     * @return occurence count
     */
    public int count(Object element);

    /**
     * Answers the Set of elements.
     * @return element set
     */
    public Set<E> elementSet();

    /**
     * Answers the set of entries in multiset.
     * @return entry set
     */
    public Set<MultiSet.Entry<E>> entrySet();

    /**
     * Remove the single occurrence.
     * @param element element to remove
     */
    public void remove(E element);

    /**
     * Remove multiple occurrences.
     * occurrence may be negative, so remove(x,i) == add(x,-i)
     * @param element element to remove
     * @param occurrence occurrence count to remove
     */
    public void remove(E element, int occurrence);

    /**
     * Clears the set, purging all elements
     */
    public void clear();

    /**
     * Returns the size of multiset.
     * This is the size of set, *including* multiple occurrences of each element
     * @return size
     */
    public int size();

    /**
     * Answers whether this multiset is empty
     * @return true, if empty.
     */
    public boolean isEmpty();

    /**
     * Atomically sets the number of occurrences of element to newCount,
     * but only if the count is currently oldCount.
     *
     * @param e element to modify
     * @param oldCount old count
     * @param newCount new count
     * @return true, if success.
     * @throws IllegalArgumentException if newCount is negative
     */
    public boolean setCount(E e, int oldCount, int newCount);

    /**
     * Sets occurrences of the element to the specified count.
     * @param e - the element
     * @param count - the desired count
     * @return the count of the element before the operation (non-negative)
     * @throws IllegalArgumentException if count is negative
     */
    public int setCount(E e, int count);

    /**
     * Multiset entry.
     *
     * @param <E>
     * @see Map.Entry
     */
    public interface Entry<E> {

        /**
         * Answers element
         * @return element
         */
        E getElement();

        /**
         * Answers the count for element
         * @return count
         */
        int getCount();

    }

}
