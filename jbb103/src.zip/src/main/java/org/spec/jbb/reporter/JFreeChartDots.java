/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

import org.apache.commons.math.stat.descriptive.DescriptiveStatistics;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYDotRenderer;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.RectangleEdge;

import java.awt.Color;
import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.TimeUnit;

public class JFreeChartDots implements ImageRender {

    @Override
    public JFreeChart render(String title, Timeline... timelines) {
        return render(title, Arrays.asList(timelines));
    }

    public JFreeChart render(String title, Collection<Timeline> timelines) {
        return render(title, true, timelines);
    }

    public JFreeChart render(String title, boolean hasLegend, Collection<Timeline> timelines) {

        if (timelines.size() == 0) {
            return null;
        }

        DescriptiveStatistics statistics = new DescriptiveStatistics();

        final XYSeriesCollection dataset = new XYSeriesCollection();

        for (Timeline timeline : timelines) {
            XYSeries series = new XYSeries(timeline.getName());
            for(DataPoint point : timeline.getAll()) {
                series.add(TimeUnit.NANOSECONDS.toMillis(point.getTime()), point.getValue(), false);
                statistics.addValue(point.getValue());
            }
            dataset.addSeries(series);
        }

        final JFreeChart chart = ChartFactory.createXYLineChart(
            title,
            "Time, msec", timelines.iterator().next().getValueLabel(),
            dataset,
            PlotOrientation.VERTICAL,
            hasLegend,  // legend
            true,  // tool tips
            false  // URLs
        );

        chart.setBackgroundPaint(Color.white);
        if(hasLegend) {
            chart.getLegend().setPosition(RectangleEdge.BOTTOM);
        }

        final XYPlot plot = chart.getXYPlot();
        XYDotRenderer renderer = new XYDotRenderer();
        renderer.setDotHeight(3);
        renderer.setDotWidth(3);
        plot.setRenderer(renderer);
        //plot.setOutlinePaint(Color.black);
        plot.setBackgroundPaint(Color.white);
        plot.setForegroundAlpha(0.65f);
        plot.setDomainGridlinePaint(Color.gray);
        plot.setRangeGridlinePaint(Color.gray);
        plot.setDomainMinorGridlinesVisible(true);
        plot.setRangeMinorGridlinesVisible(true);

        final ValueAxis domainAxis = plot.getDomainAxis();
        domainAxis.setTickMarkPaint(Color.black);
        domainAxis.setLowerMargin(0.0);
        domainAxis.setUpperMargin(0.0);
        domainAxis.setAutoRangeMinimumSize(1.0);

        final ValueAxis rangeAxis = plot.getRangeAxis();
        rangeAxis.setTickMarkPaint(Color.black);

        double lower = Math.min(statistics.getPercentile(5)*1.5, 0);
        double upper = statistics.getPercentile(95)*1.5;
        if(upper - lower > 0) {
            rangeAxis.setRange(lower, upper);
        }

        return chart;
    }

}
