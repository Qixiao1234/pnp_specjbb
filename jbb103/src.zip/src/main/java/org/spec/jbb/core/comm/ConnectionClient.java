/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm;

import java.util.List;

/**
 * Interconnect client.
 * Implementors of this interface can connect to IC.
 *
 * @see org.spec.jbb.core.comm.Interconnect
 */
public interface ConnectionClient {

    /**
     * Answer the unique name to distinguish this client on IC
     * @return client name
     */
    String getName();

    /**
     * Handle incoming requests.
     *
     * @param from source entity which sent the requests
     * @param requests requests to process
     * @param currentTier tier at which requests were generated
     * @param targetTier tier at which requests are supposed to be processed
     * @return responses
     */
    List<Response> handle(String from, List<Request> requests, int currentTier, int targetTier);

    /**
     * Handle incoming messages.
     * @param from source entity which sent the requests
     * @param currentTier tier at which messages were generated
     * @param targetTier tier at which messages are supposed to be processed
     * @param messages messages to process
     */
    void handleMessage(String from, List<Message> messages, int currentTier, int targetTier);

    /**
     * Accept the uplink to use.
     * This method is called by IC during register.
     *
     * @param link link to use for outbound requests
     */
    void setUplink(Uplink link);

    /**
     * Answer the uplink this connection client uses
     * @return uplink
     */
    Uplink getLink();

}
