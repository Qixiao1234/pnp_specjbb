/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.response;

import org.spec.jbb.core.tx.response.OkResponse;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.math.BigDecimal;
import java.util.Objects;

@XmlRootElement
public class InventoryValueResponse extends OkResponse {

    private static final long serialVersionUID = -5624217493309488034L;
    @XmlElement
    private final BigDecimal totalValue;
    
    private InventoryValueResponse() {
        // JAXB
        this(null);
    }
    
    public InventoryValueResponse(BigDecimal totalValue) {
        this.totalValue = totalValue;
    }
    
    public BigDecimal getTotalValue() {
        return totalValue;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        InventoryValueResponse that = (InventoryValueResponse) o;

        if (totalValue != null ? !totalValue.equals(that.totalValue) : that.totalValue != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), totalValue);
    }

    @Override
    public String toString() {
        return "Total inventory value = " + totalValue;
    }

}
