/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.entity;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@XmlRootElement
public class Address implements Serializable {

    private static final long serialVersionUID = -583655116332152246L;
    @XmlElement
    private final String street;

    @XmlElement
    private final String city;

    @XmlElement
    private final String state;

    @XmlElement
    private final String zip;

    @XmlElement
    private final String country;

    private Address() {
        // JAXB
        this("", "", "", "", "");
    }

    public Address(String street, String city, String state, String zip, String country) {
        this.street = street;
        this.city = city;
        this.state = state;
        this.zip = zip;
        this.country = country;
    }

    public String getStreet() {
        return street;
    }

    public String getCity() {
        return city;
    }

    public String getState() {
        return state;
    }

    public String getZip() {
        return zip;
    }

    public String getCountry() {
        return country;
    }

}
