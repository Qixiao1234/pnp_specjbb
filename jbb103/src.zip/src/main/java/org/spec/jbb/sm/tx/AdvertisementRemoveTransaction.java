/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.advertisement.AdvertisementAgent;
import org.spec.jbb.sm.advertisement.IssuedAdvertisement;
import org.spec.jbb.sm.tx.request.AdvertisementRemoveRequest;

public class AdvertisementRemoveTransaction extends AbstractSMTransaction {

    private final AdvertisementAgent agent;

    public AdvertisementRemoveTransaction(SM sm, AdvertisementRemoveRequest req, TransactionContext ctx) {
        super(sm, ctx);
        this.agent = storage.getAdvertisementAgent();
    }

    @Override
    public Response execute() {
        IssuedAdvertisement adv = agent.pollIssuedAdvertisement(ctx);
        if (adv != null) {
            advertisements.removeAdvertisements(adv);
        }
        return new OkResponse();
    }

    @Override
    public String toString() {
        return "AdvertisementRemoveTx";
    }

}
