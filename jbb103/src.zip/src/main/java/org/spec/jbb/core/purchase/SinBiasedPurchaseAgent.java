/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.purchase;

import org.spec.jbb.util.random.UniformRandom;


/**
 * An implementation of the PurchaseAgent interface which can bias
 * a Customer's selection of a Supermarket Product based on area
 * below the sin curve between 0 and 1.
 * <p/>
 * Could be used to bias the selecting of a Product bar code based
 * on the curve of the sin function.  That is, no particular set
 * of products are biased.  Rather, the bias slowly rises over a
 * set of products found in the center of Inventory's set of
 * Products to an eventual peak biased Product.
 */
public class SinBiasedPurchaseAgent extends PurchaseAgentArrayBased {

    public SinBiasedPurchaseAgent() {
        super();
        random = new UniformRandom(0, Integer.MAX_VALUE) {

            @Override
            public long nextLong() {
                return generateBiasedIndex(super.nextLong());
            }
            
        };
    }

    /**
     * Take absolute value of sin(PI * random number).  This is
     * a floating point value between 0 and 1.
     * Take this floating point value * # of Product in Inventory
     * (i.e. size of barcodeList) to get an index into a
     * the barcodeList which will find a Product barcode.
     *
     * @return a value between 0 and size of barcodeList - 1
     */
    private long generateBiasedIndex(long x) {
        double y = Math.abs(Math.sin(x * Math.PI / 180));
        long indexInBucket = Math.round(y * (barcodes.size() - 1));
        return indexInBucket;
    }

}
