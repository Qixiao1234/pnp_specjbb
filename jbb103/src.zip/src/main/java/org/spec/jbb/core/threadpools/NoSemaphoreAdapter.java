/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

class NoSemaphoreAdapter implements SemaphoreAdapter {

    @Override
    public boolean tryAcquire() {
        return true;
    }

    @Override
    public void acquire() throws InterruptedException {
        // do nothing
    }

    @Override
    public void release() {
        // do nothing
    }

    @Override
    public int availablePermits() {
        return Integer.MAX_VALUE;
    }

    @Override
    public int getQueueLength() {
        return 0;
    }
}
