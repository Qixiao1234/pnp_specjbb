/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.request;

import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.tx.DiscountRemoveTransaction;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public final class DiscountRemoveRequest extends AbstractServiceTxInjectorRequest {

    private static final long serialVersionUID = 489132169007926894L;

    @Override
    public String toString() {
        return "DiscountRemoveRequest";
    }

    @Override
    public Transaction getTransaction(SM sm, TransactionContext ctx) {
        return new DiscountRemoveTransaction(sm, this, ctx);
    }
}
