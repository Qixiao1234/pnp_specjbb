/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.executor;

import org.spec.jbb.core.EntityType;
import org.spec.jbb.core.ExecutionHandler;
import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.comm.ConnectionClient;
import org.spec.jbb.core.tx.TransactionExecutor;

/**
 * BatchExecutor.
 * <p/>
 * This interface to be implemented by batch processors.
 * Most of the housekeeping work is done in AbstractBatchExecutor.
 * <p/>
 * This interface extends BatchRouter to express the common batch
 * routing interface within all SPECjbb entities.
 *
 * @see BatchRouter
 * @see AbstractBatchExecutor
 */
public interface BatchExecutor extends ExecutionHandler, ConnectionClient, Measurable {

    EntityType getType();

    TransactionExecutor getTransactionExecutor();

    void shutdown();

}
