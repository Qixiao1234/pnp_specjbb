/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport.encapsulation;

import org.spec.jbb.core.comm.transport.Data;
import org.spec.jbb.core.objectpool.SimplePool;
import org.spec.jbb.util.InstanceFactory;
import org.spec.jbb.util.ReflectionUtils;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class PooledJAXBEncapsulationLayer<T> implements EncapsulationLayer<T> {

    private static final JAXBContext context;

    private final SimplePool<Marshaller> marshallerPool;
    private final SimplePool<Unmarshaller> unmarshallerPool;

    static {
        try {
            context = JAXBContext.newInstance(ReflectionUtils.findJAXBenabledClasses());
        } catch (JAXBException e) {
            throw new IllegalStateException("Exception during JAXB init", e);
        }
    }

    public PooledJAXBEncapsulationLayer() {
        marshallerPool = new SimplePool<>(new InstanceFactory<Marshaller>() {
            private static final long serialVersionUID = -7261877088364917213L;

            @Override
            public Marshaller getInstance() {
                try {
                    Marshaller m = context.createMarshaller();
                    m.setProperty(Marshaller.JAXB_FRAGMENT, true);
                    return m;
                } catch (JAXBException e) {
                    throw new IllegalStateException(e);
                }
            }
        });

        unmarshallerPool = new SimplePool<>(new InstanceFactory<Unmarshaller>() {
            private static final long serialVersionUID = -2281020651650380264L;

            @Override
            public Unmarshaller getInstance() {
                try {
                    return context.createUnmarshaller();
                } catch (JAXBException e) {
                    throw new IllegalStateException(e);
                }
            }
        });


    }

    @Override
    public Data convertDown(T topInstance) {
        Marshaller m = null;
        try {
            m = marshallerPool.acquire();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            m.marshal(topInstance, baos);
            return Data.wrap(baos);
        } catch (JAXBException e) {
            throw new IllegalStateException("JAXB transport encountered exception", e);
        } finally {
            if (m != null) {
                marshallerPool.release(m);
            }
        }
    }

    @Override
    public T convertUp(Data bottomInstance) {
        Unmarshaller u = null;
        try {
            u = unmarshallerPool.acquire();
            InputStream bais = bottomInstance.getStream();
            return (T) u.unmarshal(bais);
        } catch (JAXBException | ClassCastException e) {
            throw new IllegalStateException("JAXB transport encountered exception", e);
        } finally {
            if (u != null) {
                unmarshallerPool.release(u);
            }
        }
    }

}
