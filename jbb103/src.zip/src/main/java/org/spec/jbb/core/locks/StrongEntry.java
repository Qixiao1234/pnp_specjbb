/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.locks;

/**
 * Weak reference key, required to override equals()/hashCode().
 * @param <K>
 */
public class StrongEntry<K, V> implements Entry<K, V> {
    private final K key;
    private final V value;

    public StrongEntry(K key, V value) {
        this.key = key;
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        return key.equals(o);
    }

    @Override
    public int hashCode() {
        return key.hashCode();
    }

    public K getKey() {
        return key;
    }

    public V get() {
        return value;
    }

}