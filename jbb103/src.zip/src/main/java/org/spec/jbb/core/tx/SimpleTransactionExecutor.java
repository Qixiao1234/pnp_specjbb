/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.probe.ProbeFactory;
import org.spec.jbb.core.time.StopWatch;
import org.spec.jbb.core.time.TimeFactory;
import org.spec.jbb.util.JbbProperties;

import java.util.logging.Logger;

public class SimpleTransactionExecutor implements TransactionExecutor {

    private final Logger logger;
    private volatile Probe probe;
    private final boolean isLogging;

    public SimpleTransactionExecutor(String name) {
        isLogging = JbbProperties.getInstance().isTransactionLoggingEnabled();
        logger = Logger.getLogger("org.spec.jbb." + name + ".executor");
        probe = ProbeFactory.getDefaultProbe();
    }

    @Override
    public Response execute(Transaction tx) throws TransactionException {
        if (probe.shouldGoInsane()) {
            return insaneExecute(tx);
        } else {
            if (isLogging) {
                return normalExecute(tx);
            } else {
                return tx.execute();
            }
        }
    }

    private Response normalExecute(Transaction tx) throws TransactionException {
        logger.finest(tx + " started");
        try {
            Response response = tx.execute();
            logger.finest(tx + " finished");
            return response;
        } catch (TransactionException e) {
            logger.finest(tx + " failed");
            throw e;
        }
    }

    private Response insaneExecute(Transaction tx) throws TransactionException {
        logger.finest(tx + " started");

        StopWatch watch = TimeFactory.getStopwatch();
        try {
            probe.countType("inflight", tx, +1);

            watch.start();
            Response response = tx.execute();
            watch.stop();

            probe.countType("success", tx);
            logger.finest(tx + " finished");
            return response;
        } catch(TransactionException e) {
            probe.countType("failed", tx);
            logger.finest(tx + " failed");
            throw e;
        } finally {
            probe.countType("inflight", tx, -1);
            probe.countType("time", tx, watch.getElapsedNsecs());
        }
    }

    @Override
    public void instrument(Probe probe) {
        this.probe = probe;
    }

    @Override
    public void sample() {
        // do nothing
    }
}
