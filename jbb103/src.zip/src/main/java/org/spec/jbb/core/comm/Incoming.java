/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm;

import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.of.OrderFulfillment;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sp.SP;

public interface Incoming extends Transportable {

    /**
     * Answers whether this incoming is durable.
     * Durable incoming can not be dropped. It should be processed at any cost.
     * Non-durable incoming can be dropped.
     *
     * @return
     */
    boolean isDurable();

    Transaction getTransaction(SM sm, TransactionContext ctx);

    Transaction getTransaction(HQ hq, TransactionContext ctx);

    Transaction getTransaction(SP sp, TransactionContext ctx);

    Transaction getTransaction(OrderFulfillment of, TransactionContext ctx);

}
