/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.request;

import org.spec.jbb.core.comm.AbstractRequest;
import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.ProductResolveTransaction;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
public class ProductResolveRequest extends AbstractRequest {

    private static final long serialVersionUID = -387827790327416968L;
    @XmlElement
    private final long barcode;

    private ProductResolveRequest() {
        // JAXB
        this(0);
    }

    public ProductResolveRequest(long barcode) {
        this.barcode = barcode;
    }

    public long getBarcode() {
        return barcode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ProductResolveRequest that = (ProductResolveRequest) o;

        if (barcode != that.barcode) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(barcode);
    }

    @Override
    public Transaction getTransaction(HQ hq, TransactionContext ctx) {
        return new ProductResolveTransaction(hq, this, ctx);
    }

    @Override
    public String toString() {
        return "Product resolve, barcode = " + barcode;
    }

}
