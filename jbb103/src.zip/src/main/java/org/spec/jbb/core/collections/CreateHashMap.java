/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

import org.spec.jbb.util.InstanceFactory;

import java.util.HashMap;

public class CreateHashMap<K, V> extends HashMap<K, V> implements CreateMap<K,V> {

    private static final long serialVersionUID = 4803822922758297744L;

    private final InstanceFactory<V> factory;

    public CreateHashMap(InstanceFactory<V> factory) {
        this.factory = factory;
    }

    @Override
    public V getOrCreate(Object key) {
        V v = super.get(key);
        if (v == null) {
            v = factory.getInstance();
            put((K)key, v);
        }
        return v;
    }

}
