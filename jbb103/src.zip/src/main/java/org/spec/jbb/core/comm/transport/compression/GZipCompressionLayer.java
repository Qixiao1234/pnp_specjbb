/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport.compression;

import org.spec.jbb.core.comm.transport.Data;
import org.spec.jbb.util.StreamUtil;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class GZipCompressionLayer implements CompressionLayer {

    @Override
    public Data convertDown(Data topInstance) {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();

            GZIPOutputStream gzipOutputStream = new GZIPOutputStream(bos);
            gzipOutputStream.write(topInstance.getArray());
            gzipOutputStream.close();

            return Data.wrap(bos);
        } catch (IOException e) {
            throw new IllegalStateException("GZip marshaller throws unexpected exception: " + e);
        }
    }

    @Override
    public Data convertUp(Data bottomInstance) {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            InputStream bis = bottomInstance.getStream();
            GZIPInputStream gzipInputStream = new GZIPInputStream(bis);

            StreamUtil.copy(gzipInputStream, bos);

            bos.close();
            gzipInputStream.close();

            return Data.wrap(bos);
        } catch (IOException e) {
            throw new IllegalStateException("GZip unmarshaller throws unexpected exception: " + e);
        }
    }

}
