/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter.data;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.zip.Adler32;
import java.util.zip.CheckedOutputStream;
import java.util.zip.Checksum;
import java.util.zip.GZIPOutputStream;
import org.spec.jbb.core.comm.ConnectionClient;
import org.spec.jbb.core.time.StopWatch;
import org.spec.jbb.core.time.TimeFactory;
import org.spec.jbb.reporter.ChecksumFrame;
import org.spec.jbb.reporter.EndOfBlockFrame;
import org.spec.jbb.reporter.Frame;

public class InFileDataWriter implements DataWriter {

    private static final int FLUSH_EACH_MSEC = 5000;
    private static final long FLUSH_EACH_BYTES = 50 * 1024 * 1024; // 10 Mb
    private final ObjectOutputStream oos;
    private final GZIPOutputStream gzip;
    private final CheckedOutputStream cos;
    private final CountingOutputStream countOS;
    private final OutputStream file;
    private final Checksum checksum;
    private final StopWatch timeSinceLastFlush;
    private long kbSinceLastFlush;

    public InFileDataWriter(String fileName, int compressionLevel) {
        try {
            timeSinceLastFlush = TimeFactory.getStopwatch();
            timeSinceLastFlush.start();
            checksum = new Adler32();
            file = new FileOutputStream(fileName);
            gzip = new GZIPOutputStreamEx(file, compressionLevel);
            cos = new CheckedOutputStream(gzip, checksum);
            countOS = new CountingOutputStream(cos);
            oos = new ObjectOutputStream(countOS);
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    @Override
    public void open(ConnectionClient client) throws IOException {
        // Ignore, no network communication
    }

    @Override
    public void write(Frame frame) throws IOException {
        try {
            oos.writeObject(frame);
            if (timeSinceLastFlush.getElapsedMsecs() > FLUSH_EACH_MSEC
                    || (countOS.getBytes() - kbSinceLastFlush) > FLUSH_EACH_BYTES) {
                flush();
            }
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    @Override
    public void flush() throws IOException {
        // write out checksum:
        //   Should demarcate the end of business data.
        //   Otherwise it would be hard to checksum data on read.
        oos.writeObject(new EndOfBlockFrame());
        oos.flush();

        oos.writeObject(new ChecksumFrame(checksum.getValue()));

        // FLUSH to get datafile even if workload crashes
        oos.flush();
        gzip.flush();
        file.flush();

        // Reset stream, preventing memory leak in readers.
        oos.reset();

        timeSinceLastFlush.reset();
        timeSinceLastFlush.start();

        kbSinceLastFlush = countOS.getBytes();
    }

    @Override
    public void close() {
        try {
            oos.close();
        } catch (IOException e) {
        }

        try {
            gzip.finish();
            gzip.close();
        } catch (IOException e) {
        }

        try {
            file.close();
        } catch (IOException e) {
        }
    }

    private static class CountingOutputStream extends OutputStream {

        private final OutputStream oos;
        private long bytes;

        public CountingOutputStream(OutputStream oos) {
            this.oos = oos;
        }

        @Override
        public void write(int b) throws IOException {
            oos.write(b);
            bytes++;
        }

        @Override
        public void write(byte[] b) throws IOException {
            oos.write(b);
            bytes += b.length;
        }

        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            oos.write(b, off, len);
            bytes += len;
        }

        public long getBytes() {
            return bytes;
        }
    }

    public static class GZIPOutputStreamEx extends GZIPOutputStream {
        public GZIPOutputStreamEx(OutputStream out, int compressionLevel) throws IOException {
            super(out, 16*1024*1024);
            def.setLevel(compressionLevel);
        }
    }

}
