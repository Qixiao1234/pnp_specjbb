/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity;

import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.spi.SpiFactory;
import org.spec.jbb.util.JbbProperties;

public class ConnectivityFactory extends SpiFactory<ConnectivityProvider> implements Measurable {

    public ConnectivityFactory() {
        super(ConnectivityProvider.class);
    }

    public Client getClient(String name, String hostname, int port) {
        ConnectivityProvider provider = get(name);
        return provider.newClient(hostname, port);
    }

    public Server getServer(String name, int port, ServerCallback callback) {
        ConnectivityProvider provider = get(name);
        return provider.newServer(port, callback);
    }

    public Client getClient(String hostname, int port) {
        return getClient(JbbProperties.getInstance().getConnectivityType(), hostname, port);
    }

    public Server getServer(int port, ServerCallback callback) {
        return getServer(JbbProperties.getInstance().getConnectivityType(), port, callback);
    }

    @Override
    public void instrument(Probe probe) {
        ConnectivityProvider provider = get(JbbProperties.getInstance().getConnectivityType());
        provider.instrument(probe);
    }

    @Override
    public void sample() {
        ConnectivityProvider provider = get(JbbProperties.getInstance().getConnectivityType());
        provider.sample();
    }
}
