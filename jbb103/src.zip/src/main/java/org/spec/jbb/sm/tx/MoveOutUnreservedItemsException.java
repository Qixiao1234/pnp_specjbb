/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */
package org.spec.jbb.sm.tx;

import org.spec.jbb.core.tx.TransactionException;

public class MoveOutUnreservedItemsException extends TransactionException {
    private static final long serialVersionUID = 1761727217137255926L;

    public MoveOutUnreservedItemsException(String message) {
        super(message);
    }
}
