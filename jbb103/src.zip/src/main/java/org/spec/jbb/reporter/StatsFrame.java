/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

import org.spec.jbb.core.Conventions;
import org.spec.jbb.infra.ProfileData;

public class StatsFrame implements Frame {

    public static final long serialVersionUID = 2L;

    private final ProfileData profileData;

    public StatsFrame(ProfileData profileData) {
        this.profileData = profileData;
    }

    public ProfileData getProfileData() {
        return profileData;
    }

    public long getTime() {
        return (Long) profileData.attr("controller" + Conventions.getDataSeparator() + "time");
    }

    @Override
    public Frame cleanForSubmission(CleanForSubmissionContext ctx) {
        profileData.cleanForSubmission();
        profileData.internAll();
        return this;
    }
    
    @Override
    public String toString() {
        return "Stats: " + profileData;
    }
}
