/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm;

import org.spec.jbb.core.comm.transport.TransportType;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.io.Serializable;

public abstract class AbstractResponse implements Response, Serializable {

    private static final long serialVersionUID = -2283202796693712478L;

    static class JAXBAdapter extends XmlAdapter<AbstractResponse, Response> {

        @Override
        public Response unmarshal(AbstractResponse v) throws Exception {
            return v;
        }

        @Override
        public AbstractResponse marshal(Response v) throws Exception {
            return (AbstractResponse) v;
        }
    }

    @Override
    public TransportType getTransportHint() {
        return null; // use default policy
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return 1;
    }
}
