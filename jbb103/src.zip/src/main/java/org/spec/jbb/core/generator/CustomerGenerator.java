/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.generator;

import org.spec.jbb.core.Topology;
import org.spec.jbb.core.collections.CollectionUtils;
import org.spec.jbb.core.collections.Mix;
import org.spec.jbb.hq.entity.Address;
import org.spec.jbb.hq.entity.CreditCard;
import org.spec.jbb.hq.entity.Customer;
import org.spec.jbb.sm.CustomerSelection.CustomerType;
import org.spec.jbb.util.JbbProperties;
import org.spec.jbb.util.RandomData;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class CustomerGenerator {

    private volatile CachedData cachedData;

    public List<Customer> generate() {
        synchronized (this) {
            int count = JbbProperties.getInstance().getCustomerCount();
            long seed = JbbProperties.getInstance().getRandomSeed();

            CachedData data = cachedData;
            if (data == null || data.count != count || data.seed != seed) {
                data = new CachedData(generate(count, seed), count, seed);
                cachedData = data;
            }

            return Collections.unmodifiableList(data.data);
        }
    }

    List<Customer> generate(int count, long seed) {
        Set<Integer> uniqueCustomerIds = new HashSet<>();
        Set<Long> uniqueNumbers = new HashSet<>();

        int prop_MinCreditCardCompanyChars = JbbProperties.getInstance().getMinCreditCardCompanyChars();
        int prop_MaxCreditCardCompanyChars = JbbProperties.getInstance().getMaxCreditCardCompanyChars();
        int prop_MinCustomerNameChars = JbbProperties.getInstance().getMinCustomerNameChars();
        int prop_MaxCustomerNameChars = JbbProperties.getInstance().getMaxCustomerNameChars();

        int prop_MinAddressStreetChars = JbbProperties.getInstance().getMinAddressStreetChars();
        int prop_MaxAddressStreetChars = JbbProperties.getInstance().getMaxAddressStreetChars();
        int prop_MinAddressCityChars = JbbProperties.getInstance().getMinAddressCityChars();
        int prop_MaxAddressCityChars = JbbProperties.getInstance().getMaxAddressCityChars();
        int prop_MinAddressStateChars = JbbProperties.getInstance().getMinAddressStateChars();
        int prop_MaxAddressStateChars = JbbProperties.getInstance().getMaxAddressStateChars();
        int prop_MinAddressZipChars = JbbProperties.getInstance().getMinAddressZipChars();
        int prop_MaxAddressZipChars = JbbProperties.getInstance().getMaxAddressZipChars();
        int prop_MinAddressCountryChars = JbbProperties.getInstance().getMinAddressCountryChars();
        int prop_MaxAddressCountryChars = JbbProperties.getInstance().getMaxAddressCountryChars();

        Topology topology = new Topology();

        RandomData randomData = new RandomData(seed);

        Mix<String> hqMix = CollectionUtils.getMix(
                new Random(seed),
                topology.getHQnames());

        List<Customer> result = new ArrayList<>();
        for (int c = 0; c < count; c++) {

            /**
             * Generating address
             */
            Address a = new Address(
                    randomData.createRandomAString(prop_MinAddressStreetChars, prop_MaxAddressStreetChars),
                    randomData.createRandomAString(prop_MinAddressCityChars, prop_MaxAddressCityChars),
                    randomData.createRandomAString(prop_MinAddressStateChars, prop_MaxAddressStateChars),
                    randomData.createRandomAString(prop_MinAddressZipChars, prop_MaxAddressZipChars),
                    randomData.createRandomAString(prop_MinAddressCountryChars, prop_MaxAddressCountryChars)
            );

            /**
             * Generating credit card number
             */
            long creditCardNumber;
            do {
                creditCardNumber = randomData.createCreditCardNumber();
            } while (!uniqueNumbers.add(creditCardNumber));

            CreditCard cc = new CreditCard(
                    creditCardNumber,
                    randomData.createRandomAString(prop_MinCreditCardCompanyChars, prop_MaxCreditCardCompanyChars),
                    randomData.createRandomAString(prop_MinCustomerNameChars, prop_MaxCustomerNameChars),
                    randomData.createRandomAString(prop_MinCustomerNameChars, prop_MaxCustomerNameChars),
                    a,
                    JbbProperties.getInstance().getInitialCreditCardLimit(),
                    randomData.randomInt(1, 9999)
                    );

            /**
             * Generating customer
             */

            int id;
            do {
                id = randomData.randomInt(0, Integer.MAX_VALUE);
            } while (!uniqueCustomerIds.add(id));

            Customer customer = new Customer(
                    id,
                    cc.getFirstName(),
                    cc.getLastName(),
                    cc.getAddress(),
                    cc,
                    hqMix.next()
            );

            result.add(customer);
        }

        return result;
    }

    private List<Customer> getCustomersForHQ(String hqName, CustomerType type) {
        float localCustomerShare = 1.0f;
        if (new Topology().getHQnames().size() > 1) {
            localCustomerShare -= JbbProperties.getInstance().getRemoteCustomerShare();
        }

        Random random = new Random(JbbProperties.getInstance().getRandomSeed());
        List<Customer> customerSubList = new ArrayList<>();
        for (Customer customer : generate()) {
            CustomerType t = random.nextDouble() < localCustomerShare ? CustomerType.LOCAL : CustomerType.REMOTE;
            if (hqName.equalsIgnoreCase(customer.getOwningHQ()) && type == t) {
                customerSubList.add(customer);
            }
        }
        return customerSubList;
    }

    public List<Long> getRemoteCustomerIDsForSM(String smName) {
        Topology topology = new Topology();
        Random shuffle = new Random(JbbProperties.getInstance().getRandomSeed());
        Map<String, Mix<String>> hqToRemoteSM = new HashMap<>();

        List<Customer> remoteCustomers = new LinkedList<>();
        for (String hqName : topology.getHQnames()) {
            remoteCustomers.addAll(getCustomersForHQ(hqName, CustomerType.REMOTE));

            List<String> smNames = new LinkedList<>(topology.getSMnames());
            smNames.removeAll(topology.getSMforHQ(hqName));
            hqToRemoteSM.put(hqName, CollectionUtils.getMix(shuffle, smNames));
        }

        List<Long> customerSubList = new ArrayList<>();
        for (Customer customer : remoteCustomers) {
            String sm = hqToRemoteSM.get(customer.getOwningHQ()).next();
            if (smName.equalsIgnoreCase(sm)) {
                customerSubList.add(customer.getId());
            }
        }
        return customerSubList;
    }

    public List<Long> getLocalCustomerIDsForSM(String smName) {
        Topology topology = new Topology();
        final String owningHqName = topology.getHQNameForSM(smName);

        Mix<String> mix = CollectionUtils.getMix(
                new Random(JbbProperties.getInstance().getRandomSeed()),
                topology.getSMforHQ(owningHqName));

        List<Long> customerSubList = new ArrayList<>();
        for (Customer customer : getCustomersForHQ(owningHqName, CustomerType.LOCAL)) {
            if (smName.equalsIgnoreCase(mix.next())) {
                customerSubList.add(customer.getId());
            }
        }
        return customerSubList;
    }

    private static class CachedData {
        public final List<Customer> data;
        public final int count;
        public final long seed;

        public CachedData(List<Customer> data, int count, long seed) {
            this.data = data;
            this.count = count;
            this.seed = seed;
        }
    }

}
