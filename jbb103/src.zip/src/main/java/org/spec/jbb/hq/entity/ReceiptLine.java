/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.entity;

import org.spec.jbb.sm.coupon.SpecificCoupon;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ReceiptLine implements Serializable {

    private static final long serialVersionUID = 1379943153196455214L;
    @XmlElement
    private final long barcode;

    @XmlElement
    private final int quantity;

    @XmlElement
    private final BigDecimal price;
    
    @XmlElement
    private final SpecificCoupon coupon;

    @SuppressWarnings("unused")
    private ReceiptLine() {
        // JAXB constructor
        this(0, 0, BigDecimal.ZERO);
    }

    public ReceiptLine(long barcode, int quantity, BigDecimal price) {
        this(barcode, quantity, price, null);
    }

    public ReceiptLine(long barcode, int quantity, BigDecimal price, SpecificCoupon coupon) {
        this.barcode = barcode;
        this.quantity = quantity;
        this.price = price;
        this.coupon = coupon;
    }

    public long getBarcode() {
        return barcode;
    }

    public int getQuantity() {
        return quantity;
    }

    public BigDecimal getPrice() {
        return price;
    }
    
    public SpecificCoupon getSpecificCoupon() {
        return coupon;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ReceiptLine that = (ReceiptLine) o;

        if (barcode != that.barcode) {
            return false;
        }
        if (quantity != that.quantity) {
            return false;
        }
        if (price != null ? !price.equals(that.price) : that.price != null) {
            return false;
        }
        if (coupon != null ? !coupon.equals(that.coupon) : that.coupon != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                barcode,
                quantity,
                price,
                coupon
        );
    }

    @Override
    public String toString() {
        return "#" + barcode +
                ", price=" + price +
                ", quantity=" + quantity;
    }
}
