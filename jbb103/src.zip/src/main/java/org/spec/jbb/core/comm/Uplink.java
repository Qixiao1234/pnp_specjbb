/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm;

import org.spec.jbb.core.Measurable;

import java.util.Collection;
import java.util.List;

public interface Uplink extends Measurable {
    /**
     * Send requests and wait for responses.
     * This method submits all requests in one batch.
     *
     * @param targetName target client to send the request to
     * @param tier to execute on
     * @param requests list of requests to send
     * @return list of responses
     */
    List<Response> sendRequest(String targetName, int tier, List<Request> requests);

    /**
     * Send all buffered messages
     * @param tier to execute on
     */
    void flushMessages(int tier);

    /**
     * Send messages.
     * This method submits all messages in one batch.
     *
     * @param targetName target client to send the request to
     * @param tier to execute on
     * @param messages list of messages to send
     */
    void sendMessage(String targetName, int tier, List<Message> messages);

    /**
     * Send request.
     * This method is shortcut for single requests.
     *
     * @param targetName target client to send the request to
     * @param request request to send
     * @param tier to execute on
     * @return response
     * @see Uplink#sendRequest(String, int, java.util.List)
     */
    Response sendRequest(String targetName, int tier, Request request);

    /**
     * Send message.
     * This method is shortcut for single messages.
     *
     * @param targetName target client to send the message to
     * @param tier to execute on
     * @param message message to send
     * @see Uplink#sendMessage(String, int, java.util.List)
     */
    void sendMessage(String targetName, int tier, Message message);

    /**
     * Prepare requests to send.
     * This method will issue the ID with which one can then call sendPrepared()
     *
     * @param target target to send to
     * @param requests requests to pre-marshal
     * @param tier to execute on
     * @return prepared batch id.
     */
    PreparedBatch prepareRequests(String target, int tier, List<Request> requests);

    /**
     * Prepared messages to send.
     * This method will issue the ID with which one can then call sendPrepared()
     *
     * @param target target to send to
     * @param tier to execute on
     * @param messages messages to pre-marshal
     * @return prepared batch id.
     */
    PreparedBatch prepareMessages(String target, int tier, List<Message> messages);

    /**
     * Prepare request to send.
     * This is shortcut method for bulk prepareRequest().
     *
     * @param target target to send to
     * @param tier to execute on
     * @param request requests to pre-marshal
     * @return prepared batch id.
     * @see Uplink#prepareRequests(String, int, java.util.List)
     */
    PreparedBatch prepareRequest(String target, int tier, Request request);

    /**
     * Prepare mesage to send.
     * This is shortcut method for bulk prepareMessage().
     *
     * @param target target to send to
     * @param tier to execute on
     * @param message message to pre-marshal
     * @return prepared batch id.
     * @see Uplink#prepareMessages(String, int, java.util.List)
     */
    PreparedBatch prepareMessage(String target, int tier, Message message);

    /**
     * Send prepared batch of requests.
     * @param batch batch to send
     * @return responses
     * @throws IllegalArgumentException if prepared batch is not found
     */
    List<Response> sendPreparedRequests(PreparedBatch batch);

    /**
     * Send prepared batch of messages.
     * @param batch batch to send
     * @throws IllegalArgumentException if prepared batch is not found
     */
    void sendPreparedMessages(PreparedBatch batch);

    /**
     * Send prepared request.
     * This method is shortcut for sendPreparedRequests()
     *
     * @param batch prepared batch id
     * @return response
     * @throws IllegalArgumentException if prepared batch is not found
     * @throws IllegalStateException if multiple responses had arrived
     * @see Uplink#sendPreparedRequests(org.spec.jbb.core.comm.PreparedBatch)
     */
    Response sendPreparedRequest(PreparedBatch batch);

    /**
     * Send prepared message.
     * This method is shortcut for sendPreparedMessages()
     *
     * @param batch prepared batch id
     * @throws IllegalArgumentException if prepared batch is not found
     * @see #sendPreparedMessages(org.spec.jbb.core.comm.PreparedBatch)
     */
    void sendPreparedMessage(PreparedBatch batch);

    /**
     * Ask interconnect to register another client on this IC.
     * This method does not change the uplink, client will be allocated with its own uplink.
     *
     * @param client client to connect
     */
    void register(ConnectionClient client);

    /**
     * Ask interconnect to register another client on this IC.
     * This method does not change the uplink, client will be allocated with its own uplink.
     *
     * @param client client to connect
     * @param drainer message drainer to use for new client
     */
    void register(ConnectionClient client, MessageDrainer drainer);

    void deregister(ConnectionClient client);

    void disable();

    Collection<LocationInfo> getLocationInfo(String name);

}
