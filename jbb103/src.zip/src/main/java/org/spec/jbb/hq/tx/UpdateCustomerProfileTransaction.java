/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.entity.CustomerProfile;
import org.spec.jbb.hq.tx.request.UpdateCustomerProfileRequest;

public class UpdateCustomerProfileTransaction extends AbstractTransaction {

    private final HQ hq;
    private final long customerID;
    private final CustomerProfile profile;

    public UpdateCustomerProfileTransaction(HQ hq, UpdateCustomerProfileRequest request, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        this.customerID = request.getCustomerId();
        this.profile = request.getCustomerProfile();
    }

    @Override
    public Response execute() throws TransactionException {
        hq.updateCustomerProfile(customerID, profile);
        return new OkResponse();
    }

    @Override
    public String toString() {
        return "UpdateCustomerProfileTx: customerId={" + customerID + "}, profile = {" + profile + "}";
    }

}
