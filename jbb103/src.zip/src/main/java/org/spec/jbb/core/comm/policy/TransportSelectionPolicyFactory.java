/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.policy;

import org.spec.jbb.util.JbbProperties;

public class TransportSelectionPolicyFactory {

    private TransportSelectionPolicyFactory() {
        // prevent instantiation
    }

    public static TransportSelectionPolicy getInstance() {
        return getInstance(JbbProperties.getInstance().getTransportSelectionPolicyType());
    }

    public static TransportSelectionPolicy getInstance(TransportSelectionPolicyType type) {
        switch (type) {
            case MAX_SECURITY:
                return new NPESafePolicy(new MaxSecurityPolicy());
            case MAX_THROUGHPUT:
                return new NPESafePolicy(new MaxThroughputPolicy());
            case BALANCED:
                return new NPESafePolicy(new CachedPolicy(new BalancedPolicy()));
            case MAX_XML:
                return new NPESafePolicy(new MaxXmlPolicy());
            case ALL_SERIAL:
                return new NPESafePolicy(new AllSerialPolicy());
            default:
                throw new IllegalArgumentException("Unknown transport selection policy");
        }
    }

}
