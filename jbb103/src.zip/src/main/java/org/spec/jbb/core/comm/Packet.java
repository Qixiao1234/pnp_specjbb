/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm;

import org.spec.jbb.core.comm.transport.Data;
import org.spec.jbb.core.comm.transport.TransportType;

import java.io.Serializable;

/**
 * Packet.
 *
 * Resembles elementary piece of information propagated over IC.
 *
 * Packet has two parts:
 *  - "header"
 *           "from": source client
 *             "to": destination client
 *      "transport": transport used for encoding
 *  - "data": payload encoded with specified transport
 *
 * Data is usually either the object reference for PLAIN transports, or byte[] for other transports.
 * Normally, only header is getting marshalled/unmarshalled, while data is getting copied as-is.
 */
public class Packet implements Serializable {

    /**
     * Default value for empty packet.
     */
    public static final Packet NO_DATA = new Packet("", "", TransportType.NULL, Data.empty(), false, 0);
    private static final long serialVersionUID = -2080330563475333774L;

    private final Header header;
    private final Data data;

    /**
     * Create new packet.
     *
     * @param from source client
     * @param to destination client
     * @param transport transport used
     * @param data data
     * @param shouldBeAnswered true, if requires answer packet
     * @param tier current tier
     */
    public Packet(String from, String to, TransportType transport, Data data, boolean shouldBeAnswered, int tier) {
        this.header = new Header(from, to, transport, shouldBeAnswered, tier);
        this.data = data;
    }

    /**
     * Create new packet.
     * @param header header
     * @param data data
     */
    public Packet(Header header, Data data) {
        this.header = header;
        this.data = data;
    }

    public Header getHeader() {
        return header;
    }

    public String getFrom() {
        return header.from;
    }

    public String getTo() {
        return header.to;
    }

    public TransportType getTransportType() {
        return header.transport;
    }

    public boolean shouldBeAnswered() {
        return header.shouldBeAnswered;
    }

    public Data getData() {
        return data;
    }

    public int getCurrentTier() {
        return header.tier;
    }

    public static class Header implements Serializable {
        private static final long serialVersionUID = 3986130988287777169L;
        public final String from;
        public final String to;
        public final TransportType transport;
        public final boolean shouldBeAnswered;
        public final int tier;

        public Header(String from, String to, TransportType transport, boolean shouldBeAnswered, int tier) {
            this.from = from;
            this.to = to;
            this.transport = transport;
            this.shouldBeAnswered = shouldBeAnswered;
            this.tier = tier;
        }
    }

}
