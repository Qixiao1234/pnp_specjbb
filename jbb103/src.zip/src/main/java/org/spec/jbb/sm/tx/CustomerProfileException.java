/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */
package org.spec.jbb.sm.tx;

import org.spec.jbb.core.tx.TransactionException;

public class CustomerProfileException extends TransactionException {

    private static final long serialVersionUID = -7718229870812523936L;

    public CustomerProfileException(String message) {
        super(message);
    }
}
