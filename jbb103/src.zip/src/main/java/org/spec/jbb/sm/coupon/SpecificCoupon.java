/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.coupon;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;
import java.util.Objects;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class SpecificCoupon extends AbstractCoupon {

    private static final long serialVersionUID = -5801346951945766460L;
    @XmlElement
    private final long barcode;
    
    private SpecificCoupon() {
        this(0, null, 0);
        // JAXB constructor
    }

    public SpecificCoupon(long barcode, Date expirationDate, int percent) {
        super(expirationDate, percent);
        this.barcode = barcode;
    }

    public long getBarcode() {
        return barcode;
    }

    @Override
    public boolean equals(Object o) {
        if (!super.equals(o)) {
            return false;
        }

        SpecificCoupon c = (SpecificCoupon) o;
        if (barcode != c.barcode) {
            return false;
        }
        
        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), barcode);
    }

    @Override
    public String toString() {
        return "{" + super.toString() + ", barcode=" + barcode + "}";
    }

}
