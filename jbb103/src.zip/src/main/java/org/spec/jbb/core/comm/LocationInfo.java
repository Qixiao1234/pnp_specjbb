/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@XmlRootElement
public class LocationInfo implements Serializable {

    private static final long serialVersionUID = 3496535054782244707L;

    @XmlElement
    private final boolean local;

    @XmlElement
    private final String location;

    @XmlElement
    private final Integer port;
    
    public static final LocationInfo LOCAL = new LocationInfo(true, null, null);

    private LocationInfo() {
        // JAXB
        this(false, null, null);
    }

    private LocationInfo(boolean local, String location, Integer port) {
        this.local = local;
        this.location = location;
        this.port = port;
    }

    public LocationInfo(String location, Integer port) {
        this(false, location, port);
    }

    public String getLocation() {
        return location;
    }

    public Integer getPort() {
        return port;
    }

    @Override
    public String toString() {
        if (local) {
            return "local in-Java link";
        } else {
            return location + ":" + port;
        }
    }

    public boolean isLocal() {
        return local;
    }
}
