/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

import java.io.Serializable;
import java.util.AbstractSet;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class HashMultiSet<E> extends AbstractMultiSet<E> implements Serializable {

    private static final long serialVersionUID = -3129664958201384569L;
    private final Map<E, Entry<E>> map = new HashMap<>();

    private int size;

    @Override
    protected void update(E e, int count) {
        if (count > 0) {
            Entry<E> entry = map.get(e);
            if (entry != null) {
                entry.addCount(count);
            } else {
                map.put(e, new Entry<>(e, count));
            }
            updateSize(count);
        } else if (count < 0) {
            Entry<E> entry = map.get(e);
            if (entry != null) {
                int oldCount = entry.getCount();
                long newCount = (long)oldCount + (long)count;
                if (newCount <= 0) {
                    map.remove(e);
                    updateSize(-oldCount);
                } else {
                    entry.setCount(CollectionUtils.integerSaturate(newCount));
                    updateSize(count);
                }
                assert size >= 0;
            } else {
                // no entry, and negative increment
            }
        }
    }

    private void updateSize(int increment) {
        size = CollectionUtils.integerSaturatedAdd(size, increment);
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return map.isEmpty();
    }

    @Override
    public boolean setCount(E e, int oldCount, int newCount) {
        if (newCount < 0) {
            throw new IllegalArgumentException("negative newCount " + newCount);
        }
        if (oldCount == newCount) {
            return false;
        }
        if (count(e) == oldCount) {
            setCount(e, newCount);
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int setCount(E e, int count) {
        if (count < 0) {
            throw new IllegalArgumentException("negative count " + count);
        }
        if (count == 0) {
            Entry<E> old = map.remove(e);
            if (old == null) {
                return 0;
            } else {
                int oldCount = old.getCount();
                updateSize(-oldCount);
                return oldCount;
            }
        } else {
            Entry<E> old = map.get(e);
            if (old == null) {
                map.put(e, new Entry<>(e, count));
                updateSize(count);
                return 0;
            } else {
                int oldCount = old.getCount();
                old.setCount(count);
                updateSize(-oldCount + count);
                return oldCount;
            }
        }
    }

    @Override
    public int count(Object element) {
        Entry<E> entry = map.get(element);
        return entry == null ? 0 : entry.getCount();
    }

    @Override
    public Set<E> elementSet() {
        Set<E> set = elementSet;
        return (set != null) ?
                set :
                (elementSet = Collections.unmodifiableSet(map.keySet()));

    }

    @Override
    public Set<MultiSet.Entry<E>> entrySet() {
        if (entrySet == null) {
            entrySet = new EntrySet();
        }
        return entrySet;
    }

    @Override
    public void clear() {
        map.clear();
        size = 0;
    }

    @Override
    public String toString() {
        return "HashMultiSet: size = " + size() + ", keys = " + map.size();
    }

    private class EntrySet extends AbstractSet<MultiSet.Entry<E>> {
        @Override
        public Iterator<MultiSet.Entry<E>> iterator() {
            final Iterator<Entry<E>> iterator = map.values().iterator();
            return new Iterator<MultiSet.Entry<E>>() {

                @Override
                public boolean hasNext() {
                    return iterator.hasNext();
                }

                @Override
                public MultiSet.Entry<E> next() {
                    return iterator.next();
                }

                @Override
                public void remove() {
                    throw new UnsupportedOperationException();
                }
            };
        }

        @Override
        public int size() {
            return map.size();
        }
    }

    private static class Entry<E> implements MultiSet.Entry<E>, Serializable {

        private static final long serialVersionUID = -434073682009338410L;
        private final E element;
        private int count;

        public Entry(E element) {
            this.element = element;
        }

        public Entry(E e, int count) {
            this(e);
            this.count = count;
        }

        @Override
        public E getElement() {
            return element;
        }

        @Override
        public int getCount() {
            return count;
        }

        void addCount(int increment) {
            count = CollectionUtils.integerSaturatedAdd(count, increment);
        }

        void setCount(int newCount) {
            count = newCount;
        }
    }

}

