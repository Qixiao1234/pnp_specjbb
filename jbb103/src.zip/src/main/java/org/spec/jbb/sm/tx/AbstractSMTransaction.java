/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx;

import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.purchase.PurchaseAgent;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.hq.entity.Product;
import org.spec.jbb.sm.ProductResolveFailedException;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.TooBigReplenishQuantityException;
import org.spec.jbb.sm.advertisement.Advertisements;
import org.spec.jbb.sm.inventory.Inventory;
import org.spec.jbb.sm.storage.SupermarketStorage;
import org.spec.jbb.sp.tx.request.SupplyProductMessage;

public abstract class AbstractSMTransaction extends AbstractTransaction {
    protected final SM sm;
    protected final SupermarketStorage storage;
    protected final Inventory inventory;
    protected final Advertisements advertisements;
    protected final PurchaseAgent purchaseAgent;

    protected final String owningHQ;
    
    protected final Probe couponProbe;
    protected final Probe replenishProbe;

    public AbstractSMTransaction(SM sm, TransactionContext ctx) {
        super(ctx);
        this.sm = sm;
        this.storage = sm.getStorage();
        this.advertisements = storage.getAdvertisements();
        this.purchaseAgent = sm.getPurchaseAgent();
        this.owningHQ = sm.getOwningHQname();
        this.inventory = storage.getInventory();
        this.couponProbe = sm.getCouponProbe();
        this.replenishProbe = sm.getReplenishProbe();
    }

    public int reserveProduct(long barcode, int quantity) throws TransactionException {
        int reserved = inventory.reserve(barcode, quantity);
        if(reserved < quantity) {
            Product product = resolveProduct(barcode);
            orderReplenish(product);
        }
        return reserved;
    }

    public void unreserveProduct(long barcode, int quantity) throws TransactionException {
        int unreserved = inventory.unreserve(barcode, quantity);
        if (unreserved != quantity) {
            throw new IncorrectUnreserveException("Can't unreserve inventory, requested = " + quantity + ", got = " + unreserved);
        }
    }

    public int moveOut(long barcode, int quantity) throws TransactionException {
        int movedOut = inventory.moveOut(barcode, quantity);
        if (movedOut != quantity) {
            throw new MoveOutUnreservedItemsException("Can't move out from inventory, requested = " + quantity + ", got = " + movedOut);
        }

        Product product = resolveProduct(barcode);
        if (inventory.getQuantity(barcode) < product.getProductQuantity() * sm.getOrderQuantityThreshold()) {
            orderReplenish(product);
        }
        return movedOut;
    }

    public void moveIn(long barcode, int quantity) {
        inventory.moveIn(barcode, quantity);
    }

    private void orderReplenish(Product product) {
        long barcode = product.getBarcode();
        int orderQuantity = product.getOrderQuantity();
        int replenishInFlightQuantity = inventory.getReplenishInFlightQuantity(barcode);
        if (inventory.getQuantity(barcode) + replenishInFlightQuantity < product.getProductQuantity()) {
            if (replenishInFlightQuantity <= inventory.updateReplenishInFlightQuantity(barcode, orderQuantity)) {
            String spName = sm.isReplenishPercentEnabled() ? sm.getSuppliersForReplenish().next().next() : product.getSupplierName();
                ctx.sendMessage(spName, new SupplyProductMessage(sm.getName(), barcode, orderQuantity));
            replenishProbe.inc("started");
            } else {
                // Someone order before us, don't send message and reduce the inflight again
                inventory.updateReplenishInFlightQuantity(barcode, -orderQuantity);
            }
        }
    }

    public void doReplenish(long barcode, int orderQuantity) throws TransactionException {
        moveIn(barcode, orderQuantity);
        replenishProbe.inc("completed");
        if (inventory.getReplenishInFlightQuantity(barcode) < orderQuantity) {
            throw new TooBigReplenishQuantityException("Too many replenishes in flight already");
        }
        inventory.updateReplenishInFlightQuantity(barcode, -orderQuantity);
    }

    public Product resolveProduct(Long barcode) throws ProductResolveFailedException {
        return storage.getProductCache().get(ctx, barcode);
    }

}
