/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.message;

import org.spec.jbb.core.comm.AbstractMessage;
import org.spec.jbb.core.comm.Message;

import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import java.util.Objects;

@XmlRootElement
public class CompositeMessage extends AbstractMessage {
    private static final long serialVersionUID = 7137679809881802368L;

    @XmlElementWrapper
    private final List<Message> messages;

    private CompositeMessage() {
        // JAXB
        this(null);
    }

    public CompositeMessage(List<Message> messages) {
        this.messages = messages;
    }

    public List<Message> getMessages() {
        return messages;
    }

    @Override
    public boolean isDurable() {
        for (Message message : messages) {
            if (message.isDurable()) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CompositeMessage that = (CompositeMessage) o;

        if (messages != null ? !messages.equals(that.messages) : that.messages != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(messages);
    }

}
