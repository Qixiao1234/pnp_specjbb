/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.executor;

import org.spec.jbb.core.tx.response.OkResponse;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AcceptedResponse extends OkResponse {
    private static final long serialVersionUID = -6948585039922994287L;

    @Override
    public String toString() {
        return "ACCEPTED";
    }
}
