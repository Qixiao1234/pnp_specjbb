/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.sequencer;

public class SequencerFactory {

    private SequencerFactory() {
        // prevent instantiation
    }

    public static Sequencer<Long> getDefaultSequencer() {
        return new BulkRandomizedSequencer(1000);
    }

    public static Sequencer<Long> getNonSkippingSequencer() {
        return new AtomicGrowingSequencer();
    }


}
