/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

import org.spec.jbb.core.Conventions;
import org.spec.jbb.core.ExecutionHandler;
import org.spec.jbb.core.comm.Incoming;
import org.spec.jbb.core.comm.Response;
import org.spec.jbb.util.JbbProperties;

import java.util.List;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;


public class StaticForkJoinThreadPool extends AbstractPool {

    final ForkJoinPool pool;
    final int threshold;

    AtomicBoolean shutdown;

    public StaticForkJoinThreadPool(final String name) {
        super(name);
        pool = PoolHolder.getPool();
        shutdown = new AtomicBoolean();
        threshold = JbbProperties.getInstance().getForkJoinThresholdFor(Conventions.getPoolID(name));
    }

    private Future<List<Response>> submitBatch(int tier, ExecutionHandler handler, List<? extends Incoming> batch) {
        probe.inc("batches.accepted");
        int size = batch.size();
        return pool.submit(new ForkJoinBatchTask(tier, handler, batch, new Response[size], this, null, 0, size, threshold));
    }

    @Override
    public Future<List<Response>> enqueueBatch(int tier, ExecutionHandler handler, List<? extends Incoming> batch) {
        probe.inc("batches.received");
        return submitBatch(tier, handler, batch);
    }

    @Override
    public Future<List<Response>> forceBatch(int tier, ExecutionHandler handler, List<? extends Incoming> batch) throws InterruptedException {
        probe.inc("batches.received");
        return submitBatch(tier, handler, batch);
    }

    @Override
    public void start() {
        // do nothing
    }

    @Override
    public void shutdown() {
        // need to shutdown static instance anyway:
        // it's possible for Controller to decide to start from scratch.
        if (shutdown.compareAndSet(false, true)) {
            PoolHolder.shutdown();
        }
    }

    @Override
    public void assistExecute(Runnable runnable) {
        pool.submit(runnable);
    }

    @Override
    public void sample() {
        super.sample();
        probe.sample("pool.active", pool.getActiveThreadCount());
        probe.sample("pool.parallelism", pool.getParallelism());
        probe.sample("pool.size", pool.getPoolSize());
        probe.sample("pool.queueSize", pool.getQueuedTaskCount());
        probe.sample("pool.running", pool.getRunningThreadCount());
        probe.sample("pool.stealed", pool.getStealCount());
    }

    private static class PoolHolder {

        public static ForkJoinPool pool;

        public static int count;

        public static ForkJoinPool getPool() {
            synchronized (PoolHolder.class) {
                if (count == 0) {
                    pool = new ForkJoinPool(JbbProperties.getInstance().getForkJoinWorkersFor("static"));
                }
                count++;
            }
            return pool;
        }

        public static void shutdown() {
            synchronized (PoolHolder.class) {
                count--;
                if (count == 0) {
                    ThreadUtils.terminatePool(pool);
                }
            }
        }

    }

}
