/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

import java.util.List;

public class SumSquareAggregator implements Aggregator {

    @Override
    public Double aggregate(List<Double> values) {

        Double result = 0D;
        int count = 0;
        for(Double value : values) {
            if (!Double.isNaN(value)) {
                result += Math.pow(value, 2);
                count++;
            }
        }

        if (count != 0) {
            return Math.pow(result, 1.0 / count);
        } else {
            return Double.NaN;
        }
    }
}
