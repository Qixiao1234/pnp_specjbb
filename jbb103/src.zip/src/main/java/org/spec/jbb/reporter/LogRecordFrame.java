/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

import java.io.Serializable;
import org.spec.jbb.infra.TransferLogsAgent.TransferFileType;

public class LogRecordFrame implements Frame {

    public static final long serialVersionUID = 1L;

    private final LogDataChunk data;

    public LogRecordFrame(String agent, byte[] data, TransferFileType type) {
        this.data = new LogDataChunk(agent, data, type);
    }

    public LogDataChunk getData() {
        return data;
    }

    @Override
    public String toString() {
        return data.getType().name() + " record from " + data.getAgent() + " of size " + data.getData().length;
    }

    public static class LogDataChunk implements Serializable {
        public static final long serialVersionUID = -6520825434941210118L;

        private final String agent;
        private final byte[] data;
        private final TransferFileType type;

        public LogDataChunk(String agent, byte[] data, TransferFileType type) {
            this.agent = agent;
            this.data = data;
            this.type = type;
        }

        public String getAgent() {
            return agent;
        }

        public byte[] getData() {
            return data;
        }

        public TransferFileType getType() {
            return type;
        }
    }

    @Override
    public Frame cleanForSubmission(CleanForSubmissionContext ctx) {
        return null;
    }
}
