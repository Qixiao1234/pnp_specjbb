/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.request.ResolveCustomerRequest;
import org.spec.jbb.hq.tx.response.CustomerResolveResponse;

public class ResolveCustomerTransaction extends AbstractTransaction {

    private final HQ hq;
    private final long customerId;

    public ResolveCustomerTransaction(HQ hq, ResolveCustomerRequest req, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        this.customerId = req.getCustomerId();
    }

    @Override
    public Response execute() {
        return new CustomerResolveResponse(hq.getOwner(customerId));
    }

    @Override
    public String toString() {
        return "ResolveCustomerTx: customerId={" + customerId + "}";
    }

}
