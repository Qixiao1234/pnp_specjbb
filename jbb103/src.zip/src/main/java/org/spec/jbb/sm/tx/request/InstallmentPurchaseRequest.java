/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.request;

import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.tx.InstallmentPurchaseTransaction;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class InstallmentPurchaseRequest extends AbstractPurchaseRequest {
    private static final long serialVersionUID = -5862790724695978988L;

    protected InstallmentPurchaseRequest() {
        super();
    }

    public InstallmentPurchaseRequest(boolean isSaturate) {
        super(isSaturate);
    }

    @Override
    public Transaction getTransaction(SM sm, TransactionContext ctx) {
        return new InstallmentPurchaseTransaction(sm, this, ctx);
    }

    @Override
    public String toString() {
        return "Installment Purchase, " + super.toString();
    }
}
