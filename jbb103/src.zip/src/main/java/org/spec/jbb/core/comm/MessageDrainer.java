/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm;

/**
 * Drainer defines the policy which should be used to drain the messages.
 * MessageDrainer can delegate processing to some thread pool.
 */
public interface MessageDrainer {

    /**
     * Drain the messages
     */
    void drain(Uplink link);

}
