/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity.grizzlynio;

import org.glassfish.grizzly.filterchain.FilterChain;
import org.glassfish.grizzly.nio.transport.TCPNIOServerConnection;
import org.glassfish.grizzly.nio.transport.TCPNIOTransport;
import org.glassfish.grizzly.nio.transport.TCPNIOTransportBuilder;
import org.glassfish.grizzly.threadpool.AbstractThreadPool;
import org.glassfish.grizzly.threadpool.GrizzlyExecutorService;
import org.glassfish.grizzly.threadpool.ThreadPoolConfig;
import org.glassfish.grizzly.threadpool.ThreadPoolProbe;
import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.counters.Counter;
import org.spec.jbb.core.counters.CounterFactory;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.probe.ProbeFactory;
import org.spec.jbb.util.JbbProperties;

import java.io.IOException;

public class GrizzlyTransport implements Measurable {

    private final Counter threadCounter = CounterFactory.getCounter();
    private final Counter taskCounter = CounterFactory.getCounter();
    private final TCPNIOTransport transport;
    private volatile Probe probe;

    public GrizzlyTransport() {
        probe = ProbeFactory.getDefaultProbe();

        final TCPNIOTransportBuilder builder = TCPNIOTransportBuilder.newInstance();

        transport = builder.build();

        ThreadPoolConfig threadPoolConfig = builder.getIOStrategy().createDefaultWorkerPoolConfig(transport);
        final int minThreads = JbbProperties.getInstance().getConnectivityWorkerMinThreads();
        final int maxThreads = JbbProperties.getInstance().getConnectivityWorkerMaxThreads();
        threadPoolConfig.setCorePoolSize(minThreads).setMaxPoolSize(maxThreads);

        GrizzlyExecutorService executorService = GrizzlyExecutorService.createInstance(threadPoolConfig);
        transport.setWorkerThreadPool(executorService);

        final int selectorRunnersCount = JbbProperties.getInstance().getConnectivitySelectorRunnersCount();
        if (selectorRunnersCount != 0) { 
            transport.setSelectorRunnersCount(selectorRunnersCount);
        }

        executorService.getMonitoringConfig().addProbes(new ThreadPoolProbe() {
            @Override
            public void onThreadPoolStartEvent(AbstractThreadPool threadPool) {
                // do nothing
            }

            @Override
            public void onThreadPoolStopEvent(AbstractThreadPool threadPool) {
                // do nothing
            }

            @Override
            public void onThreadAllocateEvent(AbstractThreadPool threadPool, Thread thread) {
                threadCounter.inc(+1);
            }

            @Override
            public void onThreadReleaseEvent(AbstractThreadPool threadPool, Thread thread) {
                threadCounter.inc(-1);
            }

            @Override
            public void onMaxNumberOfThreadsEvent(AbstractThreadPool threadPool, int maxNumberOfThreads) {
                // do nothing
            }

            @Override
            public void onTaskQueueEvent(AbstractThreadPool threadPool, Runnable task) {
                // do nothing
            }

            @Override
            public void onTaskDequeueEvent(AbstractThreadPool threadPool, Runnable task) {
                taskCounter.inc(+1);
            }

            @Override
            public void onTaskCompleteEvent(AbstractThreadPool threadPool, Runnable task) {
                taskCounter.inc(-1);
            }

            @Override
            public void onTaskQueueOverflowEvent(AbstractThreadPool threadPool) {
                // do nothing
            }
        });
    }

    @Override
    public void instrument(Probe probe) {
        this.probe = probe;
    }

    @Override
    public void sample() {
        probe.sample("alive", threadCounter.get());
        probe.sample("busy", taskCounter.get());
        probe.sample("max", JbbProperties.getInstance().getConnectivityWorkerMaxThreads());
    }

    public void start() throws IOException {
        transport.start();
    }

    public TCPNIOTransport getTransport() {
        return transport;
    }

    public void shutdown() {
        try {
            transport.unbindAll();
        } finally {
            try {
                transport.stop();
            } catch (IOException e) {
                // swallow
            }
        }
    }

    public TCPNIOServerConnection bind(int port) throws IOException {
        return transport.bind(port);
    }

    public void setProcessor(FilterChain build) {
        transport.setProcessor(build);
    }
}
