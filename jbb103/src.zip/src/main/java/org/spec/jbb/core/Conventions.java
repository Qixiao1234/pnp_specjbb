/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;

import org.spec.jbb.core.comm.SourceType;
import org.spec.jbb.infra.AgentType;
import org.spec.jbb.Launcher.RunCategory;

public class Conventions {

    public static String getGroupIdPrefix() {
        return "GroupID";
    }
    
    public static String getJVMIdPrefix() {
        return "JVMID";
    }
    
    public static String getTxInjectorName(String groupID, String jvmID) {
        return groupID + getDataSeparator() + getTxInjectorLabel() + getDataSeparator() + jvmID;
    }

    public static String getBackendName(String groupID, String jvmID) {
        return groupID + getDataSeparator() + getBackendLabel() + getDataSeparator() + jvmID;
    }

    public static String getHQname(String beID) {
        return beID + getDataSeparator() + getHQLabel();
    }

    public static String getSMName(String beID, int no) {
        return beID + getDataSeparator() + getSMLabel() + no;
    }

    public static String getSPName(String beID, int no) {
        return beID + getDataSeparator() + getSPLabel() + no;
    }

    public static String getDataSeparator() {
        return ".";
    }
    
    public static String getGroupID(String agentName) {
        return agentName.substring(0, agentName.indexOf(getDataSeparator()));
    }
    
    public static String getJVMID(String agentName) {
        return agentName.substring(agentName.lastIndexOf(getDataSeparator()) + 1);
    }
    
    public static String getAgentName(String groupID, String jvmID, AgentType type) {
        switch (type) {
        case TXINJECTOR:
            return getTxInjectorName(groupID, jvmID);
        case BACKEND:
            return getBackendName(groupID, jvmID);
        default:
            throw new IllegalArgumentException("Unknown agent type: " + type);
        }
    }
    
    public static boolean isTxInjectorComponent(String componentName) {
        return getTxInjectorLabel().equals(getAgentLabel(componentName));
    }
    
    public static boolean isBackendComponent(String componentName) {
        return getBackendLabel().equals(getAgentLabel(componentName));
    }
    
    public static boolean isController(String componentName) {
        return getControllerLabel().equals(componentName);
    }
    
    public static boolean isSM(String componentName) {
        return componentName.contains(getDataSeparator() + getSMLabel());
    }
    
    public static boolean isSP(String componentName) {
        return componentName.contains(getDataSeparator() + getSPLabel());
    }
    
    public static boolean isHQ(String componentName) {
        return !isHQOF(componentName) && componentName.contains(getDataSeparator() + getHQLabel());
    }
     
    public static boolean isHQOF(String componentName) {
        return componentName.contains(getDataSeparator() + getHQOFLabel());
    }
     
    private static String getTxInjectorLabel() {
        return "TxInjector";
    }
    
    private static String getBackendLabel() {
        return "Backend";
    }
    
    public static String getControllerLabel() {
        return "Controller";
    }
    
    public static String getSMLabel() {
        return "SM";
    }
    
    public static String getSPLabel() {
        return "SP";
    }
    
    public static String getHQLabel() {
        return "HQ";
    }
    
    public static String getHQOFLabel() {
        return "HQ" + getDataSeparator() + "OF";
    }
    
    private static String getAgentLabel(String componentName) {
        String[] result = componentName.split(Pattern.quote(getDataSeparator()));
        if(result.length < 3) {
            return componentName;
        } else {
            return result[1];
        }
    }

    public static SourceType getSourceType(String name) {
        if(Conventions.isTxInjectorComponent(name)) {
            return SourceType.TXINJECTOR;
        } else if (Conventions.isBackendComponent(name)) {
            return SourceType.BACKEND;
        } else if (Conventions.isController(name)) {
            return SourceType.CONTROLLER;
        } else if (Conventions.isHQ(name)) {
            return SourceType.HQ;
        } else if (Conventions.isSM(name)) {
            return SourceType.SM;
        } else if (Conventions.isSP(name)) {
            return SourceType.SP;
        } else {
            return SourceType.UNKNOWN;
        }
    }

    public static String getPoolName(String agentName, String poolID) {
        return agentName + "{" + poolID + "}";
    }

    public static String getPoolID(String poolName) {
        if (poolName.contains("{") && poolName.contains("}")) {
            return poolName.substring(poolName.indexOf("{") + 1, poolName.indexOf("}"));
        } else {
            return poolName;
        }
    }

    /**
     * Default tier.
     * This supposed to be special value to hit uninitialized tier.
     * Each request should have explicitly initialized tier.
     */
    public static final int TIER_DEFAULT = Integer.MIN_VALUE;

    /**
     * Tier for infra (Controller/Agent) requests
     */
    public static final int TIER_INFRA = 0;

    /**
     * Tier for Driver requests
     */
    public static final int TIER_DRIVER = 0;

    /**
     * First tier for backend requests
     */
    public static final int TIER_BACKEND_FIRST = 1;

    public static String getTierName(int tier) {
        return "Tier" + tier;
    }

    public static String getValidationAgentName(String name) {
        return name + "-validation";
    }
    
    public static String getTransferLogsAgentName(String name) {
        return name + "-TransferLog";
    }
    
    public static String getRunDataFileNameTemplate(RunCategory runCategory) {
        return "specjbb2015-" + runCategory.getShortName() + "-" 
                + new SimpleDateFormat("yyyyMMdd").format(new Date()) + "-%1$05d.data.gz";
    }

    public static String getTimeServerName() {
        return "TimeServer";
    }
}
