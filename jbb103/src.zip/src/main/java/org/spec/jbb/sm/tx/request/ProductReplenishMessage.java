/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.request;

import org.spec.jbb.core.comm.AbstractMessage;
import org.spec.jbb.core.comm.transport.TransportType;
import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.tx.InventoryReplenishOperation;
import org.spec.jbb.sp.Invoice;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
public class ProductReplenishMessage extends AbstractMessage {

    private static final long serialVersionUID = 7230531890902719113L;
    @XmlElement
    private final Invoice invoice;

    private ProductReplenishMessage() {
        // JAXB
        this(null);
    }

    public ProductReplenishMessage(Invoice invoice) {
        this.invoice = invoice;
    }

    @Override
    public boolean isDurable() {
        return true;
    }

    public Invoice getInvoice() {
        return invoice;
    }

    @Override
    public String toString() {
        return "Replenish product invoice " + invoice;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ProductReplenishMessage that = (ProductReplenishMessage) o;

        if (invoice != null ? !invoice.equals(that.invoice) : that.invoice != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(invoice);
    }

    @Override
    public Transaction getTransaction(SM sm, TransactionContext ctx) {
        return new InventoryReplenishOperation(sm, this, ctx);
    }

    @Override
    public TransportType getTransportHint() {
        return TransportType.XML;
    }

}
