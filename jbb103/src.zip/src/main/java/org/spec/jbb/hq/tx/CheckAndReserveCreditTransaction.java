/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.response.ErrorResponse;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.request.CheckAndReserveCreditRequest;

import java.math.BigDecimal;

public class CheckAndReserveCreditTransaction extends AbstractTransaction {

    private final HQ hq;
    private final long customerId;
    private final BigDecimal amount;

    public CheckAndReserveCreditTransaction(HQ hq, CheckAndReserveCreditRequest req, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        this.customerId = req.getCustomerId();
        this.amount = req.getAmount();
    }

    @Override
    public Response execute() {
        boolean hasCredit = hq.reserveCredit(customerId, amount);

        if (hasCredit) {
            return new OkResponse();
        } else {
            return new ErrorResponse("Not enough credit");
        }
    }

    @Override
    public String toString() {
        return "CheckAndReserveCreditTx: customerId={" + customerId + "}, amount={" + amount + "}";
    }

}
