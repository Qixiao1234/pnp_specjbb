/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport;

import java.io.InputStream;

public class ReferenceData extends Data {
    private static final long serialVersionUID = -9174868754764984780L;
    private final Object ref;

    public ReferenceData(Object ref) {
        this.ref = ref;
    }

    @Override
    public byte[] getArray() {
        throw new IllegalStateException("Tried to read array from reference");
    }

    @Override
    public InputStream getStream() {
        throw new IllegalStateException("Tried to read stream from reference");
    }

    @Override
    public Object getReference() {
        return ref;
    }
}
