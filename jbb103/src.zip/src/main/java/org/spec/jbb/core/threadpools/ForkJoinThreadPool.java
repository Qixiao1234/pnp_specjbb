/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

import org.spec.jbb.core.Conventions;
import org.spec.jbb.core.ExecutionHandler;
import org.spec.jbb.core.comm.Incoming;
import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.sequencer.Sequencer;
import org.spec.jbb.core.sequencer.SequencerFactory;
import org.spec.jbb.util.JbbProperties;

import java.util.List;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinWorkerThread;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;

public class ForkJoinThreadPool extends AbstractPool {

    private ForkJoinPool pool;
    private SemaphoreAdapter semaphore;

    private int threshold;

    public ForkJoinThreadPool(final String name) {
        super(name);
        
        String poolID = Conventions.getPoolID(name);
        JbbProperties properties = JbbProperties.getInstance();

        pool = new ForkJoinPool(properties.getForkJoinWorkersFor(poolID), new ForkJoinPool.ForkJoinWorkerThreadFactory() {
            private Sequencer<Long> id = SequencerFactory.getNonSkippingSequencer();
            @Override
            public ForkJoinWorkerThread newThread(ForkJoinPool pool) {
                ForkJoinWorkerThread t = ForkJoinPool.defaultForkJoinWorkerThreadFactory.newThread(pool);
                t.setName(name + "." + id.next());
                return t;
            }
        }, null, false);

        if (JbbProperties.getInstance().isForkJoinGuarded(poolID)) {
            semaphore = new RealSemaphoreAdapter(properties.getForkJoinQueueSizeFor(poolID), properties.isFair(poolID));
        } else {
            semaphore = new NoSemaphoreAdapter();
        }
        threshold = properties.getForkJoinThresholdFor(poolID);
    }

    private Future<List<Response>> submitBatch(int tier, ExecutionHandler handler, List<? extends Incoming> batch) {
        probe.inc("batches.accepted");
        int size = batch.size();
        return pool.submit(new ForkJoinBatchTask(tier, handler, batch, new Response[size], this, null, 0, size, threshold));
    }     

    @Override
    public Future<List<Response>> enqueueBatch(int tier, ExecutionHandler handler, List<? extends Incoming> batch) {
        probe.inc("batches.received");
        boolean success = semaphore.tryAcquire();
        if (success) {
            return submitBatch(tier, handler, batch);
        } else {
            probe.inc("batches.rejected");
            throw new RejectedExecutionException();
        }
    }

    @Override
    public Future<List<Response>> forceBatch(int tier, ExecutionHandler handler, List<? extends Incoming> batch) throws InterruptedException {
        probe.inc("batches.received");
        semaphore.acquire();
        return submitBatch(tier, handler, batch);
    }

    @Override
    public void start() {
        // do nothing
    }

    @Override
    public void shutdown() {
        ThreadUtils.terminatePool(pool);
    }

    @Override
    public void assistExecute(Runnable runnable) {
        pool.submit(runnable);
    }

    @Override
    public void sample() {
        super.sample();
        probe.sample("pool.active", pool.getActiveThreadCount());
        probe.sample("pool.parallelism", pool.getParallelism());
        probe.sample("pool.size", pool.getPoolSize());
        probe.sample("pool.queueSize", pool.getQueuedTaskCount());
        probe.sample("pool.running", pool.getRunningThreadCount());
        probe.sample("pool.stealed", pool.getStealCount());
        probe.sample("queue.size", semaphore.availablePermits());
        probe.sample("queue.waiters", semaphore.getQueueLength());
    }


}
