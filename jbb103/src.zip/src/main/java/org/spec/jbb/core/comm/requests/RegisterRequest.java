/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.requests;

import org.spec.jbb.core.comm.AbstractRequest;
import org.spec.jbb.core.comm.LocationInfo;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class RegisterRequest extends AbstractRequest {

    private static final long serialVersionUID = -7985783925146854599L;
    @XmlElement
    private final String name;

    @XmlElement
    private final LocationInfo info;

    private RegisterRequest() {
        // JAXB constructor
        this(null, null);
    }

    public RegisterRequest(String name, LocationInfo info) {
        super();
        this.name = name;
        this.info = info;
    }

    public LocationInfo getInfo() {
        return info;
    }

    public String getHost() {
        return info.getLocation();
    }

    public String getName() {
        return name;
    }

    public int getPort() {
        return info.getPort();
    }

    @Override
    public String toString() {
        return "Register " + name + " @ " + info;
    }

}
