/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

import java.io.Serializable;
import java.util.AbstractSet;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicInteger;

public class ConcurrentHashMultiSet<E> extends AbstractMultiSet<E> implements Serializable {

    private static final long serialVersionUID = 7430770828618470422L;
    private final ConcurrentMap<E, Entry<E>> map;

    public ConcurrentHashMultiSet() {
        this.map = new ConcurrentHashMap<>();
    }

    @Override
    public void clear() {
        map.clear();
    }

    @Override
    protected void update(E e, int count) {
        if (count > 0) {
            respin: while (true) {
                Entry<E> oldEntry = map.get(e);
                if (oldEntry == null) {
                    oldEntry = map.putIfAbsent(e, new Entry<>(e, count));
                    if (oldEntry == null) {
                        return; // success, new entry with updated count is in map now
                    }
                }

                while (true) {
                    int oldCount = oldEntry.getCount();
                    if (oldCount == 0) {
                        if (map.replace(e, oldEntry, new Entry<>(e, count))) {
                            return; // success, new entry with updated count is in map
                        }
                        continue respin; // lost the race, need to recheck value
                    } else {
                        int newCount = CollectionUtils.integerSaturatedAdd(oldCount, count);
                        if (oldEntry.compareAndSet(oldCount, newCount)) {
                            return; // successfully updated the value
                        }
                    }
                }
            }
        } else if (count < 0) {
            Entry<E> oldEntry = map.get(e);
            if (oldEntry != null) {
                while (true) {
                    int oldCount = oldEntry.getCount();
                    if (oldCount == 0) {
                        return; // someone else is removing the entry now
                    } else {
                        long newCount = (long) oldCount + (long) count;
                        if (newCount <= 0) {
                            if (oldEntry.compareAndSet(oldCount, 0)) {
                                map.remove(e, oldEntry);
                                return; // removed the entry
                            }
                        } else {
                            if (oldEntry.compareAndSet(oldCount, CollectionUtils.integerSaturate(newCount))) {
                                return; // successfully updated the value
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Sets the number of occurrences of element to newCount,
     * but only if the count is currently oldCount.
     * @return - true if success.
     */
    @Override
    public boolean setCount(E e, int oldCount, int newCount) {
        if (newCount < 0) {
            throw new IllegalArgumentException("negative count " + newCount);
        }

        // do nothing: entry is not changed
        if (oldCount == newCount || oldCount < 0) {
            return false;
        }

        // If there's no entry, then the only viable oldCount is zero, then try to add new entry.
        // Note this block will not add "zero" entry, if (oldCount == 0) then (newCount != 0)
        Entry<E> oldEntry = map.get(e);
        if (oldEntry == null) {
            return (oldCount == 0) && (map.putIfAbsent(e, new Entry<>(e, newCount)) == null);
        }

        // optimistically check the value
        if (oldCount != oldEntry.getCount()) {
            return false;
        }

        if (newCount == 0) {
            if (oldEntry.compareAndSet(oldCount, 0)) {
                map.remove(e, oldEntry);
                return true; // success, won the race for removal
            }
            return false; // failure, someone else had updated the value
        } else if (oldCount == 0) {
            return false; // failure, someone is removing the entry
        }

        // finally, try to update
        return oldEntry.compareAndSet(oldCount, newCount);
    }

    @Override
    public int setCount(E e, int count) {
        if (count < 0) {
            throw new IllegalArgumentException("negative count " + count);
        }

        if (count == 0) {
            Entry<E> oldEntry = map.get(e);
            if (oldEntry == null) {
                return 0; // success: no entry, nothing to remove
            }
            while (true) {
                int oldCount = oldEntry.getCount();
                if (oldCount == 0) {
                    return oldCount; // success: someone else is removing the entry now
                }
                if (oldEntry.compareAndSet(oldCount, 0)) {
                    map.remove(e, oldEntry);
                    return oldCount; // success: final value is zero, removed the entry
                }
            }
        } else {
            respin: while (true) {
                Entry<E> oldEntry = map.get(e);
                if (oldEntry == null) {
                    oldEntry = map.putIfAbsent(e, new Entry<>(e, count));
                    if (oldEntry == null) {
                        return 0; // success: added count to newly created entry
                    }
                }
                while (true) {
                    int oldCount = oldEntry.getCount();
                    if (oldCount == 0) {
                        if (map.replace(e, oldEntry, new Entry<>(e, count))) {
                            return oldCount; // replaced zero entry with new count
                        }
                        continue respin; // lost the race, re-read entry
                    } else {
                        if (oldEntry.compareAndSet(oldCount, count)) {
                            return oldCount; // successfully set to new value
                        }
                    }
                }
            }
        }
    }

    @Override
    public int count(Object e) {
        Entry<E> entry = map.get(e);
        return (entry != null) ? entry.getCount() : 0;
    }

    @Override
    public int size() {
        long lSize = 0;
        for (Entry<E> v : map.values()) {
            lSize += v.getCount();
        }
        return CollectionUtils.integerSaturate(lSize);
    }

    private int elementSize() {
        long lSize = 0;
        for (Entry<E> v : map.values()) {
            if (v.getCount() > 0) {
                lSize++;
            }
        }
        return CollectionUtils.integerSaturate(lSize);
    }

    @Override
    public Set<E> elementSet() {
        Set<E> set = elementSet;
        return (set != null) ?
                set :
                (elementSet = new ElementSet());
    }

    @Override
    public Set<MultiSet.Entry<E>> entrySet() {
        Set<MultiSet.Entry<E>> set = entrySet;
        return (set != null) ?
                set :
                (entrySet = new EntrySet());

    }

    @Override
    public boolean isEmpty() {
        return size() == 0;
    }

    @Override
    public String toString() {
        return "ConcurrentHashMultiSet: size = " + size() + ", keys = " + map.size();
    }

    private static class Entry<E> extends AtomicInteger implements MultiSet.Entry<E> {

        private static final long serialVersionUID = 988561351002000016L;
        private final E element;

        public Entry(E element) {
            super();
            this.element = element;
        }

        public Entry(E element, int count) {
            super(count);
            this.element = element;
        }

        @Override
        public E getElement() {
            return element;
        }

        @Override
        public int getCount() {
            return get();
        }
    }

    private class ElementSet extends AbstractSet<E> {

        @Override
        public Iterator<E> iterator() {
            return new ElementIterator(map.values().iterator());
        }

        @Override
        public int size() {
            return ConcurrentHashMultiSet.this.elementSize();
        }

        @Override
        public boolean contains(Object o) {
            return ConcurrentHashMultiSet.this.contains(o);
        }

    }

    private class EntrySet extends AbstractSet<MultiSet.Entry<E>> {

        @Override
        public Iterator<MultiSet.Entry<E>> iterator() {
            return new EntryIterator(map.values().iterator());
        }

        @Override
        public int size() {
            return ConcurrentHashMultiSet.this.elementSize();
        }

        @Override
        public boolean contains(Object o) {
            if (!(o instanceof MultiSet.Entry)) {
                return false;
            }

            MultiSet.Entry<?> entry = (MultiSet.Entry<?>) o;
            Object element = entry.getElement();
            int entryCount = entry.getCount();
            return entryCount > 0 && ConcurrentHashMultiSet.this.count(element) == entryCount;
        }
    }

    private class AbstractIterator {

        private final Iterator<Entry<E>> backingIterator;
        private Entry<E> currentEntry;

        public AbstractIterator(Iterator<Entry<E>> iterator) {
            this.backingIterator = iterator;
            skipToNext();
        }

        private void skipToNext() {
            while (backingIterator.hasNext()) {
                Entry<E> e = backingIterator.next();
                if (e.getCount() > 0) {
                    currentEntry = e;
                    return;
                }
            }
            currentEntry = null;
        }

        public boolean hasNext() {
            return currentEntry != null;
        }

        Entry<E> nextEntry() {
            Entry<E> e = currentEntry;
            if (e == null) {
                throw new NoSuchElementException();
            }
            skipToNext();
            return e;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }

    }

    private class ElementIterator extends AbstractIterator implements Iterator<E> {

        public ElementIterator(Iterator<Entry<E>> iterator) {
            super(iterator);
        }

        @Override
        public E next() {
            return nextEntry().getElement();
        }

    }

    private class EntryIterator extends AbstractIterator implements Iterator<MultiSet.Entry<E>> {

        public EntryIterator(Iterator<Entry<E>> iterator) {
            super(iterator);
        }

        @Override
        public MultiSet.Entry<E> next() {
            return nextEntry();
        }
    }
}
