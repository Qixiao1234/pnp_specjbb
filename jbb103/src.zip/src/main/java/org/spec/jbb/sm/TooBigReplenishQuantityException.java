/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */
package org.spec.jbb.sm;

import org.spec.jbb.core.tx.TransactionException;

public class TooBigReplenishQuantityException extends TransactionException {

    private static final long serialVersionUID = 3876362670592012422L;

    public TooBigReplenishQuantityException(String message) {
        super(message);
    }
}
