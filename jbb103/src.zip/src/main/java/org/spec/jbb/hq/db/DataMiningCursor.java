/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.db;


import org.spec.jbb.core.collections.CollectionUtils;

import java.util.Collections;
import java.util.List;

public class DataMiningCursor<E> {

    private List<E> lode;
    private int lodeCursor;
    private int expectedSize;

    public DataMiningCursor() {
        this(Collections.<E>emptyList(), Integer.MAX_VALUE);
    }

    public DataMiningCursor(List<E> lode, int expectedSize) {
        this.lode = lode;
        this.expectedSize = expectedSize;
        lodeCursor = -1;
    }

    public boolean hasNext() {
        return (lodeCursor+1 < lode.size());
    }

    public E next() {
        lodeCursor++;
        return lode.get(lodeCursor);
    }

    public boolean hasAnyElements() {
        return (lode.size() > 0);
    }

    public boolean hasEnoughElements() {
        return (lode.size() == expectedSize);
    }

    /*
     * Choose a random element from this data set.  There is no guarantee that this element hasn't be visited
     * before or won't be visited in the future.
     *
     * Returns null if there are no elements to choose from.
     */
    public E getRandom() {
        return CollectionUtils.getRandomElement(lode);
    }

    public void reset() {
        lodeCursor = -1;
    }

    @Override
    public String toString() {
        return "DataMiningCursor{" +
                "lode=" + lode.size() +
                ", lodeCursor=" + lodeCursor +
                '}';
    }

}
