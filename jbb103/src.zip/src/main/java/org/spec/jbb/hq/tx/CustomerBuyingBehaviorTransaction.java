/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.collections.CollectionUtils;
import org.spec.jbb.core.collections.HashMultiSet;
import org.spec.jbb.core.collections.MultiSet;
import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.db.DataMiningCursor;
import org.spec.jbb.hq.entity.Receipt;
import org.spec.jbb.hq.entity.ReceiptLine;
import org.spec.jbb.hq.tx.request.CustomerBuyingBehaviorRequest;
import org.spec.jbb.hq.tx.response.NoDataForDataMiningResponse;
import org.spec.jbb.util.JbbProperties;

import java.util.ArrayList;
import java.util.List;
import org.spec.jbb.hq.entity.Category;
import org.spec.jbb.sm.advertisement.IssuedAdvertisement;

public class CustomerBuyingBehaviorTransaction extends AbstractTransaction {

    private final HQ hq;
    private final String smName;
    private final Long customerID;
    private final DataMiningCursor<Receipt> data;
    private static final String dmName = "CustomerBuyingBehavior";

    public CustomerBuyingBehaviorTransaction(HQ hq, CustomerBuyingBehaviorRequest request, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        this.smName = request.getSmName();
        this.data = hq.getDataMiningManager().receiptsCursor(smName);
        this.customerID = hq.getDataMiningManager().pickRandomCustomerIdFromReceipts(data);
    }

    @Override
    public Response execute() throws TransactionException {

        /*
         * Build associativity map
         */
        final MultiSet<Long> barcodeHotness = new HashMultiSet<>();

        while (data.hasNext()) {
            Receipt r = data.next();
            if (customerID.equals(r.getCustomerId())) {
                for (ReceiptLine rl : r.getReceiptLines()) {
                    barcodeHotness.add(rl.getBarcode(),rl.getQuantity());
                }
            }
        }

        if (!barcodeHotness.isEmpty()) {

            /*
             * Find most popular products
             */

            List<Long> hottestBarcodes = new ArrayList<>(
                    CollectionUtils.tail(CollectionUtils.elementsAsList(barcodeHotness),
                            JbbProperties.getInstance().getDataMiningHottestCount(dmName)));

            /*
            * Create advertisement
            */
            if(!hottestBarcodes.isEmpty()) {
                Long barcode = CollectionUtils.getRandomElement(hottestBarcodes);
                Category cat = CollectionUtils.getRandomElement(new ArrayList<>(hq.findProduct(barcode).getCategories()));
                hq.suggestAdvertisement(smName, new IssuedAdvertisement(cat, hottestBarcodes));
            }
        }

        if (data.hasEnoughElements()) {
            return new OkResponse();
        } else {
            return new NoDataForDataMiningResponse();
        }
    }

    @Override
    public String toString() {
        return "CustomerBuyingBehaviorTx: smName = {" + smName + "}, customerId = {" + customerID + "}, data = {" + data + "}";
    }

}
