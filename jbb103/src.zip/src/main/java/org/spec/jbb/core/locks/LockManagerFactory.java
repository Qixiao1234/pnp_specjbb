/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.locks;

import org.spec.jbb.util.JbbProperties;

public final class LockManagerFactory {

    private LockManagerFactory() {
        // prevent instantiation
    }

    public static <T> LockManager<T> getLockManager(boolean verboseLocks) {
        LockRefType refType = JbbProperties.getInstance().getLockManagerReferenceType();
        LockManagerType type = JbbProperties.getInstance().getLockManagerType();

        switch (type) {
            case DELEGATE:
                return new DelegateLockManager<>(refType);
            case PROFILE:
                return new ProfileLockManager<>(refType, verboseLocks);
            default:
                throw new IllegalArgumentException("Unknown type: " + type);
        }
    }

    public static <T> RWLockManager<T> getRWLockManager(boolean verboseLocks) {
        LockRefType refType = JbbProperties.getInstance().getLockManagerReferenceType();
        LockManagerType type = JbbProperties.getInstance().getLockManagerType();

        switch (type) {
            case DELEGATE:
                return new DelegateRWLockManager<>(refType);
            case PROFILE:
                return new ProfileRWLockManager<>(refType, verboseLocks);
            default:
                throw new IllegalArgumentException("Unknown type: " + type);
        }
    }

    public static <T> LockManager<T> getLockManager() {
        return getLockManager(JbbProperties.getInstance().getLockManagerVerboseLocks());
    }

    public static <T> RWLockManager<T> getRWLockManager() {
        return getRWLockManager(JbbProperties.getInstance().getLockManagerVerboseLocks());
    }
}
