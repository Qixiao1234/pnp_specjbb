/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.generator;

import org.spec.jbb.hq.entity.ShippingCompany;
import org.spec.jbb.util.JbbProperties;
import org.spec.jbb.util.RandomData;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ShippingCompanyGenerator {

    public List<ShippingCompany> generate() {
        return generate(JbbProperties.getInstance().getShippingCompanyCount(), JbbProperties.getInstance().getRandomSeed());
    }

    List<ShippingCompany> generate(int count, long seed) {
        Set<Integer> uniqueShippingCompanyIds = new HashSet<>();
        Set<String> uniqueString = new HashSet<>();

        int prop_MinCustomerNameChars = JbbProperties.getInstance().getMinCustomerNameChars();
        int prop_MaxCustomerNameChars = JbbProperties.getInstance().getMaxCustomerNameChars();

        int prop_MinAddressZipChars = JbbProperties.getInstance().getMinAddressZipChars();
        int prop_MaxAddressZipChars = JbbProperties.getInstance().getMaxAddressZipChars();

        RandomData randomData = new RandomData(seed);

        List<ShippingCompany> result = new ArrayList<>();
        for (int c = 0; c < count; c++) {
            int id;
            do {
                id = randomData.randomInt(0, Integer.MAX_VALUE);
            } while (!uniqueShippingCompanyIds.add(id));

            String zip = randomData.createRandomAString(prop_MinAddressZipChars, prop_MaxAddressZipChars);

            String name;
            do {
                name = randomData.createRandomAString(prop_MinCustomerNameChars, prop_MaxCustomerNameChars);
            } while (!uniqueString.add(name));

            result.add(new ShippingCompany(id, name, zip));
        }

        return result;
    }
}
