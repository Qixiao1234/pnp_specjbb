/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.entity.Receipt;
import org.spec.jbb.hq.tx.request.PurchaseReceiptMessage;

public class PurchaseReceiptTransaction extends AbstractTransaction {

    private final HQ hq;
    private Receipt receipt;

    public PurchaseReceiptTransaction(HQ hq, PurchaseReceiptMessage msg, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        receipt = msg.getReceipt();
    }

    @Override
    public Response execute() {
        hq.addReceipt(receipt);
        
        /*
         * Adjust the HQ's representation of the source supermarket's inventory.
         */
        hq.adjustSupermarketInventory(ctx, receipt, HQ.SMInventoryDirection.OUT, true);

        return new OkResponse();
    }

    @Override
    public String toString() {
        return "PurchaseReceiptTx, receipt={" + receipt.toString() + "}";
    }

}
