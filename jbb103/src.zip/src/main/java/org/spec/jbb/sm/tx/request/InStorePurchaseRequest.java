/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.request;

import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.tx.InStorePurchaseTransaction;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class InStorePurchaseRequest extends AbstractPurchaseRequest {
    private static final long serialVersionUID = -1196462738013353721L;

    private InStorePurchaseRequest() {
        super();
    }

    public InStorePurchaseRequest(boolean isSaturate) {
        super(isSaturate);
    }

    @Override
    public Transaction getTransaction(SM sm, TransactionContext ctx) {
        return new InStorePurchaseTransaction(sm, this, ctx);
    }

    @Override
    public String toString() {
        return "InStore Purchase, " + super.toString();
    }

}
