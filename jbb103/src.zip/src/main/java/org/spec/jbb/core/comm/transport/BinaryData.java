/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport;

import java.io.ByteArrayInputStream;

/**
 * Holder for binary data.
 */
public class BinaryData extends Data {

    private static final long serialVersionUID = -3071823986958902072L;
    private final byte[] data;

    public BinaryData(byte[] data) {
        this.data = data;
    }

    /**
     * Get backing array
     * @return backing array
     */
    @Override
    public byte[] getArray() {
        return data;
    }

    /**
     * Get BAIS corresponding to this Data
     * @return bais instance
     */
    @Override
    public ByteArrayInputStream getStream() {
        return new ByteArrayInputStream(data);
    }

    @Override
    public Object getReference() {
        throw new IllegalStateException("Tried to read reference from binary data");
    }

}
