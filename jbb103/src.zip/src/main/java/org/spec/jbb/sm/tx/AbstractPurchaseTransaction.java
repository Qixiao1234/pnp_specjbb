/*
 * Copyright (c) 2012-2014 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.purchase.PurchaseItem;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.entity.CustomerProfile;
import org.spec.jbb.hq.entity.Product;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.ShoppingCart;
import org.spec.jbb.sm.ShoppingCartItem;
import org.spec.jbb.sm.tx.request.AbstractPurchaseRequest;
import org.spec.jbb.sm.tx.request.UnreserveInventoryRequest;
import org.spec.jbb.sm.tx.response.InventoryDepletedResponse;


public abstract class AbstractPurchaseTransaction extends AbstractSMTransaction {

    protected long customerId;
    protected ShoppingCart shoppingCart;

    public AbstractPurchaseTransaction(SM sm, AbstractPurchaseRequest req, TransactionContext ctx) {
        super(sm, ctx);
        customerId = sm.getCustomerSelector().getAndLockNextCustomerID();
    }

    @Override
    public Response execute() throws TransactionException {

        shoppingCart = new ShoppingCart(customerId);

        CustomerProfile cp = null;
        try {
            cp = getCustomerProfile(customerId);
            cp.removeExpiredCoupons();

            shoppingCart.setProfile(cp);
            
            int passedCount = 0;
            int totalCount = 0;

            for (PurchaseItem purchaseItem : purchaseAgent.getNextProducts(cp)) {
                long barcode = purchaseItem.getBarcode();
                int quantity = purchaseItem.getQuantity();
                Product product = resolveProduct(barcode);
                if(doPurchase(product, quantity)) {
                    passedCount++;
                }
                totalCount++;
            }

            if((passedCount == 0) || (passedCount < Math.floor(sm.getPassedScanPercent() * totalCount))) {
                rollback();
                return new InventoryDepletedResponse("Too many products need replenish: " + passedCount + "/" + totalCount);
            }
            
            doCheckout();
            
            return new OkResponse();
        } catch (TransactionException exc) {
            try {
                rollback();
            } catch (TransactionException sup) {
                exc.addSuppressed(sup);
            }
            throw exc;
        } finally {
            if (cp != null) {
                updateCustomerProfile(customerId, cp);
            }
            releaseCustomerProfile(customerId);
            sm.getCustomerSelector().releaseCustomerID(customerId);
        }
    }
    
    /**
     * Rollback shopping cart because Purchase Tx fails
     */
    private void rollback() throws TransactionException {
        CustomerProfile profile = shoppingCart.getProfile();

        for (ShoppingCartItem item : shoppingCart) {
            if (sm.getName().equals(item.getSmName())) {
                unreserveProduct(item.getBarcode(), item.getQuantity());
            } else {
                Response response = ctx.sendRequest(item.getSmName(),
                        new UnreserveInventoryRequest(item.getBarcode(), item.getQuantity()));
                if (!(response instanceof OkResponse)) {
                    throw new TransactionException("Failed to unreserve on rollback: " + response);
                }
            }

            if (item.getSpecificCoupon() != null) {
                profile.returnBackSpecificCoupon(item.getSpecificCoupon());
            }
        }

        if (shoppingCart.getGenericCoupon() != null) {
            profile.returnBackGenericCoupon(shoppingCart.getGenericCoupon());
        }
    }

    public CustomerProfile getCustomerProfile(long id) {
        CustomerProfile cp = storage.getCustomerProfileCache().get(ctx, id);
        cp.instrument(couponProbe);
        return cp;
    }

    public void updateCustomerProfile(long id, CustomerProfile profile) {
        storage.getCustomerProfileCache().update(ctx, id, profile);
    }

    public void releaseCustomerProfile(long id) {
        storage.getCustomerProfileCache().release(ctx, id);
    }


    protected abstract boolean doPurchase(Product product, int quantity) throws TransactionException;

    protected abstract void doCheckout() throws TransactionException;

    @Override
    public String toString() {
        return "Purchase: customer " + customerId;
    }

}
