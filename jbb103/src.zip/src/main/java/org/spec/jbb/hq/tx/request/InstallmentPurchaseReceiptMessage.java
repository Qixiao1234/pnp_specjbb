/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.request;

import org.spec.jbb.core.comm.AbstractMessage;
import org.spec.jbb.core.comm.transport.TransportType;
import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.InstallmentPurchaseReceiptTransaction;
import org.spec.jbb.sm.InstallmentPurchase;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD) 
public class InstallmentPurchaseReceiptMessage extends AbstractMessage {

    private static final long serialVersionUID = 1815514602948740018L;
    @XmlElement
    private final InstallmentPurchase installmentPurchase;

    @SuppressWarnings("unused")
    private InstallmentPurchaseReceiptMessage(){
        this(null);
    }
    
    public InstallmentPurchaseReceiptMessage(InstallmentPurchase installmentPurchase) {
        this.installmentPurchase = installmentPurchase;
    }

    @Override
    public boolean isDurable() {
        return true;
    }

    @Override
    public String toString() {
        return "Installment purchase receipt: " + installmentPurchase;
    }

    public InstallmentPurchase getInstallmentPurchase() {
        return installmentPurchase;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        InstallmentPurchaseReceiptMessage installmentPurchaseReceiptMessage = (InstallmentPurchaseReceiptMessage) o;

        if (installmentPurchase != null ? !installmentPurchase.equals(installmentPurchaseReceiptMessage.installmentPurchase) : installmentPurchaseReceiptMessage.installmentPurchase != null) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(installmentPurchase);
    }

    @Override
    public Transaction getTransaction(HQ hq, TransactionContext ctx) {
        return new InstallmentPurchaseReceiptTransaction(hq, this, ctx);
    }

    @Override
    public TransportType getTransportHint() {
        return TransportType.SERIALIZED_ENCRYPTED;
    }

}
