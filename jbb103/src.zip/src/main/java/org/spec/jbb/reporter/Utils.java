/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */
package org.spec.jbb.reporter;

import java.util.Calendar;
import java.util.Date;
import org.apache.commons.lang.StringEscapeUtils;
import org.spec.jbb.core.Conventions;
import org.spec.jbb.reporter.Reporter.Resources;

public class Utils {
    private static final int BENCHMARK_COPYRIGHT_YEAR = 2015;
    private final Reporter reporter;
    
    public Utils(Reporter reporter) {
        this.reporter = reporter;
    }
    
    public static String escapeHtml(String html) {
        return StringEscapeUtils.escapeHtml(html);
    }
    
    public static String getCopyrightStatement() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        int yearFDR = calendar.get(Calendar.YEAR);
        
        StringBuilder copyright = new StringBuilder();
        copyright.append("Copyright &copy; ").append(BENCHMARK_COPYRIGHT_YEAR);
        if(yearFDR != BENCHMARK_COPYRIGHT_YEAR) {
            copyright.append('-').append(yearFDR);
        }
        copyright.append(" Standard Performance Evaluation Corporation");

        return  copyright.toString();
    }

    public boolean isLogoEnabled() {
        return reporter.isPublication();
    }

    public boolean isDefaultPropsInfoNeeded() {
        return !reporter.isPublication();
    }
    
    public boolean isLinkToFullDisclosureNeeded() {
        return reporter.isPublication();
    }

    public String getFileName(String name) {
        return reporter.getFileName(name);
    }
    
    public int getReportLevel() {
        return reporter.getLevel();
    }
    
    public boolean isExecutorHQOF(String name) {
        return Conventions.isHQOF(name);
    }
    
    public String getDescriptionValue(String key, String value) {
        return key.endsWith(".url") ? "<a href='" + value + "'>" + value + "</a>" : value;
    }

    public String getStyleSheetRef(Resources resources) {
        return reporter.isPublication() ? "/includes/css/jbb2015result.css" : resources.getRef("specjbb2015.css");
    }

    public String getLinkToFullDisclosure() {
        return "<a href='" + reporter.getResult().getDisclosureUrl() +"'>Link to Full Disclosure</a>";
    }

    public String getGlossaryLink(String text, String anchor) {
        if ((anchor != null) && (!anchor.isEmpty())) {
            return "<a class=\"glLink\" href='http://www.spec.org/jbb2015/docs/SPECjbb2015-Result_File_Fields.html#" + anchor + "'>" + text + "</a>";
        } else {
            return text;
        }
    }
}
