/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.tx.response;

import org.spec.jbb.core.comm.AbstractResponse;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public abstract class PartialOkResponse extends AbstractResponse {
    private static final long serialVersionUID = -5475714927770385204L;
}
