/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.cache;

public interface Connector<C, K, V> {

    /**
     * Read value from backing storage.
     *
     * @param ctx context
     * @param key key to read
     * @return value
     */
    V read(C ctx, K key);

    /**
     * Write back value to backing storage.
     *
     * @param ctx context
     * @param key   key to write
     * @param value value to write
     */
    void write(C ctx, K key, V value);

    /**
     * Get priority for caching.
     * Less prioritized entries will be removed earlier.
     *
     * @param ctx context
     * @param key key
     * @return priority to retain
     */
    int getPriority(C ctx, K key);
}
