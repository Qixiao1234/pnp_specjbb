/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

import org.spec.jbb.core.Conventions;
import org.spec.jbb.infra.ProfileData;

import java.util.HashMap;
import java.util.Map;

public class TimeDriftDetectorVisitor implements Visitor {

    private Map<String, Long> startTimes;
    private Map<String, Long> stopTimes;

    public TimeDriftDetectorVisitor() {
        startTimes = new HashMap<>();
        stopTimes = new HashMap<>();
    }

    @Override
    public void visit(StatsFrame point) {
        ProfileData profileData = point.getProfileData();
        for(String leaf : profileData.getKeys()) {
            if (leaf.endsWith("time")) {
                long time = (Long) profileData.attr(leaf);

                String name = leaf.replace(Conventions.getDataSeparator() + "time", "");

                if (!startTimes.containsKey(name)) {
                    startTimes.put(name, time);
                }

                stopTimes.put(name, time);
            }
        }
    }

    @Override
    public boolean shouldRun() {
        return true;
    }

    public Map<String, Long> getDrifts() {
        Map<String, Long> result = new HashMap<>();
        for (String key : startTimes.keySet()) {
            result.put(key, getRuntime() - (stopTimes.get(key) - startTimes.get(key)));
        }
        return result;
    }

    public long getRuntime() {
        return stopTimes.get("controller") - startTimes.get("controller");
    }

}
