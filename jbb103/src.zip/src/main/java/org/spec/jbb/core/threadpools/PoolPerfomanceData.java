/*
 * Copyright (c) 2014 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

import java.io.Serializable;

public class PoolPerfomanceData implements Serializable {

    private static final long serialVersionUID = -4231571426186862295L;

    private final long primaryTasksSuccess;
    private final long primaryTasksPartiallyExecuted;
    private final long primaryTasksFailed;
    private final long totalTasksProcessed;

    public PoolPerfomanceData(long primaryTasksSuccess, long primaryTasksPartiallyExecuted, long primaryTasksFailed,
            long totalTasksProcessed) {
        this.primaryTasksSuccess = primaryTasksSuccess;
        this.primaryTasksPartiallyExecuted = primaryTasksPartiallyExecuted;
        this.primaryTasksFailed = primaryTasksFailed;
        this.totalTasksProcessed = totalTasksProcessed;
    }

    public long getSuccessful() {
        return primaryTasksSuccess;
    }

    public long getPartial() {
        return primaryTasksPartiallyExecuted;
    }

    public long getFailed() {
        return primaryTasksFailed;
   
    }
    
    public long getTotalProcessed() {
        return totalTasksProcessed;
    }

    @Override
    public String toString() {
        return "(" + primaryTasksSuccess 
            + ", " + primaryTasksPartiallyExecuted 
            + ", " + primaryTasksFailed 
            + ", " + totalTasksProcessed + ")";
    }

}
