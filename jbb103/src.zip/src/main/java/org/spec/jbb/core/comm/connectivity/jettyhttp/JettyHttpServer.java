/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity.jettyhttp;

import org.eclipse.jetty.server.Request;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.AbstractHandler;
import org.spec.jbb.core.comm.Packet;
import org.spec.jbb.core.comm.connectivity.HttpConstants;
import org.spec.jbb.core.comm.connectivity.ServerCallback;
import org.spec.jbb.core.comm.transport.Data;
import org.spec.jbb.core.comm.transport.TransportType;
import org.spec.jbb.util.StreamUtil;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.util.Random;

/**
 * EXPERIMENTAL Jetty-based HTTP server
 * <p/>
 * This implementation is provided to test internal connectivity API.
 * Performance and correctness of this implementation is not guaranteed.
 */
public class JettyHttpServer implements org.spec.jbb.core.comm.connectivity.Server {

    private final ServerCallback callback;

    private int port;
    private Server server;

    public JettyHttpServer(int port, ServerCallback callback) {
        this.port = port;
        this.callback = callback;
    }

    @Override
    public void open() throws IOException {
        boolean isProbing = (port == 0);
        Random random = new Random();

        int tryCount = 10;
        while (true) {
            try {
                if (isProbing) {
                    port = random.nextInt(60000) + 1024;
                }

                server = new Server(port);
                server.setHandler(new ProtocolHandler());

                server.start();

                break;
            } catch (Exception e) {
                tryCount--;
                if (tryCount < 0) {
                    throw new IOException("Try count depleted", e);
                }
            }
        }
    }

    @Override
    public void close() {
        try {
            server.stop();
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    @Override
    public int getLocalPort() {
        return port;
    }

    private class ProtocolHandler extends AbstractHandler {

        @Override
        public void handle(String target, Request request, HttpServletRequest servletRequest, HttpServletResponse servletResponse) throws IOException, ServletException {
            switch (target) {
                case HttpConstants.CONTEXT_RESOLVEIP:
                    doResolveIP(target, request, servletRequest, servletResponse);
                    request.setHandled(true);
                    break;
                case HttpConstants.CONTEXT_DATA:
                    doData(target, request, servletRequest, servletResponse);
                    request.setHandled(true);
                    break;
            }
        }

        private void doData(String target, Request request, HttpServletRequest servletRequest, HttpServletResponse servletResponse) throws IOException {
            String from = request.getHeader(HttpConstants.HEADER_FROM);
            String to = request.getHeader(HttpConstants.HEADER_TO);
            TransportType transportType = TransportType.valueOf(request.getHeader(HttpConstants.HEADER_TRANSPORTTYPE));
            boolean shouldBeAnswered = Boolean.valueOf(request.getHeader(HttpConstants.HEADER_SHOULDBEANSWERED));
            int tier = Integer.valueOf(request.getHeader(HttpConstants.HEADER_TIER));

            InputStream stream = request.getInputStream();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            StreamUtil.copy(stream, baos);

            Packet packet = callback.handle(new Packet(from, to, transportType, Data.wrap(baos), shouldBeAnswered, tier));

            servletResponse.setHeader(HttpConstants.HEADER_FROM, packet.getFrom());
            servletResponse.setHeader(HttpConstants.HEADER_TO, packet.getTo());
            servletResponse.setHeader(HttpConstants.HEADER_TRANSPORTTYPE, packet.getTransportType().toString());
            servletResponse.setHeader(HttpConstants.HEADER_SHOULDBEANSWERED, Boolean.toString(packet.shouldBeAnswered()));
            servletResponse.setHeader(HttpConstants.HEADER_TIER, Integer.toString(packet.getCurrentTier()));

            OutputStream outputStream = servletResponse.getOutputStream();
            StreamUtil.copy(packet.getData().getStream(), outputStream);
        }

        private void doResolveIP(String target, Request request, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException {
            InetAddress byName = InetAddress.getByName(request.getRemoteAddr());
            httpServletResponse.getOutputStream().write(byName.getAddress());
        }
    }

}
