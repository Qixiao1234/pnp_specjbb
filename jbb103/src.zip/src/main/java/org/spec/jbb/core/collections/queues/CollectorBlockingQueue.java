/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections.queues;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicReference;

public class CollectorBlockingQueue<E> {
    private AtomicReference<BlockingQueue<E>> queueRef;
    private final int size;
    
    public CollectorBlockingQueue(int size) {
        this.size = size;
        queueRef = new AtomicReference<BlockingQueue<E>>(new ArrayBlockingQueue<E>(size - 1));
    }
    
    public List<E> add(E elem) {
        while(true) {
            BlockingQueue<E> queue = this.queueRef.get();
            if(!queue.offer(elem)) {
                BlockingQueue<E> newQueue = new ArrayBlockingQueue<>(size - 1);
                if(queueRef.compareAndSet(queue, newQueue)) {
                    List<E> list = new ArrayList<>(size);
                    list.addAll(queue);
                    list.add(elem);
                    return Collections.unmodifiableList(list);
                }
            } else {
                return null;
            }
        }
    }
}
