/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter.data;

public class SilentDataWriterProvider implements DataWriterProvider {

    @Override
    public DataWriter newProvider(String fileName, int compressionLevel) {
        return new SilentDataWriter();
    }

    @Override
    public String getName() {
        return "Silent";
    }

    @Override
    public String getDescription() {
        return "Drop all frames";
    }

    @Override
    public void shutdown() {
    }
    
}
