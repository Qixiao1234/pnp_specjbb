/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.discount;

import org.spec.jbb.util.JbbProperties;

import java.io.Serializable;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Semaphore;

/**
 * An abstract implementation of DiscountAgent.
 * Supports keeping the issued discount until purge operation. 
 *
 */
public abstract class AbstractDiscountAgent implements DiscountAgent, Serializable {
    private static final long serialVersionUID = -7342752927382446474L;
    /**
     * Issued Discounts
     */
    private final Queue<List<Discount>> discounts;
    /**
     * size of the queue including reserved slots
     */
    private final Semaphore freeSlots;
    

    public AbstractDiscountAgent() {
        int maxQueueSize = JbbProperties.getInstance().getDiscountQueueSize();
        freeSlots = new Semaphore(maxQueueSize);
        discounts = new ArrayBlockingQueue<>(maxQueueSize);
    }

    @Override
    public void addDiscountBatch(List<Discount> batch) {
        if(!discounts.offer(batch)) {
            throw new IllegalStateException("addIssuedAdvertisement is used without reservation");
        }
    }

    @Override
    public List<Discount> pollDiscountBatch() {
        List<Discount> batch = discounts.poll();
        if (batch != null) {
            freeSlots.release();
        }
        return batch;
    }

    @Override
    public boolean reserveSlot() {
        return freeSlots.tryAcquire();
    }

}
