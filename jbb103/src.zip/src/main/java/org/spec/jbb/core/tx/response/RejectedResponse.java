/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.tx.response;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * System response:
 * Remote is rejecting the request.
 */
@XmlRootElement
public class RejectedResponse extends FailedResponse {

    private static final long serialVersionUID = -5173922736099237899L;

    @Override
    public String toString() {
        return "Rejected";
    }

}