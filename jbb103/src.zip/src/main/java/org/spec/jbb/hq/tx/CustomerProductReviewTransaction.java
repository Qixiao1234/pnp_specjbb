/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.request.CustomerProductReviewMessage;

import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

public class CustomerProductReviewTransaction extends AbstractTransaction {

    private final HQ hq;
    private final Set<Long> barcodes;

    public CustomerProductReviewTransaction(HQ hq,
            CustomerProductReviewMessage incoming, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        this.barcodes = incoming.getOrder().getBarcodes();
    }

    @Override
    public Response execute() {
        for (Long barcode : barcodes) {
            hq.setCustomerReviewScore(barcode, ThreadLocalRandom.current().nextInt(10));
        }
        return new OkResponse();
    }

    @Override
    public String toString() {
        return "CustomerProductReviewTx: barcode={" + barcodes + "}";
    }

}

