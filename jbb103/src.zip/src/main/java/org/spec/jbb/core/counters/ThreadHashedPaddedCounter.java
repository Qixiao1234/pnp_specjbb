/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

/*
 * Written by Doug Lea with assistance from members of JCP JSR-166
 * Expert Group and released to the public domain, as explained at
 * http://creativecommons.org/publicdomain/zero/1.0/
 */

package org.spec.jbb.core.counters;

import org.spec.jbb.util.JbbProperties;

import java.io.Serializable;
import java.util.concurrent.atomic.AtomicLong;

/** 
 * A counter based on an array of counts. Each thread increments the
 * count at an index based on its hash code. Method get() collects all
 * counts non-atomically, so may return stale values. The array size
 * is configured to be the power of two nearest to the property
 * getThreadHashCounterCapBound().
 */
public class ThreadHashedPaddedCounter implements Counter, Serializable {

    public static final long serialVersionUID = 1L;

    static final int CAP = cap();
    static int cap() {
        int p = JbbProperties.getInstance().getThreadHashCounterCapBound();
        int c = 1;
        while (c < p)
            c <<= 1;
        return c;
    }

    /**
      * Version of AtomicLong that adds extra fields to reduce
      * cacheline sharing.
      */
    static final class PaddedAtomicLong extends AtomicLong {
        private static final long serialVersionUID = 7403904461056287623L;
        long pad0, pad1, pad2, pad3, pad4, pad5, pad6, pad7;
        long pad8, pad9, pada, padb, padc, padd, pade;
        PaddedAtomicLong() { super(); }
    }

    /**
     * The counters. Currently all initialized upon construction, but
     * accessors null check to simplify lazier initialization in the
     * future.
     */
    private final PaddedAtomicLong[] counters;

    public ThreadHashedPaddedCounter() {
        PaddedAtomicLong[] cs = new PaddedAtomicLong[CAP];
        for (int i = 0; i < CAP; ++i)
            cs[i] = new PaddedAtomicLong();
        counters = cs;
    }

    @Override
    public void inc(long d) {
        PaddedAtomicLong[] cs = counters;

        /**
        * Returns a hash index for the current thread.  Uses a one-step
        * FNV-1a hash code (http://www.isthe.com/chongo/tech/comp/fnv/)
        * based on the current thread's Thread.getId().
        */
        long id = Thread.currentThread().getId();
        int hash = (((int)(id ^ (id >>> 32))) ^ 0x811c9dc5) * 0x01000193;
        int i = hash & (cs.length - 1);
        PaddedAtomicLong a = cs[i];
        long v;
        do {
            v = a.get();
        } while (!a.compareAndSet(v, v + d));
    }

    @Override
    public long get() {
        PaddedAtomicLong[] cs = counters;
        long sum = 0L;
        for (PaddedAtomicLong a : cs) {
            if (a != null) {
                sum += a.get();
            }
        }
        return sum;
    }

    @Override
    public long getAndReset() {
        PaddedAtomicLong[] cs = counters;
        long sum = 0L;
        for (AtomicLong a : cs) {
            if (a != null) {
                long v;
                do {
                    v = a.get();
                } while (!a.compareAndSet(v, 0L));
                sum += v;
            }
        }
        return sum;
    }

    @Override
    public void reset() {
        PaddedAtomicLong[] cs = counters;
        for (PaddedAtomicLong a : cs) {
            if (a != null) {
                a.set(0L);
            }
        }
    }
    
    public String toString() {
        return "" + get();
    }
}