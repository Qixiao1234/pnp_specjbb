/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.tx.request.ReserveInventoryRequest;
import org.spec.jbb.sm.tx.response.ReserveInventoryResponse;

public final class ReserveInventoryTransaction extends AbstractInventoryTransaction {

    public ReserveInventoryTransaction(SM sm, ReserveInventoryRequest request, TransactionContext ctx) {
        super(sm, request.getBarcode(), request.getQuantity(), ctx);
    }

    @Override
    public Response execute() throws TransactionException {
        int quantityReserved = reserveProduct(getBarcode(), getQuantity());
        return new ReserveInventoryResponse(getBarcode(), quantityReserved);
    }

    @Override
    public String toString() {
        return super.toString() + ", RESERVE";
    }

}
