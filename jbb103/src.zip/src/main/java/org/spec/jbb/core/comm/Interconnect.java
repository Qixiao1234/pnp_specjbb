/*
 * Copyright (c) 2012-2014 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm;

import org.spec.jbb.core.Conventions;
import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.collections.ConcurrentCreateHashMap;
import org.spec.jbb.core.collections.ConcurrentWeakHashMap;
import org.spec.jbb.core.collections.CreateMap;
import org.spec.jbb.core.collections.HashMultiMap;
import org.spec.jbb.core.collections.MultiMap;
import org.spec.jbb.core.collections.queues.QueueFactory;
import org.spec.jbb.core.comm.connectivity.Client;
import org.spec.jbb.core.comm.connectivity.ConnectivityFactory;
import org.spec.jbb.core.comm.connectivity.Server;
import org.spec.jbb.core.comm.connectivity.ServerCallback;
import org.spec.jbb.core.comm.message.CompositeMessage;
import org.spec.jbb.core.comm.policy.TransportSelectionPolicy;
import org.spec.jbb.core.comm.policy.TransportSelectionPolicyFactory;
import org.spec.jbb.core.comm.requests.CompositeRequest;
import org.spec.jbb.core.comm.requests.LookupRequest;
import org.spec.jbb.core.comm.requests.RegisterRequest;
import org.spec.jbb.core.comm.response.CompositeResponse;
import org.spec.jbb.core.comm.response.LookupResponse;
import org.spec.jbb.core.comm.transport.BinaryData;
import org.spec.jbb.core.comm.transport.Data;
import org.spec.jbb.core.comm.transport.Transport;
import org.spec.jbb.core.comm.transport.TransportFactory;
import org.spec.jbb.core.comm.transport.TransportType;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.probe.ProbeFactory;
import org.spec.jbb.core.sequencer.Sequencer;
import org.spec.jbb.core.sequencer.SequencerFactory;
import org.spec.jbb.core.threadpools.ThreadUtils;
import org.spec.jbb.core.time.StopWatch;
import org.spec.jbb.core.time.TimeFactory;
import org.spec.jbb.core.tx.response.ErrorResponse;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.infra.Screen;
import org.spec.jbb.util.InstanceFactory;
import org.spec.jbb.util.JbbProperties;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Interconnect (IC) is the central abstraction in Comm API.
 *
 * It provides the "interconnect fabric" which enables clients to exchange requests and messages.
 * Each client is connecting to IC with with [uplink; downlink] pair. Uplink/downlink interfaces are pure Java.
 * It's Interconnect duty to convert from/to Java to/from binary formats, with help of transports.
 *
 * IC enables multiple JVMs to communicate. This is achieved by running one IC per each JVM.
 * When one IC detects request is targeted for client on another IC, it sends the request across the connectivity.
 * Multiple ICs share client names via Registry, thus forming global client namespace.
 *
 * Hence, one can see how requests are propagating through IC:
 *
 * 1. Local client 1 (LC1)  --->  Local client 2 (LC2):
 *   - LC1 uplink marshals the request into data
 *   - LC1 submits data to IC
 *   - IC routes data to LC2 downlink
 *   - LC2 downlink unmarshals the data into request
 *   - LC2 downlink asks client to accept the request
 *   - (...responses take the same route backwards)
 *
 * 2. Local client 1 (LC1) on IC1 --> Remote client 1 (RC1) on IC2:
 *   - LC1 uplink marshals the request into data
 *   - LC1 submits data to IC1
 *   - IC1 can't find RC1 locally
 *   - IC1 looks up RC1 in registry and sees it's on IC2
 *   - IC1 sends the data to IC2
 *   - IC2 receives the data and pushes it through RC1 downlink
 *   - RC1 downlink asks client to accept the request
 *   - (...responses take the same route backwards)
 *
 * Marshaling format is defined in transports.
 * Transport types are defined in two steps:
 *   - any request/response/message can set transportHint. If IC favors hint, selected transport is used.
 *   - otherwise, transportSelectionPolicy is used to decide which transport to use between LC1 and LC2
 */
public class Interconnect implements Measurable {


    private Logger logger = Logger.getLogger("org.spec.jbb.ic");

    /**
     * Registered uplinks/downlinks
     */
    private final Map<String, Downlink> downlinks = new ConcurrentHashMap<>();
    private final Map<String, Uplink> uplinks = new ConcurrentHashMap<>();

    /**
     * Connectivity factory used for outbound intra-IC connections.
     */
    private ConnectivityFactory connectivityFactory;

    /**
     * Server used for accepting inbound intra-IC connections
     */
    private Server serverRegistry;
    private List<Server> tieredServers;

    /**
     * Registry holding routing information.
     */
    private Registry registry;

    /**
     * Local IC host and port.
     */
    private final String localHost;

    /**
     * Transport selection policy to use
     */
    private TransportSelectionPolicy transportSelectionPolicy;

    private volatile Probe probe;

    private final int maxTiers;

    private final ScheduledExecutorService timers;

    /**
     * Creates interconnect.
     * One IC should always be master.
     *
     * @param masterHost master IC host
     * @param masterPort master IC port
     * @param isMaster true, if this IC is master
     */
    public Interconnect(String masterHost, int masterPort, boolean isMaster) {

        this.maxTiers = JbbProperties.getInstance().getMaxTiers();

        this.transportSelectionPolicy = TransportSelectionPolicyFactory.getInstance();

        this.connectivityFactory = new ConnectivityFactory();

        this.probe = ProbeFactory.getDefaultProbe();

        this.tieredServers = new ArrayList<>();

        this.timers = Executors.newScheduledThreadPool(JbbProperties.getInstance().getInterconnectTimersPoolSize());

        this.serverRegistry = connectivityFactory.getServer(isMaster ? masterPort : 0, new ProcessorCallback());
        for (int c = 0; c <= maxTiers; c++) {
            Server server = connectivityFactory.getServer(0, new ProcessorCallback());
            tieredServers.add(server);
        }

        logger.info("Init IC");

        try {
            if (isMaster) {
                /**
                 * Start registry
                 */
                registry = new Registry(isMaster);
                registry.addToAnnounce(Registry.IC_MASTER, masterHost, masterPort);

                addLink(registry);

                serverRegistry.open();
            }
            for (Server server : tieredServers) {
                server.open();
            }
        } catch (IOException e) {
            throw new IllegalStateException("IC had failed to initialize the server", e);
        }

        /**
         * Determine mine hostname and port
         */
        if (isMaster) {
            localHost = masterHost;
        } else {
            Client client = connectivityFactory.getClient(masterHost, masterPort);

            final int initTimeout = JbbProperties.getInstance().getControllerHandshakeTimeout();
            final int initPeriod = JbbProperties.getInstance().getControllerHandshakePeriod();

            String myIP = null;

            logger.info("Resolving the hostname from IC-Master...");

            StopWatch masterInitTimeoutWatcher = TimeFactory.getStopwatch();
            masterInitTimeoutWatcher.start();

            // Need to wait for Controller if Agent was started earlier
            do {
                try {
                    myIP = client.resolveMyIp();
                    logger.info("IC-Master is alive");
                } catch (IOException | InterruptedException e) {
                    if (masterInitTimeoutWatcher.getElapsedMsecs() < initTimeout) {
                        Screen.print(".");
                        try {
                            Thread.sleep(initPeriod);
                        } catch (InterruptedException exc) {
                        } 
                    } else {
                        Screen.println();
                        Screen.println("Hostname resolution failed, check if Controller was started");
                        logger.log(Level.SEVERE, "Hostname resolution failed, check if Controller was started", e);
                        throw new IllegalStateException("Timeout " + initTimeout + 
                                " ms while waiting to successfully resolve the hostname from Conroller host");
                    }
                }
            } while (myIP == null);

            localHost = myIP;
            logger.info("Hostname is resolved back as " + this.localHost);
            
            /**
             * Start registry
             */
            registry = new Registry(isMaster);
            registry.addToAnnounce(Registry.IC_MASTER, masterHost, masterPort);

            addLink(registry);
        }
        logger.info("IC init finished");
    }

    /**
     * Adds local link to interconnect.
     * This method initializes client's uplinks, announces it on IC network
     *
     * @param client client to add
     * @param drainer message drainer to use for this client
     */
    public void addLink(ConnectionClient client, final MessageDrainer drainer) {
        String name = client.getName();

        final Uplink uplink = new UplinkImpl(name);
        final Downlink downLink = new Downlink(name, client);

        client.setUplink(uplink);

        if (JbbProperties.getInstance().isMessageBufferEnabledFor(name)) {
            timers.scheduleAtFixedRate(new Runnable() {
                @Override
                public void run() {
                    drainer.drain(uplink);
                }
            }, 0, JbbProperties.getInstance().getMessageBufferDrainPeriod(), TimeUnit.MILLISECONDS);
        }
        
        uplinks.put(name, uplink);
        downlinks.put(name, downLink);
        registry.addToAnnounce(name);

        logger.info("Registered " + name);
    }

    /**
     * Adds local link to interconnect with default message drainer.
     * This method initializes client's uplinks, announces it on IC network
     *
     * @param client client to add
     */
    public void addLink(ConnectionClient client) {
        addLink(client, new MessageDrainer() {
            @Override
            public void drain(Uplink link) {
                link.flushMessages(Conventions.TIER_BACKEND_FIRST);
            }
        });
    }

    /**
     * Remove local link from interconnect.
     * @param client client to remove
     */
    public void removeLink(ConnectionClient client) {
        String name = client.getName();

        uplinks.get(name).disable();
        downlinks.get(name).disable();

        logger.info("Deregistered " + name);
    }

    /**
     * Internal send request handler.
     * It's responsibility is to decide where to forward particular packet
     *
     * @param packet packet to send
     * @param isPropagate true, if data should propagate to other ICs
     * @param isRemote true, if data was received from remote IC
     * @return received packet
     */
    private Packet forward(Packet packet, boolean isPropagate, boolean isRemote) throws InterruptedException, IOException {
        Downlink link = downlinks.get(packet.getTo());

        if (link != null) {
            return link.accept(packet, isRemote);
        } else {
            if (!isPropagate) {
                logger.severe("Client not found on local IC: " + packet.getTo());
                throw new IllegalStateException("Client not found on local IC: " + packet.getTo());
            }

            LocationInfo info = registry.resolve(packet.getTo(), packet.getCurrentTier());
            if (info == null) {
                logger.severe("Client not found in registry: " + packet.getTo());
                throw new IllegalStateException("Client not found in registry: " + packet.getTo());
            }

            String location = info.getLocation();
            int port = info.getPort();

            Client client = connectivityFactory.getClient(location, port);
            accountSendStart(packet);
            try {
                return client.send(packet);
            } finally {
                accountSendFinished(packet);
            }
        }
    }

    private void accountSendStart(Packet packet) {
        if (probe.shouldGoInsane()) {
            String mangledName = "clients.sendQ.tier" + packet.getCurrentTier();
            probe.add(mangledName, +1);
        }
    }

    private void accountSendFinished(Packet packet) {
        if (probe.shouldGoInsane()) {
            String mangledName = "clients.sendQ.tier" + packet.getCurrentTier();
            probe.add(mangledName, -1);
        }
    }

    private void accountReceivedStart(Packet packet) {
        if (probe.shouldGoInsane()) {
            String mangledName = "clients.recvQ.tier" + packet.getCurrentTier();
            probe.add(mangledName, +1);
        }
    }

    private void accountReceivedFinished(Packet packet) {
        if (probe.shouldGoInsane()) {
            String mangledName = "clients.recvQ.tier" + packet.getCurrentTier();
            probe.add(mangledName, -1);
        }
    }

    /**
     * Answers the transport type for given client.
     *
     * @param fromName source entity
     * @param toName target entity
     * @return transport type to use
     */
    private TransportType getTransportType(String fromName, String toName) {
        Downlink fromLink = downlinks.get(fromName);
        Downlink toLink = downlinks.get(toName);

        /**
         * All traffic to master IC is serialized
         */
        if (fromName.equals(Registry.IC_MASTER) || toName.equals(Registry.IC_MASTER)) {
            return TransportType.SERIALIZED;
        }

        /**
         * Ask policy about desired transport type
         */
        boolean isSpanningMultipleICs = (fromLink == null || toLink == null);
        return transportSelectionPolicy.get(fromName, toName, isSpanningMultipleICs);
    }

    public void shutdown() {
        if (serverRegistry != null) {
            serverRegistry.close();
        }
        for (Server server : tieredServers) {
            server.close();
        }
        ThreadUtils.terminatePool(timers);
        connectivityFactory.shutdown();
    }

    /**
     * Count packet in for statistics
     * @param packet packet to account
     * @param payload packet payload
     */
    private void accountPacket(Packet packet, Collection<?> payload) {
        if (!probe.shouldGoInsane()) {
            return;
        }

        String mangledName = "%" + packet.getFrom() + "%" + packet.getTo() + "%" + packet.getTransportType() + "%";

        probe.inc(mangledName + "packets.count");

        int size = 0;
        if (packet.getData() instanceof BinaryData) {
            size = packet.getData().getArray().length;
            probe.add(mangledName + "packets.size", size);
        }

        if (payload != null) {
            for(Object o : payload) {
                probe.countType(mangledName + "packets.payload.count", o);
                probe.countType(mangledName + "packets.payload.size", o, size / payload.size());
            }
        }

    }

    @Override
    public void instrument(Probe probe) {
        this.probe = probe;
        connectivityFactory.instrument(probe.getChild("connectivity"));
    }

    @Override
    public void sample() {
        connectivityFactory.sample();
    }

    /**
     * Registry.
     *
     * Registry responsibility is to handle routing information.
     * Registry piggy-backs on IC capabilities for exchanging data. The only thing Registry knows is location of Master IC.
     * Everything else gets resolved dynamically.
     */
    public class Registry implements ConnectionClient {

        /**
         * IC Master name
         */
        public static final String IC_MASTER = "IC-Master";

        /**
         * Registry name on IC
         */
        private final String name;

        /**
         * Uplink
         */
        private Uplink link;

        /**
         * Whether this registry is master?
         */
        private final boolean isMaster;

        /**
         * Registered clients: where to find particular client?
         */
        private Map<String, LocationInfo> registeredClients = new ConcurrentHashMap<>();

        public Registry(boolean isMaster) {
            this.isMaster = isMaster;
            this.name = isMaster ? IC_MASTER : "IC";
        }

        @Override
        public String getName() {
            return name;
        }

        @Override
        public List<Response> handle(String from, List<Request> requests, int currentTier, int targetTier) {
            List<Response> responses = new ArrayList<>();
            for (Request req : requests) {
                responses.add(process(req));
            }
            return responses;
        }

        /**
         * Process the specific registry request.
         *
         * @param request request to process.
         * @return response
         */
        public Response process(Request request) {

            if (request instanceof LookupRequest) {
                LookupRequest req = (LookupRequest) request;

                String name = req.getName();
                LocationInfo info = registeredClients.get(name);

                if (info != null) {
                    logger.info("Looked up " + name + " @ " + info);
                    return new LookupResponse(name, info);
                } else {
                    logger.warning(name + " wasn't found");
                    return new ErrorResponse(name + " wasn't found");
                }
            }

            if (request instanceof RegisterRequest) {
                RegisterRequest req = (RegisterRequest) request;
                registeredClients.put(req.getName(), req.getInfo());
                return new OkResponse();
            }

            return new ErrorResponse("Not recognized");
        }

        /**
         * Add something to announce.
         * NB: It's assumed topology never changes, i.e. each client has one and only location.
         *
         * @param name distinguished name
         * @param hostname location hostname
         * @param port location port
         */
        public void addToAnnounce(String name, String hostname, int port) {

            /**
             * If not master, register on master.
             * Also, if registering IC_MASTER, skip request to eliminate looping.
             */
            if (!isMaster && !name.contains(IC_MASTER)) {
                LocationInfo info = new LocationInfo(hostname, port);
                link.sendRequest(IC_MASTER, Conventions.TIER_INFRA, new RegisterRequest(name, info));
                logger.info("Pushed " + name + " @ " + info + " to announce list");
            }

            /**
             * Save in local table. On master, this will maintain the list of all clients. On slave, it will serve as cache.
             */
            registeredClients.put(name, new LocationInfo(hostname, port));

        }

        /**
         * Add local client to announce.
         * Shortcut for addToAnnounce(name, #localHost, #localPort).
         *
         * @param name service to add
         */
        private void addToAnnounce(String name) {
            for (int c = 0; c <= maxTiers; c++) {
                Server server = tieredServers.get(c);
                addToAnnounce(name + "-" + Conventions.getTierName(c), localHost, server.getLocalPort());
            }
        }

        /**
         * Resolve client.
         *
         * @param name client to resolve
         * @param tier which tier to use
         * @return location location information for client in question
         */
        private LocationInfo resolve(String name, int tier) {

            String lookupName;
            if (!name.contains(IC_MASTER)) {
                if (tier > maxTiers) {
                    throw new IllegalStateException("Not enough tiers to serve this request, requested tier = " + tier + ", max = " + (maxTiers-1));
                }
                lookupName = name + "-" + Conventions.getTierName(tier);
            } else {
                lookupName = IC_MASTER;
            }

            LocationInfo info = registeredClients.get(lookupName);

            /**
             * If local table misses the value, and I'm slave, ask master.
             */
            if (info == null && !isMaster) {
                Response response = link.sendRequest(IC_MASTER, Conventions.TIER_INFRA, new LookupRequest(lookupName));
                if (response instanceof LookupResponse) {
                    LookupResponse resp = (LookupResponse) response;
                    info = resp.getInfo();
                }

                if (info != null) {
                    logger.info("Resolved " + lookupName + " @ " + info);
                    registeredClients.put(lookupName, info);
                } else {
                    logger.warning("Unable to look up " + lookupName);
                }
            }

            return info;
        }

        @Override
        public void handleMessage(String from, List<Message> messages, int currentTier, int targetTier) {
            // do nothing
        }

        @Override
        public void setUplink(Uplink link) {
            this.link = link;
        }

        @Override
        public Uplink getLink() {
            return link;
        }

        public List<LocationInfo> getInfo(String name) {
            List<LocationInfo> result = new ArrayList<>();
            for (int t = 0; t < maxTiers; t++) {
                String k = name + "-" + Conventions.getTierName(t);
                LocationInfo v = registeredClients.get(k);
                if (v != null) {
                    result.add(v);
                }
            }

            return result;
        }

    }

    /**
     * Callback to be called by server when new data arrives over the network.
     */
    public class ProcessorCallback implements ServerCallback {

        @Override
        public Packet handle(Packet data) {
            accountReceivedStart(data);
            try {
                return Interconnect.this.forward(data, false, true);
            } catch (InterruptedException | IOException e) {
                throw new IllegalStateException("Should never happen", e);
            } finally {
                accountReceivedFinished(data);
            }
        }

    }

    /**
     * Uplink:
     *  Used by clients for outbound requests.
     *  Each client has the uplink to IC.
     */
    public class UplinkImpl implements Uplink {

        private final String name;
        private final Logger logger;

        private final boolean messageBufferingEnabled;
        private final boolean isICLoggingEnabled;
        private final boolean isICfavorTransportHints;
        private volatile boolean isDisabled;

        private final Sequencer<Long> sequencer;
        private final Map<PreparedBatch, Packet> preparedData;

        private final TransportFactory transportFactory;
        private final CreateMap<String, Queue<Message>> messageQueues;

        public UplinkImpl(String name) {
            this.name = name;
            this.messageBufferingEnabled = JbbProperties.getInstance().isMessageBufferEnabledFor(name);
            this.isICLoggingEnabled = JbbProperties.getInstance().isICloggingEnabled();
            this.isICfavorTransportHints = JbbProperties.getInstance().isICfavorTransportHints();
            this.logger = Logger.getLogger("org.spec.jbb.comm." + name + ".uplink");
            this.sequencer = SequencerFactory.getNonSkippingSequencer();
            this.preparedData = new ConcurrentWeakHashMap<>();
            this.transportFactory = TransportFactory.getInstance();
            this.messageQueues = new ConcurrentCreateHashMap(new InstanceFactory<Queue<Packet>>() {
                private static final long serialVersionUID = -3483696122918095869L;

                @Override
                public Queue<Packet> getInstance() {
                    return QueueFactory.getUnboundedQueue();
                }
            });
        }

        /**
         * Send requests and wait for responses.
         * This method submits all requests in one batch.
         *
         * @param targetName target client to send the request to
         * @param currentTier current tier at which request is generated
         * @param requests list of requests to send
         * @return list of responses
         */
        public List<Response> sendRequest(String targetName, int currentTier, List<Request> requests) {
            if (isDisabled) {
                return Collections.<Response>nCopies(requests.size(), new ErrorResponse("Link disabled"));
            }

            Packet inPacket = marshalRequests(targetName, currentTier, requests);

            if (isICLoggingEnabled) {
                logger.fine("[" + name + " >>> " + targetName + "] " + requests + " with " + inPacket.getTransportType());
            }

            Packet outPacket;
            try {
                outPacket = packetSend(inPacket);
            } catch (IOException e) {
                logger.fine("[" + name + " <<< " + targetName + "] Error response");
                return Collections.<Response>nCopies(requests.size(), new ErrorResponse("Communication problem", e));
            }

            List<Response> responses = unmarshalResponse(outPacket);

            if (isICLoggingEnabled) {
                logger.fine("[" + name + " <<< " + targetName + "] " + responses);
            }

            /**
              * If all responses were received, answer.
              * Otherwise, fall back to ErrorResponse
              */
            if (responses.size() == requests.size()) {
                return responses;
            } else {
                return Collections.<Response>nCopies(requests.size(),
                        new ErrorResponse("Partial response: " + responses.size() + " of " + requests.size()));
            }
        }

        @Override
        public void flushMessages(int tier) {
            if (!messageBufferingEnabled || isDisabled) {
                return;
            }

            for (Map.Entry<String, Queue<Message>> entry : messageQueues.entrySet()) {
                Queue<Message> queue = entry.getValue();
                String targetName = entry.getKey();

                TransportType defaultTransport = Interconnect.this.getTransportType(name, targetName);

                MultiMap<TransportType, Message> messageByType = new HashMultiMap<>();
                
                Message message;
                while ((message = queue.poll()) != null) {
                    TransportType hint = message.getTransportHint();
                    if (hint == null) {
                        messageByType.put(defaultTransport, message);
                    } else {
                        messageByType.put(hint, message);
                    }
                }

                for (Collection<Message> bulk : messageByType.asMap().values()) {
                    if (bulk.size() > 0) {
                        List<Message> messages = new ArrayList<>(bulk);
                        Packet inPacket = marshalMesages(targetName, tier, messages);

                        if (isICLoggingEnabled) {
                            logger.fine("[" + name + " >>> " + targetName + "] " + messages + " with " + inPacket.getTransportType());
                        }

                        try {
                            packetSend(inPacket);
                        } catch (IOException e) {
                            // do nothing
                        }
                    }
                }
            }
        }

        @Override
        public void sendMessage(String targetName, int tier, List<Message> messages) {
            if (isDisabled) {
                return;
            }

            if (messageBufferingEnabled) {
                Queue<Message> queue = messageQueues.getOrCreate(targetName);
                queue.addAll(messages);
                return;
            }

            Packet inPacket = marshalMesages(targetName, tier, messages);

            if (isICLoggingEnabled) {
                logger.fine("[" + name + " >>> " + targetName + "] " + messages + " with " + inPacket.getTransportType());
            }

            try {
                packetSend(inPacket);
            } catch (IOException e) {
                // do nothing
            }
        }

        @Override
        public Response sendRequest(String targetName, int tier, Request request) {
            return sendRequest(targetName, tier, Collections.singletonList(request)).get(0);
        }

        @Override
        public void sendMessage(String targetName, int tier, Message message) {
            sendMessage(targetName, tier, Collections.singletonList(message));
        }

        @Override
        public PreparedBatch prepareRequests(String target, int tier, List<Request> requests) {
            Packet packet = marshalRequests(target, tier, requests);
            PreparedBatch batch = new PreparedBatch(sequencer.next(), requests.size());
            preparedData.put(batch, packet);

            if (isICLoggingEnabled) {
                logger.fine("[" + packet.getFrom() + " >>> " + packet.getTo() + "] Prepared batch " + batch);
            }

            return batch;
        }

        @Override
        public PreparedBatch prepareMessages(String target, int tier, List<Message> messages) {
            Packet packet = marshalMesages(target, tier, messages);
            PreparedBatch batch = new PreparedBatch(sequencer.next(), messages.size());
            preparedData.put(batch, packet);

            if (isICLoggingEnabled) {
                logger.fine("[" + packet.getFrom() + " >>> " + packet.getTo() + "] Prepared batch " + batch);
            }

            return batch;
        }

        @Override
        public PreparedBatch prepareRequest(String target, int tier, Request request) {
            return prepareRequests(target, tier, Collections.singletonList(request));
        }

        @Override
        public PreparedBatch prepareMessage(String target, int tier, Message message) {
            return prepareMessages(target, tier, Collections.singletonList(message));
        }

        @Override
        public List<Response> sendPreparedRequests(PreparedBatch batch) {
            Packet inPacket = preparedData.get(batch);

            if (inPacket == null) {
                logger.warning("Prepared batch #" + batch + " is not found");
                throw new IllegalArgumentException("Prepared batch #" + batch + " is not found");
            }

            if (isICLoggingEnabled) {
                logger.fine("[" + name + " >>> " + inPacket.getTo() + "] Send prepared batch " + batch);
            }

            
            Packet outPacket;
            try {
                outPacket = packetSend(inPacket);
            } catch (IOException e) {
                return Collections.<Response>nCopies(batch.getSize(), new ErrorResponse("Communication error", e));
            }

            List<Response> responses = unmarshalResponse(outPacket);

            if (isICLoggingEnabled) {
                logger.fine("[" + name + " <<< " + outPacket.getFrom() + "] " + responses);
            }

            return responses;
        }

        @Override
        public void sendPreparedMessages(PreparedBatch batch) {
            Packet inPacket = preparedData.get(batch);

            if (inPacket == null) {
                logger.warning("Prepared batch #" + batch + " is not found");
                throw new IllegalArgumentException("Prepared batch #" + batch + " is not found");
            }

            if (isICLoggingEnabled) {
                logger.fine("[" + name + " >>> " + inPacket.getTo() + "] Send prepared batch " + batch);
            }

            try {
                packetSend(inPacket);
            } catch (IOException e) {
                // do nothing
            }
        }

        @Override
        public Response sendPreparedRequest(PreparedBatch batch) {
            List<Response> responses = sendPreparedRequests(batch);
            if (responses.size() == 1) {
                return responses.get(0);
            }
            throw new IllegalStateException("Trying to return single response, while was " + responses.size() + " available");
        }

        @Override
        public void sendPreparedMessage(PreparedBatch batch) {
            sendPreparedMessages(batch);
        }

        @Override
        public void register(ConnectionClient client) {
            Interconnect.this.addLink(client);
        }

        @Override
        public void register(ConnectionClient client, MessageDrainer drainer) {
            Interconnect.this.addLink(client, drainer);
        }

        @Override
        public void deregister(ConnectionClient client) {
            Interconnect.this.removeLink(client);
        }

        @Override
        public void disable() {
            isDisabled = true;
        }

        @Override
        public Collection<LocationInfo> getLocationInfo(String name) {
            return Interconnect.this.getLocationInfo(name);
        }

        private Packet packetSend(Packet outPacket) throws IOException {
            try {
                return Interconnect.this.forward(outPacket, true, false);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IOException("Interrupted", e);
            }
        }

        private Packet marshalRequests(String target, int tier, List<Request> requests) {
            TransportType hint = mergeHints(requests);

            TransportType transportType;
            if (isICfavorTransportHints && hint != null) {
                transportType = hint;
            } else {
                transportType = Interconnect.this.getTransportType(name, target);
            }

            if (transportType != null) {
                /**
                 * Transports to use for that client.
                 */
                Transport<Incoming, Data> incomingTransport = transportFactory.getIncomingTransport(transportType);

                /**
                 * Marshal and send request.
                 * This wraps up all requests in one solid request.
                 */
                CompositeRequest compositeRequest = new CompositeRequest(requests);
                Data inData = incomingTransport.convertDown(compositeRequest);
                Packet inPacket = new Packet(name, target, transportType, inData, true, tier);

                accountPacket(inPacket, requests);

                return inPacket;
            }

            throw new IllegalStateException("Unable to prepare data for send");
        }

        private Packet marshalMesages(String targetName, int tier, List<Message> messages) {

            TransportType hint = mergeHints(messages);

            TransportType transportType;
            if (isICfavorTransportHints && hint != null) {
                transportType = hint;
            } else {
                transportType = Interconnect.this.getTransportType(name, targetName);
            }

            if (transportType != null) {
                if (isICLoggingEnabled) {
                    logger.fine("[" + name + " >>> " + targetName + "] " + messages + " with " + transportType);
                }

                /**
                 * Transports to use for destination client.
                 */
                Transport<Incoming, Data> incomingTransport = transportFactory.getIncomingTransport(transportType);
                /**
                 * Marshal and send messages
                 * This wraps up all messages in one solid message.
                 */
                CompositeMessage compositeMessage = new CompositeMessage(messages);
                Data inData = incomingTransport.convertDown(compositeMessage);
                Packet packet = new Packet(name, targetName, transportType, inData, false, tier);

                accountPacket(packet, messages);

                return packet;
            }

            throw new IllegalStateException("Unable to prepare data for send");
        }

        private List<Response> unmarshalResponse(Packet outPacket) {
            Transport<Outgoing, Data> outgoingTransport = transportFactory.getOutgoingTransport(outPacket.getTransportType());
            CompositeResponse response = (CompositeResponse) outgoingTransport.convertUp(outPacket.getData());
            List<Response> responses = response.getResponses();
            accountPacket(outPacket, responses);
            return responses;
        }

        @Override
        public void instrument(Probe probe) {
            Interconnect.this.instrument(probe);
        }

        @Override
        public void sample() {
            Interconnect.this.sample();
        }
    }

    private static TransportType mergeHints(Collection<? extends Transportable> transportables) {
        /*
           Rules for merging hints:
             - any hint takes precendence over null hint
             - all non-null hints should be the same
         */

        TransportType type = null;
        for (Transportable t : transportables) {

            TransportType hint = t.getTransportHint();
            if (hint != null) {
                if (type == null) {
                    type = hint;
                } else if (type != hint) {
                    throw new IllegalStateException("Transport hints mismatched: expected " + type + ", but was " + hint + " on " + t);
                }
            }
        }

        return type;
    }

    private Collection<LocationInfo> getLocationInfo(String name) {
        if (downlinks.get(name) != null) {
            return Collections.singleton(LocationInfo.LOCAL);
        } else {
            return registry.getInfo(name);
        }
    }

    /**
     * Downlink:
     * Used for interconnect to communicate with clients.
     * Downlink is used for inbound connections.
     */
    public class Downlink {

        private final String name;
        private volatile ConnectionClient client;
        private Logger logger;
        private final boolean isICLoggingEnabled;
        private final boolean isICfavorTransportHints;
        private volatile boolean isDisabled;
        private final TransportFactory transportFactory;
        private final int messageTier;

        public Downlink(String name, ConnectionClient client) {
            this.name = name;
            this.client = client;
            this.isICLoggingEnabled = JbbProperties.getInstance().isICloggingEnabled();
            this.isICfavorTransportHints = JbbProperties.getInstance().isICfavorTransportHints();
            this.logger = Logger.getLogger("org.spec.jbb.comm." + name + ".downlink");
            this.transportFactory = TransportFactory.getInstance();
            this.messageTier = JbbProperties.getInstance().getMessageTier();
        }

        public Packet accept(Packet packet, boolean isRemote) {
            if (packet.shouldBeAnswered()) {
                return acceptRequest(packet, isRemote);
            } else {
                acceptMessage(packet, isRemote);
                return Packet.NO_DATA;
            }
        }

        /**
         * Accept the incoming request data
         * @param packet packet to accept
         * @return response data to accept
         */
        public Packet acceptRequest(Packet packet, boolean isRemote) {
            /**
             * Unmarshal incoming data.
             */
            Incoming incoming = transportFactory.getIncomingTransport(packet.getTransportType()).convertUp(packet.getData());
            List<Request> requests = ((CompositeRequest) incoming).getRequests();

            if (isICLoggingEnabled) {
                logger.fine("[" + packet.getFrom() + " >>> " + name + "] " + requests + " with " + packet.getTransportType());
            }

            /**
             * Choose tier to which this request should go.
             * Normally, request should go to the maximum tier of all requests.
             * Exceptions are when request is coming from Driver, then it should be submitted to base tier.
             * If request is coming from other IC, it should be submitted to upper tier.
             *
             * All requests should agree on target tier, since TransactionContext uses that to determine next one.
             */
            int currentTier = packet.getCurrentTier();
            int targetTier;

            if (currentTier == Conventions.TIER_DRIVER) {
                targetTier = Conventions.TIER_BACKEND_FIRST;
            } else {
                targetTier = currentTier;
                if (isRemote) {
                    targetTier = currentTier + 1;
                }
            }

            /**
             * Push to client
             */
            List<Response> responses;
            if (!isDisabled) {
                responses = client.handle(packet.getFrom(), requests, currentTier, targetTier);
            } else {
                responses = Collections.<Response>nCopies(requests.size(), new ErrorResponse("Down link is disabled"));
                logger.fine("downlink is disabled, request blackholed");
            }

            accountPacket(packet, requests);

            if (isICLoggingEnabled) {
                logger.fine("[" + packet.getFrom() + " <<< " + name + "] " + responses + " with " + packet.getTransportType());
            }

            /**
             * Marshal the response
             */

            TransportType hint = mergeHints(responses);

            TransportType transportType;
            if (isICfavorTransportHints && hint != null) {
                transportType = hint;
            } else {
                transportType = Interconnect.this.getTransportType(name, packet.getFrom());
            }

            Data data = transportFactory.getOutgoingTransport(transportType).convertDown(new CompositeResponse(responses));

            Packet outPacket = new Packet(name, packet.getFrom(), transportType, data, false, Conventions.TIER_DEFAULT);
            accountPacket(outPacket, responses);
            return outPacket;
        }

        /**
         * Accept the incoming message data.
         * @param packet packet to accept
         */
        public void acceptMessage(Packet packet, boolean isRemote) {
            /**
             * Unmarshal incoming data
             */
            Incoming incoming = transportFactory.getIncomingTransport(packet.getTransportType()).convertUp(packet.getData());
            List<Message> messages = ((CompositeMessage) incoming).getMessages();

            if (isICLoggingEnabled) {
                logger.finest("[? " + packet.getFrom() + " >>> " + name + "] " + messages + " with " + packet.getTransportType());
            }

            /**
             * Choose tier to which this message should go.
             * Normally, message should go to the maximum tier of all messages.
             * Exceptions are when messages is coming from Driver, then it should be submitted to base tier.
             * If message is coming from other IC, it should be submitted to upper tier.
             * If message is coming even from this IC, it should be submitted to upper tier to preserve asynchronicity.
             *
             * All messages should agree on target tier, since TransactionContext uses that to determine next one.
             */
            int currentTier = packet.getCurrentTier();
            int targetTier;

            if(messageTier != 0) {
                targetTier = messageTier;
            } else if (currentTier == Conventions.TIER_DRIVER) {
                targetTier = Conventions.TIER_BACKEND_FIRST;
            } else {
                targetTier = currentTier + 1;
            }

            accountPacket(packet, messages);

            /**
             * Push to client
             */
            if (!isDisabled) {
                client.handleMessage(packet.getFrom(), messages, currentTier, targetTier);
            } else {
                logger.fine("downlink is disabled, message blackholed");
            }
        }

        public void disable() {
            isDisabled = true;
            client = null;
        }
    }

}
