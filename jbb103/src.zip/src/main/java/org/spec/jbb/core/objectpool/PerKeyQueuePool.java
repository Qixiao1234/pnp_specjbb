/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.objectpool;

import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.probe.ProbeFactory;
import org.spec.jbb.core.threadpools.Adapters;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.LinkedBlockingDeque;

public class PerKeyQueuePool<K extends PoolKey, T extends Poolable> implements ObjectPool<K, T> {

    private final ObjectFactory<K, T> factory;
    private final int objPerQueue;

    private final ConcurrentMap<K, BlockingDeque<LazyFactoryCall>> queues;
    private final SealableSet<T> issued;
    private volatile Probe probe;

    public PerKeyQueuePool(ObjectFactory<K, T> factory, int objPerQueue) {
        this.factory = factory;
        this.objPerQueue = objPerQueue;
        this.queues = new ConcurrentHashMap<>();
        this.issued = new SealableSet<>();
        this.probe = ProbeFactory.getDefaultProbe();
    }

    @Override
    public T acquire(K key) throws PoolException, InterruptedException {

        /**
         * This method is thread-safe.
         */
        BlockingDeque<LazyFactoryCall> queue = queues.get(key);
        if (queue == null) {

            /**
             * No assigned queue.
             * Create one and inflate it to maximum size with lazy calls.
             */
            queue = new LinkedBlockingDeque<>(objPerQueue);
            for (int c = 0; c < objPerQueue; c++) {
                boolean offer = queue.offer(new LazyFactoryCall(key));
                if (!offer) {
                    throw new IllegalStateException("Queue had declined our offer");
                }
            }

            /**
             * Atomically put in CHM.
             * If mapping already exists, just use existing one. In that case,
             * just created queue will be GCed, and we don't really care,
             * because no T objects were really created.
             */
            BlockingDeque<LazyFactoryCall> prevQueue = queues.putIfAbsent(key, queue);
            if (prevQueue != null) {
                queue = prevQueue;
            }
        }

        /**
         * Get the value, possibly calling factory.
         */
        LazyFactoryCall call = Adapters.takeFirst(queue);
        try {
            return call.get();
        } catch (PoolException | InterruptedException e) {
            queue.offerFirst(new LazyFactoryCall(key));
            throw e;
        }
    }

    @Override
    public void release(K key, final T object) {
        if (key == null) {
            dispose(object);
            return;
        }

        BlockingDeque<LazyFactoryCall> queue = queues.get(key);
        if (queue == null || !queue.offerFirst(new LazyFactoryCall(key, object))) {
            dispose(object);
        }
    }

    @Override
    public void destroy(K key, T object) {
        BlockingDeque<LazyFactoryCall> queue = queues.get(key);
        if (queue != null) {
            queue.offerFirst(new LazyFactoryCall(key));
        }
        
        dispose(object);
    }

    @Override
    public void shutdown() {
        issued.seal();
        for (T object : issued) {
            object.dispose();
        }
        issued.clear();
        factory.shutdown();
    }
    
    private void dispose(T object) {
        if (object != null) {
            issued.remove(object);
            object.dispose();
        }
    }

    @Override
    public void instrument(Probe probe) {
        this.probe = probe;
    }

    @Override
    public void sample() {
        for (K key : queues.keySet()) {
            BlockingDeque<LazyFactoryCall> queue = queues.get(key);
            Probe p = probe.getChild("{" + key.toString() + "}");
            p.sample("capacity", objPerQueue);
            p.sample("busy", objPerQueue - queue.size());
        }
        probe.sample("issued", issued.size());
    }

    private class LazyFactoryCall {
        private T object;
        private K key;

        public LazyFactoryCall(K key, T object) {
            this.key = key;
            this.object = object;
        }

        public LazyFactoryCall(K key) {
            this.key = key;
        }

        public T get() throws PoolException, InterruptedException {
            if (object == null) {
                object = factory.get(key);
                if (!issued.add(object)) {
                    object.dispose();
                    object = null;
                }
            }
            return object;
        }
    }


    private static class SealableSet<E> implements Iterable<E> {
        private volatile boolean isSealed;
        private final Set<E> set;
        
        public SealableSet() {
            set = Collections.synchronizedSet(Collections.newSetFromMap(new IdentityHashMap<E, Boolean>()));
        }

        public boolean add(E e) {
            if (!isSealed) {
                return set.add(e);
            } else {
                return false;
            }
        }
        
        public void remove(E e) {
            set.remove(e);
        }

        public void seal() {
            isSealed = true;
        }

        public void clear() {
            set.clear();
        }
        
        @Override
        public Iterator<E> iterator() {
            return set.iterator();
        }

        public int size() {
            return set.size();
        }
    }

}
