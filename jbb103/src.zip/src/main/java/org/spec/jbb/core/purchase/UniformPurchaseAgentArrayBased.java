/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.purchase;

import org.spec.jbb.util.random.UniformRandom;

public class UniformPurchaseAgentArrayBased extends PurchaseAgentArrayBased {
    
    public UniformPurchaseAgentArrayBased() {
        super();
        random = new UniformRandom(0d, (double)(barcodes.size() - 1));
    }

}
