/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections.sampling;

import org.spec.jbb.core.collections.queues.QueueFactory;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Queue;

/**
 * Queued sampling buffer.
 *
 * @param <T>
 */
public class QueuedSamplingBuffer<T> implements SamplingBuffer<T>, Serializable {

    private static final long serialVersionUID = 2507363333210214032L;

    private final Queue<T> backingQueue;

    public QueuedSamplingBuffer(int capacity) {
        backingQueue = QueueFactory.getBoundedQueue(capacity);
    }

    @Override
    public void put(T element) {
        while(!backingQueue.offer(element)) {
            backingQueue.poll();
        }
    }

    @Override
    public int size() {
        return backingQueue.size();
    }

    @Override
    public List<T> snapshot() {
        return new ArrayList<>(backingQueue);
    }

    @Override
    public T get() {
        return backingQueue.peek();
    }

    @Override
    public void putAll(Collection<T> elements) {
        for (T element : elements) {
            put(element);
        }
    }
}
