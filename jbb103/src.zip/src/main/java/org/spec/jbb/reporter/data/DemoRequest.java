/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter.data;

import org.spec.jbb.core.comm.AbstractRequest;
import org.spec.jbb.reporter.Frame;

public class DemoRequest extends AbstractRequest {
    private static final long serialVersionUID = 4023329100475935923L;
    
    private final Frame frame;

    public DemoRequest(Frame frame) {
        this.frame = frame;
    }

    public Frame getFrame() {
        return frame;
    }
    
}
