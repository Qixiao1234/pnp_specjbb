/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport;

public class TransportPipeline<CT, MT> implements Transport<CT, MT> {

    private final Layer<CT, MT> marshaller;
    private final Layer<MT, MT> compressor;
    private final Layer<MT, MT> encryptor;

    public TransportPipeline(Layer<CT, MT> encapsulator,
                             Layer<MT, MT> encryptor,
                             Layer<MT, MT> compressor) {
        this.marshaller = encapsulator;
        this.encryptor = encryptor;
        this.compressor = compressor;
    }

    @Override
    public MT convertDown(CT concreteInstance) {

        /**
         * Marshalling.
         */
        MT afterMarshal = marshaller.convertDown(concreteInstance);

        /**
         * Compressing.
         */
        MT afterCompress = compressor.convertDown(afterMarshal);

        /**
         * Encrypting.
         */
        MT afterEncrypt = encryptor.convertDown(afterCompress);

        return afterEncrypt;
    }

    @Override
    public CT convertUp(MT bottomInstance) {

        /**
         * Decrypting.
         */
        MT afterDecrypt = encryptor.convertUp(bottomInstance);

        /**
         * Decompressing.
         */
        MT afterDecompress = compressor.convertUp(afterDecrypt);

        /**
         * Unmarshalling.
         */
        CT afterUnmarshal = marshaller.convertUp(afterDecompress);

        return afterUnmarshal;
    }


}
