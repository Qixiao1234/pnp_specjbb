/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.request;

import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.CustomerBuyingBehaviorTransaction;
import org.spec.jbb.sm.tx.request.AbstractBusinessTxInjectorRequest;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
public class CustomerBuyingBehaviorRequest extends AbstractBusinessTxInjectorRequest {
    private static final long serialVersionUID = 7515971010597875480L;
    @XmlElement
    private final String smName;

    private CustomerBuyingBehaviorRequest() {
        // JAXB
        this(null, false);
    }

    public CustomerBuyingBehaviorRequest(String sm, boolean isSaturate) {
        super(isSaturate);
        this.smName = sm;
    }

    public String getSmName() {
        return smName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        CustomerBuyingBehaviorRequest that = (CustomerBuyingBehaviorRequest) o;

        if (smName != null ? !smName.equals(that.smName) : that.smName != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), smName);
    }

    @Override
    public String toString() {
        return "CustomerBuyingBehaviorRequest: " + smName;
    }

    @Override
    public Transaction getTransaction(HQ hq, TransactionContext ctx) {
        return new CustomerBuyingBehaviorTransaction(hq, this, ctx);
    }
}
