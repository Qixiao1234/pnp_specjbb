/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.request;

import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.tx.ReserveInventoryTransaction;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ReserveInventoryRequest extends InventoryRequest {

    private static final long serialVersionUID = 2735782788932230393L;

    @SuppressWarnings("unused")
    private ReserveInventoryRequest() {
        // JAXB
        this(0, 0);
    }

    public ReserveInventoryRequest(long barCode, int quantity) {
        super(barCode, quantity);
    }

    @Override
    public Transaction getTransaction(SM sm, TransactionContext ctx) {
        return new ReserveInventoryTransaction(sm, this, ctx);
    }

    @Override
    public String toString() {
        return "Reserve " + super.toString();
    }

}
