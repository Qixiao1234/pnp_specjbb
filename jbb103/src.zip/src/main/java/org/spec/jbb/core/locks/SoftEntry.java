/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.locks;

import java.lang.ref.ReferenceQueue;
import java.lang.ref.SoftReference;

/**
 * Soft reference key, required to override equals()/hashCode().
 *
 * @param <K>
 */
public class SoftEntry<K, V> extends SoftReference<V> implements Entry<K, V> {
    private final K key;

    public SoftEntry(K key, V value, ReferenceQueue<V> queue) {
        super(value, queue);
        this.key = key;
    }

    @Override
    public boolean equals(Object o) {
        return key.equals(o);
    }

    @Override
    public int hashCode() {
        return key.hashCode();
    }

    public K getKey() {
        return key;
    }
}