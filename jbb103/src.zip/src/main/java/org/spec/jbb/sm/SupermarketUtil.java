/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm;

import org.spec.jbb.core.generator.ProductGenerator;
import org.spec.jbb.hq.entity.Product;
import org.spec.jbb.sm.inventory.Inventory;
import org.spec.jbb.sm.inventory.InventoryFactory;

import java.util.List;

public class SupermarketUtil {

    public static Inventory createInventory() {
        Inventory inventory = InventoryFactory.makeInventory();
        populateInventory(inventory);
        return inventory;
    }

    /**
     * Populate inventory using RandomData class
     *
     * @param inventory
     */
    private static void populateInventory(Inventory inventory) {
        List<Product> products = new ProductGenerator().generate();
        for (Product product : products) {
            inventory.moveIn(product.getBarcode(), product.getProductQuantity());
        }
    }

}
