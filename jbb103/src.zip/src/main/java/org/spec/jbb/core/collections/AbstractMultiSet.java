/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

import java.util.Collection;
import java.util.Set;

public abstract class AbstractMultiSet<E> implements MultiSet<E> {

    transient Set<E> elementSet;
    transient Set<MultiSet.Entry<E>> entrySet;

    @Override
    public void add(E element) {
        update(element, 1);
    }

    @Override
    public void add(E element, int occurrence) {
        update(element, occurrence);
    }

    @Override
    public void addAll(Collection<E> elements) {
        for(E e : elements) {
            update(e, 1);
        }
    }

    @Override
    public void addAll(Collection<E> elements, int occurrence) {
        for(E e : elements) {
            update(e, occurrence);
        }
    }

    @Override
    public boolean contains(Object element) {
        return count(element) > 0;
    }

    @Override
    public void remove(E element) {
        update(element, -1);
    }

    @Override
    public void remove(E element, int occurrence) {
        update(element, -occurrence);
    }

    abstract void update(E e, int count);

    @Override
    public int hashCode() {
        return elementSet().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MultiSet)) {
            return false;
        }
        MultiSet<E> m = (MultiSet<E>) obj;
        Set<E> elements = this.elementSet();
        if (!elements.equals(m.elementSet())) {
            return false;
        }
        for (E e : elements) {
            if (this.count(e) != m.count(e)) {
                return false;
            }
        }
        return true;
    }

}
