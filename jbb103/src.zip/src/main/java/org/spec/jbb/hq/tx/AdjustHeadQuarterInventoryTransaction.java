/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.entity.Receipt;
import org.spec.jbb.hq.tx.request.AdjustHeadQuarterInventoryMessage;

public class AdjustHeadQuarterInventoryTransaction extends AbstractTransaction {
    private final HQ hq;
    private final Receipt receipt;
    private final HQ.SMInventoryDirection movement;

    public AdjustHeadQuarterInventoryTransaction(HQ hq, AdjustHeadQuarterInventoryMessage msg, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        this.receipt = msg.getReceipt();
        this.movement = msg.getMovement();
    }

    @Override
    public Response execute() {
        hq.adjustSupermarketInventory(ctx, receipt, movement, false);
        return new OkResponse();
    }

    @Override
    public String toString() {
        return "Adjust HeadQuarter Inventory Transaction: receipt={" + receipt + "}";
    }
}
