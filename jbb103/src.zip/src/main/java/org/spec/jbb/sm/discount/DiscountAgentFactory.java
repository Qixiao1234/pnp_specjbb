/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.discount;


/**
 * The factory to create Discount agent
 * Currently only one Discount agent is supported
 */
public class DiscountAgentFactory {

    /**
     * Only static usage is allowed
     */
    private DiscountAgentFactory() {
        
    }
    
    public static DiscountAgent createDiscountAgent() {
        // Currently only Basic agent is supported
        return new BasicDiscountAgent();
    }
}
