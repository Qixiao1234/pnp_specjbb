/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.objectpool;

import org.spec.jbb.core.probe.Probe;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;

/**
 * Ignorant object pool does not actually pool objects.
 * All objects returned to this pool will be destroyed ASAP.
 *
 * @param <K>
 * @param <T>
 */
public class IgnorantPool<K extends PoolKey, T extends Poolable> implements ObjectPool<K, T> {

    private final ObjectFactory<K, T> factory;

    private final Set<T> issuedObjects;

    public IgnorantPool(ObjectFactory<K, T> factory) {
        this.factory = factory;
        this.issuedObjects = Collections.synchronizedSet(Collections.newSetFromMap(new IdentityHashMap<T, Boolean>()));
    }

    @Override
    public T acquire(K key) throws PoolException, InterruptedException {
        T object = factory.get(key);
        issuedObjects.add(object);
        return object;
    }

    @Override
    public void release(K key, T object) {
        if (issuedObjects.remove(object)) {
            object.dispose();
        }
    }

    @Override
    public void destroy(K key, T object) {
        release(key, object);
    }

    @Override
    public void shutdown() {
        synchronized (issuedObjects) {
            for (T object : issuedObjects) {
                object.dispose();
            }
        }
    }

    @Override
    public void instrument(Probe probe) {
        // do nothing
    }

    @Override
    public void sample() {
        // do nothing
    }
}
