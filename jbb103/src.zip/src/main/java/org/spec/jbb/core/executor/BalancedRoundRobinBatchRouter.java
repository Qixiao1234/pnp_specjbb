/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.executor;

import org.spec.jbb.core.comm.Message;
import org.spec.jbb.core.comm.Request;
import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.comm.Uplink;
import org.spec.jbb.core.tx.response.ErrorResponse;

import java.util.Collections;
import java.util.List;


public class BalancedRoundRobinBatchRouter extends AbstractBatchRouter {

    private int executor_pos;
    private Uplink link;

    public BalancedRoundRobinBatchRouter(String name, String... names) {
        super(name, names);
        this.executor_pos = 0;
    }

    @Override
    public List<Response> handle(String from, List<Request> requests, int currentTier, int targetTier) {
        String[] targets = getTargets();

        if (targets.length == 0) {
            return Collections.<Response>nCopies(requests.size(), new ErrorResponse(getName() + " router had rejected"));
        }

        executor_pos = (executor_pos + 1) % targets.length;

        String target = targets[executor_pos];

        List<Response> responseList = link.sendRequest(target, targetTier, requests);
        if (responseList.size() == requests.size()) {
            return responseList;
        } else {
            return Collections.<Response>nCopies(requests.size(), new ErrorResponse(getName() + " request size didn't match"));
        }
    }

    @Override
    public void handleMessage(String from, List<Message> messages, int currentTier, int targetTier) {
        String[] targets = getTargets();

        if (targets.length == 0) {
            return;
        }

        executor_pos = (executor_pos + 1) % targets.length;
        String target = targets[executor_pos];
        link.sendMessage(target, targetTier, messages);
    }

    @Override
    public void setUplink(Uplink link) {
        this.link = link;
    }

    @Override
    public Uplink getLink() {
        return link;
    }
}