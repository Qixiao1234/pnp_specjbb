/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.sequencer;

import java.util.concurrent.atomic.AtomicLong;

public class AtomicGrowingSequencer implements Sequencer<Long> {

    private final AtomicLong counter;

    public AtomicGrowingSequencer() {
        this.counter = new AtomicLong();
    }

    @Override
    public Long next() {
        return counter.incrementAndGet();
    }
}
