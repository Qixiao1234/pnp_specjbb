/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.response;

import org.spec.jbb.core.comm.AbstractResponse;
import org.spec.jbb.hq.entity.Receipt;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
public class PurchaseResponse extends AbstractResponse {

    private static final long serialVersionUID = -1608345788045925210L;
    @XmlElement
    private final Receipt receipt;

    private PurchaseResponse() {
        // JAXB
        this(null);
    }

    public PurchaseResponse(Receipt receipt) {
        this.receipt = receipt;
    }

    public Receipt getReceipt() {
        return receipt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        PurchaseResponse that = (PurchaseResponse) o;

        if (receipt != null ? !receipt.equals(that.receipt) : that.receipt != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), receipt);
    }

    @Override
    public String toString() {
        return "Purchase ok, receipt={" + receipt + "}";
    }

}
