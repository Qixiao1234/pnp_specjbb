/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.mapreduce;

public interface Actor<T, E> {
    E act(T value) throws Exception;
}
