/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Message;
import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.request.OnlineOrderProcessRequest;
import org.spec.jbb.of.tx.request.InStorePickupProcessMessage;
import org.spec.jbb.of.tx.request.ShippingOrderProcessMessage;
import org.spec.jbb.sm.entity.InStorePickupOrder;
import org.spec.jbb.sm.entity.ShippingOrder;

import java.util.ArrayList;
import java.util.List;

public class OnlineOrderProcessTransaction extends AbstractTransaction {

    private static final int BATCH_DIV = 1;
    private static final int MESSAGE_BATCHSIZE = 100;
    private HQ hq;
    private final boolean instorePickup;

    public OnlineOrderProcessTransaction(HQ hq,
            OnlineOrderProcessRequest incoming, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        this.instorePickup = incoming.isInstorePickup();
    }

    @Override
    public Response execute() throws TransactionException {
        if (instorePickup) {
            return executeInstoreOrder();
        } else {
            return executeShippingOrder();
        }
    }

    private Response executeInstoreOrder() {
        long batchSize = hq.getOnlinePurchaseInstorePickupQueueSize()
                / BATCH_DIV;
        List<Message> messages = new ArrayList<>();
        for (int index = 0; index < batchSize; index++) {
            InStorePickupOrder order = hq.getNextInStorePickup();
            if (order == null) {
                break;
            }
            messages.add(new InStorePickupProcessMessage(order));
            if (messages.size() >= MESSAGE_BATCHSIZE) {
                sendMessage(messages);
                messages = new ArrayList<>();
            }
        }
        sendMessage(messages);
        return new OkResponse();
    }

    private Response executeShippingOrder() {
        long batchSize = hq.getOnlinePurchaseShippingQueueSize() / BATCH_DIV;
        List<Message> messages = new ArrayList<>();
        for (int index = 0; index < batchSize; index++) {
            ShippingOrder order = hq.getNextShippingOrder();
            if (order == null) {
                break;
            }
            messages.add(new ShippingOrderProcessMessage(order));
            if (messages.size() >= MESSAGE_BATCHSIZE) {
                sendMessage(messages);
                messages = new ArrayList<>();
            }
        }
        sendMessage(messages);
        return new OkResponse();
    }

    protected void sendMessage(List<Message> messages) {
        if (messages.size() > 0) {
            ctx.sendMessage(hq.getOrderFulfillmentName(), messages);
        }
    }

    @Override
    public String toString() {
        return "OrderOnlineProcessTx: inStorePickup={" + instorePickup + "}";
    }

}
