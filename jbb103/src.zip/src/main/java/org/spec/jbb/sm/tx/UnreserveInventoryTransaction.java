/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sm.tx.request.UnreserveInventoryRequest;

public class UnreserveInventoryTransaction extends AbstractInventoryTransaction {

    public UnreserveInventoryTransaction(SM sm, UnreserveInventoryRequest request, TransactionContext ctx) {
        super(sm, request.getBarcode(), request.getQuantity(), ctx);
    }

    @Override
    public Response execute() throws TransactionException {
        unreserveProduct(getBarcode(), getQuantity());
        return new OkResponse();
    }

    @Override
    public String toString() {
        return super.toString() + ", UNRESERVE";
    }
}
