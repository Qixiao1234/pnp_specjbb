/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.policy;

import org.spec.jbb.core.Conventions;
import org.spec.jbb.core.EntityType;
import org.spec.jbb.core.comm.transport.TransportType;

public class BalancedPolicy implements TransportSelectionPolicy {

    @Override
    public TransportType get(String fromName, String toName, boolean spanningMultipleICs) {

        EntityType fromType = guessEntityType(fromName);
        EntityType toType = guessEntityType(toName);

        if (match(fromType, toType, EntityType.SM, EntityType.SP)) {
            return TransportType.XML;
        }

        if (match(fromType, toType, EntityType.SM, EntityType.HQ)) {
            return TransportType.SERIALIZED_COMPRESSED_ENCRYPTED;
        }

        if (match(fromType, toType, EntityType.HQ, EntityType.SP)) {
            return TransportType.XML;
        }

        if (spanningMultipleICs) {
            return TransportType.SERIALIZED;
        } else {
            return TransportType.PLAIN;
        }
    }

    private boolean match(EntityType t1, EntityType t2, EntityType v1, EntityType v2) {
        return (t1 == v1 && t2 == v2) || (t1 == v2 && t2 == v1);
    }

    private EntityType guessEntityType(String name) {
        if (Conventions.isSP(name)) {
            return EntityType.SP;
        }

        if (Conventions.isSM(name)) {
            return EntityType.SM;
        }

        if (Conventions.isHQ(name)) {
            return EntityType.HQ;
        }

        if (Conventions.isTxInjectorComponent(name)) {
            return EntityType.TXINJECTOR;
        }

        if (Conventions.isController(name)) {
            return EntityType.CONTROLLER;
        }

        return EntityType.DUMMY;
    }

}
