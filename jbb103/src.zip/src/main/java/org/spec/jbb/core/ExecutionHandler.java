/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core;

import org.spec.jbb.core.comm.Incoming;
import org.spec.jbb.core.comm.Outgoing;
import org.spec.jbb.core.tx.TransactionException;

public interface ExecutionHandler {

    Outgoing execute(int tier, Incoming incoming) throws TransactionException;

}
