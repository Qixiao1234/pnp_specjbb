/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.purchase;

import org.spec.jbb.util.random.UniformRandom;

public class PurchaseAgentBiased extends PurchaseAgentArrayBased {
    
    private int count = 0;

    public PurchaseAgentBiased() {
        super();
        random = new UniformRandom(0, barcodes.size() - 1) {

            @Override
            public long nextLong() {
                long res = super.nextLong();
                return (count++ % 2) == 0 ? res % 1000 : res;
            }
            
        };
    }

}
