/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.tx;


public abstract class AbstractTransaction implements Transaction {

    protected final TransactionContext ctx;

    public AbstractTransaction(TransactionContext ctx) {
        this.ctx = ctx;
    }

    @Override
    public String toString() {
        return "Unknown transaction: " + getClass();
    }

}
