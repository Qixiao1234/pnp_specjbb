/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.response;

import org.spec.jbb.core.comm.AbstractResponse;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ProductResolveFailedResponse extends AbstractResponse {
    private static final long serialVersionUID = -3705429766067157533L;

    @Override
    public String toString() {
        return "Product resolve failed";
    }
}
