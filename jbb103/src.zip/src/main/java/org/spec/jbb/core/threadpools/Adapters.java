/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

import org.spec.jbb.util.JbbProperties;

import java.util.concurrent.BlockingDeque;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.ForkJoinWorkerThread;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class Adapters {

    /**
     * Adapt future to use within threadpools.
     * Adapted future can be wait-by worker threads in pools, to let pools compensate for blocked workers.
     *
     * @param future future to adapt
     * @param <V> future type
     * @return adapter future
     */
    public static <V> Future<V> adapt(Future<V> future) {
        if (JbbProperties.getInstance().isFJPcompensate()) {
            return new ForkJoinFutureAdapter<>(future);
        } else {
            return future;
        }
    }

    /**
     * Sleep worker thread.
     * Thread pool will be able to compensate for sleeping thread.
     *
     * @param timeout delay to sleep
     * @param timeUnit delay to sleep
     * @throws InterruptedException
     */
    public static void sleep(long timeout, TimeUnit timeUnit) throws InterruptedException {
        if (JbbProperties.getInstance().isFJPcompensate()) {
            new ForkJoinSleeper(timeout, timeUnit).sleep();
        } else {
            timeUnit.sleep(timeout);
        }
    }

    /**
     * Adaptively block on Deque.takeFirst().
     * Thread pools will be able to compensate for blocked thread.
     *
     * @param queue queue to wait on
     * @param <T>
     * @return queue.takeFirst() result
     * @throws InterruptedException
     */
    public static <T> T takeFirst(BlockingDeque<T> queue) throws InterruptedException {
        if (JbbProperties.getInstance().isFJPcompensate()) {
            T result = queue.pollFirst();
            return result == null ? new ForkJoinBlockingDequeTaker<>(queue).take() : result;
        } else {
            return queue.take();
        }
    }

    /**
     * A single-client adapter for an arbitrary Future as used by a
     * ForkJoinTask.
     */
    private static class ForkJoinFutureAdapter<V> implements Future<V>, ForkJoinPool.ManagedBlocker {
        private final Future<V> future;
        private boolean timed;
        private long nanos; // for timed gets

        public ForkJoinFutureAdapter(Future<V> future) {
            this.future = future;
        }

        public boolean isDone() {
            return future.isDone();
        }

        public boolean isReleasable() {
            return future.isDone() || (Thread.currentThread().isInterrupted());
        }

        public boolean isCancelled() {
            return future.isCancelled();
        }

        public boolean cancel(boolean mayInterruptIfRunning) {
            return future.cancel(mayInterruptIfRunning);
        }

        public boolean block() throws InterruptedException {
            if (!future.isDone()) {
                try {
                    if (timed) {
                        future.get(nanos, TimeUnit.NANOSECONDS);
                    } else {
                        future.get();
                    }
                } catch (ExecutionException | TimeoutException e) {
                    // swallow
                }
            }
            return true;
        }

        public V get() throws InterruptedException, ExecutionException {
            if (!future.isDone() && !(future instanceof ForkJoinTask)
                    && (Thread.currentThread() instanceof ForkJoinWorkerThread)) {
                timed = false;
                ForkJoinPool.managedBlock(this);
            }
            return future.get();
        }

        public V get(long timeout, TimeUnit unit)
                throws InterruptedException, ExecutionException, TimeoutException {
            long resultWaitTime;
            long ns = unit.toNanos(timeout);
            if (future.isDone() || ns <= 0L) {
                resultWaitTime = 0L;
            } else if (future instanceof ForkJoinTask || !(Thread.currentThread() instanceof ForkJoinWorkerThread)) {
                resultWaitTime = ns;
            } else {
                resultWaitTime = 1L;
                nanos = (ns > 1L) ? ns - 1L : ns; // wait 1 ns after blocking
                timed = true;
                ForkJoinPool.managedBlock(this);
            }
            return future.get(resultWaitTime, TimeUnit.NANOSECONDS);
        }
    }

    /**
     * A single-use adapter to compensate pools while a ForkJoinTask
     * sleeps.
     */
    private static class ForkJoinSleeper implements ForkJoinPool.ManagedBlocker {

        private final long timeout;
        private final TimeUnit timeUnit;

        boolean slept;

        public ForkJoinSleeper(long timeout, TimeUnit timeUnit) {
            this.timeout = timeout;
            this.timeUnit = timeUnit;
        }

        public boolean isReleasable() {
            return slept || (Thread.currentThread().isInterrupted());
        }

        public boolean block() throws InterruptedException {
            if (!slept) {
                timeUnit.sleep(timeout);
                slept = true;
            }
            return true;
        }

        public void sleep() throws InterruptedException {
            if (!(Thread.currentThread() instanceof ForkJoinWorkerThread)) {
                timeUnit.sleep(timeout);
            }
            ForkJoinPool.managedBlock(this);
        }

    }

    /**
     * A single-client adapter for taking an element from a deque by a
     * ForkJoinTask.
     */
    public static final class ForkJoinBlockingDequeTaker<E> implements ForkJoinPool.ManagedBlocker {
        private final BlockingDeque<E> queue;
        private volatile E item;

        public ForkJoinBlockingDequeTaker(BlockingDeque<E> queue) {
            this.queue = queue;
        }

        public boolean isReleasable() {
            return item != null || (item = queue.pollFirst()) != null || (Thread.currentThread().isInterrupted());
        }

        public boolean block() throws InterruptedException {
            if (item == null) {
                item = queue.takeFirst();
            }
            return true;
        }

        public E take() throws InterruptedException {
            if (!(Thread.currentThread() instanceof ForkJoinWorkerThread)) {
                return queue.takeFirst();
            }
            E x;
            while ((x = item) == null && (x = item = queue.pollFirst()) == null) {
                ForkJoinPool.managedBlock(this);
            }
            return x;
        }
    }
}
