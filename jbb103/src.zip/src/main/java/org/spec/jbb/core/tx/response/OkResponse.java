/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.tx.response;

import org.spec.jbb.core.comm.AbstractResponse;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class OkResponse extends AbstractResponse {

    private static final long serialVersionUID = 4537272744674797240L;

    @Override
    public String toString() {
        return "OK";
    }
}