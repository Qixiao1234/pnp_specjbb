/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

public interface Visitor {

    void visit(StatsFrame point);

    boolean shouldRun();

}
