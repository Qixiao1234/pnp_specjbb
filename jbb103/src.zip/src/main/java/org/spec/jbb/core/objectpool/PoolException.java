/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.objectpool;

public class PoolException extends Exception {
    private static final long serialVersionUID = -980882102572360989L;

    public PoolException(Throwable cause) {
        super(cause);
    }

    public PoolException(String msg, Throwable throwable) {
        super(msg, throwable);
    }
}
