/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity.grizzlynio;

import org.spec.jbb.core.objectpool.PoolKey;

import java.util.Objects;

public class Destination implements PoolKey {
    private final String hostName;
    private final int port;

    public Destination(String hostName, int port) {
        this.hostName = hostName;
        this.port = port;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Destination that = (Destination) o;

        if (port != that.port) {
            return false;
        }
        if (hostName != null ? !hostName.equals(that.hostName) : that.hostName != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(hostName, port);
    }

    public String getHost() {
        return hostName;
    }

    public int getPort() {
        return port;
    }

    @Override
    public String toString() {
        return hostName + ":" + port;
    }
}
