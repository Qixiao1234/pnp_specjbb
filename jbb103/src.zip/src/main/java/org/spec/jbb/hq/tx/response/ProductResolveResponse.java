/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.response;

import org.spec.jbb.core.comm.AbstractResponse;
import org.spec.jbb.hq.entity.Product;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
public class ProductResolveResponse extends AbstractResponse {

    private static final long serialVersionUID = 8578024839272120401L;
    @XmlElement
    private final Product product;

    private ProductResolveResponse() {
        // JAXB
        this(null);
    }

    public ProductResolveResponse(Product product) {
        this.product = product;
    }

    public Product getProduct() {
        return product;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        ProductResolveResponse that = (ProductResolveResponse) o;

        if (product != null ? !product.equals(that.product) : that.product != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), product);
    }

    @Override
    public String toString() {
        return "Product resolved: " + product;
    }

}
