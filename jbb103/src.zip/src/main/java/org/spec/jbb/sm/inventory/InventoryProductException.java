/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.inventory;

/**
 * An exception which encapsulates all Inventory product exception conditions.
 */
public abstract class InventoryProductException extends RuntimeException {

    private static final long serialVersionUID = 2060280556677425108L;
}
