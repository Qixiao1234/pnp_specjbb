/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.objectpool;

import org.spec.jbb.core.Measurable;

public interface ObjectPool<K, T> extends Measurable {

    T acquire(K key) throws PoolException, InterruptedException;

    void release(K key, T object);

    void destroy(K key, T object);

    void shutdown();

}
