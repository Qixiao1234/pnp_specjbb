/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.threadpools;

import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.probe.ProbeFactory;
import org.spec.jbb.core.time.StopWatch;
import org.spec.jbb.core.time.TimeFactory;

import java.util.Queue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Specialization of ThreadPoolExecutor.
 * <p/>
 * This implementation differs on two points:
 * - it has exactly corePoolSize..maximumPoolSize threads
 * - it blocks on submit() when no threads are available
 */
public class JUCThreadPoolExecutor implements Measurable {

    private ThreadPoolExecutor executor;

    private final Semaphore semaphore;

    private final StopWatch waitTimer;
    private final StopWatch submitTimer;
    private Probe probe;

    public JUCThreadPoolExecutor(final String name, int corePoolSize, int maximumPoolSize, BlockingQueue<Runnable> queue, boolean isFair) {

        this.waitTimer = TimeFactory.getStopwatch();
        this.submitTimer = TimeFactory.getStopwatch();

        this.executor = new ThreadPoolExecutor(Math.max(0, corePoolSize), maximumPoolSize, 5, TimeUnit.MINUTES, queue);
        this.executor.setThreadFactory(SpecThreadFactory.newFactory(name));

        /**
         * Semaphore is bounded by queue size + maximum thread pool size.
         * It's required for executor to create new threads when queue is full.
         */
        this.semaphore = new Semaphore(queue.remainingCapacity() + maximumPoolSize, isFair);

        this.probe = ProbeFactory.getDefaultProbe();
    }

    public Queue<Runnable> getQueue() {
        return executor.getQueue();
    }

    public int getActiveCount() {
        return executor.getActiveCount();
    }

    public int getMaximumPoolSize() {
        return executor.getMaximumPoolSize();
    }

    public int getPoolSize() {
        return executor.getPoolSize();
    }

    public int getCorePoolSize() {
        return executor.getCorePoolSize();
    }

    public <T> Future<T> submit(final Callable<T> task) throws InterruptedException {
        waitTimer.start();
        semaphore.acquire();
        waitTimer.stop();

        probe.add("wait", waitTimer.getElapsedMsecs());

        /**
         * There's subtle race condition:
         *  semaphore.release() is called from the context of worker thread, and hence
         *  semaphore.acquire() might succeed for other thread when release() caller is not
         *  yet back in the thread pool, thus causing the abnormal reject.
         *
         * We're mitigating this by spinning until submit is succeeded.
         */

        while (true) {
            try {
                submitTimer.start();
                return executor.submit(new Callable<T>() {
                    @Override
                    public T call() throws Exception {
                        try {
                            return task.call();
                        } finally {
                            semaphore.release();
                        }
                    }
                });
            } catch (RejectedExecutionException e) {
                /**
                 * Wait for space to become available.
                 * Rethrow exception is pool is shut down.
                 */
                if (executor.isShutdown()) {
                    throw e;
                }

                Thread.yield();
            } finally {
                submitTimer.stop();
                probe.add("submit", submitTimer.getElapsedMsecs());
            }

        }
    }

    public void submit(Runnable runnable) {
        executor.submit(runnable);
    }

    public <T> Future<T> trySubmit(final Callable<T> task) {
        boolean acquired = semaphore.tryAcquire();

        if (!acquired) {
            return null;
        }

        try {
            return executor.submit(new Callable<T>() {
                @Override
                public T call() throws Exception {
                    try {
                        return task.call();
                    } finally {
                        semaphore.release();
                    }
                }
            });
        } catch(RejectedExecutionException e) {
            semaphore.release();
            throw e;
        }
    }

    public void shutdownNow() {
        ThreadUtils.terminatePool(executor);
    }

    @Override
    public void instrument(Probe probe) {
        this.probe = probe;
    }

    @Override
    public void sample() {
        // do nothing
    }
}
