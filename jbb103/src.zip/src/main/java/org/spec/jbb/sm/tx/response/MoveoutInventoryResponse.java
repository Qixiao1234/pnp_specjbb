/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.response;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public final class MoveoutInventoryResponse extends InventoryResponse {

    private static final long serialVersionUID = 5475942837433927040L;

    private MoveoutInventoryResponse() {
        this(0, 0);
    }

    public MoveoutInventoryResponse(long barCode, int quantity) {
        super(barCode, quantity);
    }

    @Override
    public String toString() {
        return super.toString() + ", move out";
    }

}
