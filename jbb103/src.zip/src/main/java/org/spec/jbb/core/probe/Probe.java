/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.probe;

import org.spec.jbb.core.ResetMode;

import java.util.Map;

public interface Probe {

    /**
     * Increment the specific counter
     * @param label counter name
     */
    void inc(String label);

    /**
     * Increment the specific counter
     * @param label counter name
     * @param inc increment
     */
    void add(String label, long inc);

    /**
     * Count types for objects in specific counter
     * @param label counter name
     * @param o object type to count
     */
    void countType(String label, Object o);

    /**
     * Count types for objects in specific counter
     * @param label counter name
     * @param o object type to count
     * @param inc increment
     */
    void countType(String label, Object o, long inc);

    /**
     * Record sample
     * @param label counter name
     * @param object sample
     */
    void sample(String label, Object object);

    /**
     * Should probe user go for insane probing?
     * @return true, if allowed insane profiling modes
     */
    boolean shouldGoInsane();

    /**
     * Answer dependent counter
     * @param prefix prefix to use
     * @return child counter
     */
    Probe getChild(String prefix);

    /**
     * Reset counters
     * @param mode mode to use
     */
    void reset(ResetMode mode);

    /**
     * Get the full values
     * @return map of [event name -> either sample value or counter value]
     */
    Map<String, Object> get();

}

