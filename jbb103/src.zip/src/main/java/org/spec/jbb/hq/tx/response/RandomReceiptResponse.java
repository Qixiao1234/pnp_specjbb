/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.response;

import org.spec.jbb.core.comm.AbstractResponse;
import org.spec.jbb.hq.entity.Receipt;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class RandomReceiptResponse extends AbstractResponse {

    private static final long serialVersionUID = -3311303742690374776L;
    private final Receipt receipt;

    private RandomReceiptResponse() {
        // JAXB
        this(null);
    }

    public RandomReceiptResponse(Receipt receipt) {
        this.receipt = receipt;
    }

    public Receipt getReceipt() {
        return receipt;
    }

    public String toString() {
        return "Random Receipt: " + receipt;
    }
}
