/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.policy;

import org.spec.jbb.core.comm.transport.TransportType;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class CachedPolicy implements TransportSelectionPolicy {

    private final TransportSelectionPolicy backPolicy;
    private final TransportTypeCache cache;

    public CachedPolicy(TransportSelectionPolicy backPolicy) {
        this.backPolicy = backPolicy;
        this.cache = new TransportTypeCache();
    }

    @Override
    public TransportType get(String fromName, String toName, boolean spanningMultipleICs) {
        TransportType type = cache.get(fromName, toName);
        if (type == null) {
            type = backPolicy.get(fromName, toName, spanningMultipleICs);
            cache.put(fromName, toName, type);
        }

        return type;
    }

    private static class TransportTypeCache {

        private final Map<List<String>, TransportType> cache;

        public TransportTypeCache() {
            cache = new ConcurrentHashMap<>();
        }

        public TransportType get(String fromName, String toName) {
            return cache.get(Arrays.asList(fromName, toName));
        }

        public void put(String fromName, String toName, TransportType type) {
            cache.put(Arrays.asList(fromName, toName), type);
        }

        public void clear() {
            cache.clear();
        }
    }

}
