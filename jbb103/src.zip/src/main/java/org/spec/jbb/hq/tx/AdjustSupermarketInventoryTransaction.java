/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.HQ.SMInventoryDirection;
import org.spec.jbb.hq.entity.Receipt;
import org.spec.jbb.hq.tx.request.AdjustSupermarketInventoryMessage;

public class AdjustSupermarketInventoryTransaction extends AbstractTransaction {
    private HQ hq;
    private Receipt receipt;
    private SMInventoryDirection direction;

    public AdjustSupermarketInventoryTransaction(HQ hq, AdjustSupermarketInventoryMessage msg, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        receipt = msg.getReceipt();
        direction = msg.getDirection();
    }

    @Override
    public Response execute() {
        /*
         * Adjust the HQ's representation of the source supermarket's inventory.
         */
        hq.adjustSupermarketInventory(ctx, receipt, direction, true);
        return new OkResponse();
    }
    
    @Override
    public String toString() {
        return "Adjust Supermarket Inventory Transaction, receipt = {" + receipt + "}, direction = {" + direction + "}" ;
    }
}
