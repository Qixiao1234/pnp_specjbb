/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.advertisement;

public enum AdvertisementAgentType {
    BASIC,
    
    HQBASED
}
