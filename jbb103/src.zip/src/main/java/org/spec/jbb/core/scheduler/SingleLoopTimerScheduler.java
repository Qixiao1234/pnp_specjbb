/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.scheduler;

import org.spec.jbb.core.threadpools.ThreadUtils;
import org.spec.jbb.util.random.SpecRandom;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.spec.jbb.core.collections.CollectionUtils;
import org.spec.jbb.util.JbbProperties;

public final class SingleLoopTimerScheduler implements Scheduler {

    /**
     * Minimal time to sleep.
     */
    private static final long SLEEP_THRESHOLD_NSEC = TimeUnit.MILLISECONDS.toNanos(20);

    private final Logger logger = Logger.getLogger("org.spec.jbb.scheduler");

    private final ThreadPoolExecutor workerPool;

    /**
     * Registered triggers
     */
    private final ConcurrentMap<ScheduledTask, TaskTrigger> registered;

    /**
     * Active triggers
     */
    private final ConcurrentMap<ScheduledTask, TaskTrigger> active;

    /**
     * Timer thread
     */
    private final Thread timerThread;

    public SingleLoopTimerScheduler(int threads, ThreadFactory factory) {
        this.workerPool = new ThreadPoolExecutor(threads, threads,
                5L, TimeUnit.SECONDS,
                new LinkedBlockingQueue<Runnable>(
                        CollectionUtils.integerSaturate((long) threads * JbbProperties.getInstance().getCustomerDriverQueueMultiplier())),
                factory);
        this.registered = new ConcurrentHashMap<>();
        this.active = new ConcurrentHashMap<>();

        Thread timerThread = factory.newThread(new TimerTask());
        timerThread.setName(timerThread.getName() + ".quartz");
        timerThread.setPriority(Thread.MAX_PRIORITY);
        timerThread.start();

        this.timerThread = timerThread;
    }

    @Override
    public void register(ScheduledTask task, SpecRandom delayRandom, DelayType delayType) {
        TaskTrigger trigger;
        switch (delayType) {
            case RATE:
                trigger = new RateTaskTrigger(task, delayRandom);
                break;
            case DELAY:
                trigger = new DelayTaskTrigger(task, delayRandom);
                break;
            default:
                throw new IllegalArgumentException("Unknown delay type");
        }

        // if task was registered before, disable previous one
        if (registered.put(task, trigger) != null) {
            disable(task);
        }
    }

    @Override
    public void remove(ScheduledTask task) {
        disable(task);
        registered.remove(task);
    }

    @Override
    public void shutdown() {
        ThreadUtils.terminateThread(timerThread);
        ThreadUtils.terminatePool(workerPool);
        active.clear();
        registered.clear();
    }

    @Override
    public void enable(ScheduledTask task) {
        TaskTrigger ts = registered.get(task);
        if (ts != null) {
            ts.enable();
            active.put(task, ts);
        }
    }

    @Override
    public void disable(ScheduledTask task) {
        active.remove(task);
        task.cleanup();
    }

    @Override
    public void zap() {
        workerPool.getQueue().clear();
    }

    private class TimerTask implements Runnable {

        @Override
        public void run() {
            /**
             * Spin-loop until terminated:
             *   - deliver new time tick to all parties
             *   - compensate for possible stalls
             */
            while (!Thread.currentThread().isInterrupted()) {
                long fireTime = System.nanoTime();
                fire(fireTime);
                long sleep = fireTime + SLEEP_THRESHOLD_NSEC - System.nanoTime();
                try {
                    TimeUnit.NANOSECONDS.sleep(sleep);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }

        }

        private void fire(long fireTime) {
            for (TaskTrigger ts : active.values()) {
                ts.tick(fireTime);
            }
        }
    }

    /**
     * Abstract task for triggering tasks.
     *
     */
    private abstract class TaskTrigger {

        private final SpecRandom random;
        protected final ScheduledTask task;

        /**
         * Next timestamp this task should fire
         */
        protected long nextTime;

        public TaskTrigger(ScheduledTask task, SpecRandom delayRandom) {
            this.task = task;
            this.random = delayRandom;
            this.nextTime = Long.MAX_VALUE;
        }

        public abstract void tick(long tickTime);

        public void enable() {
            this.nextTime = System.nanoTime() + nextInterval();
        }

        protected long nextInterval() {
            return random.nextLong();
        }

    }

    /**
     * Trigger for DelayType.RATE task
     */
    private class RateTaskTrigger extends TaskTrigger {

        public RateTaskTrigger(ScheduledTask task, SpecRandom delayRandom) {
            super(task, delayRandom);
        }

        public void tick(long tickTime) {
            try {
                while (nextTime <= tickTime) {
                    nextTime += nextInterval();
                    workerPool.submit(task.getRunTask());
                }
            } catch (RejectedExecutionException e) {
                // swallow
            }
        }

    }

    /**
     * Trigger for DelayType.DELAY task
     */
    private class DelayTaskTrigger extends TaskTrigger {

        public DelayTaskTrigger(ScheduledTask task, SpecRandom delayRandom) {
            super(task, delayRandom);
        }

        @Override
        public void tick(long tickTime) {
            if (nextTime <= tickTime) {

                // disable execution
                nextTime = Long.MAX_VALUE;

                try {
                    final Runnable runner = task.getRunTask();
                    workerPool.submit(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                runner.run();
                            } catch (Throwable e) {
                                logger.log(Level.WARNING, "Exception", e);
                            }
                            nextTime = System.nanoTime() + nextInterval();
                        }
                    });
                } catch (RejectedExecutionException e) {
                    // swallow
                }
            }
        }

    }

}
