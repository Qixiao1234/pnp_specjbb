/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.entity;

import org.spec.jbb.core.collections.HashMultiMap;
import org.spec.jbb.core.collections.MultiMap;
import org.spec.jbb.core.comm.transport.encapsulation.JAXBAdapters;
import org.spec.jbb.sm.coupon.GenericCoupon;

import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;
import java.util.Set;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Receipt implements Serializable {

    private static final long serialVersionUID = -8756143347521486469L;
    @XmlElement
    private final long id;

    @XmlElement
    private final String sm;

    @XmlElement
    private final long customerId;

    @XmlJavaTypeAdapter(JAXBAdapters.MultiHashMapAdapter.class)
    private final HashMultiMap<String, ReceiptLine> receiptLines;

    @XmlElement
    private final long transactionDate;

    @XmlElement
    private final BigDecimal total;

    @XmlElement
    private final GenericCoupon genericCoupon;
    
    @XmlElement
    private volatile Set<Long> localBarcodes;

    @XmlElement
    private volatile Set<Long> allBarcodes;

    /*
       Alas, in JAXB the behavior for empty collections is undefined.
       So, it can unmarshal empty collection to null.
       We recreate collections in that case.
     */
    void afterUnmarshal(Unmarshaller u,  Object parent) {
        if (localBarcodes == null) {
            localBarcodes = Collections.emptySet();
        }
        if (allBarcodes == null) {
            allBarcodes = Collections.emptySet();
        }
    }

    private Receipt() {
        // JAXB
        this(0, "", 0, null, null, null, 0, null, null);
    }

    public Receipt(long id, String sm, long customerId, HashMultiMap<String, ReceiptLine> receiptLines, 
            Set<Long> localBarcodes, Set<Long> allBarcodes, long transactionDate, BigDecimal total, GenericCoupon genericCoupon) {
        this.id = id;
        this.sm = sm;
        this.customerId = customerId;
        this.receiptLines = receiptLines;
        this.localBarcodes = localBarcodes;
        this.allBarcodes = allBarcodes;
        this.transactionDate = transactionDate;
        this.total = total;
        this.genericCoupon = genericCoupon;
    }

    public long getId() {
        return id;
    }

    public long getCustomerId() {
        return customerId;
    }

    public String getSupermarket() {
        return sm;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public long getTransactionDate() {
        return transactionDate;
    }

    public Iterable<ReceiptLine> getReceiptLines() {
        return receiptLines.values();
    }

    public MultiMap<String, ReceiptLine> getReceiptLinesBySM() {
        return receiptLines;
    }

    public GenericCoupon getGenericCoupon() {
        return genericCoupon;
    }

    public Collection<Long> getAllBarcodesLocalToReceiptSM() {
        return localBarcodes;
    }

    public Collection<Long> getAllBarcodes() {
        return allBarcodes;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Receipt receipt = (Receipt) o;

        if (id != receipt.id) {
            return false;
        }
        if (sm != null ? !sm.equals(receipt.sm) : receipt.sm != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                id,
                sm
        );
    }

    @Override
    public String toString() {
        return "Receipt: customer=" + customerId + ", price=" + total + ", products=" + receiptLines.size();
    }

    public long getSize() {
        return receiptLines.size();
    }
}
