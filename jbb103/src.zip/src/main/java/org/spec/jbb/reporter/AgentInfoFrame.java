/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

import org.spec.jbb.core.comm.LocationInfo;

import java.util.Collection;

public class AgentInfoFrame implements Frame {

    public static final long serialVersionUID = 1L;

    private final String agent;
    private final Collection<LocationInfo> locations;

    public AgentInfoFrame(String agent, Collection<LocationInfo> locations) {
        this.agent = agent;
        this.locations = locations;
    }

    public Collection<LocationInfo> getLocations() {
        return locations;
    }

    public String getAgent() {
        return agent;
    }

    @Override
    public Frame cleanForSubmission(CleanForSubmissionContext ctx) {
        return this;
    }

    @Override
    public String toString() {
        return "Agent" + agent + " Info ->" + locations;
    }
}
