/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.probe;

public class ProbeFactory {

    private ProbeFactory() {
        // prevent instantiation
    }

    public static Probe getProbe(ProfileMode mode) {
        switch(mode) {
            case DISABLED:
                return new EmptyProbe();
            case NON_INTRUSIVE:
                return new NonIntrusiveProbe();
            case INTRUSIVE:
                return new IntrusiveProbe();
            default:
                throw new IllegalStateException("unknown profile type: " + mode);
        }
    }

    public static Probe getDefaultProbe() {
        return getProbe(ProfileMode.DISABLED);
    }
}
