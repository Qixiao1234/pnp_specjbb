/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport;

public class EmptyTransport<CT> implements Transport<CT, Data> {

    @Override
    public Data convertDown(CT topInstance) {
        return Data.wrapReference(topInstance);
    }

    @Override
    public CT convertUp(Data bottomInstance) {
        return (CT) bottomInstance.getReference();
    }

}
