/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity;

import org.spec.jbb.core.comm.connectivity.grizzlynio.ConnectionFactory;
import org.spec.jbb.core.comm.connectivity.grizzlynio.Destination;
import org.spec.jbb.core.comm.connectivity.grizzlynio.GrizzlyNioClient;
import org.spec.jbb.core.comm.connectivity.grizzlynio.GrizzlyNioServer;
import org.spec.jbb.core.comm.connectivity.grizzlynio.PoolableConnection;
import org.spec.jbb.core.objectpool.ObjectPool;
import org.spec.jbb.core.objectpool.PerKeyQueuePool;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.probe.ProbeFactory;
import org.spec.jbb.util.JbbProperties;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GrizzlyNioProvider implements ConnectivityProvider {

    private final ObjectPool<Destination, PoolableConnection> connectionPool;
    private final ConnectionFactory connectionFactory;
    private final List<GrizzlyNioServer> issuedServers = Collections.synchronizedList(new ArrayList<GrizzlyNioServer>());
    private volatile Probe probe;

    public GrizzlyNioProvider() {
        connectionFactory = new ConnectionFactory();
        this.connectionPool = new PerKeyQueuePool<>(
                connectionFactory, JbbProperties.getInstance().getConnectivityClientConnectionPoolSize());
        this.probe = ProbeFactory.getDefaultProbe();
    }

    @Override
    public void shutdown() {
        connectionPool.shutdown();
    }

    @Override
    public Server newServer(int port, ServerCallback callback) {
        GrizzlyNioServer server = new GrizzlyNioServer(port, callback);
        issuedServers.add(server);
        server.instrument(probe.getChild("server.{" + server.toString() + "}.threads"));
        return server;
    }

    @Override
    public Client newClient(String hostname, int port) {
        return new GrizzlyNioClient(connectionPool, hostname, port);
    }

    @Override
    public String getName() {
        return "NIO_Grizzly";
    }

    @Override
    public String getDescription() {
        return "Grizzly NIO server, Grizzly NIO client";
    }

    @Override
    public void instrument(Probe probe) {
        this.probe = probe;
        connectionPool.instrument(probe.getChild("client.connections"));
        connectionFactory.instrument(probe.getChild("client.threads"));
        for (GrizzlyNioServer server : issuedServers) {
            server.instrument(probe.getChild("server.{" + server.toString() + "}.threads"));
        }
    }

    @Override
    public void sample() {
        connectionPool.sample();
        connectionFactory.sample();
        for (GrizzlyNioServer server : issuedServers) {
            server.sample();
        }
    }
}
