/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

import org.spec.jbb.core.counters.Counter;
import org.spec.jbb.core.counters.CounterFactory;
import org.spec.jbb.util.InstanceFactory;

public class ConcurrentCounterMap<K> extends ConcurrentCreateHashMap<K, Counter> {
    private static final long serialVersionUID = 3827423914749646238L;

    public ConcurrentCounterMap() {
        super(new InstanceFactory<Counter>() {
            private static final long serialVersionUID = -3580837102681432674L;

            @Override
            public Counter getInstance() {
                return CounterFactory.getCounter();
            }
        });
    }
}
