/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm;

public enum SourceType {

    UNKNOWN,

    TXINJECTOR,

    BACKEND,

    CONTROLLER,

    HQ,

    SM,

    SP,

}
