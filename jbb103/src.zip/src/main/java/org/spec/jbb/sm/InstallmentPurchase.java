/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD) 
public final class InstallmentPurchase implements Delayed, Serializable {

    private static final long DELAYTIME = 1000;
    private static final long serialVersionUID = -8588906116593133969L;

    @XmlElement
    private long endOfDelay;

    @XmlElement
    private final BigDecimal installmentFee;

    @XmlElement 
    private volatile BigDecimal payments;

    @XmlElement
    private final BigDecimal totalAmount;

    @XmlElement
    private final long customerId;

    @SuppressWarnings("unused")
    private InstallmentPurchase() {
        super();
        payments = BigDecimal.ZERO;
        this.installmentFee = BigDecimal.ZERO;
        this.totalAmount = BigDecimal.ZERO;
        this.customerId = 0;
    }

    public InstallmentPurchase(BigDecimal installmentFee,
            BigDecimal initialPayment, BigDecimal totalAmount, long customerId) {
        this.payments = initialPayment != null ? initialPayment : BigDecimal.ZERO;
        resetDelay();
        this.installmentFee = installmentFee != null ? installmentFee : BigDecimal.ZERO;
        this.totalAmount =  totalAmount != null ? totalAmount : BigDecimal.ZERO;
        this.customerId = customerId;
    }

    public long getEndOfDelay() {
        return endOfDelay;
    }

    public void resetDelay() {
        endOfDelay = System.currentTimeMillis() + DELAYTIME;
    }

    public BigDecimal getInstallmentFee() {
        return installmentFee;
    }

    @Override
    public int compareTo(Delayed o) {
        long cEndofDelay = ((InstallmentPurchase) o).getEndOfDelay();
        if (endOfDelay < cEndofDelay) {
            return -1;
        } else if (endOfDelay > cEndofDelay) {
            return 1;
        } else {
            return 0;
        }
    }

    @Override
    public long getDelay(TimeUnit unit) {
        long currMills = System.currentTimeMillis();
        return unit.convert(endOfDelay - currMills, TimeUnit.MILLISECONDS);
    }

    public void addPayment(BigDecimal payment) {
        payments = payments.add(payment);
    }

    public BigDecimal getBalance() {
        return totalAmount.subtract(payments);
    }

    public BigDecimal getVoidAmount() {
        return payments.subtract(installmentFee);
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public long getCustomerId() {
        return customerId;
    }

    @Override
    public String toString() {
        return "Installment Purchase: installment fee : " + installmentFee
                + " payments: " + payments + " customer: " + customerId
                + " total amount: " + totalAmount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        InstallmentPurchase installmentPurchase = (InstallmentPurchase) o;

        if (endOfDelay != installmentPurchase.getEndOfDelay()){
            return false;
        }

        if (!installmentFee.equals(installmentPurchase.installmentFee)) {
            return false;
        }

        if (!totalAmount.equals(installmentPurchase.totalAmount)) {
            return false;
        }
        
        if (customerId != installmentPurchase.getCustomerId()){
            return false;
        }

        if (!payments.equals(installmentPurchase.payments)) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                customerId,
                endOfDelay,
                installmentFee,
                totalAmount,
                payments
        );
    }
}
