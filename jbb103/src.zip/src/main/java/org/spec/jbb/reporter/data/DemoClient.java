/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter.data;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.spec.jbb.core.Conventions;
import org.spec.jbb.core.comm.AbstractConnectionClient;
import org.spec.jbb.core.comm.Interconnect;
import org.spec.jbb.core.comm.Request;
import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.reporter.EndOfStreamFrame;
import org.spec.jbb.reporter.Frame;

public class DemoClient extends AbstractConnectionClient {
    private static final Logger logger = Logger.getLogger(DemoClient.class.getName());
    private Interconnect ic;
    private final CountDownLatch isStop = new CountDownLatch(1);
    
    public DemoClient() {
        super("DemoClient");
    }
    
    public void connect(String host, int port) {
        ic = new Interconnect(host, port, false);
        ic.addLink(this);
        Response r = null;
        do {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                logger.log(Level.SEVERE, null, ex);
            }
            logger.info("Connecting to DemoDataWriter");
            r = getLink().sendRequest("DemoDataWriter", Conventions.TIER_INFRA, new DemoAttachRequest());
            logger.info("Got response: " + r);
        } while (!(r instanceof OkResponse));
    }
    
    public void close() {
        ic.shutdown();
    }
    
    public void waitFor() throws InterruptedException {
        isStop.await();
    }
    
    public void process(Frame frame) {
        logger.info(frame.toString());
    }

    @Override
    public List<Response> handle(String from, List<Request> requests, int currentTier, int targetTier) {
        for(Request r : requests) {
            if(r instanceof DemoRequest) {
                Frame f = ((DemoRequest)r).getFrame();
                process(f);
                if(f instanceof EndOfStreamFrame) {
                    isStop.countDown();
                }
            }
        }
        return Collections.nCopies(requests.size(), (Response)new OkResponse());
    }

    public static void main(String[] args) {
        System.out.println("This is simple example of demo client");
        DemoClient client = new DemoClient();
        client.connect(args[0], Integer.parseInt(args[1]));
        try {
            client.waitFor();
        } catch (InterruptedException ex) {
            logger.log(Level.SEVERE, null, ex);
        }
        client.close();
    }

}
