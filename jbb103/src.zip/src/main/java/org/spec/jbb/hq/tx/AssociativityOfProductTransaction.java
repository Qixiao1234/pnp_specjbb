/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;


import org.spec.jbb.core.collections.CollectionUtils;
import org.spec.jbb.core.collections.HashMultiSet;
import org.spec.jbb.core.collections.MultiSet;
import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.db.DataMiningCursor;
import org.spec.jbb.hq.entity.Category;
import org.spec.jbb.hq.entity.Receipt;
import org.spec.jbb.hq.tx.request.AssociativityOfProductRequest;
import org.spec.jbb.hq.tx.response.NoDataForDataMiningResponse;
import org.spec.jbb.sm.advertisement.IssuedAdvertisement;
import org.spec.jbb.util.JbbProperties;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class AssociativityOfProductTransaction extends AbstractTransaction {

    private final HQ hq;
    private final String smName;
    private final Long barcode;
    private final DataMiningCursor<Receipt> data;
    private final static String dmName = "AssociativityOfProduct";
    private static final String dmStatEmptyAssocMap = dmName + ".assocMap.EMPTY";
    private static final String dmStatNonEmptyAssocMap = dmName + ".assocMap.NON_EMPTY";
    
    public AssociativityOfProductTransaction(HQ hq, AssociativityOfProductRequest request, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        this.smName = request.getSmName();
        this.data = hq.getDataMiningManager().receiptsCursor(smName);
        this.barcode = hq.getDataMiningManager().pickRandomBarcodeFromReceipts(data);
    }

    @Override
    public Response execute() throws TransactionException {

        /*
         * Build associativity map
         */
        final MultiSet<Long> barcodeAssociativity = new HashMultiSet<> ();

        while (data.hasNext()) {
            Receipt r = data.next();
            Collection<Long> barcodes = r.getAllBarcodesLocalToReceiptSM();
            if (barcodes.contains(barcode)) {
                barcodeAssociativity.addAll(barcodes);
            }
        }

        if (!barcodeAssociativity.isEmpty()) {
            /*
            * Find most popular products
            */
            hq.getDataMiningTxProbe().inc(dmStatNonEmptyAssocMap);
            List<Long> hottestBarcodes = new ArrayList<>(
                    CollectionUtils.tail(CollectionUtils.elementsAsList(barcodeAssociativity),
                            JbbProperties.getInstance().getDataMiningHottestCount(dmName)));

            /*
            * Create advertisement
            */
            Category cat = CollectionUtils.getRandomElement(new ArrayList<>(hq.findProduct(barcode).getCategories()));

            hq.suggestAdvertisement(smName, new IssuedAdvertisement(cat, hottestBarcodes));
        } else {
            hq.getDataMiningTxProbe().inc(dmStatEmptyAssocMap);
        }

        if (data.hasEnoughElements()) {
            return new OkResponse();
        } else {
            return new NoDataForDataMiningResponse();
        }
    }

    @Override
    public String toString() {
        return "AssociativityOfProductTx: smName = {" + smName + "}, barcode = {" + barcode + "}, data = {" + data + "}";
    }

}
