/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.purchase;

import org.spec.jbb.core.generator.ProductGenerator;
import org.spec.jbb.hq.entity.CustomerProfile;
import org.spec.jbb.util.random.SpecRandom;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public abstract class PurchaseAgentArrayBased extends AbstractPurchaseAgent {

    protected final List<Long> barcodes;
    protected SpecRandom random;

    public PurchaseAgentArrayBased() {
        super();
        barcodes = new ProductGenerator().generateBarcodes();
        Collections.shuffle(barcodes);
    }

    @Override
    public Collection<PurchaseItem> getNextProducts(CustomerProfile cp) {
        final int purchaseSize = getPurchaseSize();
        List<PurchaseItem> result = new ArrayList<>(purchaseSize);
        for(int i = 0; i < purchaseSize; i++) {
            long barcode = getNextBarcode();
            result.add(new PurchaseItem(barcode, getQuantityNumber()));
        }
        return result;
    }
    
    protected long getNextBarcode() {
        return barcodes.get((int)random.nextLong());
    }
    
}
