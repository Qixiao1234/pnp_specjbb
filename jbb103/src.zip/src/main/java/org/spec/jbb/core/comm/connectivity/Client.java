/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity;

import org.spec.jbb.core.comm.Packet;

import java.io.IOException;

public interface Client {

    Packet send(Packet data) throws IOException, InterruptedException;

    String resolveMyIp() throws IOException, InterruptedException;

}
