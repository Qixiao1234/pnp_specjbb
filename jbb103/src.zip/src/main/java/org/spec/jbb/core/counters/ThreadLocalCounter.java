/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.counters;

import org.spec.jbb.util.InstanceFactory;
import org.spec.jbb.util.Mergeable;
import org.spec.jbb.util.ThreadLocalAggregator;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Collection;

public class ThreadLocalCounter implements Counter, Serializable {

    public static final long serialVersionUID = 1L;

    private transient ThreadLocalAggregator<VolatileCounter> aggregator =
            new ThreadLocalAggregator<>(new InstanceFactory<VolatileCounter>() {
                private static final long serialVersionUID = 2294548231699626229L;

                @Override
                public VolatileCounter getInstance() {
                    return new VolatileCounter(0);
                }
            });

    private long serializedValue;

    @Override
    public void inc(long increment) {
        aggregator.getLocal().inc(increment);
    }

    @Override
    public long get() {
        return aggregator.getAggregate().get();
    }

    @Override
    public void reset() {
        aggregator.reset();
    }

    @Override
    public long getAndReset() {
        long result = get();
        reset();
        return result;
    }

    public String toString() {
        return "" + get();
    }

    private void writeObject(ObjectOutputStream oos) throws IOException {
        serializedValue = get();
        oos.defaultWriteObject();
    }

    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
        ois.defaultReadObject();
        inc(serializedValue);
    }

    /**
     * Specialization of counter which has volatile long.
     * Non-volatile counter can expose torn value if read in other threads (JLS 17.7)
     */
    public static class VolatileCounter implements Mergeable<VolatileCounter> {

        private static final long serialVersionUID = -3050126773282455022L;
        private volatile long counter;

        public VolatileCounter(long initialValue) {
            counter = initialValue;
        }

        @Override
        public void mergeAll(Collection<VolatileCounter> others) {
            for(VolatileCounter other : others) {
                counter += other.get();
            }
        }

        @Override
        public void reset() {
            counter = 0;
        }

        public void inc(long increment) {
            counter += increment;
        }

        public long get() {
            return counter;
        }

        @Override
        public String toString() {
            return Long.toString(counter);
        }

    }

}
