/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.policy;

public enum TransportSelectionPolicyType {

    MAX_THROUGHPUT,

    BALANCED,

    MAX_SECURITY,

    // oh, brave new world!
    MAX_XML,

    ALL_SERIAL,

}
