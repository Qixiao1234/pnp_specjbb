/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.request;

import org.spec.jbb.core.comm.AbstractMessage;
import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.entity.Receipt;
import org.spec.jbb.hq.tx.PurchaseReceiptTransaction;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
public class PurchaseReceiptMessage extends AbstractMessage {

    private static final long serialVersionUID = 7216025728020771587L;
    @XmlElement
    private final Receipt receipt;

    private PurchaseReceiptMessage() {
        // JAXB
        this(null);
    }

    public PurchaseReceiptMessage(Receipt receipt) {
        this.receipt = receipt;
    }

    @Override
    public boolean isDurable() {
        return true;
    }

    public Receipt getReceipt() {
        return receipt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        PurchaseReceiptMessage that = (PurchaseReceiptMessage) o;

        if (receipt != null ? !receipt.equals(that.receipt) : that.receipt != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(receipt);
    }

    @Override
    public String toString() {
        return "Purchase receipt: " + receipt;
    }

    @Override
    public Transaction getTransaction(HQ hq, TransactionContext ctx) {
        return new PurchaseReceiptTransaction(hq, this, ctx);
    }
}
