/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.advertisement;

import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.util.JbbProperties;

import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Semaphore;

/**
 * An abstract implementation of AdvertisementAgent.
 * Supports keeping the issued discount until purge operation. 
 *
 */
public abstract class AbstractAdvertisementAgent implements AdvertisementAgent {

    /**
     * Issued advertisements
     */
    private final Queue<IssuedAdvertisement> advertisements;
    /**
     * size of the queue including reserved slots
     */
    private final Semaphore freeSlots;
    
    public AbstractAdvertisementAgent() {
        int maxQueueSize = JbbProperties.getInstance().getAdvertisementQueueSize();
        freeSlots = new Semaphore(maxQueueSize);
        advertisements = new ArrayBlockingQueue<>(maxQueueSize);
    }

    @Override
    public void addIssuedAdvertisement(TransactionContext ctx, IssuedAdvertisement adv) {
        if(!advertisements.offer(adv)) {
            throw new IllegalStateException("addIssuedAdvertisement is used without reservation");
        }
    }

    @Override
    public IssuedAdvertisement pollIssuedAdvertisement(TransactionContext ctx) {
        IssuedAdvertisement adv = advertisements.poll();
        if (adv != null) {
            freeSlots.release();
        }
        return adv;
    }

    @Override
    public boolean reserveSlot(TransactionContext ctx) {
        return freeSlots.tryAcquire();
    }

}
