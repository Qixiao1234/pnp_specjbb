/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.response;

import org.spec.jbb.core.comm.AbstractResponse;
import org.spec.jbb.core.comm.transport.TransportType;
import org.spec.jbb.hq.entity.CustomerProfile;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
public class CustomerProfileResponse extends AbstractResponse {

    private static final long serialVersionUID = 5905433986399778721L;
    @XmlElement
    private final CustomerProfile profile;

    private CustomerProfileResponse() {
        // JAXB
        this(null);
    }

    public CustomerProfileResponse(CustomerProfile profile) {
        this.profile = profile;
    }

    public CustomerProfile getCustomerProfile() {
        return profile;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        CustomerProfileResponse that = (CustomerProfileResponse) o;

        if (profile != null ? !profile.equals(that.profile) : that.profile != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), profile);
    }

    @Override
    public String toString() {
        return "CustomerProfile: " + profile;
    }

    @Override
    public TransportType getTransportHint() {
        return TransportType.SERIALIZED_ENCRYPTED;
    }

}
