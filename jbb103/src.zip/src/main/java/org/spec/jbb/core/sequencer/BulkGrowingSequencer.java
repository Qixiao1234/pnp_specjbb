/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.sequencer;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.concurrent.atomic.AtomicLong;

public class BulkGrowingSequencer implements Sequencer<Long>, Serializable {

    private static final long serialVersionUID = 6773376608115789273L;
    private transient volatile ThreadLocal<Sequencer<Long>> seq;
    private final AtomicLong regions;
    private final int regionSize;

    public BulkGrowingSequencer(int regionSize) {
        this.regionSize = regionSize;
        this.regions = new AtomicLong();
        this.seq = new ThreadLocal<>();
    }

    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
        ois.defaultReadObject();
        seq = new ThreadLocal<>();
    }

    @Override
    public Long next() {
        Sequencer<Long> sequencer = seq.get();
        if (sequencer != null) {
            Long nextValue = sequencer.next();
            if (nextValue != null) {
                return nextValue;
            }
        }

        long newRegion = regions.getAndIncrement();
        sequencer = new RangeSequencer(newRegion*regionSize, (newRegion+1)*regionSize);
        seq.set(sequencer);
        return sequencer.next();
    }

}
