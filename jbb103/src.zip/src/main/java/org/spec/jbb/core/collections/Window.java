/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Window<T> implements Serializable {

    private static final long serialVersionUID = -167600005831051805L;

    @XmlElementWrapper
    private final Object[] elems;

    @XmlElement
    private int highBound;

    @XmlElement
    private int index;

    private Window() {
        this(0);
        // JAXB constructor
    }

    public Window(int size) {
        super();
        this.elems = new Object[size];
        clear();
    }

    public Window(Window<T> w) {
        super();
        elems = Arrays.copyOf(w.elems, w.elems.length);
        index = w.index;
        highBound = w.highBound;
    }

    public void clear() {
        for (int c = 0; c < elems.length; c++) {
            elems[c] = null;
        }
        index = 0;
        highBound = 0;
    }

    public int size() {
        return highBound;
    }

    public T add(T elem) {
        if (elem == null) {
            throw new NullPointerException();
        }
        int lastIndex = index;
        Object oldElem = elems[lastIndex];
        elems[lastIndex] = elem;
        highBound = Math.max(lastIndex + 1, highBound);
        index = (lastIndex + 1) % elems.length;
        return (T)oldElem;
    }

    public T get(int index) {
        return (T)elems[index];
    }

    public Collection<T> getAll() {
        if (highBound == elems.length) {
            return Arrays.asList((T[])elems);
        } else {
            return Arrays.asList((T[])elems).subList(0, highBound);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Window window = (Window) o;

        if (highBound != window.highBound) {
            return false;
        }
        if (index != window.index) {
            return false;
        }
        if (!Arrays.equals(elems, window.elems)) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(elems, highBound, index);
    }

    @Override
    public String toString() {
        return "{" + "Elems=" + Arrays.toString(elems) + ", Index=" + index + "}";
    }

    public T getRandomValue() {
        if (highBound == 0) {
            return null;
        }
        return get(ThreadLocalRandom.current().nextInt(0, highBound));
    }
}
