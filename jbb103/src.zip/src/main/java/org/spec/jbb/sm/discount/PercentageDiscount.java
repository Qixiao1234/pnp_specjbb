/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.discount;

import java.math.BigDecimal;

/**
 * Percentage discount implementation keeping the percent of discount for
 * specified product. The price of the product is calculated by the following
 * formula: Actual price = price * (1 - percent / 100)
 * 
 */
public class PercentageDiscount extends AbstractDiscount {

    private static final long serialVersionUID = 3263881890990289449L;
    private final int percent;

    public PercentageDiscount(long barcode, int percent) {
        super(barcode);
        this.percent = percent;
    }

    public int getPercent() {
        return percent;
    }

    public BigDecimal getMultiplier() {
        return BigDecimal.ONE.subtract(BigDecimal.valueOf(percent, 2));
    }

}
