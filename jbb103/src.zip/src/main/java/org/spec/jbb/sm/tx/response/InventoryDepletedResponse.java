/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.response;

import org.spec.jbb.core.tx.response.PartialOkResponse;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class InventoryDepletedResponse extends PartialOkResponse {
    private static final long serialVersionUID = -7660228836638287323L;
    private final String message;

    private InventoryDepletedResponse() {
        // JAXB
        this(null);
    }

    public InventoryDepletedResponse(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "Inventory depleted: " + message;
    }
}
