/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.response;

import org.spec.jbb.core.comm.AbstractResponse;
import org.spec.jbb.sm.advertisement.IssuedAdvertisement;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
public class SuggestedAdvertisementResponse extends AbstractResponse {

    private static final long serialVersionUID = -576782928162101132L;
    @XmlElement
    private final IssuedAdvertisement adv;

    private SuggestedAdvertisementResponse() {
        // JAXB
        this(null);
    }

    public SuggestedAdvertisementResponse(IssuedAdvertisement adv) {
        this.adv = adv;
    }

    public IssuedAdvertisement getSuggestedAdvertisement() {
        return adv;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        SuggestedAdvertisementResponse that = (SuggestedAdvertisementResponse) o;

        if (adv != null ? !adv.equals(that.adv) : that.adv != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), adv);
    }

    @Override
    public String toString() {
        return "SuggestedAdvertisement: " + adv;
    }

}
