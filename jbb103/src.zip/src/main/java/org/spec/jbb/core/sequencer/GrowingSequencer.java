/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.sequencer;

public class GrowingSequencer implements Sequencer<Long> {

    private long counter;

    public GrowingSequencer() {
        this.counter = 0;
    }

    @Override
    public Long next() {
        return counter++;
    }
}
