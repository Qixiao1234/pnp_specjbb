/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm;


import java.util.List;

public abstract class AbstractConnectionClient implements ConnectionClient {
    private final String name;

    private volatile Uplink link;

    public AbstractConnectionClient(String name) {
        this.name = name;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public List<Response> handle(String from, List<Request> requests, int currentTier, int targetTier) {
        throw new UnsupportedOperationException("No requests expected");
    }

    @Override
    public void handleMessage(String from, List<Message> messages, int currentTier, int targetTier) {
        throw new UnsupportedOperationException("No messages expected");
    }

    @Override
    public void setUplink(Uplink link) {
        this.link = link;
    }

    public Uplink getLink() {
        return link;
    }

}
