/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import org.spec.jbb.core.collections.HashMultiMap;
import org.spec.jbb.core.collections.MultiMap;
import org.spec.jbb.core.comm.LocationInfo;
import org.spec.jbb.infra.IterationStatus;
import org.spec.jbb.infra.TimeData;
import org.spec.jbb.infra.validation.ValidationReport;
import org.spec.jbb.reporter.LogRecordFrame.LogDataChunk;
import org.spec.jbb.util.JbbProperties;

public class EmptySourceData implements SourceData {
    private final MultiMap<String, LocationInfo> agentInfo = new HashMultiMap<>();

    @Override
    public void ensureRead() {
    }

    @Override
    public void runPass(Collection<? extends Visitor> visitors) {
    }

    @Override
    public void runPass(Collection<? extends Visitor>... visitors) {
    }

    @Override
    public void runPass(Visitor... visitors) {
    }

    @Override
    public void shutdown() {
    }

    @Override
    public Iterable<LogDataChunk> getLogRecords() {
        return Collections.EMPTY_LIST;
    }

    @Override
    public Iterable<Map<String, JbbProperties>> getProperties() {
        return Collections.EMPTY_LIST;
    }

    @Override
    public Iterable<IterationStatus> getStatuses() {
        return Collections.EMPTY_LIST;
    }

    @Override
    public MultiMap<String, LocationInfo> getAgentInfos() {
        return agentInfo;
    }

    @Override
    public Iterable<ValidationReport> getValidationReports() {
        return Collections.EMPTY_LIST;
    }

    @Override
    public Map<String, String> getMarks() {
        return Collections.EMPTY_MAP;
    }

    @Override
    public Iterable<TimeData> getTimeData() {
        return Collections.EMPTY_LIST;
    }

    @Override
    public boolean isDataValid() {
        return true;
    }
    
}
