/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections.sampling;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/**
 * Array-backed circular buffer.
 *
 * @param <T>
 */
public class CircularArraySamplingBuffer<T> implements SamplingBuffer<T>, Serializable {

    private static final long serialVersionUID = -617257989451855831L;

    /**
     * Note this implementation *appears* to be incorrectly synchronized.
     *
     * However, one can use this in thread-safe manner since the only effect needed to be enforced
     * by synchronization is correct visibility on head/tail.
     *
     * In most cases array is completely filled with data, and missing update to head/tail
     * will cause get/overwrite of another stale entry, which will slightly offset the ordering,
     * but will not penalize throughput much.
     */

    private final int capacity;
    private final T[] data;
    private int tail;
    private int head;
    private int rightMost;

    public CircularArraySamplingBuffer(int capacity) {
        this.capacity = capacity;
        this.data = (T[]) new Object[capacity];
        this.head = -1;
        this.tail = -1;
    }

    @Override
    public void put(T element) {
        rightMost = Math.max(rightMost, tail + 1);
        tail = (tail + 1) % capacity;
        data[tail] = element;

        // bump head if the item was overwritten.
        if (head == tail || head == -1) {
            head = (head + 1) % capacity;
        }

    }

    @Override
    public void putAll(Collection<T> elements) {
        for (T element : elements) {
            put(element);
        }
    }

    @Override
    public int size() {
        return capacity;
    }

    @Override
    public List<T> snapshot() {
        List<T> result = new ArrayList<>();
        if (head > tail) {
            result.addAll(Arrays.asList(data).subList(head, rightMost));
            result.addAll(Arrays.asList(data).subList(0, tail + 1));
        } else {
            result.addAll(Arrays.asList(data).subList(Math.max(0, head), Math.max(0, tail+1)));
        }
        return result;
    }

    @Override
    public T get() {
        if (head != -1) {
            return data[head];
        } else {
            return null;
        }
    }
}
