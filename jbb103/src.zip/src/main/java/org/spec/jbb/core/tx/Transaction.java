/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.tx;

import org.spec.jbb.core.comm.Response;

/**
 * Generic transaction.
 */
public interface Transaction {

    Response execute() throws TransactionException;

}
