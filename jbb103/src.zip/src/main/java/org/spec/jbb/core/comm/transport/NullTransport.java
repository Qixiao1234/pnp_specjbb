/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport;

public class NullTransport<CT> implements Transport<CT, Data> {
    @Override
    public Data convertDown(CT topInstance) {
        return Data.empty();
    }

    @Override
    public CT convertUp(Data bottomInstance) {
        // always return null
        return null;
    }
}
