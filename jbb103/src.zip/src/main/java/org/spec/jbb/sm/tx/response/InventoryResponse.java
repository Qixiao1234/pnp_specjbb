/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.response;

import org.spec.jbb.core.comm.AbstractResponse;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class InventoryResponse extends AbstractResponse {

    private static final long serialVersionUID = -2712954442169372736L;
    @XmlElement
    private final long barCode;

    @XmlElement
    private final int quantity;

    @SuppressWarnings("unused")
    private InventoryResponse() {
        // JAXB
        this(0, 0);
    }

    public InventoryResponse(long barCode, int quantity) {
        this.barCode = barCode;
        this.quantity = quantity;
    }

    public long getBarcode() {
        return barCode;
    }

    public int getQuantity() {
        return quantity;
    }

    @Override
    public String toString() {
        return "Inventory result: barcode={" + barCode + "}, quantity = {" + quantity + "}";
    }

}
