/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.response;

import org.spec.jbb.core.comm.AbstractResponse;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ProductReviewScoreResponse extends AbstractResponse {

    private static final long serialVersionUID = -8216854996832347115L;
    @XmlElement
    private final int rating;

    private ProductReviewScoreResponse() {
        // JAXB
        this(0);
    }

    public ProductReviewScoreResponse(int rating) {
        this.rating = rating;
    }

    public int getRating() {
        return rating;
    }

    @Override
    public String toString() {
        return "Product review score = " + rating;
    }
}
