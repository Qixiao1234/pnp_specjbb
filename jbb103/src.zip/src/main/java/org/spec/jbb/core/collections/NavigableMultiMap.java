/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

import java.util.Collection;
import java.util.Comparator;
import java.util.NavigableMap;

public interface NavigableMultiMap<K,V> extends MultiMap<K,V> {

    public NavigableMap<K, Collection<V>> asNavigableMap();

    public Comparator<? super K> comparator();

    public K firstKey();

    public K lastKey();

}
