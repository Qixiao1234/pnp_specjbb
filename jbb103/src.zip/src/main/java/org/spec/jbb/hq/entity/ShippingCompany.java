/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.entity;

public final class ShippingCompany {
    private final long id;
    private final String name;
    private final String zip;

    public ShippingCompany(long id, String name, String zip) {
        this.id = id;
        this.name = name;
        this.zip = zip;
    }

    public String getName() {
        return name;
    }

    public String getZip() {
        return zip;
    }

    public long getId() {
        return id;
    }
}
