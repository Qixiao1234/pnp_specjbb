/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.scheduler;

import org.spec.jbb.core.threadpools.ThreadUtils;
import org.spec.jbb.util.random.SpecRandom;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

public class SelfReSubmitScheduler implements Scheduler {

    private ScheduledExecutorService pool;

    private ConcurrentMap<ScheduledTask, QuartzTask> quartzes;

    public SelfReSubmitScheduler(int customerDriverThreads, ThreadFactory factory) {
        pool = Executors.newScheduledThreadPool(customerDriverThreads, factory);
        quartzes = new ConcurrentHashMap<>();
    }

    @Override
    public void register(ScheduledTask task, SpecRandom delayRandom, DelayType delayType) {
        QuartzTask quartz = new QuartzTask(delayRandom, delayType, task);
        quartzes.put(task, quartz);
    }

    @Override
    public void remove(ScheduledTask task) {
        disable(task);
        quartzes.remove(task);
    }

    @Override
    public void shutdown() {
        ThreadUtils.terminatePool(pool);
    }

    @Override
    public void enable(ScheduledTask task) {
        QuartzTask quartz = quartzes.get(task);
        quartz.enable();
    }

    @Override
    public void disable(ScheduledTask task) {
        QuartzTask quartz = quartzes.get(task);
        quartz.disable();
        task.cleanup();
    }

    @Override
    public void zap() {
        // nothing to do
    }

    public class QuartzTask implements Runnable {

        private final SpecRandom random;
        private final DelayType delayType;
        private final ScheduledTask task;
        private volatile boolean isScheduled;
        private ScheduledFuture<?> future;

        public QuartzTask(SpecRandom random, DelayType delayType, ScheduledTask task) {
            this.random = random;
            this.delayType = delayType;
            this.task = task;
            isScheduled = true;
        }

        public void enable() {
            isScheduled = true;
            schedule();
        }

        public void schedule() {
            if (isScheduled) {
                future = pool.schedule(this, random.nextLong(), TimeUnit.NANOSECONDS);
            }
        }

        @Override
        public void run() {
            if (delayType == DelayType.RATE) {
                schedule();
            }

            try {
                task.getRunTask().run();
            } catch (Throwable e) {
                // shun exception, otherwise task will die
            }

            if (delayType == DelayType.DELAY) {
                schedule();
            }
        }

        public void disable() {
            if (future != null) {
                future.cancel(true);
            }
            isScheduled = false;
        }

    }

}
