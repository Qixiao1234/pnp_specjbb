/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.policy;

import org.spec.jbb.core.comm.transport.TransportType;

public class MaxSecurityPolicy implements TransportSelectionPolicy {

    @Override
    public TransportType get(String fromName, String toName, boolean spanningMultipleICs) {
        if (spanningMultipleICs) {
            return TransportType.SERIALIZED_ENCRYPTED;
        } else {
            return TransportType.SERIALIZED_ENCRYPTED;
        }
    }

}
