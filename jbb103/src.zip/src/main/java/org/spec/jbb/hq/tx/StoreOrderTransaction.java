/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.request.StoreOrderMessage;
import org.spec.jbb.sm.entity.Order;

public class StoreOrderTransaction extends AbstractTransaction {

    private final HQ hq;
    private Order order;

    public StoreOrderTransaction(HQ hq, StoreOrderMessage order, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        this.order = order.getOrder();
    }

    @Override
    public Response execute() {
        hq.addOrder(order);
        return new OkResponse();
    }

    @Override
    public String toString() {
        return "StoreOrderTx: order={" + order + "}";
    }
}
