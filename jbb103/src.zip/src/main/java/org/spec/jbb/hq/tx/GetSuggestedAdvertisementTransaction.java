/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.request.GetSuggestedAdvertisementRequest;
import org.spec.jbb.hq.tx.response.SuggestedAdvertisementResponse;

public class GetSuggestedAdvertisementTransaction extends AbstractTransaction {

    private final HQ hq;
    private final String smName;
    
    public GetSuggestedAdvertisementTransaction(HQ hq, GetSuggestedAdvertisementRequest request, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        this.smName = request.getSmName();
    }

    @Override
    public Response execute() throws TransactionException {
        return new SuggestedAdvertisementResponse(hq.getSuggestedAdvertisement(smName));
    }

    @Override
    public String toString() {
        return "GetSuggestedAdvertisementTx: smName = {" + smName + "}";
    }

}
