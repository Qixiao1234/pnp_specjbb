/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.entity.HQBusinessReport;
import org.spec.jbb.hq.entity.SMBusinessReport;
import org.spec.jbb.hq.tx.request.BusinessReportRequest;
import org.spec.jbb.hq.tx.response.BusinessReportResponse;
import org.spec.jbb.hq.tx.response.NoDataForDataMiningResponse;


public class BusinessReportTransaction extends AbstractTransaction {

    private final HQ hq;
    private final String smName;

    public BusinessReportTransaction(HQ hq, BusinessReportRequest incoming, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        this.smName = incoming.getSmName();
    }

    @Override
    public Response execute() {

        SupermarketAudit smb = new SupermarketAudit(hq, smName);
        SMBusinessReport smReport = smb.generate();

        if (smReport != null) {
            HQBusinessReport hqReport = hq.generateHQReport(smReport);

            if (hqReport != null) {
                return new BusinessReportResponse(hqReport);
            }
        }

        // A report will not be produced if there is insufficient data to create one.  This should only
        // occur very early in the benchmark.
        //
        return new NoDataForDataMiningResponse();
    }

    @Override
    public String toString() {
        return "BusinessReportTx";
    }

}
