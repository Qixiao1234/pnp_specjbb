/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.response;

import org.spec.jbb.core.comm.AbstractResponse;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
public class RollbackResponse extends AbstractResponse {

    private static final long serialVersionUID = 27682407199301034L;
    @XmlElement
    private final String msg;

    private RollbackResponse() {
        // JAXB
        this(null);
    }

    public RollbackResponse(String msg) {
        this.msg = msg;
    }

    public String getMsg() {
        return msg;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        RollbackResponse that = (RollbackResponse) o;

        if (msg != null ? !msg.equals(that.msg) : that.msg != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), msg);
    }

    @Override
    public String toString() {
        return "Rollback, reason: " + msg;
    }
}
