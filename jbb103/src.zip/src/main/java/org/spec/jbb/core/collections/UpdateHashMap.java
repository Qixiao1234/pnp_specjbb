/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

import org.spec.jbb.util.InstanceFactory;

public class UpdateHashMap<K,V> extends CreateHashMap<K,V> implements UpdateMap<K,V> {

    private static final long serialVersionUID = 7017064880758202346L;

    public UpdateHashMap(InstanceFactory<V> instanceFactory) {
        super(instanceFactory);
    }

    @Override
    public void update(K key, V value, BinaryFunction<V> updateFunction) {
        super.put(key, updateFunction.apply(super.getOrCreate(key), value));
    }

}
