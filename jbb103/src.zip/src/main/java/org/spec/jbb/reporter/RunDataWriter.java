/*
 * Copyright (c) 2012-2015 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

import org.spec.jbb.core.comm.LocationInfo;
import org.spec.jbb.core.comm.ConnectionClient;
import org.spec.jbb.core.threadpools.SpecThreadFactory;
import org.spec.jbb.core.threadpools.ThreadUtils;
import org.spec.jbb.infra.IterationStatus;
import org.spec.jbb.infra.ProfileData;
import org.spec.jbb.infra.TimeData;
import org.spec.jbb.infra.TransferLogsAgent.TransferFileType;
import org.spec.jbb.infra.validation.ValidationReport;
import org.spec.jbb.reporter.data.DataWriter;
import org.spec.jbb.util.JbbProperties;

import java.io.IOException;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RunDataWriter implements AutoCloseable {

    private final BlockingQueue<Frame> outstandingFrames;
    private final ExecutorService writer;
    private final DataWriter dataWriter;

    public RunDataWriter(DataWriter writer) {
        this(writer, 10_000);
    }

    public RunDataWriter(DataWriter writer, int bufferSize) {
        outstandingFrames = new ArrayBlockingQueue<>(bufferSize);
        this.writer = Executors.newSingleThreadExecutor(SpecThreadFactory.newFactory("RunDataWriter"));
        this.writer.execute(new WriterTask(dataWriter = writer));
    }
    
    public void open(ConnectionClient client) throws IOException {
        dataWriter.open(client);
    }

    @Override
    public void close() {
        ThreadUtils.terminatePool(writer);
    }

    public void write(Frame frame) {
        try {
            outstandingFrames.put(frame);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public void write(ProfileData profileData) {
        write(new StatsFrame(profileData));
    }

    public void write(Map<String, JbbProperties> map) {
        write(new PropertiesFrame(map));
    }

    public void write(String agent, byte[] data, TransferFileType type) {
        write(new LogRecordFrame(agent, data, type));
    }

    public void writeRunStatus(IterationStatus status) {
        write(new RunStatusFrame(System.currentTimeMillis(), status));
    }
    
    public void write(ValidationReport report) {
        write(new ValidationFrame(report));
    }

    public void writeMark(String key, String value) {
        write(new MarkFrame(key, value));
    }

    public void writeAgentInfo(String agent, Collection<LocationInfo> locations) {
        write(new AgentInfoFrame(agent, locations));
    }
    
    public void write(TimeData timeData) {
        write(new TimeDataFrame(timeData));
    }

    private class WriterTask implements Runnable {
        private final DataWriter writer;

        public WriterTask(DataWriter writer) {
            this.writer = writer;
        }

        @Override
        public void run() {
            try {
                while (!Thread.interrupted()) {
                    Frame frame = outstandingFrames.take();
                    writeOut(frame);
                }
            } catch (InterruptedException e) {
                // ok, let's terminate
            }

            // write out all outstanding frames
            Frame frame;
            while ((frame = outstandingFrames.poll()) != null) {
                writeOut(frame);
            }

            writeOut(new EndOfStreamFrame());

            try {
                writer.flush();
            } catch (IOException e) {
                // ignore
            }
            
            writer.close();

            // closing streams
        }
        
        private void writeOut(Frame frame) {
            try {
                writer.write(frame);
            } catch (IOException e) {
                throw new IllegalStateException(e);
            }
        }

    }

}
