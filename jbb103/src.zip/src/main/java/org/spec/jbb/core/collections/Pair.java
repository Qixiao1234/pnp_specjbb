/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

import java.io.Serializable;
import java.util.Objects;

public class Pair<L, R> implements Serializable {
    public static final long serialVersionUID = 7496827231381720102L;
    
    public final L left;
    public final R right;
    
    public Pair(L left, R right) {
        this.left = left;
        this.right = right;
    }

    public L getLeft() {
        return left;
    }

    public R getRight() {
        return right;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Pair pair = (Pair) o;

        if (left != null ? !left.equals(pair.left) : pair.left != null) {
            return false;
        }
        if (right != null ? !right.equals(pair.right) : pair.right != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(left, right);
    }
    
    @Override
    public String toString() {
        return "(" + left + ", " + right + ")";
    }
}
