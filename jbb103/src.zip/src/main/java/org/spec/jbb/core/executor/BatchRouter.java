/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.executor;

import org.spec.jbb.core.comm.ConnectionClient;

/**
 * Batch Router.
 * <p/>
 * The general contract for implementors of this interface is following:
 * - acceptRequest batches for routing/execution
 * - register lifecycle events handlers for enqueued batches
 * - gather statistics for all batches down the routing hierarchy
 *
 * @see AbstractBatchRouter
 */
public interface BatchRouter extends ConnectionClient {

    /**
     * Shutdown the router/executor.
     */
    void shutdown();


}
