/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.advertisement;

import org.spec.jbb.hq.entity.Category;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;

/**
 * The class represents a one entry of issued advertisement.
 * It contains a category and a list of product's barcode for advertisement
 * if the current product in shopping cart belongs to this category. 
 *
 */
@XmlRootElement
public class IssuedAdvertisement implements Serializable {
    
    public static final IssuedAdvertisement EMPTY = new IssuedAdvertisement();
    private static final long serialVersionUID = 6903014061641418083L;

    @XmlElement
    private final Category category;
    
    @XmlElementWrapper
    private final List<Long> barcodes;
    
    private IssuedAdvertisement() {
        this.category = null;
        this.barcodes = null;
        // JAXB constructor
    }

    public IssuedAdvertisement(Category category, List<Long> barcodes) {
        this.category = category;
        this.barcodes = barcodes;
    }

    public Category getCategory() {
        return category;
    }

    public List<Long> getBarcodes() {
        return barcodes;
    }

    @Override
    public String toString() {
        return "Category " + category + ":" + barcodes;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        IssuedAdvertisement that = (IssuedAdvertisement) o;

        if (category != null ? !category.equals(that.category) : that.category != null) {
            return false;
        }

        if (barcodes != null ? !barcodes.equals(that.barcodes) : that.barcodes != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                super.hashCode(),
                category,
                barcodes
        );
    }

}
