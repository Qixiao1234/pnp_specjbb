/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.scheduler;

import org.spec.jbb.core.threadpools.SpecThreadFactory;
import org.spec.jbb.util.JbbProperties;

import java.util.concurrent.ThreadFactory;

public class SchedulerFactory {

    private SchedulerFactory() {
        // prevent instantiation
    }

    public static Scheduler getScheduler(String name, String purpose, SchedulerType type) {
        int threadCount = JbbProperties.getInstance().getCustomerDriverThreads(purpose);
        ThreadFactory factory = SpecThreadFactory.newFactory(name + "." + purpose, Thread.MAX_PRIORITY, true);

        switch(type) {
            case SELF_RESUBMIT:
                return new SelfReSubmitScheduler(threadCount, factory);
            case SELF_RESUBMIT_QUEUED:
                return new SelfReSubmitQueuedScheduler(threadCount, factory);
            case LOOP_TIMER_QUEUED:
                return new LoopTimerQueuedScheduler(threadCount, factory);
            case PLL:
                return new PLLScheduler(threadCount, factory);
            case SINGLE_LOOP_TIMER:
                return new SingleLoopTimerScheduler(threadCount, factory);
            default:
                throw new IllegalArgumentException("Unknown scheduler type: " + type);
        }
    }


    public static Scheduler getScheduler(String name, String purpose) {
        SchedulerType type = JbbProperties.getInstance().getSchedulerType();
        return getScheduler(name, purpose, type);
    }

}
