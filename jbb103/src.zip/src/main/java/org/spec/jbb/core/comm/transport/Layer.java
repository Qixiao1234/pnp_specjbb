/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport;

/**
 * Depicts one layer, like in ISO OSI model.
 *
 * @param <TT> top-level type
 * @param <BT> bottom-level type
 */
public interface Layer<TT, BT> {

    BT convertDown(TT topInstance);

    TT convertUp(BT bottomInstance);

}
