/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

import org.spec.jbb.infra.ProfileData;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Pattern;

public class RegexpVisitor implements Visitor {
    private final Aggregator aggregator;
    private final Timeline timeline;
    private long startTime;
    private Collection<String> catchAttrs;

    public RegexpVisitor(Collection<String> attrs, String regexp) {
        this(attrs, regexp, new SumAggregator());
    }

    public RegexpVisitor(Collection<String> attrs, String regexp, Aggregator aggregator) {
        this.aggregator = aggregator;
        this.timeline = new Timeline();

        Pattern pattern = Pattern.compile(regexp);
        this.catchAttrs = new HashSet<>();
        for(String attr : attrs) {
            if(pattern.matcher(attr).matches()) {
                catchAttrs.add(attr);
            }
        }

//        System.err.println(pattern + " matches " + catchAttrs);
    }

    @Override
    public void visit(StatsFrame point) {
        if (startTime == 0) {
            startTime = point.getTime();
        }

        ProfileData profileData = point.getProfileData();
        List<Double> values = new ArrayList<>();
        for (String attr : catchAttrs) {
            Double val = toDouble(profileData.attr(attr));
            if (val != null) {
                values.add(val);
            }
        }

        if (values.size() > 0) {
            Double finalValue = aggregator.aggregate(values);
            timeline.add(new DataPoint(point.getTime() - startTime, finalValue));
        }
    }

    protected Double toDouble(Object val) {
        if ((val != null) && (val instanceof Number)) {
            return ((Number) val).doubleValue();
        }
        return null;
    }
            
    public Timeline getData() {
        return timeline;
    }

    public boolean shouldRun() {
        return !catchAttrs.isEmpty();
    }

}
