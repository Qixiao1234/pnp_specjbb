/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

public class InsufficientDataForDataMiningException extends Exception {
    private static final long serialVersionUID = -7826930373654631691L;
}
