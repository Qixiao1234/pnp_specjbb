/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity.grizzlynio.proto;

import org.glassfish.grizzly.Buffer;
import org.glassfish.grizzly.filterchain.BaseFilter;
import org.glassfish.grizzly.filterchain.FilterChainContext;
import org.glassfish.grizzly.filterchain.NextAction;
import org.spec.jbb.core.comm.Packet;
import org.spec.jbb.core.comm.connectivity.ServerCallback;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.InetSocketAddress;

public class ServerProtocolDataUnitFilter extends BaseFilter {
    private final ServerCallback callback;

    public ServerProtocolDataUnitFilter(ServerCallback callback) {
        this.callback = callback;
    }

    @Override
    public NextAction handleRead(final FilterChainContext ctx)
            throws IOException {
        final Object message = ctx.getMessage();
        final Object address = ctx.getAddress();

        if (message instanceof Buffer) {
            ((Buffer) message).allowBufferDispose(true);
        }

        if (message instanceof ProtocolDataUnit) {
            ProtocolDataUnit answer = parseUnit((ProtocolDataUnit)message, address);
            ctx.write(address, answer, null);
        }

        return ctx.getStopAction();
    }

    private ProtocolDataUnit parseUnit(ProtocolDataUnit unit, Object address) {
        if (unit.getType() == ProtocolDataUnit.Type.IP_REQUEST) {
            byte[] data = ((InetSocketAddress) address).getAddress().getAddress();
            return new ProtocolDataUnit(ProtocolDataUnit.Type.IP_DATA, null, data);
        }

        if (unit.getType() == ProtocolDataUnit.Type.DATA) {
            try {
                Packet data = callback.handle(unit.toPacket());
                return new ProtocolDataUnit(data);
            } catch (Throwable e) {
                StringWriter sw = new StringWriter();
                PrintWriter pw = new PrintWriter(sw, true);
                e.printStackTrace(pw);
                pw.close();

                return new ProtocolDataUnit(ProtocolDataUnit.Type.ERROR, null, sw.toString().getBytes());
            }
        }

        return new ProtocolDataUnit(ProtocolDataUnit.Type.ERROR, null, null);
    }

}
