/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx;

import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.sm.SM;

public abstract class AbstractInventoryTransaction extends AbstractSMTransaction {

    private final long barCode;
    private final int quantity;

    public AbstractInventoryTransaction(SM sm, long barCode, int quantity, TransactionContext ctx) {
        super(sm,  ctx);
        this.barCode = barCode;
        this.quantity = quantity;
    }

    protected long getBarcode() {
        return barCode;
    }

    protected int getQuantity() {
        return quantity;
    }

    @Override
    public String toString() {
        return "InventoryTx: barcode = {" + barCode + "}, quantity = {" + quantity + "}";
    }

}
