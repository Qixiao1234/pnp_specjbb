/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections.queues;

import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/**
 * Partial implementation of _bounded_ PriorityBlockingQueue<T>
 *
 * @param <T>
 * @see java.util.concurrent.PriorityBlockingQueue
 */
public class BoundedPriorityBlockingQueue<T extends Comparable> extends NonSupportedBlockingQueue<T> {

    private PriorityBlockingQueue<T> backingQueue;

    private Semaphore spaceAvailable;

    public BoundedPriorityBlockingQueue(int size) {
        this.backingQueue = new PriorityBlockingQueue<>();
        this.spaceAvailable = new Semaphore(size);
    }

    @Override
    public T poll(long timeout, TimeUnit unit) throws InterruptedException {
        T t = backingQueue.poll(timeout, unit);
        if (t != null) {
            spaceAvailable.release(1);
        }
        return t;
    }

    @Override
    public boolean offer(T t) {
        boolean isAcquired = spaceAvailable.tryAcquire();
        if (isAcquired) {
            return backingQueue.offer(t);
        } else {
            return false;
        }
    }

    @Override
    public int size() {
        return backingQueue.size();
    }

    @Override
    public void put(T t) throws InterruptedException {
        spaceAvailable.acquire(1);
        backingQueue.put(t);
    }
}
