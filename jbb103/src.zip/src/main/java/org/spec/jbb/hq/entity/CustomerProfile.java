/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.entity;

import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.collections.Window;
import org.spec.jbb.core.comm.transport.encapsulation.JAXBAdapters;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.core.probe.ProbeFactory;
import org.spec.jbb.sm.coupon.Coupon;
import org.spec.jbb.sm.coupon.GenericCoupon;
import org.spec.jbb.sm.coupon.SpecificCoupon;
import org.spec.jbb.util.JbbProperties;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Represents the customer profile. Keeps the information about available
 * coupons and advertisements.
 * 
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class CustomerProfile implements Measurable, Serializable {
    private static final long serialVersionUID = -5993793751976253816L;
    /**
     * Queue of available generic coupons
     */
    @XmlJavaTypeAdapter(JAXBAdapters.PriorityQueueAdapter.class)
    private Queue<GenericCoupon> genericCoupons;
    /**
     * Map barcode to queue of available coupons for this barcode
     */
    @XmlJavaTypeAdapter(JAXBAdapters.ConcurrentHashMap2PriorityQueueAdapter.class)
    private Map<Long, Queue<SpecificCoupon>> specificCoupons;

    @XmlJavaTypeAdapter(JAXBAdapters.PriorityQueueAdapter.class)
    private Queue<SpecificCoupon> globalSpecificCoupons;

    /**
     * Fixed array of advertisements
     */
    @XmlElement
    private Window<Long> advertisements;
    
    private transient Lock lock;
    
    private transient volatile Probe probe;
    
    public CustomerProfile() {
        genericCoupons = new PriorityQueue<>();
        specificCoupons = new ConcurrentHashMap<>();
        globalSpecificCoupons = new PriorityQueue<>();
        advertisements = new Window<>(JbbProperties.getInstance().getAdvertisementCustomerSize());
        lock = new ReentrantLock();
        probe = ProbeFactory.getDefaultProbe();
    }

    public CustomerProfile(CustomerProfile cp) {
        this();
        genericCoupons.addAll(cp.genericCoupons);
        for(Map.Entry<Long, Queue<SpecificCoupon>> entry : cp.specificCoupons.entrySet()) {
            putSpecificCoupon(entry.getKey(), new PriorityQueue<>(entry.getValue()));
        }
        advertisements = new Window<>(cp.advertisements);
    }

    /**
     * Returns unexpired generic coupon
     * 
     * @return available generic coupon or null if there is no one
     */
    public GenericCoupon pollGenericCoupon() {
        lock.lock();
        try {
            GenericCoupon gc = genericCoupons.poll();
            if (gc != null) {
                probe.inc("genericApplied");
            }
            return gc;
        } finally {
            lock.unlock();
        }
    }

    /**
     * Returns unexpired specific coupon
     * 
     * @param barcode
     *            of the product
     * @return available specific coupon or null if there is no one
     */
    public SpecificCoupon pollSpecificCoupon(long barcode) {
        lock.lock();
        try {
            Queue<SpecificCoupon> queue = specificCoupons.get(barcode);
            SpecificCoupon cp = (queue == null) ? null : queue.poll();
            if (cp != null) {
                probe.inc("specificApplied");
            }
            return cp;
        } finally {
            lock.unlock();
        }
    }

    /**
     * Put generic coupon into profile
     * 
     * @param coupon
     *            to add to profile
     */
    public void addGenericCoupon(GenericCoupon coupon) {
        lock.lock();
        try {
            genericCoupons.add(coupon);
            probe.inc("genericIssued");
        } finally {
            lock.unlock();
        }
    }
    
    /**
     * Return back the generic coupon if it was taken but not used
     * 
     * @param coupon
     *            to add to profile
     */
    public void returnBackGenericCoupon(GenericCoupon coupon) {
        lock.lock();
        try {
            addGenericCoupon(coupon);
            probe.add("genericApplied", -1);
        } finally {
            lock.unlock();
        }
    }

    /**
     * Puts specific coupon into profile
     * 
     * @param coupon
     *            to add to profile
     */
    public void addSpecificCoupon(SpecificCoupon coupon) {
        lock.lock();
        try {
            addSpecificCoupons(coupon.getBarcode(), Collections.singletonList(coupon));
        } finally {
            lock.unlock();
        }
    }
    
    /**
     * Return back the specific coupon if it was taken but not used
     * 
     * @param coupon
     *            to add to profile
     */
    public void returnBackSpecificCoupon(SpecificCoupon coupon) {
        lock.lock();
        try {
            putSpecificCoupon(coupon.getBarcode(), Collections.singletonList(coupon));
            probe.add("specificApplied", -1);
        } finally {
            lock.unlock();
        }
    }

    /**
     * Puts the list of specific coupons into profile
     * 
     * @param coupons
     *            to add to profile
     */
    public void addSpecificCoupons(long barcode, List<SpecificCoupon> coupons) {
        lock.lock();
        try {
            putSpecificCoupon(barcode, coupons);
            probe.add("specificIssued", coupons.size());
        } finally {
            lock.unlock();
        }
    }
    
    private void putSpecificCoupon(long barcode, Collection<SpecificCoupon> coupons) {
        lock.lock();
        try {
            Queue<SpecificCoupon> queue = specificCoupons.get(barcode);
            if (queue == null) {
                queue = new PriorityQueue<>();
                specificCoupons.put(barcode, queue);
            }
            queue.addAll(coupons);
            globalSpecificCoupons.addAll(coupons);
        } finally {
            lock.unlock();
        }
    }

    /**
     * Remove expired both specific and generic coupons from the profile
     */
    public void removeExpiredCoupons() {
        lock.lock();
        try {
            Date now = new Date();

            Coupon c;

            /**
             * This will try to expunge the specific coupons which barcodes were never requested.
             * As fast-path we look at global queue to determine which barcodes need to be reviewed.
             * It will usually return with empty #expungedBarcodes, and we'll just fall-through.
             * If some barcodes need cleanup, then we will do aggressive cleanup in per-barcode queues.
             */

            Set<Long> expungedBarcodes = new HashSet<>();
            while((c = globalSpecificCoupons.peek()) != null && c.isExpired(now)) {
                SpecificCoupon expunged = globalSpecificCoupons.poll();
                expungedBarcodes.add(expunged.getBarcode());
            }

            if (expungedBarcodes.size() > 0) {
                List<Long> expungedQueues = new ArrayList<>();
                for (Long barcode : expungedBarcodes) {
                    Queue<SpecificCoupon> queue = specificCoupons.get(barcode);
                    if (queue != null) {
                        while ((c = queue.peek()) != null && c.isExpired(now)) {
                            queue.poll();
                            probe.inc("specificExpired");
                        }
                        if (queue.peek() == null) {
                            expungedQueues.add(barcode);
                        }
                    }
                }

                // remove empty queues
                for (Long barcode : expungedQueues) {
                    specificCoupons.remove(barcode);
                }
            }

            // Remove expired generic coupons
            while ((c = genericCoupons.peek()) != null && c.isExpired(now)) {
                genericCoupons.poll();
                probe.inc("genericExpired");
            }

        } finally {
            lock.unlock();
        }
    }

    public void addAdvertisement(long barcode) {
        lock.lock();
        try {
            advertisements.add(barcode);
        } finally {
            lock.unlock();
        }
    }
    
    public Set<Long> getBarcodesForSpecificCoupons() {
        lock.lock();
        try {
            return Collections.unmodifiableSet(specificCoupons.keySet());
        } finally {
            lock.unlock();
        }
    }

    public int getBarcodesForSpecificCouponsSize() {
        return specificCoupons.size();
    }

    public int getAdvertisementSize() {
        lock.lock();
        try {
            return advertisements.size();
        } finally {
            lock.unlock();
        }
    }
    
    public Collection<Long> getAdvertisementBarcodes() {
        lock.lock();
        try {
            return advertisements.getAll();
        } finally {
            lock.unlock();
        }
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CustomerProfile that = (CustomerProfile) o;
        
        if (!advertisements.equals(that.advertisements)) {
            return false;
        }

        // Queue does not support deep equal
        // Comparator is not used so natural ordering is used => no need to compare order
        // equals is used in testing only => no need to optimize it => compare them as Sets
        // Sets may hide the same coupons into one entry, so compare sizes also
        if (genericCoupons.size() != that.genericCoupons.size()
                || !new HashSet<>(genericCoupons).equals(new HashSet<>(that.genericCoupons))) {
            return false;
        }

        // Compare them as Map<Long, Set<SpecificCoupon>>
        // See comment above
        Map<Long, Set<SpecificCoupon>> a = new HashMap<>();
        Map<Long, Integer> aSizes = new HashMap<>();
        for (Entry<Long, Queue<SpecificCoupon>> entry : specificCoupons.entrySet()) {
            a.put(entry.getKey(), new HashSet<>(entry.getValue()));
            aSizes.put(entry.getKey(), entry.getValue().size());
        }
        Map<Long, Set<SpecificCoupon>> b = new HashMap<>();
        Map<Long, Integer> bSizes = new HashMap<>();
        for (Entry<Long, Queue<SpecificCoupon>> entry : that.specificCoupons.entrySet()) {
            b.put(entry.getKey(), new HashSet<>(entry.getValue()));
            bSizes.put(entry.getKey(), entry.getValue().size());
        }
        if (!aSizes.equals(bSizes) || !a.equals(b)) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(advertisements, genericCoupons, specificCoupons.keySet());
    }

    private void writeObject(ObjectOutputStream oos) throws IOException {
        lock.lock();
        try {
            oos.defaultWriteObject();
        } finally {
            lock.unlock();
        }
    }

    @Override
    public String toString() {
        return "Profile {" + 
                "Generic coupons=" + genericCoupons + 
                ", Specific coupons=" + specificCoupons + 
                ", Advertisements=" + advertisements + 
                "}";
    }

    private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
        ois.defaultReadObject();
        lock = new ReentrantLock();
    }

    @Override
    public void instrument(Probe probe) {
        if (probe != this.probe) {
            this.probe = probe;
        }
    }

    @Override
    public void sample() {
        // do nothing
    }

}
