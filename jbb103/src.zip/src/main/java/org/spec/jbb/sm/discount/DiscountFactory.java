/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.discount;

/**
 * The factory class is responsible for discount instances creation
 *
 */
public class DiscountFactory {
    public static Discount createDiscount(long barcode, int percent) {
        if(percent == 0) {
            return new BOGODiscount(barcode);
        } else {
            return new PercentageDiscount(barcode, percent);
        }
    }
}
