/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.transport;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import javax.crypto.spec.SecretKeySpec;

/**
 * This class holds encryption keys for transports that leverage Java Cryptography API.
 */
public class EncryptionKeys {

    private static final HashMap<String, SecretKeySpec> KEYS = new HashMap<>();

    static {
        try {
            KEYS.put("AES", new SecretKeySpec("RIP Alan Adamson".getBytes("US-ASCII"), "AES"));
        } catch (UnsupportedEncodingException ex) {
            // Should never happen. Any JVM implementation MUST support US-ASCII
            throw new IllegalArgumentException("JVM does not support US-ASCII encoding");
        }
        KEYS.put("DES", new SecretKeySpec(
                new byte[]{-23, 7, 8, -70, 74, 50, 84, 79}, "DES"));
    }

    public static SecretKeySpec getFor(String cipherName) {
        return KEYS.get(cipherName);
    }
}
