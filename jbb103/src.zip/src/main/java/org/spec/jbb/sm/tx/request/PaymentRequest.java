/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.request;

import org.spec.jbb.core.comm.AbstractRequest;
import org.spec.jbb.core.comm.transport.TransportType;
import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.sp.Invoice;
import org.spec.jbb.sp.SP;
import org.spec.jbb.sp.tx.PaymentProcessOperation;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
public class PaymentRequest extends AbstractRequest {

    private static final long serialVersionUID = -3176254783580356782L;
    @XmlElement
    private final Invoice.Key key;

    private PaymentRequest() {
        // JAXB
        this(null);
    }

    public PaymentRequest(Invoice.Key key) {
        this.key = key;
    }

    public Invoice.Key getKey() {
        return key;
    }

    @Override
    public boolean isDurable() {
        return false;
    }

    @Override
    public boolean isRequiresResponse() {
        return false;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        PaymentRequest that = (PaymentRequest) o;

        if (key != null ? !key.equals(that.key) : that.key != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(key);
    }

    @Override
    public Transaction getTransaction(SP sp, TransactionContext ctx) {
        return new PaymentProcessOperation(sp, this, ctx);
    }

    @Override
    public String toString() {
        return "Payment for invoice #" + key;
    }

    @Override
    public TransportType getTransportHint() {
        return TransportType.XML;
    }

}
