/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.TransactionException;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.request.InventoryValueRequest;
import org.spec.jbb.hq.tx.response.InventoryValueResponse;

import java.math.BigDecimal;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

public class InventoryValueTransaction extends AbstractTransaction {

    private final HQ hq;
    private final String smName;

    public InventoryValueTransaction(HQ hq, InventoryValueRequest request, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        this.smName = request.getSmName();
    }

    @Override
    public Response execute() throws TransactionException {
        BigDecimal totalValue = BigDecimal.ZERO;
        for(Map.Entry<Long, AtomicLong> entry : hq.getSupermarketInventoryMirror(smName).entrySet()) {
            BigDecimal price = hq.findProduct(entry.getKey()).getPrice();
            long quantity = entry.getValue().get();
            totalValue = totalValue.add(price.multiply(BigDecimal.valueOf(quantity, 2)).setScale(2, BigDecimal.ROUND_HALF_EVEN));
        }
        return new InventoryValueResponse(totalValue);
    }

    @Override
    public String toString() {
        return "InventoryValueTx: smName={" + smName + "}";
    }

}
