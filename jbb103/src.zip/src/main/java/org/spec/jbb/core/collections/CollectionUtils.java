/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

import org.spec.jbb.util.InstanceFactory;

import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ThreadLocalRandom;

public class CollectionUtils {

    /**
     * Returns "window" from map: window will contain only mappings which keys are between
     * (index("pivot") - window) and (index("pivot") + window) indicies.
     *
     * @param map source
     * @param pivot pivot key
     * @param window window size
     * @param <K> key type
     * @param <V> value type
     * @return copy of window
     */
    public static <K,V> NavigableMap<K,V> getWindow(NavigableMap<K,V> map, K pivot, int window) {

        NavigableMap<K, V> result = new TreeMap<>();

        final NavigableMap<K, V> forwMap = map.tailMap(pivot, true);
        final NavigableMap<K, V> backMap = map.headMap(pivot, true).descendingMap();

        int trueWindow = Math.min(window, Math.min(forwMap.size(), backMap.size()));

        Iterator<Map.Entry<K, V>> forwIterator = forwMap.entrySet().iterator();
        Iterator<Map.Entry<K, V>> backIterator = backMap.entrySet().iterator();

        for(int c = 0; c < trueWindow && forwIterator.hasNext(); c++) {
            Map.Entry<K, V> entry = forwIterator.next();
            result.put(entry.getKey(), entry.getValue());
        }

        for(int c = 0; c < trueWindow && backIterator.hasNext(); c++) {
            Map.Entry<K, V> entry = backIterator.next();
            result.put(entry.getKey(), entry.getValue());
        }

        return result;
    }

    /**
     * Apply given function to every element of list
     *
     * @param list values to process
     * @param f function to apply
     * @param <E> destination type
     * @param <V> source type
     * @return processed list
     */
    public static <E,V> List<E> map(List<V> list, UnaryFunction<V,E> f) {
        List<E> result = new ArrayList<>(list.size());
        for(V v : list) {
            result.add(f.apply(v));
        }
        return result;
    }

    public static <E, V> Collection<V> map(final Collection<E> collection, final UnaryFunction<E, V> f) {
        return new AbstractCollection<V>() {
            @Override
            public Iterator<V> iterator() {
                final Iterator<E> iterator = collection.iterator();
                return new Iterator<V>() {
                    @Override
                    public boolean hasNext() {
                        return iterator.hasNext();
                    }

                    @Override
                    public V next() {
                        return f.apply(iterator.next());
                    }

                    @Override
                    public void remove() {
                        iterator.remove();
                    }
                };
            }

            @Override
            public int size() {
                return collection.size();
            }
        };
    }

    /**
     * Return first "count" elements from the list.
     * If list does not contain enough elements, return entire list.
     *
     * @param list list to process
     * @param count how many elements to take
     * @param <E> type
     * @return head list
     */
    public static <E> List<E> head(List<E> list, int count) {
        return list.size() <= count ? list : list.subList(0, count);
    }

    /**
     * Return last "count" elements from the list.
     * If list does not contain enough elements, return entire list.
     *
     * @param list list to process
     * @param count how many elements to take
     * @param <E> type
     * @return tail list
     */
    public static <E> List<E> tail(List<E> list, int count) {
        int lsize = list.size();
        return lsize <= count ? list : list.subList(lsize-count, lsize);
    }

    /**
     * returns list of MultiSet elements sorted by occurrence (ascending)
     * @param set
     * @param <E>
     * @return
     */
    public static <E> List<E> elementsAsList(MultiSet<E> set) {
        List<MultiSet.Entry<E>> sortedEntries = new ArrayList<>(set.entrySet());
        Collections.sort(sortedEntries, new Comparator<MultiSet.Entry<E>>() {
            @Override
            public int compare(MultiSet.Entry<E> a, MultiSet.Entry<E> b) {
                return Integer.compare(a.getCount(), b.getCount());
            }
        });
        return CollectionUtils.map(sortedEntries, new UnaryFunction<MultiSet.Entry<E>, E>(){
            @Override
            public E apply(MultiSet.Entry<E> value) {
                return value.getElement();
            }
        });
    }

    /**
     * Return unmodifiable view to MultiSet.
     * Modifying calls to this view will result in exception.
     * All changes in decorated multiset are visible in unmodifiable view.
     *
     * @param multiset multiset to decorate
     * @param <E> type
     * @return unmodifiable view
     */
    public static <E> MultiSet<E> unmodifiableMultiSet(MultiSet<E> multiset) {
        return new UnmodifiableMultiSet<E>(multiset);
    }

    public static int integerSaturate(long l) {
        if (l > Integer.MAX_VALUE || l < 0) {
            throw new ArithmeticException("Integer overflow: " + l);
        }
        return (int) l;
    }

    public static int integerSaturatedAdd(int x, int y) {
        return integerSaturate((long)x+(long)y);
    }

    /**
     * Unmodifiable adapter for MultiSet.
     * @param <E>
     */
    private static class UnmodifiableMultiSet<E> extends AbstractMultiSet<E> {

        private final MultiSet<E> backingSet;

        public UnmodifiableMultiSet(MultiSet<E> backingSet) {
            this.backingSet = backingSet;
        }

        @Override
        public int count(Object element) {
            return backingSet.count(element);
        }

        @Override
        public Set<E> elementSet() {
            return Collections.unmodifiableSet(backingSet.elementSet());
        }

        @Override
        public void clear() {
            throw new UnsupportedOperationException();
        }

        @Override
        public int size() {
            return backingSet.size();
        }

        @Override
        public boolean isEmpty() {
            return backingSet.isEmpty();
        }

        @Override
        public boolean setCount(E e, int oldCount, int newCount) {
            throw new UnsupportedOperationException();
        }

        @Override
        public int setCount(E e, int count) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Set<MultiSet.Entry<E>> entrySet() {
            return Collections.unmodifiableSet(backingSet.entrySet());
        }

        @Override
        public int hashCode() {
            return backingSet.hashCode();
        }

        @Override
        public boolean equals(Object obj) {
            return backingSet.equals(obj);    //To change body of overridden methods use File | Settings | File Templates.
        }

        @Override
        void update(E e, int count) {
            throw new UnsupportedOperationException();
        }

    }

    public interface RandomProvider {
        public int nextInt(int max);
    }

    private static class EmptyMix<E> implements Mix<E> {

        @Override
        public boolean isEmpty() {
            return true;
        }

        @Override
        public E next() {
            return null;
        }

        @Override
        public int getMixWeight() {
            return 0;
        }

    }

    private static class SingletonMix<E> implements Mix<E> {

        private final E element;

        SingletonMix(E element) {
            this.element = element;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public E next() {
            return element;
        }

        @Override
        public int getMixWeight() {
            return 1;
        }
    }

    private abstract static class FixedMix<E> implements Mix<E>, RandomProvider {

        private final E[] elems;
        private final int[] wSums;
        private final int maxWeight;

        FixedMix(E[] elements, int[] weights) {
            elems = Arrays.copyOf(elements, elements.length);
            wSums = new int[weights.length];
            int sum = 0;
            for (int i = 0; i < weights.length; i++) {
                if (weights[i] < 0) {
                    throw new IllegalArgumentException("weight["+i+"]="+weights[i]+" (should be non-negative)");
                }
                sum += weights[i];
                wSums[i] = sum;
            }
            maxWeight = sum;
        }

        @Override
        public boolean isEmpty() {
            return (maxWeight == 0);
        }

        @Override
        public E next() {
            if (isEmpty()) {
                return null;
            }
            int rnd = nextInt(maxWeight);
            int index = Arrays.binarySearch(wSums, rnd);
            if (index >= 0) {
                return elems[index+1];
            } else {
                return elems[-(index+1)];
            }
        }

        @Override
        public int getMixWeight() {
            return maxWeight;
        }
    }

    private abstract static class ArrayUniformMix<E> implements Mix<E>, RandomProvider {

        private final E[] elements;

        ArrayUniformMix(E[] elements) {
            this.elements = elements;
        }

        @Override
        public boolean isEmpty() {
            return elements.length > 0;
        }

        @Override
        public E next() {
            return elements[nextInt(elements.length)];
        }

        @Override
        public int getMixWeight() {
            return elements.length;
        }
    }
    
    private static class LazyMix<E> implements Mix<E> {
        private final InstanceFactory<Mix<E>> factory;
        private Mix<E> backingMix;
        private final int totalWeight;
        
        LazyMix(InstanceFactory<Mix<E>> factory, int futureTotalWeight) {
            this.factory = factory;
            this.backingMix = null;
            this.totalWeight = futureTotalWeight;
        }

        @Override
        public int getMixWeight() {
            return totalWeight;
        }

        @Override
        public boolean isEmpty() {
            return totalWeight > 0;
        }

        @Override
        public E next() {
            if(backingMix == null) {
                backingMix = factory.getInstance();
                if(backingMix.getMixWeight() != totalWeight) {
                    throw new IllegalStateException("The mix weight " + backingMix.getMixWeight() + 
                            " is not the same as predicted " + totalWeight);
                }
            }
            return backingMix.next();
        }
    }
    
    /**
     * Binary case: pick one random value out of two possibilities.
     *
     * @param e0 first element
     * @param w0 first element weight
     * @param e1 second element
     * @param w1 second element weight
     * @param <E> type
     * @return random element; null, if (w0+w1) == 0
     */
    public static <E> E selectRandom(E e0, int w0, E e1, int w1) {
        int size = w0 + w1;
        if (size > 0) {
            int index = ThreadLocalRandom.current().nextInt(size);
            if (index < w0) {
                return e0;
            } else {
                return e1;
            }
        }
        return null;
    }

    /**
     * Triple case: pick one random value out of three possibilities.
     *
     * @param e0 first element
     * @param w0 first element weight
     * @param e1 second element
     * @param w1 second element weight
     * @param e2 third element
     * @param w2 third element weight
     * @param <E> type
     * @return random element; null, if (w0+w1+w2) == 0
     */
    public static <E> E selectRandom(E e0, int w0, E e1, int w1, E e2, int w2) {
        int size = w0 + w1 + w2;
        if (size > 0) {
            int index = ThreadLocalRandom.current().nextInt(size);
            if (index < w0) {
                return e0;
            } else if (index < w0 + w1) {
                return e1;
            } else {
                return e2;
            }
        }
        return null;
    }

    /**
     * Pick one random value out of four possibilities.
     *
     * @param e0 first element
     * @param w0 first element weight
     * @param e1 second element
     * @param w1 second element weight
     * @param e2 third element
     * @param w2 third element weight
     * @param e2 forth element
     * @param w2 forth element weight
     * @param <E> type
     * @return random element; null, if (w0+w1+w2+w3) == 0
     */
    public static <E> E selectRandom(E e0, int w0, E e1, int w1, E e2, int w2, E e3, int w3) {
        int size = w0 + w1 + w2 + w3;
        if (size > 0) {
            int index = ThreadLocalRandom.current().nextInt(size);
            if (index < w0) {
                return e0;
            } else if (index < w0 + w1) {
                return e1;
            } else if (index < w0 + w1 + w2) {
                return e2;
            } else {
                return e3;
            }
        }
        return null;
    }

    /**
     * Pick random element from the list.
     * NOTE: This method is not thread-safe.
     *
     * @param list source list
     * @param <E> type
     * @return random element; null, if list is empty
     */
    public static <E> E getRandomElement(List<E> list) {
        if (list != null) {
            int size = list.size();
            if (size > 0) {
                int index = ThreadLocalRandom.current().nextInt(size);
                return list.get(index);
            }
        }
        return null;
    }

    /**
     * Answers empty mix.
     *
     * @param <E> type
     * @return empty mix
     */
    @SuppressWarnings("unchecked")
    public static <E> Mix<E> emptyMix() {
        return (Mix<E>) EMPTY_MIX;
    }
    
    public static <E> Mix<E> getLazyMix(InstanceFactory<Mix<E>> factory, int futureTotalWeight) {
        if (futureTotalWeight == 0) {
            return emptyMix();
        }
        return new LazyMix<E>(factory, futureTotalWeight);
    }

    public static <E> Mix<E> getMix(final Random random, Collection<E> elements) {
        if (elements.isEmpty()) {
            return emptyMix();
        }
        E[] elems = elements.toArray((E[]) new Object[elements.size()]);
        if (elems.length == 1) {
            return new SingletonMix<E>(elems[0]);
        } else {
            return new ArrayUniformMix<E>(elems) {
                @Override
                public int nextInt(int max) {
                    return random.nextInt(max);
                }
            };
        }
    }


    public static <E> Mix<E> getMix(Collection<E> elements) {
        if (elements.isEmpty()) {
            return emptyMix();
        }
        E[] elems = elements.toArray((E[]) new Object[elements.size()]);
        if (elems.length == 1) {
            return new SingletonMix<E>(elems[0]);
        } else {
            return new ArrayUniformMix<E>(elems) {

                @Override
                public int nextInt(int max) {
                    return ThreadLocalRandom.current().nextInt(max);
                }
            };
        }
    }
    
    public static <E> Mix<E> getMix(Collection<E> elements, final int weight) {
        if (elements.isEmpty()) {
            return emptyMix();
        }
        E[] elems = elements.toArray((E[]) new Object[elements.size()]);
        if (elems.length == 1) {
            return new SingletonMix<E>(elems[0]) {
                @Override
                public int getMixWeight() {
                    return weight;
                }
            };
        } else {
            return new ArrayUniformMix<E>(elems) {

                @Override
                public int nextInt(int max) {
                    return ThreadLocalRandom.current().nextInt(max);
                }

                @Override
                public int getMixWeight() {
                    return super.getMixWeight() * weight;
                }
                
            };
        }
    }
    
    public static <E> Mix<E> getMix(MultiSet<E> set) {
        Map<Integer, List<E>> weightsMap = new HashMap<>();
        for (MultiSet.Entry<E> entry : set.entrySet()) {
            int weight = entry.getCount();
            assert weight > 0;
            List<E> group = weightsMap.get(weight);
            if (group == null) {
                group = new ArrayList<>();
                weightsMap.put(weight, group);
            }
            group.add(entry.getElement());
        }
        if (weightsMap.isEmpty()) {
            return CollectionUtils.emptyMix();
        }
        List<Integer> weights = new ArrayList<>(weightsMap.size());
        List<List<E>> elements = new ArrayList<>(weightsMap.size());
        for (Map.Entry<Integer, List<E>> entry : weightsMap.entrySet()) {
            weights.add(entry.getKey());
            elements.add(entry.getValue());
        }
        return new CardMix<E>(elements, weights);
    }

    public static Mix<Integer> getRangeMix(final Random random, final int min, final int max) {
        if (min > max) {
            throw new IllegalArgumentException("Min= " + min + "; Max=" + max);
        }
        return new Mix<Integer>() {

            @Override
            public boolean isEmpty() {
                return min >= max;
            }

            @Override
            public Integer next() {
                return min + random.nextInt(max - min);
            }

            @Override
            public int getMixWeight() {
                return max - min;
            }
        };
    }

    public static <E> Mix<E> getFixedMix(final E[] elements, final int[] weights) {
        if (elements.length != weights.length) {
            throw new IllegalArgumentException("elements.length!=weights.length");
        }
        if (elements.length == 0) {
            return emptyMix();
        } else if (elements.length == 1 && weights[0] > 0) {
            return new SingletonMix<E>(elements[0]);
        } else {
            return new FixedMix<E>(elements, weights) {

                @Override
                public int nextInt(int max) {
                    return ThreadLocalRandom.current().nextInt(max);
                }

            };
        }
    }

    public static <E> Mix<E> getFixedMix(final Random random, final E[] elements, final int[] weights) {
        if (elements.length != weights.length) {
            throw new IllegalArgumentException("elements.length!=weights.length");
        }
        if (elements.length == 0) {
            return emptyMix();
        } else if (elements.length == 1 && weights[0] > 0) {
            return new SingletonMix<E>(elements[0]);
        } else {
            return new FixedMix<E>(elements, weights) {

                @Override
                public int nextInt(int max) {
                    return random.nextInt(max);
                }

            };
        }
    }
    
    private static final Mix EMPTY_MIX = new EmptyMix<>();

}
