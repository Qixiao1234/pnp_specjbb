/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.inventory;

import org.spec.jbb.hq.entity.Product;

/**
 * An exception which represents an exception condition where a new
 * Product is being added to an Inventory, but the Inventory already
 * contains a Product with the same Product barcode.
 */
class ProductBarcodeAlreadyInInventory extends InventoryProductException {
    private static final long serialVersionUID = -3979376266908675897L;
    final private Product oldProduct;
    final private Product newProduct;

    /**
     * Constructor
     *
     * @param oldProduct - old Product which was in the Inventory
     * @param newProduct - new Product which has same barcode as old Product
     */
    ProductBarcodeAlreadyInInventory(Product oldProduct, Product newProduct) {
        this.oldProduct = oldProduct;
        this.newProduct = newProduct;
    }

    /**
     * Return a String representing this Exception
     */
    @Override
    public String toString() {
        return oldProduct + " was replaced by " + newProduct;
    }
}
