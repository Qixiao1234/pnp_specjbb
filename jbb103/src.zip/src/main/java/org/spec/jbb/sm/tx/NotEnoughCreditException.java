/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx;

import org.spec.jbb.core.tx.TransactionException;

public class NotEnoughCreditException extends TransactionException {
    private static final long serialVersionUID = 5865698832788356061L;

    public NotEnoughCreditException(String message) {
        super(message);
    }
}
