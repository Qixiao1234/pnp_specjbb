/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

import org.spec.jbb.infra.IterationLabel;
import org.spec.jbb.infra.IterationStatus;

public class RunStatusFrame implements Frame {

    public static final long serialVersionUID = 2L;

    private final long time;
    private final IterationStatus status;

    public RunStatusFrame(long time, IterationStatus status) {
        this.time = time;
        this.status = status;
    }

    public IterationStatus getStatus() {
        return status;
    }

    public long getTime() {
        return time;
    }
    
    @Override
    public Frame cleanForSubmission(CleanForSubmissionContext ctx) {
        if(status.getLabel() != IterationLabel.RT_CURVE) {
            return null;
        }
        return this;
    }

    @Override
    public String toString() {
        return "Run status: " + status.toString();
    }
}
