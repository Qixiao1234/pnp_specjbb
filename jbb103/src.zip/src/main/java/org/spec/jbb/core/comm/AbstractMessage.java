/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm;

import org.spec.jbb.core.comm.transport.TransportType;
import org.spec.jbb.core.tx.Transaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.of.OrderFulfillment;
import org.spec.jbb.sm.SM;
import org.spec.jbb.sp.SP;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.io.Serializable;

public abstract class AbstractMessage implements Message, Serializable {

    private static final long serialVersionUID = 7037182718836638879L;

    public static class JAXBAdapter extends XmlAdapter<AbstractMessage, Message> {

        @Override
        public Message unmarshal(AbstractMessage v) throws Exception {
            return v;
        }

        @Override
        public AbstractMessage marshal(Message v) throws Exception {
            return (AbstractMessage) v;
        }
    }

    @Override
    public boolean isDurable() {
        return false;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return 1;
    }

    @Override
    public TransportType getTransportHint() {
        return null; // use default
    }

    @Override
    public Transaction getTransaction(SM sm, TransactionContext ctx) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Transaction getTransaction(HQ hq, TransactionContext ctx) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Transaction getTransaction(SP sp, TransactionContext ctx) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Transaction getTransaction(OrderFulfillment of, TransactionContext ctx) {
        throw new UnsupportedOperationException();
    }

}
