/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx.response;

import org.spec.jbb.core.comm.AbstractResponse;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
public class CustomerResolveResponse extends AbstractResponse {

    private static final long serialVersionUID = -7107438492639076349L;
    @XmlElement
    private final String owningHq;

    private CustomerResolveResponse() {
        // JAXB
        this(null);
    }

    public CustomerResolveResponse(String owningHq) {
        this.owningHq = owningHq;
    }

    public String getOwningHQ() {
        return owningHq;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        CustomerResolveResponse that = (CustomerResolveResponse) o;

        if (owningHq != null ? !owningHq.equals(that.owningHq) : that.owningHq != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), owningHq);
    }

    @Override
    public String toString() {
        return "Customer belongs to " + owningHq;
    }

}
