/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.RectangleEdge;

import java.awt.Color;
import java.util.concurrent.TimeUnit;

public class JFreeChartArea implements ImageRender {

    @Override
    public JFreeChart render(String title, Timeline... timelines) {

        final XYSeriesCollection dataset = new XYSeriesCollection();

        for (Timeline timeline : timelines) {
            XYSeries series = new XYSeries(timeline.getName());
            for(DataPoint point : timeline.getAll()) {
                series.add(TimeUnit.NANOSECONDS.toMillis(point.getTime()), point.getValue(), false);
            }
            dataset.addSeries(series);
        }

        final JFreeChart chart = ChartFactory.createXYAreaChart(
            title,
            "Time, msec", timelines[0].getValueLabel(),
            dataset,
            PlotOrientation.VERTICAL,
            true,  // legend
            true,  // tool tips
            false  // URLs
        );

        chart.setBackgroundPaint(Color.white);
        chart.getLegend().setPosition(RectangleEdge.BOTTOM);
       
        final XYPlot plot = chart.getXYPlot();
        //plot.setOutlinePaint(Color.black);
        plot.setBackgroundPaint(Color.white);
        plot.setForegroundAlpha(0.65f);
        plot.setDomainGridlinePaint(Color.white);
        plot.setRangeGridlinePaint(Color.white);

        final ValueAxis domainAxis = plot.getDomainAxis();
        domainAxis.setTickMarkPaint(Color.black);
        domainAxis.setLowerMargin(0.0);
        domainAxis.setUpperMargin(0.0);

        final ValueAxis rangeAxis = plot.getRangeAxis();
        rangeAxis.setTickMarkPaint(Color.black);

        return chart;
    }
}
