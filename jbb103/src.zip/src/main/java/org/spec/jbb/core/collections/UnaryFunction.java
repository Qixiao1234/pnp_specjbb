/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

public interface UnaryFunction<T, E>  {

    public E apply(T value);

}
