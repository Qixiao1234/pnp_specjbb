/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections.queues;


import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class StripedConcurrentLinkedQueue<E> extends AbstractStripedQueue<E> {

    private static final long serialVersionUID = -1539665128371804906L;

    public StripedConcurrentLinkedQueue(int capacity) {
        super(capacity);
    }

    public StripedConcurrentLinkedQueue(int capacity, int stripes) {
        super(capacity, stripes);
    }

    @Override
    protected Queue<E> newQueue(int capacity) {
        return new ConcurrentLinkedQueue<>();
    }

}
