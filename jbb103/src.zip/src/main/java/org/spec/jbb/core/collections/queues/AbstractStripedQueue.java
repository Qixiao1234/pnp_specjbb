/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections.queues;


import org.spec.jbb.util.JbbProperties;

import java.io.Serializable;
import java.util.AbstractQueue;
import java.util.Collections;
import java.util.Iterator;
import java.util.Queue;

public abstract class AbstractStripedQueue<E> extends AbstractQueue<E> implements Serializable {

    private static final long serialVersionUID = -8494226024229970168L;
    private final int capacity;
    private final int stripes;

    protected final Queue<E>[] queues;

    public AbstractStripedQueue(int capacity) {
        this(capacity, JbbProperties.getInstance().getQueueStripeCount());
    }

    public AbstractStripedQueue(int capacity, int reqStripes) {

        // Find a power of 2 >= stripes
        int stripes = toNextPowerOfTwo(reqStripes);

        this.stripes = stripes;
        this.capacity = capacity;
        this.queues = new Queue[stripes];

        int perQueueCapacity = capacity / stripes;
        int remCapacity = capacity - perQueueCapacity * stripes;

        queues[0] = newQueue(Math.max(1, perQueueCapacity + remCapacity));
        for (int c = 1; c < stripes; c++) {
            queues[c] = newQueue(Math.max(1, perQueueCapacity));
        }
    }

    private int toNextPowerOfTwo(int v) {
        v = v - 1;
        v = v | (v >> 1);
        v = v | (v >> 2);
        v = v | (v >> 4);
        v = v | (v >> 8);
        v = v | (v >> 16);
        return v + 1;
    }

    private int getIndex() {
        /**
        * Returns a hash index for the current thread.  Uses a one-step
        * FNV-1a hash code (http://www.isthe.com/chongo/tech/comp/fnv/)
        * based on the current thread's Thread.getId().
        */
        long id = Thread.currentThread().getId();
        int hash = (((int)(id ^ (id >>> 32))) ^ 0x811c9dc5) * 0x01000193;
        return hash & (stripes - 1);
    }

    private int shift(int base, int shift) {
        // assume stripes is power of two
        return (base + shift) & (stripes - 1);
    }

    protected abstract Queue<E> newQueue(int capacity);

    @Override
    public int size() {
        int size = 0;
        int base = getIndex();
        for (int c = 0; c < stripes; c++) {
            size += queues[shift(base, c)].size();
        }
        return size;
    }

    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {

            int index = 0;

            Iterator<E> current = queues[0].iterator();

            @Override
            public boolean hasNext() {
                while(index < stripes && !current.hasNext()) {
                    current = queues[index++].iterator();
                }

                if (index >= stripes) {
                    current = Collections.<E>emptyList().iterator();
                }

                return current.hasNext();
            }

            @Override
            public E next() {
                hasNext();
                return current.next();
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    @Override
    public Object[] toArray() {
        int base = getIndex();

        Object[][] datas = new Object[stripes][];

        int size = 0;
        for (int c = 0; c < stripes; c++) {
            datas[c] = queues[shift(base, c)].toArray();
            size += datas[c].length;
        }

        Object[] result = new Object[size];

        int pos = 0;
        for (int c = 0; c < stripes; c++) {
            System.arraycopy(datas[c], 0, result, pos, datas[c].length);
            pos += datas[c].length;
        }

        return result;
    }


    @Override
    public boolean offer(E e) {
        int base = getIndex();
        for (int c = 0; c < stripes; c++) {
            if (queues[shift(base, c)].offer(e)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public E poll() {
        int base = getIndex();
        for (int c = 0; c < stripes; c++) {
            E result = queues[shift(base, c)].poll();
            if (result != null) {
                return result;
            }
        }
        return null;
    }

    @Override
    public E peek() {
        int base = getIndex();
        for (int c = 0; c < stripes; c++) {
            E result = queues[shift(base, c)].peek();
            if (result != null) {
                return result;
            }
        }
        return null;
    }
}
