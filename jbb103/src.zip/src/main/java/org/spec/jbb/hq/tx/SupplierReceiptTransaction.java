/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.hq.tx;

import org.spec.jbb.core.comm.Response;
import org.spec.jbb.core.tx.AbstractTransaction;
import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.core.tx.response.OkResponse;
import org.spec.jbb.hq.HQ;
import org.spec.jbb.hq.tx.request.SupplierReceiptMessage;
import org.spec.jbb.sp.Invoice;

public class SupplierReceiptTransaction extends AbstractTransaction {

    private final HQ hq;
    private final Invoice invoice;

    public SupplierReceiptTransaction(HQ hq, SupplierReceiptMessage msg, TransactionContext ctx) {
        super(ctx);
        this.hq = hq;
        this.invoice = msg.getInvoice();
    }

    @Override
    public Response execute() {
        hq.addSupplierInvoice(invoice);
        
        /*
         * Adjust the HQ's representation of the source supermarket's inventory.
         */
        hq.adjustSupermarketInventory(invoice);

        return new OkResponse();
    }

    @Override
    public String toString() {
        return "SupplierReceiptTx, invoice={" + invoice + "}";
    }

}
