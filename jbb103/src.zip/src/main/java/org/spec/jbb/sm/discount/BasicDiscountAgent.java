/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.discount;

import org.spec.jbb.core.collections.CollectionUtils;
import org.spec.jbb.core.generator.ProductGenerator;
import org.spec.jbb.util.JbbProperties;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * This is simple implementation of DiscountAgent based on random generator.
 * Products for issuing discount are chosen randomly between all available barcodes   
 */
public class BasicDiscountAgent extends AbstractDiscountAgent {

    private static final long serialVersionUID = 625084428198838103L;
    /**
     * Minimum number of products to provide discount to at once
     */
    private final int minQty;
    /**
     * Maximum number of products to provide discount to at once
     */
    private final int maxQty;
    /**
     * List of all available barcodes
     */
    private List<Long> barcodes;

    public BasicDiscountAgent() {
        super();
        minQty = JbbProperties.getInstance().getMinDiscountBasicQty();
        maxQty = JbbProperties.getInstance().getMaxDiscountBasicQty();
        barcodes = new ArrayList<>(new ProductGenerator().generateBarcodes());
    }

    @Override
    public List<Discount> createDiscountBatch() {
        int qty = ThreadLocalRandom.current().nextInt(minQty, maxQty);
        List<Discount> batch = new ArrayList<>(qty);
        for (int i = 0; i < qty; i++) {
            long barcode = CollectionUtils.getRandomElement(barcodes);
            // detect type of discount
            int percent = ThreadLocalRandom.current().nextInt(0, 5);
            batch.add(DiscountFactory.createDiscount(barcode, percent));
        }
        return batch;
    }

}
