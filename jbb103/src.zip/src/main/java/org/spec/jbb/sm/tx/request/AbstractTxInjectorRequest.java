/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.tx.request;

import org.spec.jbb.core.comm.AbstractRequest;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement
public abstract class AbstractTxInjectorRequest extends AbstractRequest {

    private static final long serialVersionUID = -5681539729185831102L;
    @XmlElement
    private final boolean isSaturate;

    protected AbstractTxInjectorRequest() {
        // JAXB
        this(false);
    }

    public AbstractTxInjectorRequest(boolean isSaturate) {
        super();
        this.isSaturate = isSaturate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        AbstractTxInjectorRequest that = (AbstractTxInjectorRequest) o;

        if (isSaturate != that.isSaturate) {
            return false;
        }
        
        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(isSaturate);
    }

    @Override
    public boolean isRequiresResponse() {
        return !isSaturate;
    }

    public String toString() {
        return "isSaturate = " + isSaturate;
    }

}
