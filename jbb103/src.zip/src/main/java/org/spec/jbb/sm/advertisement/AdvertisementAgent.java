/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.sm.advertisement;

import org.spec.jbb.core.tx.TransactionContext;
import org.spec.jbb.sm.SM;


/**
 * This is advertisement agent.
 * It is responsible for preparation data required for issuing advertisement,
 * keeping the list of issued advertisements and purging them. 
 *
 */
public interface AdvertisementAgent {
    /**
     * Prepare the advertisement batch.
     * 
     * @param ctx transaction context to run in
     * @param sm SM this advertisement for
     * @return advertisement ready to be issued
     */
    public IssuedAdvertisement createAdvertisementBatch(TransactionContext ctx, SM sm);
    /**
     * Add issued advertisement to storage
     *
     * @param ctx transaction context to run in
     * @param adv issued advertisement
     */
    public void addIssuedAdvertisement(TransactionContext ctx, IssuedAdvertisement adv);
    /**
     * Returns the oldest advertisement and remove it from storage
     *
     * @param ctx transaction context to run in
     * @return oldest advertisement or null is there is no issued advertisements
     */
    public IssuedAdvertisement pollIssuedAdvertisement(TransactionContext ctx);
    
    /**
     * Reserve the slot for storing issued advertisement.
     *
     * @param ctx transaction context to run in
     * @return true if slot is available
     */
    public boolean reserveSlot(TransactionContext ctx);
}
