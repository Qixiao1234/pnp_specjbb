/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.collections;

public interface Mix<E> {

    /**
     * Answers whether this mix is empty.
     *
     * @return true, if mix is empty.
     */
    public boolean isEmpty();

    /**
     * Answers random value from the mix.
     *
     * @return random element; null if mix is empty
     */
    public E next();

    /**
     * Answers sum of all weights in mix.
     *
     * @return sum of all weights
     */
    public int getMixWeight();

}
