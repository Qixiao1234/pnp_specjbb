/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.probe;

import org.spec.jbb.core.ResetMode;

import java.util.Collections;
import java.util.Map;

public class EmptyProbe implements Probe {

    @Override
    public void inc(String label) {
        // do nothing
    }

    @Override
    public void add(String label, long inc) {
        // do nothing
    }

    @Override
    public void countType(String label, Object o) {
        // do nothing
    }

    @Override
    public void countType(String label, Object o, long inc) {
        // do nothing
    }

    @Override
    public void sample(String label, Object object) {
        // do nothing
    }

    @Override
    public boolean shouldGoInsane() {
        return false;
    }

    @Override
    public Probe getChild(String prefix) {
        return new EmptyProbe();
    }

    @Override
    public void reset(ResetMode mode) {
        // do nothing
    }

    @Override
    public Map<String, Object> get() {
        return Collections.emptyMap();
    }

}
