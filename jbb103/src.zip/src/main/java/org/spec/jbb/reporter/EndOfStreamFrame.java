/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.reporter;

public class EndOfStreamFrame implements Frame {
    private static final long serialVersionUID = 1L;

    @Override
    public Frame cleanForSubmission(CleanForSubmissionContext ctx) {
        return this;
    }

    @Override
    public String toString() {
        return "End Of Stream";
    }
}
