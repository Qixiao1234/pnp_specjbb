/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.mapreduce;

import org.spec.jbb.core.sequencer.Sequencer;
import org.spec.jbb.core.sequencer.SequencerFactory;
import org.spec.jbb.util.JbbProperties;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.ForkJoinWorkerThread;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import org.spec.jbb.core.threadpools.ThreadUtils;

public class MapReducer {

    private volatile ForkJoinPool pool;

    public MapReducer() {
        setParallelism(JbbProperties.getInstance().getMapReducerPoolSize());
    }
    
    public void setParallelism(int parallelism) {
        if(pool != null) {
            if(pool.getParallelism() == parallelism) {
                return;
            }
            ThreadUtils.terminatePool(pool);
        }
        pool = new ForkJoinPool(parallelism, new ForkJoinPool.ForkJoinWorkerThreadFactory() {
            private Sequencer<Long> id = SequencerFactory.getNonSkippingSequencer();
            @Override
            public ForkJoinWorkerThread newThread(ForkJoinPool pool) {
                ForkJoinWorkerThread t = ForkJoinPool.defaultForkJoinWorkerThreadFactory.newThread(pool);
                t.setName("MapReducer." + id.next());
                t.setDaemon(true);
                return t;
            }
        }, null, false);
    }

    public <T, E> Map<T, E> map(Collection<T> values, final Actor<T, E> actor) throws ExecutionException {
        List<T> items = // We need items in List to index into while subdividing
            (values instanceof List)? (List<T>)values : new ArrayList<T>(values);
        int size = items.size();
        int last = size - 1;
        ConcurrentHashMap<T, E> map = // avoid resizing map
            new ConcurrentHashMap<>(size + (size >>> 1));
        MapReduceTask<T, E> task = last <= 0 ? null :
            new MapReduceTask<T, E>(items, map, actor, null, 0, last);
        if (task != null)
            pool.submit(task);
        if (last >= 0) // perform one leaf action while waiting for others
            leafAction(items.get(last), actor, map);
        if (task != null)
            task.join();
        return map;
    }

    static <T, E> void leafAction(T t, Actor<T, E> actor, Map<T, E> map) {
        try {
            E e = actor.act(t);
            if (e != null)
                map.put(t, e);
        } catch(Exception ex) { // must tunnel checked exception
            throw new RuntimeException(ex);
        }
    }

    /**
     * MapReduce task.
     * Subdivides into single calls.
     * See ForkJoinBatchTask for explanation
     */
    final static class MapReduceTask<T, E> extends ForkJoinTask<Void> {
        private static final long serialVersionUID = -5826550721538531762L;
        final List<T> items;
        final ConcurrentHashMap<T, E> map;
        final Actor<T, E> actor;
        final int lo;
        final int hi;
        MapReduceTask<T, E> parent;
        volatile int joinCount;
        static final AtomicIntegerFieldUpdater<MapReduceTask> joinCountUpdater =
            AtomicIntegerFieldUpdater.newUpdater(MapReduceTask.class, "joinCount");
        public final Void getRawResult() { return null; }
        public final void setRawResult(Void x) { } 

        MapReduceTask(List<T> items, ConcurrentHashMap<T, E> map,
                      Actor<T, E> actor, MapReduceTask<T, E> parent,
                      int lo, int hi) {
            this.items = items;
            this.map = map;
            this.actor = actor;
            this.parent = parent;
            this.lo = lo;
            this.hi = hi;
        }

        public final boolean exec() {
            MapReduceTask<T, E> t = this;
            int l = this.lo;
            int h = this.hi;
            int mid;
            while ((mid = (l + h) >>> 1) != l) {
                new MapReduceTask<T, E>(items, map, actor, t, mid, h).fork();
                t = new MapReduceTask<T, E>(items, map, actor, t, l, mid);
                h = mid;
            }
            MapReduceTask<T, E> p;
            if (l < h && ((p = t.parent) == null || !p.isDone())) {
                try {
                    leafAction(items.get(l), actor, map);
                } catch (Throwable ex) {
                    upwardFail(t, ex);
                    return true;
                }
            }
            upwardJoin(t);
            return false;
        }

        static <T, E> void upwardJoin(MapReduceTask<T, E> t) {
            while (t != null) {
                MapReduceTask<T, E> p = t.parent;
                if (p == null) { // t is root task
                    t.complete(null);
                    break;
                }
                else if (p.joinCount == 0) {
                    if (joinCountUpdater.compareAndSet(p, 0, 1)) {
                        t.parent = null;
                        break;
                    }
                }
                else {
                    t.parent = null;
                    t = p;
                }
            }
        }
        
        static <T, E> void upwardFail(MapReduceTask<T, E> t,
                                              Throwable ex) {
            while (t != null) {
                t.completeExceptionally(ex);
                t = t.parent;
            }
        }
    }
}
