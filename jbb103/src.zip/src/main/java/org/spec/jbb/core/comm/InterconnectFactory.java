/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm;

import org.spec.jbb.util.JbbProperties;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class InterconnectFactory {

    public static final List<Interconnect> ICs = Collections.synchronizedList(new ArrayList<Interconnect>());

    public static Interconnect getMaster() {
        String hostname = JbbProperties.getInstance().getControllerHostname();
        int port = JbbProperties.getInstance().getControllerPort();

        Interconnect interconnect = new Interconnect(hostname, port, true);
        ICs.add(interconnect);

        return interconnect;
    }

    public static Interconnect getSlave() {
        String hostname = JbbProperties.getInstance().getControllerHostname();
        int port = JbbProperties.getInstance().getControllerPort();

        Interconnect interconnect = new Interconnect(hostname, port, false);
        ICs.add(interconnect);

        return interconnect;
    }

    public static void shutdownAll() {
        for (Interconnect ic : ICs) {
            ic.shutdown();
        }
        ICs.clear();
    }

}
