/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity.grizzlyhttp;

import org.glassfish.grizzly.http.server.HttpHandler;
import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.grizzly.http.server.Request;
import org.glassfish.grizzly.http.server.Response;
import org.spec.jbb.core.comm.Packet;
import org.spec.jbb.core.comm.connectivity.HttpConstants;
import org.spec.jbb.core.comm.connectivity.Server;
import org.spec.jbb.core.comm.connectivity.ServerCallback;
import org.spec.jbb.core.comm.transport.Data;
import org.spec.jbb.core.comm.transport.TransportType;
import org.spec.jbb.util.StreamUtil;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.util.Random;

/**
 * EXPERIMENTAL Grizzly-based HTTP server
 *
 * This implementation is provided to test internal connectivity API.
 * Performance and correctness of this implementation is not guaranteed.
 */
public class GrizzlyHttpServer implements Server {

    private HttpServer webServer;
    private int port;
    private final ServerCallback callback;

    public GrizzlyHttpServer(int port, ServerCallback callback) {
        this.port = port;
        this.callback = callback;
    }

    @Override
    public void open() throws IOException {
        boolean isProbing = (port == 0);
        Random random = new Random();

        int tryCount = 10;
        while (true) {
            try {
                if (isProbing) {
                    port = random.nextInt(60000) + 1024;
                }
                webServer = HttpServer.createSimpleServer(".", port);
                webServer.start();

                webServer.getServerConfiguration().addHttpHandler(new ProtocolHttpHandler(), HttpConstants.CONTEXT_DATA);
                webServer.getServerConfiguration().addHttpHandler(new ResolveIPHttpHandler(), HttpConstants.CONTEXT_RESOLVEIP);

                break;
            } catch (IOException e) {
                tryCount--;
                if (tryCount < 0) {
                    throw new IOException("Try count depleted", e);
                }
            }
        }
    }

    @Override
    public void close() {
        webServer.stop();
    }

    @Override
    public int getLocalPort() {
        return port;
    }

    private class ProtocolHttpHandler extends HttpHandler {
        @Override
        public void service(Request request, Response response) throws Exception {
            String from = request.getHeader(HttpConstants.HEADER_FROM);
            String to = request.getHeader(HttpConstants.HEADER_TO);
            TransportType transportType = TransportType.valueOf(request.getHeader(HttpConstants.HEADER_TRANSPORTTYPE));
            boolean shouldBeAnswered = Boolean.valueOf( request.getHeader(HttpConstants.HEADER_SHOULDBEANSWERED) );
            int tier = Integer.valueOf( request.getHeader(HttpConstants.HEADER_TIER) );

            InputStream stream = request.getInputStream();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            StreamUtil.copy(stream, baos);

            Packet packet = callback.handle(new Packet(from, to, transportType, Data.wrap(baos), shouldBeAnswered, tier));

            response.setHeader(HttpConstants.HEADER_FROM, packet.getFrom());
            response.setHeader(HttpConstants.HEADER_TO, packet.getTo());
            response.setHeader(HttpConstants.HEADER_TRANSPORTTYPE, packet.getTransportType().toString());
            response.setHeader(HttpConstants.HEADER_SHOULDBEANSWERED, Boolean.toString(packet.shouldBeAnswered()));
            response.setHeader(HttpConstants.HEADER_TIER, Integer.toString(packet.getCurrentTier()));

            OutputStream outputStream = response.getOutputStream();
            StreamUtil.copy(packet.getData().getStream(), outputStream);
        }
    }

    private static class ResolveIPHttpHandler extends HttpHandler {
        @Override
        public void service(Request request, Response response) throws Exception {
            InetAddress byName = InetAddress.getByName(request.getRemoteAddr());
            response.getOutputStream().write(byName.getAddress());
        }
    }
}
