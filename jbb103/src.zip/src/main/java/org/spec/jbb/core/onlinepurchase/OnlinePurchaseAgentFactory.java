/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.onlinepurchase;

public class OnlinePurchaseAgentFactory {

    public static OnlinePurchaseAgent getOnlinePurchaseAgent() {
        // for now just return random agent
        return new RandomOnlinePurchaseAgent();
    }
}
