/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity.grizzlynio;

import org.glassfish.grizzly.Connection;

import org.spec.jbb.core.comm.connectivity.grizzlynio.proto.ProtocolDataUnit;
import org.spec.jbb.core.objectpool.Poolable;
import org.spec.jbb.core.threadpools.Adapters;
import org.spec.jbb.core.threadpools.SettableFuture;

import java.util.concurrent.Future;

public class PoolableConnection implements Poolable {
    private final Connection conn;
    private final FutureHolder futureHolder;

    public PoolableConnection(Connection conn, FutureHolder futureHolder) {
        this.conn = conn;
        this.futureHolder = futureHolder;
    }

    public Connection getConn() {
        return conn;
    }

    @Override
    public void dispose() {
        conn.close();
    }

    Future<ProtocolDataUnit> prepare() {
        final SettableFuture<ProtocolDataUnit> resultMessageFuture = new SettableFuture<>();
        final Future<ProtocolDataUnit> adaptedFuture = Adapters.adapt(resultMessageFuture);
        futureHolder.resetFuture(resultMessageFuture);
        
        return adaptedFuture;
    }
}
