/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.connectivity.grizzlynio;

import org.glassfish.grizzly.Connection;
import org.glassfish.grizzly.SocketConnectorHandler;
import org.glassfish.grizzly.filterchain.FilterChainBuilder;
import org.glassfish.grizzly.filterchain.TransportFilter;
import org.glassfish.grizzly.nio.transport.TCPNIOConnectorHandler;
import org.spec.jbb.core.Measurable;
import org.spec.jbb.core.comm.connectivity.grizzlynio.GrizzlyNioClient.CustomClientFilter;
import org.spec.jbb.core.comm.connectivity.grizzlynio.proto.ProtocolDataUnitFilter;
import org.spec.jbb.core.objectpool.ObjectFactory;
import org.spec.jbb.core.objectpool.PoolException;
import org.spec.jbb.core.probe.Probe;
import org.spec.jbb.util.JbbProperties;

import java.io.IOException;
import java.nio.channels.ClosedByInterruptException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;


public class ConnectionFactory implements ObjectFactory<Destination, PoolableConnection>, Measurable {

    private final GrizzlyTransport wrapper;
    private final long connectTimeout;

    public ConnectionFactory() {
        connectTimeout = JbbProperties.getInstance().getConnectTimeout();

        wrapper = new GrizzlyTransport();

        try {
            wrapper.start();
        } catch (IOException e) {
            throw new IllegalStateException("Unexpected exception", e);
        }
    }

    @Override
    public PoolableConnection get(Destination key) throws PoolException, InterruptedException {
        try {
            final CustomClientFilter customClientFilter = new CustomClientFilter();
            
            FilterChainBuilder builder = FilterChainBuilder.stateless();
            builder.add(new TransportFilter());
            builder.add(new ProtocolDataUnitFilter());
            builder.add(customClientFilter);
            
            final SocketConnectorHandler connectorHandler =
                    TCPNIOConnectorHandler.builder(wrapper.getTransport())
                    .processor(builder.build())
                    .build();

            Future<Connection> future = connectorHandler.connect(key.getHost(), key.getPort());
            Connection connection = future.get(connectTimeout, TimeUnit.MILLISECONDS);
            return new PoolableConnection(connection, customClientFilter);
        } catch (ExecutionException e) {
            // :(
            if (e.getCause() instanceof ClosedByInterruptException) {
                InterruptedException newEx = new InterruptedException();
                newEx.addSuppressed(e.getCause());
                throw newEx;
            } else {
                throw new PoolException("Exception while connecting to " + key, e);
            }
        } catch (IOException | TimeoutException e) {
            throw new PoolException(e);
        }
    }

    @Override
    public void shutdown() {
        wrapper.shutdown();
    }

    @Override
    public void instrument(final Probe probe) {
        wrapper.instrument(probe);
    }

    @Override
    public void sample() {
        wrapper.sample();
    }
}
