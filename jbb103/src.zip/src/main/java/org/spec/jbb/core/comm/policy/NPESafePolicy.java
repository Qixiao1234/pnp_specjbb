/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.comm.policy;

import org.spec.jbb.core.comm.transport.TransportType;

public class NPESafePolicy implements TransportSelectionPolicy {

    private final TransportSelectionPolicy policy;

    public NPESafePolicy(TransportSelectionPolicy policy) {
        this.policy = policy;
    }

    @Override
    public TransportType get(String fromName, String toName, boolean spanningMultipleICs) {
        if (fromName == null) {
            throw new NullPointerException("fromName is null");
        }

        if (toName == null) {
            throw new NullPointerException("toname is null");
        }

        return policy.get(fromName, toName, spanningMultipleICs);
    }
}
