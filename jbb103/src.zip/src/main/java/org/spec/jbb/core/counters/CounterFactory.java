/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.counters;

import org.spec.jbb.util.JbbProperties;

public class CounterFactory {

    private CounterFactory() {
        // prevent instantiation
    }

    public static Counter getCounter() {
        CounterType type = JbbProperties.getInstance().getCounterType();
        switch (type) {
            case THREAD_LOCAL:
                return new ThreadLocalCounter();
            case THREAD_HASHED:
                return new ThreadHashedCounter();
            case THREAD_HASHED_PADDED:
                return new ThreadHashedPaddedCounter();
            case ATOMIC:
                return new AtomicCounter();
            default:
                throw new IllegalStateException("Unknown counter type: " + type);
        }
    }

}
