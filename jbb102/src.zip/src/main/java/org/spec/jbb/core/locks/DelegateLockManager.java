/*
 * Copyright (c) 2012 Standard Performance Evaluation Corporation (SPEC).
 * All rights reserved.
 */

package org.spec.jbb.core.locks;

import org.spec.jbb.core.probe.Probe;

import java.lang.ref.ReferenceQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Lock manager provides thread-safe and garbage-collected mapping from key to Lock.
 * @param <K> key to map from
 */
public class DelegateLockManager<K> implements LockManager<K> {

    private final ConcurrentMap<K, Entry<K, Lock>> locks;

    private final ReferenceQueue<Lock> queue;

    private EntryFactory<K, Lock> entryFactory;

    public DelegateLockManager(LockRefType type) {
        locks = new ConcurrentHashMap<>();
        queue = new ReferenceQueue<>();
        entryFactory = new EntryFactory<>(type);
    }

    @Override
    public Lock getLock(K key) {
        /*
         * Design consideration:
         *  We are draining reference queue when lock is not found.
         *  This both optimizes for frequent case, when keys are never evicted,
         *  and amortizes the cost of draining among callers.
         */
        Entry<K, Lock> entry;
        Lock adapter;

        entry = locks.get(key);
        if (entry != null) {
            adapter = entry.get();
            if (adapter != null) {
                return adapter;
            }
        }

        /*
        * Slow-path: we're playing races with GC, so spin-loop
        */
        do {
            drain();

            Lock newAdapter = new ReentrantLock();
            Entry<K, Lock> newEntry = entryFactory.newEntry(key, newAdapter, queue);
            Entry<K, Lock> extEntry = locks.putIfAbsent(key, newEntry);
            entry = (extEntry != null) ? extEntry : newEntry;

            adapter = entry.get();
        } while (adapter == null);

        return adapter;
    }

    /**
     * Drain the reference queue, thus removing the items from backing map.
     */
    private void drain() {
        Entry<K, Lock> staleEntry;

        // unchecked cast here: we only register correct types on queue.
        // strong references will always return null, hence no checkcast exception.
        while((staleEntry = (Entry<K, Lock>) queue.poll()) != null) {
            locks.remove(staleEntry.getKey());
        }
    }

    @Override
    public void instrument(Probe probe) {
        // do nothing
    }

    @Override
    public void sample() {
        // do nothing
    }

}
